export interface NigoData {
    checkerEntry: string | string[];
    dataStatus: boolean;
    field: string;
    id: number;
    makerEntry: string | string[];
}

export function initializeNigoData(): NigoData {
    return {
        "checkerEntry": "",
        "dataStatus": true,
        "field": "",
        "id": 0,
        "makerEntry": "",
    };
}
