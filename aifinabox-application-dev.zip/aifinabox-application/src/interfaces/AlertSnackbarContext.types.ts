import { FXAlertSnackbarProps } from "../components/FXAlertSnackbar/FXAlertSnackbarProps.types";

export interface AlertSnackbarContext {
    description: string;
    open: boolean;
    severity: FXAlertSnackbarProps["severity"];
    title: string;
}

export function initialAlertSnackbarContext(): AlertSnackbarContext {
    return (
        {
            "description": "",
            "open": false,
            "severity": "info",
            "title": "",
        }
    );
}
