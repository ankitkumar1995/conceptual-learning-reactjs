export interface FieldValidation {
    helperText: string;
    isError: boolean;
    isVerified: boolean;
    isWarning: boolean;
}

export function initializeFieldValidation(): FieldValidation {
    return (
        {
            "helperText": "",
            "isError": false,
            "isVerified": false,
            "isWarning": false,
        }
    );
}

export function initializeVerifiedFieldValidation(): FieldValidation {
    return (
        {
            "helperText": "",
            "isError": false,
            "isVerified": true,
            "isWarning": false,
        }
    );
}
