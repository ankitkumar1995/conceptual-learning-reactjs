export interface MenuItem {
    value: string;
    label: string;
}

export function initializeMenuItem(): MenuItem {
    return {
        "label": "",
        "value": "",
    };
}
