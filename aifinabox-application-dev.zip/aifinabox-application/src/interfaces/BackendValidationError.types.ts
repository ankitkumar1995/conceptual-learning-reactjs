export interface BackendValidationError {
    error: string;
    index: number;
    name: string;
}
