interface DrawerItemChild {
    id: string;
    route: string;
    title: string;
    type: "item" | "step";
}

export interface DrawerItem {
    children?: DrawerItemChild[];
    id: string;
    normalStateIcon: React.ReactNode;
    route: string;
    selectedStateIcon: React.ReactNode;
    title: string;
    type: "group" | "stepper" | "normal";
}
