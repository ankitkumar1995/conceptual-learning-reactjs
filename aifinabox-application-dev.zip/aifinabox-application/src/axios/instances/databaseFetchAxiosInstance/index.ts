import axios from "axios";

const databaseFetchAxiosInstance = axios.create({
    "baseURL": import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT,
    "headers": {
        "Content-Type": "application/json",
        "authorizationToken": import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_TOKEN,
    },
    "method": "get",
});

export default databaseFetchAxiosInstance;
