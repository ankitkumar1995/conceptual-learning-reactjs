import axios from "axios";

const masterAxiosInstance = axios.create({
    "baseURL": import.meta.env.VITE_MASTER_API_GATEWAY_ROOT,
    "headers": {
        "Content-Type": "application/json",
        "authorizationToken": import.meta.env.VITE_MASTER_API_GATEWAY_TOKEN,
    },
    "maxBodyLength": Infinity,
});

export default masterAxiosInstance;
