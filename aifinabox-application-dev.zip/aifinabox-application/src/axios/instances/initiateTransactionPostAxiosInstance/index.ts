import axios from "axios";
import encrypt from "../../helpers/encrypt";

const initiateTransactionPostAxiosInstance = axios.create({
    "baseURL": import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2,
    "headers": {
        "Content-Type": "application/json",
        "authorizationToken": import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_TOKEN,
    },
    "method": "post",
    "transformRequest": [function (data) {
        const dataJsonString = JSON.stringify(data);
        console.log("DECRYTTTTT", dataJsonString);
        const encryptionObject = encrypt(dataJsonString);
        const encryptionObjectJsonString = JSON.stringify(encryptionObject);

        return encryptionObjectJsonString;
    }],
});

export default initiateTransactionPostAxiosInstance;
