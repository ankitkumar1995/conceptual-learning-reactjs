import axios from "axios";

const authAxiosInstance = axios.create({
    "baseURL": import.meta.env.VITE_SAAS_AUTH_API_GATEWAT_ROOT,
    "headers": {
        "Content-Type": "application/json",
    },
    "method": "post",
});

export default authAxiosInstance;
