import forge from "node-forge";
import rsaEncryptionPublickKey from "../../keys/rsaEncryptionPublickKey";

interface EncryptionObject {
    encryptedMessageInHex: string;
    safeIv: string;
    safeKey: string;
}

function rsaEncrypt(message: string): string {
    const messageBuffer = forge.util.encodeUtf8(message);
    const encryptedMessageBuffer = forge.pki
        .publicKeyFromPem(rsaEncryptionPublickKey)
        .encrypt(messageBuffer, "RSA-OAEP");
    const encryptedMessage = forge.util.encode64(encryptedMessageBuffer);

    return encryptedMessage;
};

function encrypt(message: string): EncryptionObject {
    const key = forge.random.getBytesSync(32);
    const iv = forge.random.getBytesSync(32);

    const safeKey = rsaEncrypt(key);
    const safeIv = rsaEncrypt(iv);

    const cipher = forge.cipher.createCipher("AES-CBC", key);

    cipher.start({ iv });
    cipher.update(forge.util.createBuffer(message));
    cipher.finish();

    return {
        "encryptedMessageInHex": cipher.output.toHex(),
        "safeIv": safeIv,
        "safeKey": safeKey,
    };
}

export default encrypt;
