const UpdateIcon = () => {
    return (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <mask id="mask0_7483_73560" style={{ "maskType": "luminance" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                <path d="M0 0H20V20H0V0Z" fill="white"/>
            </mask>
            <g mask="url(#mask0_7483_73560)">
                <path d="M19.2188 19.2188H10" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M13.0781 16.1484H19.2239" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M19.2214 13.0703H16.1484" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14.6094 0.78125L19.2188 5.39062L5.39062 19.2188H0.78125V14.6094L14.6094 0.78125Z" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </g>
            <mask id="mask1_7483_73560" style={{ "maskType": "luminance" }} maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="20">
                <path d="M0 0H20V20H0V0Z" fill="white"/>
            </mask>
            <g mask="url(#mask1_7483_73560)">
                <path d="M19.2188 19.2188H10" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M13.0781 16.1484H19.2239" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M19.2214 13.0703H16.1484" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14.6094 0.78125L19.2188 5.39062L5.39062 19.2188H0.78125V14.6094L14.6094 0.78125Z" stroke="#201C43" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </g>
        </svg>  
    );
};

export default UpdateIcon;
