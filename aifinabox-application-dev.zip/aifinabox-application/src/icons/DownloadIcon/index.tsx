const DownloadIcon = () => {
    return (

        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3.82422 8.15918L7.50098 11.8359L11.1777 8.15918" stroke="black" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square"/>
            <mask id="mask0_3129_18798" maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="15">
                <path d="M0 0H15V15H0V0Z" fill="white"/>
            </mask>
            <g mask="url(#mask0_3129_18798)">
                <path d="M7.5 11.3086V0.585937" stroke="black" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square" stroke-linejoin="round"/>
                <path d="M0 14.4141H15" stroke="black" stroke-width="2" stroke-miterlimit="10"/>
            </g>
        </svg>
    );
};

export default DownloadIcon;

{/* <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M3.82422 8.15918L7.50098 11.8359L11.1777 8.15918" stroke="black" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square"/>
        <mask id="mask0_3129_18798" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="0" width="15" height="15">
        <path d="M0 0H15V15H0V0Z" fill="white"/>
        </mask>
        <g mask="url(#mask0_3129_18798)">
        <path d="M7.5 11.3086V0.585937" stroke="black" stroke-width="2" stroke-miterlimit="10" stroke-linecap="square" stroke-linejoin="round"/>
        <path d="M0 14.4141H15" stroke="black" stroke-width="2" stroke-miterlimit="10"/>
        </g>
        </svg> */}
