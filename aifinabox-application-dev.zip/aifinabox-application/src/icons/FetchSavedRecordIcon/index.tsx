const FetchSavedRecordIcon = () => {
    return (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19.2188 19.2188H10" stroke="#201C43" strokeWidth="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M13.0781 16.1484H19.2239" stroke="#201C43" strokeWidth="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M19.2214 13.0703H16.1484" stroke="#201C43" strokeWidth="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14.6094 0.78125L19.2188 5.39062L5.39062 19.2188H0.78125V14.6094L14.6094 0.78125Z" stroke="#201C43" strokeWidth="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    );
};

export default FetchSavedRecordIcon;
