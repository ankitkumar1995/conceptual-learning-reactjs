import { MenuItem } from "./../../interfaces/MenuItem.types";

export const USER_ROLE_MENU_ITEMS: MenuItem[] =[
    {
        "label": "Maker",
        "value": "maker",
    },
    {
        "label": "Checker",
        "value": "checker",
    },
    {
        "label": "Auditor",
        "value": "audit",
    },
    {
        "label": "Admin",
        "value": "admin",
    },
];

export const INVESTOR_ONBOARDING_DOC_DETAILS_OPTIONS: MenuItem[] = [
    {
        "label": "Yes",
        "value": "Yes",
    },
    {
        "label": "No",
        "value": "No",
    },
    {
        "label": "NA",
        "value": "NA",
    },
];

export const RESIDENT_IND_HOLDER_TAX_STATUS: MenuItem[] = [
    {
        "label": "Resident Individual",
        "value": "Resident Individual",
    },
    {
        "label": "Minor - Resident Individual",
        "value": "Minor - Resident Individual",
    },
];

export const NON_RESIDENT_IND_HOLDER_TAX_STATUS: MenuItem[] = [
    {
        "label": "Non Resident Individual - NRE",
        "value": "Non Resident Individual - NRE",
    },
    {
        "label": "Non Resident Individual - NRO",
        "value": "Non Resident Individual - NRO",
    },
    {
        "label": "Minor - Non Resident Individual - NRE",
        "value": "Minor - Non Resident Individual - NRE",
    },
    {
        "label": "Minor - Non Resident Individual - NRO",
        "value": "Minor - Non Resident Individual - NRO",
    },
];

export const FOREIGN_NATIONAL_IND_HOLDER_TAX_STATUS: MenuItem[] = [
    {
        "label": "Foreign National Individual",
        "value": "Foreign National Individual",
    },
    {
        "label": "Foreign National Minor",
        "value": "Foreign National Minor",
    },
    {
        "label": "Person of Indian Origin",
        "value": "Person of Indian Origin",
    },
    {
        "label": "Overseas Citizen of India",
        "value": "Overseas Citizen of India",
    },
    {
        "label": "Qualified Foreign Investor",
        "value": "Qualified Foreign Investor",
    },
];

export const CURRENCY_MENU_ITEMS: MenuItem[] = [
    {
        "label": "INR",
        "value": "INR"
    },
    {
        "label": "USD",
        "value": "USD"
    },
    {
        "label": "AUD",
        "value": "AUD"
    },
    {
        "label": "SAR",
        "value": "SAR"
    },
    {
        "label": "GBP",
        "value": "GBP"
    },
];
