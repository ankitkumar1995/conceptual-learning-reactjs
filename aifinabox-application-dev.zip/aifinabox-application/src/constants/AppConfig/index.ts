export const APPLICATION_ID = "2d2fb7cb-faa5-4205-9c5b-84cece8aebb0";
export const APPLICATION_CODE = "101";
export const APPLICATION_NAME = "aifSaas";
export const AUTHENTICATION_CHALLENGE_NAME = "CUSTOM_CHALLENGE";
export const AUTHENTICATION_FLOW_TYPE = "CUSTOM_AUTH";
export const AUTH_DATA_KEY = "authData";
export const CHALLENGE_NAME_POST_OTP_MISMATCH = "CUSTOM_CHALLENGE";
