import { FieldValidation } from "../../../../interfaces/FieldValidation.types";
import { ReactNode } from "react";

export type AcceptedFormat = 
        ".pdf" |
        ".tiff" |
        ".tif"

export interface DocumentUploadProps {
        accept?: AcceptedFormat[];
        assetType?: string;
        disabled?: boolean;
        documentType?: string;
        error?: boolean;
        helperText?: ReactNode;
        identifier?: string;
        onFieldErrorChange?: (error: string) => void;
        onFileUpload: (fileDetails: FileList) => void;
        onRemoveFile?: () => void;
        onS3PresignedUrlFetch?: (format: string, s3PresignedUrl: string, s3Key: string) => void;
        onValueChange?: (result: string) => void;
        s3CustomFileName?: string;
}
