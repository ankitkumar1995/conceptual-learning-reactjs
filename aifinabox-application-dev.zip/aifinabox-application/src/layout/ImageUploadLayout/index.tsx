// import {
//     Box,
//     Grid,
//     Paper
// } from "@mui/material";

// import DocumentUpload from "./components/DocumentUpload";
// import FXDocumentViewer from "../../components/FXDocumentViewer";
// import { Outlet } from "react-router-dom";
// import { RootState } from "../../redux/store";
// import imageUploadDisptachActionsProvider from "../../redux/ImageUpload/dispatchActionsProvider";
// import { useSelector } from "react-redux";

// const ImageUploadLayout = () => {
//     const imageUploadFormState = useSelector(
//         (state: RootState) => 
//             state
//                 .imageUploadState
//     ); 

//     const { 
//         applicationFormFile, 
//         transactionNumber,
//         transactionType, 
//     } =  imageUploadFormState;

//     const { 
//         setApplicationFormFile,
//         setApplicationFormFileFormat,
//         setApplicationFormFileS3Key,
//         setApplicationFormFileS3SignedURL,
//         setApplicationFormFileSize,
//         setMimeType
//     } = imageUploadDisptachActionsProvider();
    

//     return (
//         <Box width="100%" mt={3} mb={3}>
//             <Grid container spacing={0}>
//                 <Grid item xs={6.2}>
//                     <Box width="95%">
//                         <Paper
//                             elevation={0}
//                             sx={{
//                                 "backgroundColor": "#FFFFFF",
//                                 "borderRadius": "15px",
//                                 "boxShadow": "0px 4px 24px 0px rgba(0, 0, 0, 0.10)",
//                                 "height": "740px",
//                                 "padding": "10px"
//                             }}
//                         >
//                             {
//                                 (applicationFormFile === null) 
//                                     ?
//                                     <DocumentUpload
//                                         identifier={`TRANSACTION_NUMBER_${transactionNumber}`}
//                                         assetType="Application Forms"
//                                         documentType="APLCN"
//                                         s3CustomFileName={transactionNumber}
//                                         onFileUpload={(files) => { 
//                                             const { size } = files[0];

//                                             setApplicationFormFile(files[0]);
//                                             setApplicationFormFileSize(size);
//                                             setMimeType(files[0].type);
//                                         }}
//                                         onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
//                                             setApplicationFormFileFormat(format);
//                                             setApplicationFormFileS3Key(s3Key);
//                                             setApplicationFormFileS3SignedURL(s3Url);
//                                         }}
//                                     /> 
//                                     :
//                                     <FXDocumentViewer document={applicationFormFile}/>
//                             }
//                         </Paper>     
//                     </Box>
//                 </Grid>

//                 <Grid item xs={5.8}>
//                     <Box width="100%">
//                         <Paper
//                             className="form-list"
//                             elevation={0}
//                             sx={{
//                                 "backgroundColor": "transparent",
//                                 "borderRadius": "2px",
//                                 "maxHeight": "805px",
//                                 "minHeight": "805px",
//                                 "overflowY": "auto",
//                                 "width": "98%",
//                             }}
//                         >
//                             <Outlet />
//                         </Paper>
//                     </Box>
//                 </Grid>
//             </Grid>
//         </Box>
//     );
// };

// export default ImageUploadLayout;

import {
    Box,
    Grid,
    Paper
} from "@mui/material";

import DocumentUpload from "./components/DocumentUpload";
import FXAlertSnackbar from "../../components/FXAlertSnackbar";
import FXDocumentViewer from "../../components/FXDocumentViewer";
import { Outlet } from "react-router-dom";
import { RootState } from "../../redux/store";
import imageUploadDisptachActionsProvider from "../../redux/ImageUpload/dispatchActionsProvider";
import { initialAlertSnackbarContext } from "../../interfaces/AlertSnackbarContext.types";
import { useSelector } from "react-redux";
import { useState } from "react";

const ImageUploadLayout = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState(initialAlertSnackbarContext());
    const imageUploadFormState = useSelector(
        (state: RootState) => 
            state
                .imageUploadState
    ); 

    const { 
        applicationFormFile, 
        applicationFormFileS3SignedURL,
        transactionNumber,
        transactionType, 
    } =  imageUploadFormState;

    const { 
        setApplicationFormFile,
        setApplicationFormFileFormat,
        setApplicationFormFileS3Key,
        setApplicationFormFileS3SignedURL,
        setApplicationFormFileSize,
        setMimeType
    } = imageUploadDisptachActionsProvider();
    
    return (
        <>
            <Box width="100%" mt={3} mb={3}>
                <Grid container spacing={0}>
                    <Grid item xs={6.2}>
                        <Box width="95%">
                            <Paper
                                elevation={0}
                                sx={{
                                    "backgroundColor": "#FFFFFF",
                                    "borderRadius": "15px",
                                    "boxShadow": "0px 4px 24px 0px rgba(0, 0, 0, 0.10)",
                                    "height": "740px",
                                    "padding": "10px"
                                }}
                            >
                                {
                                    (applicationFormFile === null || applicationFormFileS3SignedURL === "") 
                                        ?
                                        <DocumentUpload
                                            identifier={`TRANSACTION_NUMBER_${transactionNumber}`}
                                            assetType="Application Forms"
                                            documentType="APLCN"
                                            s3CustomFileName={transactionNumber}
                                            onFileUpload={(files) => { 
                                                const { size } = files[0];

                                                setApplicationFormFile(files[0]);
                                                setApplicationFormFileSize(size);
                                                setMimeType(files[0].type);
                                            }}
                                            onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
                                                setApplicationFormFileFormat(format);
                                                setApplicationFormFileS3Key(s3Key);
                                                setApplicationFormFileS3SignedURL(s3Url);
                                            }}
                                            onFieldErrorChange={(error: string) => {
                                                setAlertSnackbarContext({
                                                    "description": error,
                                                    "open": true,
                                                    "severity": "error",
                                                    "title": "Invalid Document Uploaded",
                                                });
                                            }}
                                        /> 
                                        :
                                        <FXDocumentViewer document={applicationFormFile}/>
                                }
                            </Paper>     
                        </Box>
                    </Grid>

                    <Grid item xs={5.8}>
                        <Box width="100%">
                            <Paper
                                className="form-list"
                                elevation={0}
                                sx={{
                                    "backgroundColor": "transparent",
                                    "borderRadius": "2px",
                                    "maxHeight": "805px",
                                    "minHeight": "805px",
                                    "overflowY": "auto",
                                    "width": "98%",
                                }}
                            >
                                <Outlet />
                            </Paper>
                        </Box>
                    </Grid>
                </Grid>
            </Box>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    setApplicationFormFile(null);
                    setApplicationFormFileFormat("");
                    setApplicationFormFileS3Key("");
                    setApplicationFormFileS3SignedURL("");
                    setApplicationFormFileSize(0);
                    setMimeType("");
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default ImageUploadLayout;
