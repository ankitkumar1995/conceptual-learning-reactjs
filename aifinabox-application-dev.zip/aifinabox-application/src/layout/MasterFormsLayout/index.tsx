import { Outlet } from "react-router-dom";
import { Paper } from "@mui/material";

const MasterFormsLayout = () => {
    return (
        <Paper 
            elevation={0}
            sx={{
                "backgroundColor": "#FFFFFF",
                "borderRadius": "15px",
                "marginTop": "40px",
                "padding": "30px",
            }}
        >
            <Outlet />
        </Paper>
    );
};

export default MasterFormsLayout;
