import "./form.css";
import {
    Box,
    Grid,
    Paper,
    useTheme
} from "@mui/material";

import FXDocumentViewer from "../../components/FXDocumentViewer";
import {
    FXDocumentViewerProps
} from "../../components/FXDocumentViewer/FXDocumentViewerProps.types";
import { RootState } from "../../redux/store";
import { useSelector } from "react-redux";

interface InvestorOnboardingLayoutProps {
    children: React.ReactNode;
};

const InvestorOnboardingLayout: React.FC<InvestorOnboardingLayoutProps> = ({ children }) => {
    const theme = useTheme();

    const drawerOpen = useSelector(
        (state: RootState) => 
            state
                .applicationContextState
                .drawerOpen
    );

    const imageUploadFormState = useSelector(
        (state: RootState) => 
            state
                .imageUploadState
    );

    const documentViewerState = useSelector(
        (state: RootState) => 
            state
                .investorOnboardingState
                .documentViewerState
    );

    const { applicationFormFile } = imageUploadFormState;
    const { applicationFileMimeType, applicationFileUri } = documentViewerState;

    return (
        <Box width="100%" mt={3}>
            <Grid container columnSpacing="15px">
                <Grid 
                    item 
                    xs={6}
                    sx={{
                        "transition": theme.transitions.create("all", {
                            "duration": theme.transitions.duration.leavingScreen,
                            "easing": theme.transitions.easing.sharp, 
                        })
                    }}
                >
                    <Box width="100%">
                        <Paper
                            elevation={0}
                            sx={{
                                "& > div > div:nth-child(1)": {
                                    "display": "flex",
                                    "justifyContent": "center",
                                    "width": "100%",
                                },

                                "& > div:nth-child(1)": {
                                    "height": "calc(100vh - 165px)",
                                },

                                "& > div:nth-child(2) > div": {
                                    "display": "flex",
                                    "justifyContent": "center",
                                },

                                "backgroundColor": "#FFFFFF",
                                "borderRadius": "15px",
                                "boxShadow": "0px 4px 24px 0px rgba(0, 0, 0, 0.10)",
                                "height": "745px",
                                "maxHeight": "calc(100vh - 165px)",
                            }}
                        >
                            {
                                (applicationFormFile !== null) 
                                    ?
                                    <FXDocumentViewer
                                        document={applicationFormFile}
                                    />
                                    :
                                    <>
                                        {
                                            (
                                                applicationFileUri !== "" &&
                                                applicationFileMimeType !== ""
                                            )
                                                ?
                                                <FXDocumentViewer
                                                    documentUri={applicationFileUri}
                                                    documentFileType={
                                                        applicationFileMimeType as 
                                                        FXDocumentViewerProps["documentFileType"]
                                                    }
                                                />
                                                :
                                                <></>
                                        }
                                    </>
                            }
                        </Paper>     
                    </Box>
                </Grid>

                <Grid 
                    item 
                    xs={6}
                    sx={{
                        "transition": theme.transitions.create("all", {
                            "duration": theme.transitions.duration.leavingScreen,
                            "easing": theme.transitions.easing.sharp, 
                        })
                    }}
                >
                    <Box width="100%">
                        <Paper
                            className="form-list"
                            elevation={0}
                            sx={{
                                "backgroundColor": "transparent",
                                "borderRadius": "2px",
                                "maxHeight": "calc(100vh - 140px)",
                                "overflowY": "auto",
                                "width": "100%",
                            }}
                        >
                            {children}
                        </Paper>
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
};

export default InvestorOnboardingLayout;
