import {
    Box,
    IconButton,
    Menu,
    MenuItem,
    Stack,
    Typography
} from "@mui/material";

import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { AuthRole } from "../../../../redux/Authorization/initialState";
import FXSelectInput from "../../../../components/FXSelectInput";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { RootState } from "../../../../redux/store";
import applicationContextDispatchActionsProvider from "../../../../redux/ApplicationContext/dispatchActionsProvider";
import authorizationDispatchActionsProvider from "../../../../redux/Authorization/dispatchActionsProvider";
import useLogout from "../../../../hooks/auth/useLogout";
import { useSelector } from "react-redux";
import { useState } from "react";

interface HeaderProps {
    pageDescription?: string;
    pageHeading?: string;
}

const Header: React.FC<HeaderProps> = ({
    pageDescription,
    pageHeading,
}) => {
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);

    const allowedClientMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .allowedClientMenuItems
    );

    const authorizationState = useSelector(
        (state: RootState) => 
            state
                .authorizationState
    );

    const clientId = useSelector(
        (state: RootState) => 
            state
                .applicationContextState
                .clientId
    );

    const makerIhno = useSelector(
        (state: RootState) =>
            state
                .investorOnboardingState
                .makerState
                .pageContext
                .ihno
    );

    const checkerIhno = useSelector(
        (state: RootState) =>
            state
                .investorOnboardingState
                .checkerState
                .pageContext
                .ihno
    );

    const nigoIhno = useSelector(
        (state: RootState) =>
            state
                .investorOnboardingState
                .nigoState
                .ihno
    );

    const auditIhno = useSelector(
        (state: RootState) =>
            state
                .investorOnboardingState
                .auditorState
                .pageContext
                .ihno
    );

    const documentUri = useSelector(
        (state: RootState) =>
            state
                .investorOnboardingState
                .documentViewerState
                .applicationFileUri
    );

    const makerIhnoInitialContribution = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .initialContribution
                .maker
                .pageContext
                .ihno
    );

    const checkerIhnoInitialContribution = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .initialContribution
                .checker
                .pageContext
                .ihno
    );

    const nigoIhnoInitialContribution = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .initialContribution
                .nigo
                .pageContext
                .ihno
    );

    const auditorIhnoInitialContribution = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .initialContribution
                .auditor
                .pageContext
                .ihno
    );

    const makerIhnoTopUp = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .topUpState
                .maker
                .pageContext
                .ihno
    );

    const checkerIhnoTopUp = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .topUpState
                .checker
                .pageContext
                .ihno
    );

    const nigoIhnoTopUp = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .topUpState
                .nigo
                .pageContext
                .ihno
    );

    const auditorIhnoTopUp = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .topUpState
                .auditor
                .pageContext
                .ihno
    );

    const disableClientCodeDropdown = () => {
        return (
            makerIhno !== "" || 
            checkerIhno !== "" || 
            auditIhno !== "" || 
            nigoIhno !== "" ||
            makerIhnoInitialContribution !== "" ||
            checkerIhnoInitialContribution !== "" ||
            nigoIhnoInitialContribution !== "" ||
            auditorIhnoInitialContribution !== "" ||
            makerIhnoTopUp !== "" ||
            checkerIhnoTopUp !== "" ||
            auditorIhnoTopUp !== "" ||
            nigoIhnoTopUp !== ""
        );
    };

    const {
        authData,
        authToken,
    } = authorizationState;

    const {
        setClientId,
        setClientName
    } = applicationContextDispatchActionsProvider();

    const {
        setAuthRole,
    } = authorizationDispatchActionsProvider();

    const logout = useLogout();

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClientIdChange = (newClientId: string) => {
        const authDetails = 
            authData.find((authDataItem) => (
                authDataItem.clientCode === newClientId
            ));
        
        setClientId(newClientId);
        if (authDetails) {
            setClientName(authDetails.clientName);
            setAuthRole(authDetails.authRole as AuthRole);
        }

    };

    return ( 
        <Stack direction="row" justifyContent="space-between" mt={2} >
            <Box display="flex" flexDirection="column">
                <Typography variant="pageHeading">
                    {pageHeading}
                </Typography>

                <Typography variant="pageDescription" mt={1}>
                    {pageDescription}
                </Typography>
            </Box> 

            <Box>
                <Stack direction="row" mt={-2}>
                    <FXSelectInput
                        label="Client Code"
                        disabled={disableClientCodeDropdown()}
                        value={clientId}
                        onValueChange={handleClientIdChange}
                        menuItems={allowedClientMenuItems}
                        sx={{
                            "marginRight": "25px",
                            "width": "300px"
                        }}
                        formLabelSx={{
                            "& .MuiFormLabel-root": {
                                "& .MuiTypography-root": {
                                    "color": "#1c2d47",
                                    "fontSize": "14px",
                                    "fontWeight": 600,
                                },
                                "p": 0,
                            }
                        }}
                    />
                
                    <IconButton
                        id="header-menu-button"
                        disableRipple 
                        onClick={handleClick}
                        sx={{ "padding": 0 }}
                        aria-controls={open ? 'basic-menu' : undefined}
                        aria-haspopup="true"
                        aria-expanded={open ? 'true' : undefined}
                    >
                        <AccountCircleIcon fontSize="large" />
                        <KeyboardArrowDownIcon/>
                    </IconButton>
                </Stack>

                <Menu 
                    open={open}
                    anchorEl={anchorEl}
                    onClose={() => setAnchorEl(null)}
                    MenuListProps={{
                        "aria-labelledby": "header-menu-button",
                    }}
                >
                    <MenuItem onClick={() => logout(authToken)}>
                        Logout
                    </MenuItem>
                </Menu>
            </Box>
        </Stack> 
    );
};

export default Header;
