import { 
    Box, 
    IconButton, 
    Stack
} from "@mui/material";
import DrawerItems from "./components/DrawerItems";
import { DrawerProps } from "./DrawerProps.types";
import KfintechLogo from "../../../../icons/KfintechLogo";
import MenuIcon from "@mui/icons-material/Menu";
import MenuOpenIcon from "@mui/icons-material/MenuOpen";
import { RootState } from "../../../../redux/store";
import StyledDrawer from "./StyledDrawer";
import applicationContextDispatchActionsProvider from "../../../../redux/ApplicationContext/dispatchActionsProvider";
import { useSelector } from "react-redux";


const Drawer: React.FC<DrawerProps> = () => {
    const drawerOpen = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
                .drawerOpen
    );

    const {
        setDrawerOpen
    } = applicationContextDispatchActionsProvider();

    return (
        <StyledDrawer
            variant="permanent"
            anchor="left"
            open={drawerOpen}
        >
            <Box
                display="flex"
                alignItems="center"
                justifyContent="center"
                padding={1}
                paddingBottom="30px"
                paddingTop="20px"
                marginLeft="-50px"
            >
                {
                    !(drawerOpen)
                        ? <Box 
                            width="100%"
                            ml="47px"
                        >
                            <IconButton
                                onClick={() => setDrawerOpen(true)}
                            >
                                <MenuIcon/>
                            </IconButton>
                            
                        </Box>

                        : <Stack 
                            direction="row" 
                            width="100%"
                            sx={{ "ml": 3 }}
                        >
                            <Box display="flex" alignItems="center">
                                <Box ml={5}>
                                    <KfintechLogo/>
                                </Box>
                                
                                <IconButton
                                    onClick={() => setDrawerOpen(false)}
                                    sx={{ "ml": 3 }}
                                >
                                    <MenuOpenIcon/>
                                </IconButton>
                            </Box>
                        </Stack>
                }
            </Box>

            <Box>
                <DrawerItems/>
            </Box>
        </StyledDrawer>
    );
};

export default Drawer;
