import { 
    CSSObject, 
    Theme, 
    styled 
} from "@mui/material";
import Drawer, { DrawerProps } from "@mui/material/Drawer";

const drawerWidth = "290px";

const openedMixin = (theme: Theme): CSSObject => ({
    "overflowX": "hidden",
    "transition": theme.transitions.create("width", {
        "duration": theme.transitions.duration.enteringScreen,
        "easing": theme.transitions.easing.sharp,
    }),
    "width": drawerWidth
});

const closedMixin = (theme: Theme): CSSObject => ({
    [theme.breakpoints.up('sm')]: {
        "width": `calc(${theme.spacing(8)} + 1px)`
    },
    "overflowX": "hidden",
    "transition": theme.transitions.create("width", {
        "duration": theme.transitions.duration.leavingScreen,
        "easing": theme.transitions.easing.sharp,
    }),
    "width": `calc(${theme.spacing(7)} + 1px)`
});

const StyledDrawer = styled(Drawer, { 
    "shouldForwardProp": (prop) => prop !== "open" 
}
)<DrawerProps>( ({ theme, open }) => {
    return ({
        "boxSizing": 'border-box',
        "flexShrink": 0,
        "whiteSpace": 'nowrap',
        "width": drawerWidth,
        ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
        }),
        ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
        }),
    });
},
);

export default StyledDrawer;
