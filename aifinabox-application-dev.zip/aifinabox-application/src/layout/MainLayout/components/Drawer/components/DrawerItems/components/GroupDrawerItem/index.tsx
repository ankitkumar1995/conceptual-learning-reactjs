import { useEffect, useState } from "react";

import AddIcon from "@mui/icons-material/Add";
import Collapse from "@mui/material/Collapse";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import RemoveIcon from "@mui/icons-material/Remove";
import { RootState } from "../../../../../../../../redux/store";
import { StepperDrawerItemProps } from "./GroupDrawerItemProps.types";
import TripOriginSharpIcon from "@mui/icons-material/TripOriginSharp";
import Typography from "@mui/material/Typography";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import pageContextDispatchActionsProvider from "../../../../../../../../redux/AifMaster/FundMaster/PageContext/dispatchActionsProvider";
import planMasterPageContextDispatchActionsProvider from "../../../../../../../../redux/AifMaster/PlanMaster/PageContext/dispatchActionsProvider";
import provideApplicationContextDispatchActions from "../../../../../../../../redux/ApplicationContext/dispatchActionsProvider";
import { useNavigate } from "react-router";
import { useSelector } from "react-redux";

const GroupDrawerItem: React.FC<StepperDrawerItemProps> = ({
    drawerItem,
}) => {
    const childDrawerItemId = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
                .childDrawerItemId
    );

    const drawerItemId = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
                .drawerItemId
    );

    const drawerOpen = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
                .drawerOpen
    );

    const childTitle = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
                .title
    );

    const authorizationState = useSelector(
        (state: RootState) => 
            state
                .authorizationState
    );

    const { authRole } = authorizationState;

    // const {
    //     childDrawerItemId,
    //     drawerItemId,
    //     drawerOpen,
    //     title,
    // } = applicationContextState;

    const { 
        setDrawerItemId,
        setChildDrawerItemId, 
        setPageHeading,
        setTitle, 
    } = provideApplicationContextDispatchActions();

    const {
        setFlowType,
        setMakerNavigation,
        setCheckerNavigation,
        "setNigoRaised": setNigoRaisedClassMaster
    } = classMasterPageContextDispatchActionProvider();

    const {
        "setMakerNavigation": setBankMasterNavigation,
    } = bankMasterPageContextFormDispatchActionsProvider();

    const {"setMakerNavigation": setPlanMasterNavigation} = planMasterPageContextDispatchActionsProvider();

    const { setCheckerNavigateTo, setNigoRaised } = pageContextDispatchActionsProvider();

    const {
        id,
        children,
        normalStateIcon,
        "route": parentRoute,
        selectedStateIcon,
        title,
    } = drawerItem;

    const navigate = useNavigate();

    useEffect(() => {
        if (drawerItemId === id) {
            const pageHeading = title + " - " + authRole;
            setPageHeading(pageHeading);
        }
    }, [drawerItemId, authRole]);

    useEffect(() => {
        if (childDrawerItemId !== "class-master") {
            setFlowType(null);
            setMakerNavigation("");
            setCheckerNavigation("");  
            setNigoRaisedClassMaster(false);  
        }
        
        if (childDrawerItemId !== "bank-master") {
            setBankMasterNavigation("");
        }

        if (childDrawerItemId !== "plan-master") {
            setPlanMasterNavigation("");
        }
        if (childDrawerItemId !== "fund-master") {
            setCheckerNavigateTo("");
            setNigoRaised(false);
        }
        if (
            childDrawerItemId === "initial-contribution" || 
            childDrawerItemId === "top-up" || 
            childDrawerItemId === "mutual-fund-gains" ||
            childDrawerItemId === "income-distribution" ||
            childDrawerItemId === "drawdown" ||
            childDrawerItemId === "redemption"
        ) {
            setPageHeading(`${childTitle} - ${authRole}`);
        }
    }, [childDrawerItemId, drawerItemId]);

    return (
        <>
            <ListItemButton
                onClick={() => setDrawerItemId(id)}
                sx={{
                    "background":
                        (drawerItemId === id)
                            ? "linear-gradient(90deg, #2057A6 -31.87%, rgba(32, 87, 166, 0) 111.56%)"
                            : "white",
                    "height": "50px",
                }}
            >
                <ListItemIcon>
                    {
                        (drawerItemId === id)
                            ? selectedStateIcon
                            : normalStateIcon
                    }
                </ListItemIcon>

                <ListItemText primary={
                    <Typography variant={
                        (drawerItemId === id)
                            ? "navigationSectionSelected"
                            : "navigationSectionNormal"
                    }>
                        {title}
                    </Typography>
                }/>

                {
                    (drawerItemId === id) 
                        ? <RemoveIcon sx={{ "color": "#2057A6" }}/> 
                        : <AddIcon sx={{ "color": "#A0AEC3" }}/>
                }
            </ListItemButton>

            <Collapse 
                in={drawerOpen && (drawerItemId === id)} 
                timeout="auto" 
                unmountOnExit
            >
                <List>
                    {
                        children?.map((drawerItemChild, index) => {
                            const {
                                id,
                                "route": childRoute,
                                title,
                            } = drawerItemChild;

                            return (
                                <ListItemButton 
                                    key={id}
                                    onClick={() => {
                                        setChildDrawerItemId(id);
                                        setTitle(title);
                                        navigate(`${parentRoute}${childRoute}`);
                                    }}
                                >
                                    <ListItemIcon sx={{ "marginLeft": "25px" }}>
                                        <TripOriginSharpIcon sx={{
                                            "color": 
                                                (childDrawerItemId === id)
                                                    ? "#2057A6"
                                                    : "#DCEAFF",
                                            "transform": "scale(0.6)",
                                        }}/>
                                    </ListItemIcon>

                                    <ListItemText
                                        sx={{ "marginLeft": "-25px" }}
                                        primary={
                                            <Typography variant={
                                                (childDrawerItemId === id)
                                                    ? "navigationSubStepSelected"
                                                    : "navigationSubStepNormal"
                                            }>
                                                {title}
                                            </Typography>
                                        }
                                    />
                                </ListItemButton>
                            );
                        })
                    }
                </List>
            </Collapse>
        </>
    );
};

export default GroupDrawerItem;
