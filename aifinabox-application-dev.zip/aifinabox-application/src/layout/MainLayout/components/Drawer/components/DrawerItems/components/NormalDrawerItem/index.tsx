import {
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Typography
} from "@mui/material";
import { useEffect, useState } from "react";
import { NormalDrawerItemProps } from "./NormalDrawerItemProps.types";
import { RootState } from "../../../../../../../../redux/store";
import provideApplicationContextDispatchActions from "../../../../../../../../redux/ApplicationContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux"; 

const NormalDrawerItem: React.FC<NormalDrawerItemProps> = ({
    drawerItem,
}) => {
    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    const applicationContextState = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
    );
    
    const { drawerItemId } = applicationContextState;

    const { 
        setChildDrawerItemId, 
        setDrawerItemId, 
        setPageHeading 
    } = provideApplicationContextDispatchActions();

    // const [openList, setOpenList] = useState(false);

    const {
        id,
        normalStateIcon,
        "route": parentRoute,
        selectedStateIcon,
        title,
    } = drawerItem;

    const navigate = useNavigate();

    useEffect(() => {
        if (drawerItemId === id) {
            const pageHeading = title + " - " + authRole;
            setPageHeading(pageHeading);
        }
    }, [drawerItemId, authRole]);

    return (
        <>
            <ListItemButton
                onClick={() => {
                    setDrawerItemId(id);
                    setChildDrawerItemId("");
                    navigate(`${parentRoute}`);
                }}
                sx={{
                    "background":
                        (drawerItemId === id)
                            ? "linear-gradient(90deg, #2057A6 -31.87%, rgba(32, 87, 166, 0) 111.56%)"
                            : "white",
                    "height": "50px",
                }}
            >
                <ListItemIcon>
                    {
                        (drawerItemId === id)
                            ? selectedStateIcon
                            : normalStateIcon
                    }
                </ListItemIcon>

                <ListItemText primary={
                    <Typography variant={
                        (drawerItemId === id)
                            ? "navigationSectionSelected"
                            : "navigationSectionNormal"
                    }>
                        {title}
                    </Typography>
                }/>
            </ListItemButton>
        </>
    );
};

export default NormalDrawerItem;
