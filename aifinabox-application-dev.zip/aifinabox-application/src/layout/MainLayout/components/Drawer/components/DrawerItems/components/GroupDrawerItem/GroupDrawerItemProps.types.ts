import { DrawerItem } from "../../../../../../../../interfaces/DrawerItem.types";

export interface StepperDrawerItemProps {
    drawerItem: DrawerItem;
}
