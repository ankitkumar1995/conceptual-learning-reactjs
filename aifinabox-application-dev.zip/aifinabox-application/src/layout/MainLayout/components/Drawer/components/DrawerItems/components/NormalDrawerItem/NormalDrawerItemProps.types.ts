import { DrawerItem } from "../../../../../../../../interfaces/DrawerItem.types";

export interface NormalDrawerItemProps {
    drawerItem: DrawerItem;
}
