import { useEffect, useState } from "react";

import { Box } from "@mui/material";
import GroupDrawerItem from "./components/GroupDrawerItem";
import ImageUploadDrawerItem from "../../../../../../drawer-items/ImageUploadDrawerItems";
import List from "@mui/material/List";
import NormalDrawerItem from "./components/NormalDrawerItem";
import { RootState } from "../../../../../../redux/store";
import drawerItems from "../../../../../../drawer-items";
import provideApplicationContextDispatchActions from "../../../../../../redux/ApplicationContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const DrawerItems = () => {

    const [newDrawerItems, setNewDrawerItems] = useState(drawerItems);
    const [initialRenderState, setInitialRenderState] = useState(false);

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    const navigate = useNavigate();

    const { setDrawerItemId, setChildDrawerItemId} = provideApplicationContextDispatchActions();

    useEffect(() => {
        setInitialRenderState(true);
        if (authRole !== "" && authRole !== "Maker"){
            setNewDrawerItems(newDrawerItems.filter(drawer => JSON.stringify(drawer) !== JSON.stringify(ImageUploadDrawerItem)));
            if (initialRenderState) {
                setDrawerItemId("");
                setChildDrawerItemId("");
                navigate("/");
            }
        }
        else {
            setNewDrawerItems(drawerItems);
        }
    }, [authRole]);

    return (
        <List
            component="nav"
            sx={{ "width": "100%" }}
        >
            {
                newDrawerItems.map((drawerItem) => {
                    const { id, type } = drawerItem;

                    return (
                        <Box key={id}>
                            {(() => {
                                switch (type) {
                                case "group":
                                    return <GroupDrawerItem drawerItem={drawerItem}/>;

                                case "normal":
                                    return <NormalDrawerItem drawerItem={drawerItem}/>;
                
                                case "stepper":
                                    return <></>;
                
                                default:
                                    return <>Invalid Drawer Item Type</>;
                                }
                            })()}
                        </Box>
                    );
                })
            }
        </List>
    );
};

export default DrawerItems;
