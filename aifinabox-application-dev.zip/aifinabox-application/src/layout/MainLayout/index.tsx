import {
    Box,
    Paper,
    Stack
} from "@mui/material";
import { Outlet, useLocation } from "react-router-dom";

import Drawer from "./components/Drawer";
import FXBackdrop from "../../components/FXBackdrop";
import Header from "./components/Header";
import { MainLayoutProps } from "./MainLayoutProps.types";
import { RootState } from "../../redux/store";
import provideApplicationContextDispatchActions from "../../redux/ApplicationContext/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const MainLayout: React.FC<MainLayoutProps> = () => {
    const applicationContextState = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
    );

    const {
        openBackdrop,
        pageHeading, 
    } = applicationContextState;

    const { setDrawerItemId, setChildDrawerItemId } = provideApplicationContextDispatchActions();
    
    const location = useLocation();

    useEffect(() => {
        const paths = location.pathname.split("/").filter(Boolean);

        if (paths.length === 1) {
            const draweItemId = paths[0];
            setDrawerItemId(draweItemId);
            setChildDrawerItemId("");
        }

        if (paths.length === 2) {
            const draweItemId = paths[0];
            const childDrawerItemId = paths[1];
            setDrawerItemId(draweItemId);
            setChildDrawerItemId(childDrawerItemId);
        }
    }, [location]);

    return (
        <Box display="flex" width="100%">
            <Drawer/>

            <Box 
                width="calc(100% - 362px)"
                flexGrow={1}
                p={1}
                ml={1} 
                mr={1}
            >
                <Header 
                    pageHeading={pageHeading}
                    pageDescription=" "
                />

                <Box
                    width="100%"
                    flexGrow={1}
                    mt="30px"
                >
                    <Outlet />
                </Box>
            </Box>
        </Box>
    );
};

export default MainLayout;
