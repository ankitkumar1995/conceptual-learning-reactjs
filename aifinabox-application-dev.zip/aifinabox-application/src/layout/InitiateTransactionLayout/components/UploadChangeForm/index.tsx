import { AcceptedFormat, UploadChangeFormProps } from "./UploadChangeForm.types";
import { Box, Typography } from "@mui/material";
import React, {
    useEffect,
    useRef,
    useState
} from "react";

import { BackendValidationError } from "../../../../interfaces/BackendValidationError.types";
import ChangeFormUploadIcon from "../../../../icons/ChangeFormUploadIcon";
import axios from "axios";
import checkFileMagicNumber from "../../../../utils/checkFileMagicNumber";
import { setOpenBackdrop } from "../../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

const UploadChangeForm: React.FC<UploadChangeFormProps> = ({ 
    accept,
    assetType,
    disabled,
    documentType,
    error,
    helperText,
    identifier,
    onFieldErrorChange,
    onFileUpload,
    onRemoveFile,
    onS3PresignedUrlFetch,
    s3CustomFileName,
}) => {
    const [highlight, setHighlight] = useState(false);
    const [event, setEvent] = useState<React.ChangeEvent<HTMLInputElement>>();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const acceptedFileFormat: AcceptedFormat[] = [".eml", ".pdf"];
    const acceptStringFileFormat = accept?.join(",") || acceptedFileFormat.join(",");

    const dispatch = useDispatch();

    const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setHighlight(true);
    };

    const handleDragLeave = () => {
        setHighlight(false);
    };

    const handleDrop = async (event: React.DragEvent<HTMLDivElement>) => {
        dispatch(setOpenBackdrop(true));
        event.preventDefault();
        setHighlight(false);
        onFileUpload(event.dataTransfer.files);
        const selectedFile = event.dataTransfer.files && event.dataTransfer.files[0];

        if (selectedFile) {
            const isPDF = await checkFileMagicNumber(selectedFile, ["%PDF"]);
            const isEML = await checkFileMagicNumber(selectedFile, ["MIME-Version:"]);
            
            if (isPDF || isEML) {
                if (onS3PresignedUrlFetch !== undefined)
                {
                    if (identifier === undefined || identifier.length > 0)
                        getS3SignedURL((event.dataTransfer.files !== null) ? event.dataTransfer.files[0] : null);
                    else {
                        onS3PresignedUrlFetch("","",""); 
                        dispatch(setOpenBackdrop(false));
                    }
                }
                console.log("File Dropped is a PDF or EML");
            } else {
                dispatch(setOpenBackdrop(false));
                onFieldErrorChange && onFieldErrorChange("Please choose a valid pdf or eml document");
                console.log("File Dropped type not recognized");
            }
        }
    };

    const handleUploadClick = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };

    const handleFileInputChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const {files} = event.target;
        const selectedFile = files && files[0];
        dispatch(setOpenBackdrop(true));

        if (selectedFile) {
            const isPDF = await checkFileMagicNumber(selectedFile, ['%PDF']);
            const isEML = await checkFileMagicNumber(selectedFile, ["%eml"]);

            console.log("isEML", isEML);
            
            if (isPDF || isEML) {
                if (files && files.length > 0) {
                    onFileUpload(files);
                }
                setEvent(event);
                if (onS3PresignedUrlFetch !== undefined)
                {
                    if (identifier === undefined || identifier.length > 0)
                        getS3SignedURL((event.target.files !== null) ? event.target.files[0] : null);
                    else {
                        onS3PresignedUrlFetch("","",""); 
                        dispatch(setOpenBackdrop(false));
                    }
                }
                console.log('File is a PDF or Tiff');
            } else {
                dispatch(setOpenBackdrop(false));
                onFieldErrorChange && onFieldErrorChange("Please choose a valid pdf or eml document");
                console.log('File type not recognized');
            }
        }
    };

    const getS3SignedURL = async (file: File | null) => {
        dispatch(setOpenBackdrop(true));
        
        let s3SignedUrl = "", s3Key = "";
        
        //const file = (e.target.files !== null) ? e.target.files[0] : null;
        const name = (file !== null) ? file.name : "";
        const size = (file !== null) ? file.size : 0;
        const extension = (name !== undefined) ? name.split('.').pop() : "";

        let data = {
            "assetType": assetType,
            "documentType": documentType,
            "fileExtension": extension,
            "fileName": s3CustomFileName,
            "fileSize": size/(1024**2),
            "identifier": identifier
        };

        const config = {
            "data": JSON.stringify(data),
            "method": "post",
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT}/s3presignedurl`,
        };
        
        await axios(config)
            .then((result) => {
                s3Key = result.data.key;
                s3SignedUrl = result.data.preSignedUrl;
                const { bucketName, format } = result.data;

                const s3KeyWithBucket = `${bucketName}: ${s3Key}`;

                if (onS3PresignedUrlFetch !== undefined) 
                    onS3PresignedUrlFetch(format, s3KeyWithBucket, s3SignedUrl);
                dispatch(setOpenBackdrop(false));
            })
            .catch((error) => {
                const statusCode = error.response.status;

                if (onS3PresignedUrlFetch !== undefined) onS3PresignedUrlFetch("", "", "");

                if (statusCode === 475) {
                    const validationErrors = JSON.parse(
                        error
                            .response
                            .data
                            .message
                    );
                    
                    validationErrors.map((validationError: BackendValidationError) => {
                        
                        if (onFieldErrorChange) 
                            onFieldErrorChange(validationError.error);
                    });
                    dispatch(setOpenBackdrop(false));
                }
            });
    };

    return (
        <Box 
            sx={{ 
                "alignItems": "center",
                "backgroundColor": "#0FD4D833",
                "border": highlight ? "1px dashed #2057A6": "1px dashed #B0B0B0",
                "borderRadius": "10px",
                "display": "flex",
                "flexDirection": "column",
                "height": "200px",
                "justifyContent": "center",
                "marginLeft": "15px",
                "width": "100%",
            }}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={handleUploadClick}
        >
            <Box 
                mt={6}
                mb={2.5} 
                onClick={handleUploadClick}
                sx={{ "cursor": "pointer" }}
            >
                <ChangeFormUploadIcon/>
            </Box>
                
            <Box 
                onClick={handleUploadClick}
                sx={{  
                    "cursor": "pointer",  
                    "height": "150px",
                    "textAlign": "center",
                    "width": "410px",
                }}  
            >
                <Typography variant="uploadImageText">
                    Upload Image Here
                </Typography>
                    
                <input
                    type="file"
                    ref={fileInputRef}
                    onClick={() => {
                        if (fileInputRef.current !== null) 
                            fileInputRef.current.value = '';
                    }}
                    style={{ "display": "none" }}
                    onChange={handleFileInputChange}
                    accept={acceptStringFileFormat}
                />
            </Box>
        </Box>
    );
};

export default UploadChangeForm;
