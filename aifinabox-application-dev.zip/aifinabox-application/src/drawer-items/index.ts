import CreditIdentificationDrawerItem from "./CreditIdentificationDrawerItems";
import { DrawerItem } from "../interfaces/DrawerItem.types";
import ImageUploadDrawerItem from "./ImageUploadDrawerItems";
import InitiateTransactionDrawerItem from "./InitiateTransactionDrawerItems";
import InvestorOnboardingDrawerItem from "./InvestorOnboardingDrawerItems";
import MasterSetupDrawerItem from "./MasterSetupDrawerItems";

const drawerItems: DrawerItem[] = [
    ImageUploadDrawerItem,
    //MasterSetupDrawerItem,
    InvestorOnboardingDrawerItem,
    InitiateTransactionDrawerItem,
    CreditIdentificationDrawerItem
];

export default drawerItems;
