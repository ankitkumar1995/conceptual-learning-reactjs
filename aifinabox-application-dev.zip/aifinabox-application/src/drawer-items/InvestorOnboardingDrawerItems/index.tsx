import { DrawerItem } from "../../interfaces/DrawerItem.types";
import NormalInvestorOnboardingNavigationIcon from "../../icons/NavigationDrawerIcons/InvestorOnboarding/Normal";
import SelectedInvestorOnboardingNavigationIcon from "../../icons/NavigationDrawerIcons/InvestorOnboarding/Selected";

const InvestorOnboardingDrawerItem: DrawerItem = {
    "id": "investor-onboarding",
    "normalStateIcon": <NormalInvestorOnboardingNavigationIcon/>,
    "route": "/investor-onboarding",
    "selectedStateIcon": <SelectedInvestorOnboardingNavigationIcon/>,
    "title": "Investor Onboarding",
    "type": "normal"
};

export default InvestorOnboardingDrawerItem;
