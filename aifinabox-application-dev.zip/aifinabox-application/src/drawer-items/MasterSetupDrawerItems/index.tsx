import { DrawerItem } from "../../interfaces/DrawerItem.types";
import NormalMasterSetupNavigationIcon from "../../icons/NavigationDrawerIcons/MasterSetup/Normal";
import SelectedMasterSetupNavigationIcon from "../../icons/NavigationDrawerIcons/MasterSetup/Selected";

const MasterSetupDrawerItem: DrawerItem = {
    "children": [
        {
            "id": "client-master",
            "route": "/client-master",
            "title": "Client Master",
            "type": "item",
        },
        {
            "id": "contact-master",
            "route": "/contact-master",
            "title": "Contact Master",
            "type": "item",
        },
        {
            "id": "fund-master",
            "route": "/fund-master",
            "title": "Fund Master",
            "type": "item",
        },
        {
            "id": "benchmark-master",
            "route": "/benchmark-master",
            "title": "Benchmark Master",
            "type": "item",
        },
        {
            "id": "bank-master",
            "route": "/bank-master",
            "title": "Bank Master",
            "type": "item",
        },
        {
            "id": "plan-master",
            "route": "/plan-master",
            "title": "Plan Master",
            "type": "item",
        },
        {
            "id": "class-master",
            "route": "/class-master",
            "title": "Class Master",
            "type": "item",
        },
        {
            "id": "dd-master",
            "route": "/dd-master",
            "title": "DD Master",
            "type": "item",
        },
        // {
        //     "id": "topup-master",
        //     "route": "/topup-master",
        //     "title": "Topup Master",
        //     "type": "item",
        // },
    ],
    "id": "client-onboarding",
    "normalStateIcon": <NormalMasterSetupNavigationIcon/>,
    "route": "/client-onboarding",
    "selectedStateIcon": <SelectedMasterSetupNavigationIcon/>,
    "title": "Client Onboarding",
    "type": "group"
};

export default MasterSetupDrawerItem;
