import { DrawerItem } from "../../interfaces/DrawerItem.types";
import NormalCreditIdentificationNavigationIcon from "../../icons/NavigationDrawerIcons/CreditIdentification/Normal";
import SelectedCreditIdentificationNavigationIcon from "../../icons/NavigationDrawerIcons/CreditIdentification/Selected";

const CreditIdentificationDrawerItem: DrawerItem = {
    "id": "credit-identification",
    "normalStateIcon": <NormalCreditIdentificationNavigationIcon/>,
    "route": "/credit-identification",
    "selectedStateIcon": <SelectedCreditIdentificationNavigationIcon/>,
    "title": "Credit Identification",
    "type": "normal"
};

export default CreditIdentificationDrawerItem;
