import { DrawerItem } from "../../interfaces/DrawerItem.types";
import NormalInitiateTransactionNavigationIcon from "../../icons/NavigationDrawerIcons/InitiateTransaction/Normal";
import SelectedInitiateTransactionNavigationIcon from "../../icons/NavigationDrawerIcons/InitiateTransaction/Selected";

const InitiateTransactionDrawerItem: DrawerItem = {
    "children": [
        {
            "id": "initial-contribution",
            "route": "/initial-contribution",
            "title": "Initial Contribution",
            "type": "item",
        },
        {
            "id": "top-up",
            "route": "/top-up",
            "title": "Top Up",
            "type": "item",
        },
        {
            "id": "mutual-fund-gains",
            "route": "/mutual-fund-gains",
            "title": "Mutual Fund gains",
            "type": "item",
        },
        {
            "id": "income-distribution",
            "route": "/income-distribution",
            "title": "Income Distributions",
            "type": "item",
        },
        {
            "id": "drawdown",
            "route": "/drawdown",
            "title": "Generate Drawdown",
            "type": "item",
        },
        {
            "id": "redemption",
            "route": "/redemption",
            "title": "Initiate Redemption",
            "type": "item",
        }
    ],
    "id": "initiate-transaction",
    "normalStateIcon": <NormalInitiateTransactionNavigationIcon/>,
    "route": "/initiate-transaction",
    "selectedStateIcon": <SelectedInitiateTransactionNavigationIcon/>,
    "title": "Initiate Transaction",
    "type": "group"
};

export default InitiateTransactionDrawerItem;
