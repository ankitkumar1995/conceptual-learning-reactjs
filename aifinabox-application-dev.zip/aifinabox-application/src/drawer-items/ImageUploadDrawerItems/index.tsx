import { DrawerItem } from "../../interfaces/DrawerItem.types";
import NormalImageUploadNavigationIcon from "../../icons/NavigationDrawerIcons/ImageUpload/Normal";
import SelectedImageUploadNavigationIcon from "../../icons/NavigationDrawerIcons/ImageUpload/Selected";

const ImageUploadDrawerItem: DrawerItem = {
    "id": "image-upload",
    "normalStateIcon": <NormalImageUploadNavigationIcon/>,
    "route": "/image-upload",
    "selectedStateIcon": <SelectedImageUploadNavigationIcon/>,
    "title": "Image Upload",
    "type": "normal"
};

export default ImageUploadDrawerItem;
