import {
    BankAccountDetailsType,
    initializeBankAccountDetails
} from "../../../pages/AIFMaster/BankMaster/Maker/MakerBankMasterForm/interfaces/bankAccountDetails";
import {
    BankMasterDetails,
    initialBankMasterDetailsFormState
} from "../../../redux/AifMaster/BankMaster/Maker/initialState";
import initializeUpdateState, {
    UpdateState
} from "../../../redux/AifMaster/BankMaster/Update/initialState";
import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface BankMaster {
    bankMasterFormState: BankMasterDetails;
    bankMasterUpdateState: UpdateState;
}

function useFetchRejectBankMaster() {
    const dispatch = useDispatch();

    let bankMasterData: BankAccountDetailsType | BankMasterDetails = initializeBankAccountDetails;
    let bankMasterUpdateData: UpdateState = initializeUpdateState();
    let bankMaster: BankMaster;

    const fetchRejectBankMaster = async (
        bankAccountNumber: string,
        bankName: string, 
        clientCode: string,
        fundCode: string,
        masterName: MasterName, 
        planCode: string,
        role:  "C" | "M",
    ): Promise<BankMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/reject?bankAccountNumber=${bankAccountNumber}&bankName=${bankName}&classCode=""&clientCode=${clientCode}&fundCode=${fundCode}&masterName=${masterName}&planCode=${planCode}&role=${role}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const bankMasterMakerEntryFromApi = responseData[0];

                bankMasterData = {
                    "accountType": bankMasterMakerEntryFromApi.accountType?.value ?? "",
                    "bankAccountName": bankMasterMakerEntryFromApi.bankAccountName?.value ?? "",
                    "bankAccountNumber": bankMasterMakerEntryFromApi.bankAccountNumber?.value ?? "",
                    "bankCode": bankMasterMakerEntryFromApi.bankCode?.value ?? "",
                    "bankIfscRtgsCode": bankMasterMakerEntryFromApi.ifscOrRtgsCode?.value ?? "",
                    "bicSwiftCode": bankMasterMakerEntryFromApi.bicOrSwiftCode?.value ?? "",
                    "branchName": bankMasterMakerEntryFromApi.branchName?.value ?? "",
                    "city": bankMasterMakerEntryFromApi.city?.value ?? "",
                    "companyCode": bankMasterMakerEntryFromApi.clientCode ?? "",
                    "companyName": bankMasterMakerEntryFromApi.clientName ?? "",
                    "corporateBankName": bankMasterMakerEntryFromApi.bankName?.value ?? "",
                    "corporateId": bankMasterMakerEntryFromApi.corporateId?.value ?? "",
                    "currency": bankMasterMakerEntryFromApi.currency?.value ?? "",
                    "defaultAccount": bankMasterMakerEntryFromApi.defaultAccount.value ?? "",
                    "dormant": bankMasterMakerEntryFromApi.dormant?.value ?? "",
                    "dormantDate": bankMasterMakerEntryFromApi.dormantDate?.value ?? null,
                    "fundCode": bankMasterMakerEntryFromApi.fundCode ?? "",
                    "fundName": bankMasterMakerEntryFromApi.fundName ?? "",
                    "isActive": bankMasterMakerEntryFromApi.isActive?.value ?? "",
                    "ownershipType": bankMasterMakerEntryFromApi.ownershipType?.value ?? "",
                    "proofFile": null,
                    "proofFileFormat": "",
                    "proofFileS3Key": "",
                    "proofFileS3SignedURL": "",
                    "proofFileSize": "",
                    "remarks": bankMasterMakerEntryFromApi.remarks?.value ?? "",
                };

                bankMasterUpdateData = {
                    "accountType": bankMasterMakerEntryFromApi.accountType?.updated ?? false,
                    "bankAccountName": bankMasterMakerEntryFromApi.bankAccountName?.updated ?? false,
                    "bankAccountNumber": bankMasterMakerEntryFromApi.bankAccountNumber?.updated ?? false,
                    "bankCode": bankMasterMakerEntryFromApi.bankCode?.updated ?? false,
                    "bankIfscRtgsCode": bankMasterMakerEntryFromApi.ifscOrRtgsCode?.updated ?? false,
                    "bicSwiftCode": bankMasterMakerEntryFromApi.bicOrSwiftCode?.updated ?? false,
                    "branchName": bankMasterMakerEntryFromApi.branchName?.updated ?? false,
                    "city": bankMasterMakerEntryFromApi.city?.updated ?? false,
                    "companyCode": false,
                    "companyName": false,
                    "corporateBankName": bankMasterMakerEntryFromApi.bankName?.updated ?? false,
                    "corporateId": bankMasterMakerEntryFromApi.corporateId?.updated ?? false,
                    "currency": bankMasterMakerEntryFromApi.currency?.updated ?? false,
                    "defaultAccount": bankMasterMakerEntryFromApi.defaultAccount.updated ?? false,
                    "dormant": bankMasterMakerEntryFromApi.dormant?.updated ?? false,
                    "dormantDate": bankMasterMakerEntryFromApi.dormantDate?.updated ?? false,
                    "fundCode": false,
                    "fundName": false,
                    "isActive": bankMasterMakerEntryFromApi.isActive?.updated ?? false,
                    "ownershipType": bankMasterMakerEntryFromApi.ownershipType?.updated ?? false,
                    "remarks": bankMasterMakerEntryFromApi.remarks?.updated ?? false,
                    "updateFlag": "1"
                };

                bankMaster = {
                    "bankMasterFormState": bankMasterData,
                    "bankMasterUpdateState": bankMasterUpdateData,
                };
            })
            .catch((error) => {
                console.error(error);
            });
            
        dispatch(setOpenBackdrop(false));
            
        return bankMaster; 
    };

    return fetchRejectBankMaster;
}

export default useFetchRejectBankMaster;
