import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostMFGainsReject() {
    const dispatch = useDispatch();

    const postMFGainsReject = async (
        batchNo: string,
        clientId: string,
        clientName: string,
        processCode: string,
        rejectRemarks: string,
        role: "M" | "C" | "A",
        sourceuser: string,
        stageCode: string,
        userId: string,  
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "batchNo": batchNo,
            "clientId": clientId,
            "clientName": clientName,
            "processCode": processCode,
            "rejectRemarks": rejectRemarks,
            "role": role, // [C/A]
            "sourceUser": sourceuser,
            "stageCode": stageCode, // [ checker: MFPSEN, auditor: MFPAEN]
            "userId": userId,
        };

        console.log(data, 'DATA FOM POST HOOK');

        const axiosConfig = {
            "data": data,
            "url": "/reject",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postMFGainsReject;
}

export default usePostMFGainsReject;
