import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usefetchRejectIncomeDistributionRecords() {
    const dispatch = useDispatch();
    let uploadedMasterData: any;

    const fetchRejectIncomeDistributionRecords = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role: "M" | "C" |"A", 
        batchNo: string,
        self?: boolean,
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        let url = `/reject?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&role=${role}&batchNo=${batchNo}`;

        if (self !== undefined) {
            url += `&self=${self}`;
        }

        const axiosConfig = {
            "url": url,
        };


        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                uploadedMasterData = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return uploadedMasterData;
    };
    
    return fetchRejectIncomeDistributionRecords;
}

export default usefetchRejectIncomeDistributionRecords;
