import { ClientMasterDetails } from "../../../redux/AifMaster/ClientMaster/Maker/initialState";
import { 
    UpdateState 
} from "../../../pages/AIFMaster/ClientMaster/Maker/MakerClientMasterForm/helper/initializeUpdateState";

import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostClientMaster() {
    const dispatch = useDispatch();

    const postClientMaster = async (
        clientMasterState: ClientMasterDetails,
        sourceUser: string,
        updateFlag: "0" | "1",
        userId: string,
        userRole: "C" | "M",
        updateStatus: UpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "address1": {
                "update": updateStatus.address1,
                "value": clientMasterState.address1,
            },
            "address2": {
                "update": updateStatus.address2,
                "value": clientMasterState.address2,
            },
            "address3": {
                "update": updateStatus.address3,
                "value": clientMasterState.address3,
            },
            "agreementDate": {
                "update": updateStatus.agreementDate,
                "value": clientMasterState.agreementDate,
            },
            "city": {
                "update": updateStatus.city,
                "value": clientMasterState.city,
            },
            "ckycInstCode": {
                "update": updateStatus.ckycInstitutionCode,
                "value": clientMasterState.ckycInstitutionCode,
            },
            "ckycPassword": {
                "update": updateStatus.ckycPassword,
                "value": clientMasterState.ckycPassword,
            },
            "ckycUserId": {
                "update": updateStatus.ckycUserId,
                "value": clientMasterState.ckycUserId,
            },
            "ckycUserName": {
                "update": updateStatus.ckycUserName,
                "value": clientMasterState.ckycUserName,
            },
            "clientCode": clientMasterState.clientCode,
            "clientName": {
                "update": updateStatus.name,
                "value": clientMasterState.name,
            },
            "clientType": {
                "update": updateStatus.clientType,
                "value": clientMasterState.clientType,
            },
            "country": {
                "update": updateStatus.country,
                "value": clientMasterState.country,
            },
            "countryDialCode": "+91",
            "domicile": {
                "update": updateStatus.domicile,
                "value": clientMasterState.domicile,
            },
            "entryDate": currentData,
            "format": clientMasterState.logoFileFormat,
            "kraLoginId": {
                "update": updateStatus.kraUserId,
                "value": clientMasterState.kraUserId,
            },
            "kraName": {
                "update": updateStatus.kraName,
                "value": clientMasterState.kraName,
            },
            "kraPOSCode": {
                "update": updateStatus.kraPosCode,
                "value": clientMasterState.kraPosCode,
            },
            "kraPassword": {
                "update": updateStatus.kraPassword,
                "value": clientMasterState.kraPassword,
            },
            "kraUserName": {
                "update": updateStatus.kraUserName,
                "value": clientMasterState.kraUserName,
            },
            "landlineNo": {
                "update": updateStatus.landlineNumber,
                "value": clientMasterState.landlineNumber,
            },
            "legalEntIdCode": clientMasterState.legalEntityIdentificationCode,
            "legalEntIdCodeValidity": {
                "update": updateStatus.legalEntityIdentificationCodeValidity,
                "value": clientMasterState.legalEntityIdentificationCodeValidity,
            },
            "pan": {
                "update": updateStatus.permanentAccountNumber,
                "value": clientMasterState.permanentAccountNumber,
            },
            "path": clientMasterState.logoFileS3Key,
            "pin": {
                "update": updateStatus.pin,
                "value": clientMasterState.pin,
            },
            "role": userRole,
            "size": clientMasterState.logoFileSize,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "state": {
                "update": updateStatus.state,
                "value": clientMasterState.state,
            },
            "taxIdNo": {
                "update": updateStatus.taxIdentificationNumber,
                "value": clientMasterState.taxIdentificationNumber,
            },
            "updateFlag": updateFlag,
            // "userId": userRole === "M" ? "1001" : "2001"
            "userId": userId
        };

        const axiosConfig = {
            "data": data,
            "url": "/clientmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postClientMaster;
}

export default usePostClientMaster;
