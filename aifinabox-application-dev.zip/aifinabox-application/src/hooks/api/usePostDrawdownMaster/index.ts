import { DrawdownMasterDetails } from "../../../redux/AifMaster/DrawdownMaster/Maker/initialState";
import { 
    UpdateState 
} from "../../../pages/AIFMaster/DrawdownMaster/Maker/MakerDrawdownMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostDrawdownMaster() {
    const dispatch = useDispatch();

    const postDrawdownMaster = async (
        drawdownMasterState: DrawdownMasterDetails,
        sourceUser: string,
        updateExistingData: "0" | "1",
        userId: string,
        userRole: "C" | "M",
        updateStatus: UpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");
            
        const data =  {
            "allotmentDate1": {
                "updated": updateStatus.allotmentDate1,
                "value": drawdownMasterState.allotmentDate1
            },
            "allotmentDate2": {
                "updated": updateStatus.allotmentDate2, 
                "value": drawdownMasterState.allotmentDate2
            },
            "allotmentDate3": {
                "updated": updateStatus.allotmentDate3,
                "value": drawdownMasterState.allotmentDate3
            },
            "allotmentDate4": {
                "updated": updateStatus.allotmentDate4,
                "value": drawdownMasterState.allotmentDate4
            },
            "allotmentMethod": {
                "updated": updateStatus.allotmentMethod,
                "value": drawdownMasterState.allotmentMethod
            },
            "attachmentMail": {
                "updated": updateStatus.ddSourceFile,
                "value": drawdownMasterState.ddSourceFileS3Key
            },
            "clientCode": drawdownMasterState.clientCode,
            "clientName": drawdownMasterState.companyName,
            "ddExtentionDate": {
                "updated": updateStatus.ddExtensionDate,
                "value": drawdownMasterState.ddExtensionDate
            },
            "ddNo": {
                "updated": updateStatus.ddNo,
                "value": drawdownMasterState.ddNo
            },
            "endDate": {
                "updated": updateStatus.endDate,
                "value": drawdownMasterState.endDate
            },
            "entryDate": currentData,
            "eventId": drawdownMasterState.eventOrBatchId,

            "foliosApplicableFromDate": {
                "updated": updateStatus.foliosApplicableFromDate,
                "value": drawdownMasterState.foliosApplicableFromDate
            },
            "foliosApplicableToDate": {
                "updated": updateStatus.foliosApplicableToDate,
                "value": drawdownMasterState.foliosApplicableToDate
            },
            "fundClassCategory": {
                "updated": updateStatus.fundClassCategory,
                "value": drawdownMasterState.fundClassCategory
            },
            "fundCode": drawdownMasterState.fundCode, 
            "fundName": drawdownMasterState.fundName,        
            "isActive": {
                "updated": updateStatus.isActive,
                "value": drawdownMasterState.isActive
            },
            "percentageOfDD": {
                "updated": updateStatus.percentageOfDD,
                "value": drawdownMasterState.percentageOfDD
            },
            "role": userRole,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "startDate": {
                "updated": updateStatus.startDate,
                "value": drawdownMasterState.startDate
            },
            "totalCommitment": {
                "updated": updateStatus.totalCommitment,
                "value": drawdownMasterState.totalCommitment
            },
            "updateFlag": updateExistingData,
            // "userId": userRole === "M" ? "1001" : userRole === "C" ? "2001" : null
            "userId": userId
        };

        console.log(data);

        const axiosConfig = {
            "data": data,
            "url": "/ddmaster",
        };
        
        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
        
        dispatch(setOpenBackdrop(false));
    };

    return postDrawdownMaster;
}

export default usePostDrawdownMaster;
