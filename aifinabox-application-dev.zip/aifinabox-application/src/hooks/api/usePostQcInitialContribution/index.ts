import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostQcInitialContribution() {
    const dispatch = useDispatch();

    const postQcInitialContribution = async (
        transactionNumber: string,
        clientId: string,
        clientName: string,
        processCode: string,
        userRole: "C" | "M" | "Q" | "A",
        stageCode: string,
        userId: string,
        updatedFieldValue: any,
        folioNo: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "QC": updatedFieldValue,
            "clientId": clientId,
            "clientName": clientName,
            "folioNo": folioNo,
            "processCode": processCode,
            "role": userRole,
            "sourceUser": "Local",
            "stageCode": stageCode,
            "transactionNo": transactionNumber,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": "/initcontrib",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postQcInitialContribution;
}

export default usePostQcInitialContribution;
