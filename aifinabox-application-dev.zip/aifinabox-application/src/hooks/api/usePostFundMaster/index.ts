import { FundMasterDetails } from "../../../redux/AifMaster/FundMaster/Maker/initialState";
import { 
    UpdateState 
} from "../../../pages/AIFMaster/FundMaster/Maker/MakerFundMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostFundMaster() {
    const dispatch = useDispatch();

    const postFundMaster = async (
        fundMasterDetails: FundMasterDetails,
        sourceUser: string,
        userId: string,
        userRole: "A" | "M" | "C",
        updateFlag: "0" | "1",
        clientType: string,
        updateState: UpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentDate = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "clientCode": fundMasterDetails.fundBasicDetails.companyCode,
            "clientName": fundMasterDetails.fundBasicDetails.companyName,
            "clientType": clientType,
            "defaulterPenaltyApplicableOrNotApplicable": {
                "update": updateState.fundAdditionalInformationUpdateState.defaulterPenalty,
                "value": fundMasterDetails.fundAdditionalInformation.defaulterPenalty,
            },
            "distributionFrequency": {
                "update": updateState.fundAdditionalInformationUpdateState.distributionFrequency,
                "value": fundMasterDetails.fundAdditionalInformation.distributionFrequency,
            },
            "dormantDate": {
                "update": updateState.fundAdditionalInformationUpdateState.dormantDate,
                "value": fundMasterDetails.fundAdditionalInformation.dormantDate,
            },
            "entryDate": currentDate,
            "forexSource": {
                "update": updateState.fundAdditionalInformationUpdateState.forexSource,
                "value": fundMasterDetails.fundAdditionalInformation.forexSource,
            },
            "fundAccountantContactCountryCode": {
                "update": updateState.fundSpecificDetailsUpdateState.fundAccountantContactNumberPrefix,
                "value": fundMasterDetails.fundSpecificDetails.fundAccountantContactNumberPrefix,
            },
            "fundAccountantContactNumber": {
                "update": updateState.fundSpecificDetailsUpdateState.fundAccountantContactNumber,
                "value": fundMasterDetails.fundSpecificDetails.fundAccountantContactNumber,
            },
            "fundAccountantEmail": {
                "update": updateState.fundSpecificDetailsUpdateState.fundAccountantEmail,
                "value": fundMasterDetails.fundSpecificDetails.fundAccountantEmail,
            },
            "fundAccountantName": {
                "update": updateState.fundSpecificDetailsUpdateState.fundAccountantName,
                "value": fundMasterDetails.fundSpecificDetails.fundAccountantName,
            },
            "fundAdditionalFee": {
                "update": updateState.fundAdditionalInformationUpdateState.fundAdditionalFee,
                "value": fundMasterDetails.fundAdditionalInformation.fundAdditionalFee,
            },
            "fundBusinessType": {
                "update": updateState.fundBasicDetailsUpdateState.fundBusinessType,
                "value": fundMasterDetails.fundBasicDetails.fundBusinessType,
            },
            "fundCategory": fundMasterDetails.fundBasicDetails.fundCategory,
            "fundClientID": {
                "update": updateState.fundBasicDetailsUpdateState.fundClientId,
                "value": fundMasterDetails.fundBasicDetails.fundClientId,
            },
            "fundCode": fundMasterDetails.fundBasicDetails.fundCode,
            "fundCommitmentApplicability": {
                "update": updateState.fundAdditionalInformationUpdateState.fundCommitmentApplicability,
                "value": fundMasterDetails.fundAdditionalInformation.fundCommitmentApplicability,
            },
            "fundCurrency": {
                "update": updateState.fundBasicDetailsUpdateState.fundCurrency,
                "value": fundMasterDetails.fundBasicDetails.fundCurrency,
            },
            "fundCurrentDate": {
                "update": updateState.fundValuationInformationUpdateState.fundCurrentDate,
                "value": fundMasterDetails.fundValuationInformation.fundCurrentDate,
            },
            "fundCurrentYearEnd": {
                "update": updateState.fundValuationInformationUpdateState.fundCurrentYearEnd,
                "value": fundMasterDetails.fundValuationInformation.fundCurrentYearEnd,
            },
            "fundCustodianCode": {
                "update": updateState.fundSpecificDetailsUpdateState.fundCustodianCode,
                "value": fundMasterDetails.fundSpecificDetails.fundCustodianCode,
            },
            
            "fundDDNoticePeriod": {
                "update": updateState.fundValuationInformationUpdateState.fundDDNoticePeriod,
                "value": fundMasterDetails.fundValuationInformation.fundDDNoticePeriod,
            },
            "fundDDPenaltyCharges": {
                "update": updateState.fundValuationInformationUpdateState.fundDDPenaltyCharges,
                "value": fundMasterDetails.fundValuationInformation.fundDDPenaltyCharges,
            },
            "fundDDTreatment": {
                "update": updateState.fundValuationInformationUpdateState.fundDDTreatment,
                "value": fundMasterDetails.fundValuationInformation.fundDDTreatment,
            },
            "fundDPID": {
                "update": updateState.fundBasicDetailsUpdateState.fundDpId,
                "value": fundMasterDetails.fundBasicDetails.fundDpId,
            },
            "fundDepositoryType": {
                "update": updateState.fundBasicDetailsUpdateState.fundDepositoryType,
                "value": fundMasterDetails.fundBasicDetails.fundDepositoryType,
            },
            "fundDomicile": {
                "update": updateState.fundBasicDetailsUpdateState.fundDomicile,
                "value": fundMasterDetails.fundBasicDetails.fundDomicile,
            },
            "fundEndDate": {
                "update": updateState.fundSpecificDetailsUpdateState.fundEndDate,
                "value": fundMasterDetails.fundSpecificDetails.fundEndDate,
            },
            "fundFaceValue": {
                "update": updateState.fundBasicDetailsUpdateState.fundFaceValue,
                "value": fundMasterDetails.fundBasicDetails.fundFaceValue,
            },
            "fundFrom": {
                "update": updateState.fundBasicDetailsUpdateState.fundFrom,
                "value": fundMasterDetails.fundBasicDetails.fundFrom,
            },
            "fundISINNumber": {
                "update": updateState.fundBasicDetailsUpdateState.fundIsinNumber,
                "value": fundMasterDetails.fundBasicDetails.fundIsinNumber,
            },
            "fundInitialContributionAmount": {
                "update": updateState.fundSpecificDetailsUpdateState.fundInitialContributionAmount,
                "value": fundMasterDetails.fundSpecificDetails.fundInitialContributionAmount,
            },
            "fundInitialContributionCloseDate": {
                "update": updateState.fundSpecificDetailsUpdateState.fundInitialContributionCloseDate,
                "value": fundMasterDetails.fundSpecificDetails.fundInitialContributionCloseDate,
            },
            "fundInitialContributionPercentage": {
                "update": updateState.fundSpecificDetailsUpdateState.fundInitialContribution,
                "value": fundMasterDetails.fundSpecificDetails.fundInitialContribution,
            },
            "fundInitialContributionStartDate": {
                "update": updateState.fundSpecificDetailsUpdateState.fundInitialContributionStartDate,
                "value": fundMasterDetails.fundSpecificDetails.fundInitialContributionStartDate,
            },
            "fundInvestmentManager": {
                "update": updateState.fundSpecificDetailsUpdateState.fundInvestmentManager,
                "value": fundMasterDetails.fundSpecificDetails.fundInvestmentManager,
            },
            "fundManagementFee": {
                "update": updateState.fundAdditionalInformationUpdateState.fundManagementFee,
                "value": fundMasterDetails.fundAdditionalInformation.fundManagementFee,
            },
            "fundMaturityDate": {
                "update": updateState.fundSpecificDetailsUpdateState.fundMaturityDate,
                "value": fundMasterDetails.fundSpecificDetails.fundMaturityDate,
            },
            "fundMaxInvestors": {
                "update": updateState.fundSpecificDetailsUpdateState.fundMaxInvestors,
                "value": fundMasterDetails.fundSpecificDetails.fundMaxInvestors,
            },
            "fundName": {
                "update": updateState.fundBasicDetailsUpdateState.fundName,
                "value": fundMasterDetails.fundBasicDetails.fundName,
            },
            "fundNature": {
                "update": updateState.fundBasicDetailsUpdateState.fundNature,
                "value": fundMasterDetails.fundBasicDetails.fundNature,
            },
            "fundNextDate": {
                "update": updateState.fundValuationInformationUpdateState.fundNextDate,
                "value": fundMasterDetails.fundValuationInformation.fundNextDate,
            },
            "fundPLCompMethod": {
                "update": updateState.fundValuationInformationUpdateState.fundPlCompMethod,
                "value": fundMasterDetails.fundValuationInformation.fundPlCompMethod,
            },
            "fundPanOrTin": {
                "update": updateState.fundBasicDetailsUpdateState.panOrTin,
                "value": fundMasterDetails.fundBasicDetails.panOrTin,
            },
            "fundPeriodType": {
                "update": updateState.fundBasicDetailsUpdateState.fundPeriodSuffix,
                "value": fundMasterDetails.fundBasicDetails.fundPeriodSuffix,
            },
            "fundPeriodValue": {
                "update": updateState.fundBasicDetailsUpdateState.fundPeriod,
                "value": fundMasterDetails.fundBasicDetails.fundPeriod,
            },
            "fundPreviousDate": {
                "update": updateState.fundValuationInformationUpdateState.fundPreviousDate,
                "value": fundMasterDetails.fundValuationInformation.fundPreviousDate,
            },
            "fundPreviousYearEnd": {
                "update": updateState.fundValuationInformationUpdateState.fundPreviousYearEnd,
                "value": fundMasterDetails.fundValuationInformation.fundPreviousYearEnd,
            },
            "fundRTACode": {
                "update": updateState.fundSpecificDetailsUpdateState.fundRtaCode,
                "value": fundMasterDetails.fundSpecificDetails.fundRtaCode,
            },
            "fundRegistrationNumber": {
                "update": updateState.fundBasicDetailsUpdateState.fundRegistrationNumber,
                "value": fundMasterDetails.fundBasicDetails.fundRegistrationNumber,
            },
            "fundShortName": {
                "update": updateState.fundBasicDetailsUpdateState.fundShortName,
                "value": fundMasterDetails.fundBasicDetails.fundShortName,
            },
            "fundSizeCorpus": {
                "update": updateState.fundSpecificDetailsUpdateState.fundSize,
                "value": fundMasterDetails.fundSpecificDetails.fundSize,
            },
            "fundSpecificStartDate": {
                "update": updateState.fundSpecificDetailsUpdateState.fundStartDate,
                "value": fundMasterDetails.fundSpecificDetails.fundStartDate,
            },
            "fundSponsorName": {
                "update": updateState.fundSpecificDetailsUpdateState.fundSponsorName,
                "value": fundMasterDetails.fundSpecificDetails.fundSponsorName,
            },
            "fundStampDutyBourne": {
                "update": updateState.fundAdditionalInformationUpdateState.fundStampDutyBorne,
                "value": fundMasterDetails.fundAdditionalInformation.fundStampDutyBorne,
            },
            "fundSubCategory": fundMasterDetails.fundBasicDetails.fundSubCategory,
            "fundTopupTreatment": {
                "update": updateState.fundValuationInformationUpdateState.fundTopupTreatment,
                "value": fundMasterDetails.fundValuationInformation.fundTopupTreatment,
            },
            "fundTrusteeFee": {
                "update": updateState.fundAdditionalInformationUpdateState.fundTrusteeFee,
                "value": fundMasterDetails.fundAdditionalInformation.fundTrusteeFee,
            },
            "fundTrusteeName": {
                "update": updateState.fundSpecificDetailsUpdateState.fundTrusteeName,
                "value": fundMasterDetails.fundSpecificDetails.fundTrusteeName,
            },
            "fundValuationStartDate": {
                "update": updateState.fundValuationInformationUpdateState.fundStartDate,
                "value": fundMasterDetails.fundValuationInformation.fundStartDate,
            },
            "goodsAndServiceTax": {
                "update": updateState.fundAdditionalInformationUpdateState.goodsServiceTax,
                "value": fundMasterDetails.fundAdditionalInformation.goodsServiceTax,
            },
            "gpSharingRation": {
                "update": updateState.fundAdditionalInformationUpdateState.gpSharingRation,
                "value": fundMasterDetails.fundAdditionalInformation.gpSharingRation,
            },
            "gstin": fundMasterDetails.fundBasicDetails.gstin,
            "highWaterMark": {
                "update": updateState.fundAdditionalInformationUpdateState.highWaterMark,
                "value": fundMasterDetails.fundAdditionalInformation.highWaterMark,
            },
            "hurdleRate": {
                "update": updateState.fundAdditionalInformationUpdateState.hurdleRate,
                "value": fundMasterDetails.fundAdditionalInformation.hurdleRate,
            },
            "hurdleStartDate": {
                "update": updateState.fundAdditionalInformationUpdateState.hurdleStartDate,
                "value": fundMasterDetails.fundAdditionalInformation.hurdleStartDate,
            },
            "isActive": {
                "update": updateState.fundAdditionalInformationUpdateState.isActive,
                "value": fundMasterDetails.fundAdditionalInformation.isActive,
            },
            "isDormant": {
                "update": updateState.fundAdditionalInformationUpdateState.dormant,
                "value": fundMasterDetails.fundAdditionalInformation.dormant,
            },
            "legalAdvisorName": {
                "update": updateState.fundSpecificDetailsUpdateState.legalAdvisorName,
                "value": fundMasterDetails.fundSpecificDetails.legalAdvisorName,
            },
            "navFrequency": {
                "update": updateState.fundValuationInformationUpdateState.navFrequency,
                "value": fundMasterDetails.fundValuationInformation.navFrequency,
            },
            "navPubFrequency": {
                "update": updateState.fundValuationInformationUpdateState.navPubFrequency,
                "value": fundMasterDetails.fundValuationInformation.navPubFrequency,
            },
            "navPublishType": {
                "update": updateState.fundValuationInformationUpdateState.navPublishType,
                "value": fundMasterDetails.fundValuationInformation.navPublishType,
            },
            "navRatioMethod": {
                "update": updateState.fundAdditionalInformationUpdateState.navRadioMethod,
                "value": fundMasterDetails.fundAdditionalInformation.navRadioMethod,
            },
            "nextNAVDate": {
                "update": updateState.fundValuationInformationUpdateState.nextNavDate,
                "value": fundMasterDetails.fundValuationInformation.nextNavDate,
            },
            "nextNAVPubDate": {
                "update": updateState.fundValuationInformationUpdateState.nextNavPubDate,
                "value": fundMasterDetails.fundValuationInformation.nextNavPubDate,
            },
            "operatingExpensesApplicableOrNotApplicable": {
                "update": updateState.fundAdditionalInformationUpdateState.operatingExpenses,
                "value": fundMasterDetails.fundAdditionalInformation.operatingExpenses,
            },
            "preferredRateOfReturnApplicableOrNotApplicable": {
                "update": updateState.fundAdditionalInformationUpdateState.preferredRateOfReturn,
                "value": fundMasterDetails.fundAdditionalInformation.preferredRateOfReturn,
            },
            "prevNAVDate": {
                "update": updateState.fundValuationInformationUpdateState.prevNavDate,
                "value": fundMasterDetails.fundValuationInformation.prevNavDate,
            },
            "prevNAVPubDate": {
                "update": updateState.fundValuationInformationUpdateState.prevNavPubDate,
                "value": fundMasterDetails.fundValuationInformation.prevNavPubDate,
            },
            "role": userRole,
            "roundDecimals": {
                "update": updateState.fundValuationInformationUpdateState.roundDecimals,
                "value": fundMasterDetails.fundValuationInformation.roundDecimals,
            },
            "roundMethod": {
                "update": updateState.fundValuationInformationUpdateState.roundMethod,
                "value": fundMasterDetails.fundValuationInformation.roundMethod,
            },
            "serviceModel": fundMasterDetails.fundBasicDetails.serviceModel,
            "setupFee": {
                "update": updateState.fundAdditionalInformationUpdateState.setupFee,
                "value": fundMasterDetails.fundAdditionalInformation.setupFee,
            },
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "taxAdvisorName": {
                "update": updateState.fundSpecificDetailsUpdateState.taxAdvisorName,
                "value": fundMasterDetails.fundSpecificDetails.taxAdvisorName,
            },
            "transferAgentAccountantEmail": {
                "update": updateState.fundSpecificDetailsUpdateState.transferAgentAccountantEmail,
                "value": fundMasterDetails.fundSpecificDetails.transferAgentAccountantEmail,
            },
            "transferAgentContactCountryCode": {
                "update": updateState.fundSpecificDetailsUpdateState.transferAgentContactNumberPrefix,
                "value": fundMasterDetails.fundSpecificDetails.transferAgentContactNumberPrefix,
            },
            "transferAgentContactNumber": {
                "update": updateState.fundSpecificDetailsUpdateState.transferAgentContactNumber,
                "value": fundMasterDetails.fundSpecificDetails.transferAgentContactNumber,
            },
            "transferAgentName": {
                "update": updateState.fundSpecificDetailsUpdateState.transferAgentName,
                "value": fundMasterDetails.fundSpecificDetails.transferAgentName,
            },
            "unitDecimals": {
                "update": updateState.fundValuationInformationUpdateState.unitDecimals,
                "value": fundMasterDetails.fundValuationInformation.unitDecimals,
            },
            "updateFlag": updateFlag,
            // "userId": userRole === "M" ? "1001" : userRole === "C" ? "2001" : userRole === "A" ? "3001" : null,
            "userId": userId,
            "valuationSequence": {
                "update": updateState.fundValuationInformationUpdateState.valuationSequence,
                "value": fundMasterDetails.fundValuationInformation.valuationSequence,
            },  
        };

        const axiosConfig = {
            "data": data,
            "url": "/fundmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
            
        dispatch(setOpenBackdrop(false));
    };

    return postFundMaster;
}

export default usePostFundMaster;
