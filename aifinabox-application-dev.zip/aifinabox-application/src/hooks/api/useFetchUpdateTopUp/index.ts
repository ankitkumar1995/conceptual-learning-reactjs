import { UpdateTopUp, initializeUpdateTopUpState } from "./interfaces";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

// interface IhNumberResponse {
//     iHNumber: string;
// }

// interface UpdateTopupResponse {
//     // ihno: MenuItem[];
//     data: FolioDetails[];
// }

function useFetchUpdateTopUp() {
    const dispatch = useDispatch();

    const fetchUpdateTopUp = async (
        clientCode: string,
        folioNo: string,
    ): Promise<UpdateTopUp[]> => {
        dispatch(setOpenBackdrop(true));

        let topUpData: UpdateTopUp[] = [ initializeUpdateTopUpState ];

        const axiosConfig = {
            "url": `/updatetopup?clientCode=${clientCode}&folioNo=${folioNo}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                topUpData = [...response.data];
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return topUpData;
    };

    return fetchUpdateTopUp;
}

export default useFetchUpdateTopUp;
