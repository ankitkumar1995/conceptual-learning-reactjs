/* eslint-disable sort-keys */

interface PoaDetails {
    poaType: string;
    poaTaxIdNo: string;
    nameOfPoa: string;
};

interface AllotmentMode  {
    modeOfAllotment: string;
    repositoryType: string;
    dPId: string;
    clientId: string;
};

interface InvestmentDetails  {
    class: string;
    productType: string;
    schemeCode: string;
    schemeName: string;
    schemeIsinNo: string;
};

interface DistributorDetails  {
    distributorType: string;
    amcRmName: string;
    amcRmCode: string;
    distributorCode: string;
    distributorName: string;
};

interface GstWaiverAttachment {
    documentFormat: string | null;
    documentPath: string | null;
    documentSize: string | null;
};

interface TopUpDetails {
    allottedDate: string;
    applicableAmt: string;
    className: string;
    createNewFolioNo: string;
    folioNo: string;
    ihNo: string;
}

interface ContributionDetails  {
    existingCommitmentAmt: string;
    transactionCurrency: string;
    topUpCommitmentAmt: string;
    topUpContributionAmt: string;
    initContribAmt: string;
    exchngRate: string;
    fundCurrencyAmount: string;
    fundInitContribPercent: string;
    fundBusinessType: string;
    fundCurrency: string;
    otherFee: string;
    primaryHolderPercent: string;
    primaryHolderContrib: string;
    secondHolderPercent: string;
    secondHolderContrib: string;
    thirdHolderPercent: string;
    thirdHolderContrib: string;
    setupFeePercent: string;
    setupFeeAmt: string;
    gst: string;
    gstWaiver: string;
    gstWaiverAttachment: GstWaiverAttachment;
    totalSetupFee: string;
    paymentType: string | null;
    fundTopUpTreatment: string;
    topUp: TopUpDetails[];
};

interface DocumentDetails {
    documentFormat: string | null;
    documentPath: string | null;
    documentSize: string | null;
    timestamp?: string | null;
}

interface DocumentsProvided  {
    topUpRequestLetter: string;
    bankProofOrChequeCopy: string;
    amcApproval: string;
    poaNotaryAgreementCopy: string;
    initContribForm: string | null;
};

interface ForeignBankAccount {
    lastFourDigitsOfRegForeignBankAccNo: string;
    paymentBankAddr: string;
    paymentBankBranch: string;
    paymentBankIbanCode: string;
    paymentBankName: string;
    paymentBankSwiftAndBic: string;
    paymentForeignBankAccType: string;
    regPaymentForeignBankAccNo: string;
}
  
interface NationalBankAccount {
    lastFourDigOfRegBankAccountNo: string;
    paymentBankAccName: string;
    paymentBankAccNo: string;
    paymentBankAccType: string;
    paymentBankChqRefNo: {
      chequeAmount: string;
      chequeRefNo: string;
    }[];
    paymentBankIfsc: string;
    paymentBankMicr: string;
    paymentBankPennyDropStatus: string;
    paymentBankUtrNo: string;
    paymentType: string;
    pennyDropValidationDt: string;
}
  
interface PaymentBankDetails {
    primaryHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
    secondaryHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
    thirdHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
}

export interface UpdateTopUp {
    _id: string;
    clientId: string;
    clientName: string;
    transactionNo: string;
    parentTransactionNo: string | null;
    folioNo: string;
    endorsedFlag: boolean;
    invName: string;
    invCategory: string;
    invType: string;
    taxId: string;
    modeOfHolding: string;
    secHolderRelatshpWithPrimaryHolder: string;
    thirdHolderRelatshpWithPrimaryHolder: string | null;
    accreditationFlag: boolean;
    allotmentMode: AllotmentMode;
    poa: PoaDetails;
    distributorDetails: DistributorDetails;
    investmentDetails: InvestmentDetails;
    contributionDetails: ContributionDetails;
    updatedDocuments: DocumentDetails[];
    paymentBankDetails: PaymentBankDetails;
    documentsProvided: DocumentsProvided;
    updateFlag: string;
    recordStatus: number;
    revisionNo: number;
    currentStage: number;
    stage: string;
    initEntryUserId: string;
    secEntryUserId: string;
    ocUserId: string | null;
    auditorId: string;
    auditStatus: string;
    auditedOn: string;
}

export const initializeUpdateTopUpState: UpdateTopUp = {
    "_id": "",
    "clientId": "",
    "clientName": "",
    "transactionNo": "",
    "parentTransactionNo": null,
    "folioNo": "",
    "endorsedFlag": false,
    "invName": "",
    "invCategory": "",
    "invType": "",
    "taxId": "",
    "modeOfHolding": "",
    "secHolderRelatshpWithPrimaryHolder": "",
    "thirdHolderRelatshpWithPrimaryHolder": null,
    "accreditationFlag": false,
    "allotmentMode": {
        "modeOfAllotment": "",
        "repositoryType": "",
        "dPId": "",
        "clientId": "",
    },
    "poa": {
        "poaType": "",
        "poaTaxIdNo": "",
        "nameOfPoa": "",
    },
    "distributorDetails": {
        "distributorType": "",
        "distributorCode": "",
        "distributorName": "",
        "amcRmCode": "",
        "amcRmName": "",
    },
    "investmentDetails": {
        "schemeName": "",
        "schemeCode": "",
        "productType": "",
        "class": "",
        "schemeIsinNo": "",
    },
    "contributionDetails": {
        "existingCommitmentAmt": "",
        "transactionCurrency": "",
        "topUpCommitmentAmt": "",
        "topUpContributionAmt": "",
        "initContribAmt": "",
        "exchngRate": "",
        "fundCurrencyAmount": "",
        "fundInitContribPercent": "",
        "fundBusinessType": "",
        "fundCurrency": "",
        "otherFee": "",
        "primaryHolderPercent": "",
        "primaryHolderContrib": "",
        "secondHolderPercent": "",
        "secondHolderContrib": "",
        "thirdHolderPercent": "",
        "thirdHolderContrib": "",
        "setupFeePercent": "",
        "setupFeeAmt": "",
        "gst": "",
        "gstWaiver": "",
        "gstWaiverAttachment": {
            "documentFormat": null,
            "documentPath": null,
            "documentSize": null,
        },
        "totalSetupFee": "",
        "paymentType": null,
        "fundTopUpTreatment": "",
        "topUp": [
            {
                "allottedDate": "",
                "applicableAmt": "",
                "className": "",
                "createNewFolioNo": "",
                "folioNo": "",
                "ihNo": "",
            },
        ]
    },
    "updatedDocuments": [
        {
            "documentFormat": null,
            "documentPath": null,
            "documentSize": null,
            "timestamp": null,
        },
    ],
    "paymentBankDetails": {
        "primaryHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
        "secondaryHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
        "thirdHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
    },
    "documentsProvided": {
        "topUpRequestLetter": "",
        "bankProofOrChequeCopy": "",
        "amcApproval": "",
        "poaNotaryAgreementCopy": "",
        "initContribForm": null,
    },
    "updateFlag": "",
    "recordStatus": 1,
    "revisionNo": 0,
    "currentStage": 0,
    "stage": "",
    "initEntryUserId": "",
    "secEntryUserId": "",
    "ocUserId": null,
    "auditorId": "",
    "auditStatus": "",
    "auditedOn": "",
};

