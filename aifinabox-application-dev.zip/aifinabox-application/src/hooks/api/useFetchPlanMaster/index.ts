import { 
    PlanMasterDetails, 
    initialPlanMasterDetailsFormState 
} from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import initializeUpdateState, {
    UpdateState
} from "../../../redux/AifMaster/PlanMaster/Update/initialState";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";

import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

import { useDispatch } from "react-redux";

export interface FetchPlanMaster {
    planMasterMakerState: PlanMasterDetails;
    planMasterUpdateState: UpdateState;
    updateFlag: string;
};

function useFetchPlanMaster() {
    const dispatch = useDispatch();

    let planMasterData: PlanMasterDetails = initialPlanMasterDetailsFormState;
    let planMasterDataUpdate: UpdateState = initializeUpdateState();
    let planMaster: FetchPlanMaster;

    const fetchPlanMaster = async (
        clientCode: string,
        fundCode: string,
        planCode: string,
        updateExistingData: "0" | "1",
        userId: string,
    ): Promise<FetchPlanMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/planmaster?clientCode=${clientCode}&fundCode=${fundCode}&planCode=${planCode}&updateFlag=${updateExistingData}&userId=${userId}`,
        };
        
        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const planMasterMakerEntryFromApi = responseData[0];
                planMasterData = {
                    "clientCode": planMasterMakerEntryFromApi.clientCode,
                    "companyName": planMasterMakerEntryFromApi.clientName,
                    "fundCode": planMasterMakerEntryFromApi.fundCode,
                    "fundName": planMasterMakerEntryFromApi.fundName,
                    // "fundPlanCategory": planMasterMakerEntryFromApi.planCategory,
                    "fundPlanCategory": planMasterMakerEntryFromApi.planCategory.value,
                    "fundPlanCode": planMasterMakerEntryFromApi.planCode.value,
                    // "fundPlanDescription": planMasterMakerEntryFromApi.planDescription,
                    "fundPlanDescription": planMasterMakerEntryFromApi.planDescription.value,
                };

                planMasterDataUpdate = {
                    "clientCode": false,
                    "companyName": false,
                    "fundCode": false,
                    "fundName": false,
                    // "fundPlanCategory": planMasterMakerEntryFromApi.planCategory,
                    "fundPlanCategory": planMasterMakerEntryFromApi.planCategory.update,
                    "fundPlanCode": planMasterMakerEntryFromApi.planCode.update,
                    // "fundPlanDescription": planMasterMakerEntryFromApi.planDescription,
                    "fundPlanDescription": planMasterMakerEntryFromApi.planDescription.update,
                    "updateFlag": planMasterMakerEntryFromApi.updateFlag,
                };

                planMaster = {
                    'planMasterMakerState': planMasterData,
                    'planMasterUpdateState': planMasterDataUpdate,
                    "updateFlag": responseData.updateFlag
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return planMaster; 
    };

    return fetchPlanMaster;
}

export default useFetchPlanMaster;
