import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface TodoApiResultDataItem {
    fundName: string;
    createdBy: string;
    createdOn: string;
    batchNo: string;
    totalRecords: string;
    transactionNo: string;
}

export interface QueueItem {
    fundName: string;
    createdBy: string;
    creationOn: string;
    batchNo: string;
    totalRecords: string;
    transactionNo: string;
}

function useFetchRejectTodoQueueIncomeDistribution() {
    const dispatch = useDispatch();

    const fetchRejectTodoQueueIncomeDistribution = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userId: string,
        role:  "C" |"A", 
        pageIndex: number,
        queueLength: number,
    ): Promise<{
        ToDoQueue: QueueItem[];
        investorQueueItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let todoQueue: QueueItem[] = [];
        let investorQueueItemCount = 0;

        const axiosConfig = {
            "url": `/rejectqueue?stageCode=${stageCode}&userId=${userId}&processCode=${processCode}&pageIndex=${pageIndex}&queueLength=${queueLength}&clientId=${clientId}&role=${role}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response: any) => {
                const responseData = response.data.result;
                investorQueueItemCount = response.data.count;
                
                todoQueue = responseData.map((queueItem: {"contextDetails": TodoApiResultDataItem;}) => {
                    return queueItem;
                });

            })
            .catch((error) => {
                console.log(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "ToDoQueue": todoQueue,
            "investorQueueItemCount": investorQueueItemCount,
        };
    };
    
    return fetchRejectTodoQueueIncomeDistribution;
}

export default useFetchRejectTodoQueueIncomeDistribution;
