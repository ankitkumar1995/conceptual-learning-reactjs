import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface FundClassData {
    classCode: {
        value: string;
        update: boolean;
    };
}

function useFetchFundClass() {
    const dispatch = useDispatch();

    const fetchFundClass = async (
        clientCode: string,
        fundCode: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let classCodes: MenuItem[] = [];

        const axiosConfig = {
            "url": `/fundclass?clientCode=${clientCode}&fundCode=${fundCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const classCodesData = responseData;

                classCodes = classCodesData.map((classCodes: FundClassData) => ({
                    "label": classCodes.classCode.value,
                    "value": classCodes.classCode.value,
                }) as MenuItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classCodes;
    };

    return fetchFundClass;
}

export default useFetchFundClass;
