import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ExcelFile {
  fileName: string;
  format: string;
  bucketName: string;
  key: string;
  size: string;
}

interface SourceFile {
  fileName: string;
  format: string;
  bucketName: string;
  key: string;
  size: string;
}

function usePostIncomeDistributionSubmit() {
    const dispatch = useDispatch();

    const postIncomeDistributionSubmit = async (
        transactionNo: string,
        batchNo: string,
        clientId: string,
        clientName: string,
        userId: string,
        sourceuser: string,
        processCode: string,
        stageCode: string,
        role: string,
        sourceFile: SourceFile[],
        fundName: string
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "batchNo": batchNo,
            "clientId": clientId,
            "clientName": clientName,
            "fundName": fundName,
            "processCode": processCode,
            "role": role,
            "sourceFile": sourceFile,
            "sourceUser": sourceuser,
            "stageCode": stageCode,
            "transactionNo": transactionNo,
            "userId": userId,
        };

        console.log(data, 'DATA FOM POST HOOK');

        const axiosConfig = {
            "data": data,
            "url": "/initcontrib",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postIncomeDistributionSubmit;
}

export default usePostIncomeDistributionSubmit;
