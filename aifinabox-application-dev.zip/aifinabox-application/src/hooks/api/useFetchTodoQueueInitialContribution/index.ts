import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface QueueItems {
    _id: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    clientName: string;
    createdBy: string;
    createdOn: string;
    folioNumber: string;
    rejectRemarks?: string;
    sourceUser: string;
    transactionNo: string;
    transactionType: string;
}

export interface PendingItems {
    contextDetails: QueueItems;
}

interface ApiItems {
    _id: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    clientName?: string;
    createdBy: string;
    createdOn: string;
    folioNo: string;
    rejectRemarks?: string;
    sourceUser: string;
    transactionNo: string;
    transactionType: string;
}

interface ApiResultDataItem {
    contextDetails: ApiItems;
}

function useFetchTodoQueueInitialContribution() {
    const dispatch = useDispatch();

    const fetchTodoQueueInitialContribution = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userId: string,
        pageIndex: number,
        queueLength: number,
        role: "C" | "A" | "M" | "Q",
    ): Promise<{
        todoQueue: QueueItems[];
        itemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let todoQueue: QueueItems[] = [];
        let itemCount = 0;

        const axiosConfig = {
            "url": `/todoqueue?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&pageIndex=${pageIndex}&queueLength=${queueLength}&role=${role}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const pendingItems = responseData.result;
                
                itemCount = responseData.count;
                todoQueue = pendingItems.map((items: ApiResultDataItem) => {
                    const {
                        _id,
                        applicationId,
                        barcode,
                        branchId,
                        clientId,
                        createdBy,
                        createdOn,
                        folioNo,
                        sourceUser,
                        transactionNo,
                        transactionType,
                    } = items.contextDetails;
                    
                    return ({
                        "applicationId": (applicationId ?? ""),
                        "barcode": (barcode ?? ""),
                        "branchId": (branchId ?? ""),
                        "clientId": (clientId ?? ""),
                        "createdBy": createdBy,
                        "createdOn": createdOn,
                        "folioNumber": (folioNo ?? ""),
                        "sourceUser": (sourceUser ?? ""),
                        "transactionNo": (transactionNo ?? ""),
                        "transactionType": (transactionType ?? ""),
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "itemCount": itemCount,
            "todoQueue": todoQueue,
        };
    };
    
    return fetchTodoQueueInitialContribution;
}

export default useFetchTodoQueueInitialContribution;
