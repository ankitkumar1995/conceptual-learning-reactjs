import axios from "axios";

export interface RuleEngineResponse {
    errorMessage: string;
    errorCode: string;
    errorType: "E" | "W";
}

function usePostRuleEngineValidator() {

    const postRuleEngineValidator = async (
        attribute: Object,
        transactionType: string,
        dependencies?: Object,
        dependentNotRequired?: Array<any>,
    ): Promise<RuleEngineResponse | {}> => {
        let dependenciesData = (typeof dependencies !== "undefined") ? dependencies : {};
        let dependenciesNotRequiredData = (typeof dependentNotRequired !== "undefined") ? dependentNotRequired : [];
        let errorResponse: RuleEngineResponse | {} = {};
        let transaction = (transactionType.length !== 0) ? transactionType : "investorOnboarding";

        const attributeData = {
            ...attribute,
            ...dependenciesData,
        };

        let data = JSON.stringify({
            "attributes": attributeData,
            "dependentNotRequired": dependenciesNotRequiredData,
            "language": "en",
            "manfCode": "108",
            "source": "FE",
            "transactionType": transaction,
        });
        
        let config = {
            "data": data,
            "headers": { 
                'Content-Type': 'application/json',
                'authorizationToken': import.meta.env.VITE_AIF_IN_A_BOX_RULE_ENGINE_API_GATEWAY_TOKEN, 
            },
            "maxBodyLength": Infinity,
            "method": 'post',
            "url": 'https://92kz3wm723.execute-api.ap-south-1.amazonaws.com/dev/validate',
        };
        
        await axios.request(config)
            .then((response) => {
                let flag = 0;
                const responseData = response.data;
                const responseKeys = Object.keys(attributeData);

                for (let i=0; i< responseKeys.length; i++) {
                    const key = responseKeys[i];
                    const result = responseData[key];

                    if (flag > 0)
                        break;

                    if (typeof result !== "undefined") {
                        errorResponse = {
                            "errorCode": result[0].errorCode,
                            "errorMessage": result[0].message,
                            "errorType": result[0].errorType,
                        };

                        flag++;
                    }
                }
                // const result = responseData[key];

                // if (typeof result !== "undefined")
                //     errorResponse = {
                //         "errorCode": result[0].errorCode,
                //         "errorMessage": result[0].message,
                //         "errorType": result[0].errorType,
                //     };
            })
            .catch((error) => {
                console.log(error);
            });

        return errorResponse;
    };
    
    return postRuleEngineValidator;
}

export default usePostRuleEngineValidator;
