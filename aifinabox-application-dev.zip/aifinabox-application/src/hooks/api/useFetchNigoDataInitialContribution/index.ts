import { 
    InitialContributionInfo, 
    UserIdsType, 
    getInitialContributionInfo 
} from "../useGetInitialContribution";
import { useDispatch, useSelector } from "react-redux";

import GetInvestorType from "../useGetInvestor/interfaces/GetInvestor.types";
import { 
    MakerInitialContributionDetails 
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";
import { NigoDataResponse } from "./interfaces/InvestorNigo.types";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

interface Result {
    "nigoData": NigoDataResponse[];
    "qcData": MakerInitialContributionDetails;
    "userIds": UserIdsType;
}

function useFetchNigoDataInitialContribution() {
    const dispatch = useDispatch();
    
    let initialContributionInfo: InitialContributionInfo ;

    const fetchInitialContributionDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<Result> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/initcontrib?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        let nigoResponse: NigoDataResponse[] = [];

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                nigoResponse = responseData[0].QC;

                const investorDetailsFromApi: GetInvestorType = responseData[1];
                
                initialContributionInfo = getInitialContributionInfo(investorDetailsFromApi);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "nigoData": nigoResponse,
            "qcData": initialContributionInfo.initialContributionDetails,
            "userIds": initialContributionInfo.userIds,
        }; 
    };

    return fetchInitialContributionDetails;
}

export default useFetchNigoDataInitialContribution;
