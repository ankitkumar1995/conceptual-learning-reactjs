import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface PaymentBankDetails {
    bankName: string;
    accountNumber: string;
    accountType: string;
    swiftCode: string;
    bicCode: string;
    ibanCode: string;
    ifscCode: string;
    micrCode: string;
}

function useFetchPaymentBankDetails() {
    const dispatch = useDispatch();

    const fetchPaymentBankDetails = async (
        folioNo: string,
        foreignFlag: string,
        holder: string,
        last4Digits: string,
    ): Promise<PaymentBankDetails> => {
        dispatch(setOpenBackdrop(true));

        let paymentBankDetails: PaymentBankDetails = {
            "accountNumber": "",
            "accountType": "",
            "bankName": "",
            "bicCode": "",
            "ibanCode": "",
            "ifscCode": "",
            "micrCode": "",
            "swiftCode": "",
        };
          
        const axiosConfig = {
            "url": `/paymentbankdetails?folioNo=${folioNo}&foreignFlag=${foreignFlag}&holder=${holder}&last4Digits=${last4Digits}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response?.data;

                paymentBankDetails.accountNumber = responseData?.accountNumber;
                paymentBankDetails.accountType = responseData?.accountType;
                paymentBankDetails.bankName = responseData?.bankName;
                paymentBankDetails.bicCode = responseData?.bicCode;
                paymentBankDetails.ibanCode = responseData?.ibanCode;
                paymentBankDetails.swiftCode = responseData?.swiftCode;
                paymentBankDetails.ifscCode = responseData?.ifscCode;
                paymentBankDetails.micrCode = responseData?.micrCode;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return paymentBankDetails;
    };

    return fetchPaymentBankDetails;
}

export default useFetchPaymentBankDetails;
