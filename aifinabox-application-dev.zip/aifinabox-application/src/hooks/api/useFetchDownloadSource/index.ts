import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDownloadSource() {
    const dispatch = useDispatch();

    const fetchDownloadSource = async (
        clientId: string,        
        batchNo: string,
        role: "M" | "C" | "A",
        
    ): Promise<{
        "url": string[];
    }> => {
        dispatch(setOpenBackdrop(true));

        let templateURL: string[] = [];

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/downloadsourcefile?clientId=${clientId}&batchNo=${batchNo}&role=${role}`,
        };
 
        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                console.log("RESPONSE", response);
                const responseData = response.data.downloads;
                responseData.map((data: string, index: number) => {
                    templateURL.push(data);
                });
                console.log("Template", templateURL);
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));

        return  {
            "url": templateURL,
        }; 
    };

    return fetchDownloadSource;
}

export default useFetchDownloadSource;
