import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface QueueItems {
    _id: string;
    applicationId: string;
    clientId: string;
    clientName: string;
    createdBy: string;
    createdOn: string;
    folioNumber: string;
    rejectRemarks?: string;
    sourceUser: string;
    batchNo: string;
    role: "M" | "C" | "A" ;
    fundName: string;
}

export interface PendingItems {
    contextDetails: QueueItems;
}

interface ApiItems {
    _id: string;
    applicationId: string;
    clientId: string;
    clientName?: string;
    createdBy: string;
    createdOn: string;
    folioNo: string;
    rejectRemarks?: string;
    sourceUser: string;
    batchNo: string; 
    role: "M" | "C" | "A" ;
    fundName: string;
    totalRejected: number;
}
 
function useFetchRejectQueueMFGains() {
    const dispatch = useDispatch();

    const fetchRejectQueueMFGains = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userId: string,
        pageIndex: number,
        queueLength: number,
        role: "M" | "C" | "A",
    ): Promise<{
        rejectQueue: QueueItems[];
        itemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let rejectQueue: QueueItems[] = [];
        let itemCount = 0;

        //rejectqueue?pageIndex=0&clientId=101&queueLength=20&stageCode=MFPIEN&userId=2001
        const axiosConfig = {
            "url": `/rejectqueue?pageIndex=${pageIndex}&clientId=${clientId}&queueLength=${queueLength}&stageCode=${stageCode}&userId=${userId}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response.data;
                const pendingItems = responseData.result;
                itemCount = responseData.count;
                rejectQueue = pendingItems.map((items: ApiItems) => {
                    const {
                        _id,
                        applicationId,
                        clientId,
                        createdBy,
                        createdOn,
                        folioNo,
                        sourceUser,
                        batchNo,
                        fundName,
                        totalRejected,
                        rejectRemarks,
                    } = items;
                    
                    return ({
                        "applicationId": (applicationId ?? ""),
                        "batchNo": (batchNo ?? ""),                        
                        "clientId": (clientId ?? ""),
                        "createdBy": createdBy,
                        "createdOn": createdOn,
                        "folioNumber": (folioNo ?? ""),
                        "fundName": (fundName ?? ""),
                        "rejectRemarks": (rejectRemarks ?? ""),
                        "sourceUser": (sourceUser ?? ""),
                        "totalRejected": (totalRejected ?? ""),
                    });
                });
            })
            .catch((error) => {
                console.error("rejectTodoError", error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "itemCount": itemCount,
            "rejectQueue": rejectQueue,
        };
    };
    
    return fetchRejectQueueMFGains;
}

export default useFetchRejectQueueMFGains;
