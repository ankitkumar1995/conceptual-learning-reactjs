import { 
    DrawdownMasterDetails, 
    initialDrawdownMasterDetailsFormState 
} from "../../../redux/AifMaster/DrawdownMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState 
} from "../../../redux/AifMaster/DrawdownMaster/Update/initialState";

import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface DrawdownMaster {
    drawdownMasterFormState: DrawdownMasterDetails;
    drawdownMasterUpdateState: UpdateState;
}

function useFetchDrawdownMaster() {
    const dispatch = useDispatch();

    let drawdownMasterData: DrawdownMasterDetails = initialDrawdownMasterDetailsFormState;
    let drawdownMasterUpdateData: UpdateState = initializeUpdateState();
    let drawdownMaster: DrawdownMaster;

    const fetchDrawdownMaster = async (
        clientCode: string,
        updateExistingData: "0" | "1",
        fundClassCategory: string,
        fundCode: string,
        eventId: string,
        userId: string,
    ): Promise<DrawdownMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/ddmaster?clientCode=${clientCode}&updateFlag=${updateExistingData}&fundCode=${fundCode}&eventId=${eventId}&fundClassCategory=${fundClassCategory}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const drawdownMasterMakerEntryFromApi = responseData[0];

                drawdownMasterData = {
                    "allotmentDate1": drawdownMasterMakerEntryFromApi.allotmentDate1.value,
                    "allotmentDate2": drawdownMasterMakerEntryFromApi.allotmentDate2.value,
                    "allotmentDate3": drawdownMasterMakerEntryFromApi.allotmentDate3.value,
                    "allotmentDate4": drawdownMasterMakerEntryFromApi.allotmentDate4.value,
                    "allotmentMethod": drawdownMasterMakerEntryFromApi.allotmentMethod.value,
                    "clientCode": drawdownMasterMakerEntryFromApi.clientCode,
                    "companyName": drawdownMasterMakerEntryFromApi.clientName,
                    "ddExtensionDate": drawdownMasterMakerEntryFromApi.ddExtentionDate.value,
                    "ddNo": drawdownMasterMakerEntryFromApi.ddNo.value,
                    "ddSourceFile": null,
                    "ddSourceFileFormat": "",
                    "ddSourceFileS3Key": "",
                    "ddSourceFileS3SignedURL": "",
                    "endDate": drawdownMasterMakerEntryFromApi.endDate.value,
                    "eventOrBatchId": drawdownMasterMakerEntryFromApi.eventId,
                    "foliosApplicableFromDate": drawdownMasterMakerEntryFromApi.foliosApplicableFromDate.value,
                    "foliosApplicableToDate": drawdownMasterMakerEntryFromApi.foliosApplicableToDate.value,
                    "fundClassCategory": drawdownMasterMakerEntryFromApi.fundClassCategory.value,
                    "fundCode": drawdownMasterMakerEntryFromApi.fundCode,
                    "fundName": drawdownMasterMakerEntryFromApi.fundName,
                    "isActive": drawdownMasterMakerEntryFromApi.isActive.value,
                    "percentageOfDD": drawdownMasterMakerEntryFromApi.percentageOfDD.value,
                    "startDate": drawdownMasterMakerEntryFromApi.startDate.value,
                    "totalCommitment": drawdownMasterMakerEntryFromApi.totalCommitment.value,
                };

                drawdownMasterUpdateData = {
                    "allotmentDate1": drawdownMasterMakerEntryFromApi.allotmentDate1.updated,
                    "allotmentDate2": drawdownMasterMakerEntryFromApi.allotmentDate2.updated,
                    "allotmentDate3": drawdownMasterMakerEntryFromApi.allotmentDate3.updated,
                    "allotmentDate4": drawdownMasterMakerEntryFromApi.allotmentDate4.updated,
                    "allotmentMethod": drawdownMasterMakerEntryFromApi.allotmentMethod.updated,
                    "clientCode": false,
                    "companyName": false,
                    "ddExtensionDate": drawdownMasterMakerEntryFromApi.ddExtentionDate.updated,
                    "ddNo": drawdownMasterMakerEntryFromApi.ddNo.updated,
                    "ddSourceFile": false,
                    "endDate": drawdownMasterMakerEntryFromApi.endDate.updated,
                    "eventOrBatchId": drawdownMasterMakerEntryFromApi.eventId,
                    "foliosApplicableFromDate": drawdownMasterMakerEntryFromApi.foliosApplicableFromDate.updated,
                    "foliosApplicableToDate": drawdownMasterMakerEntryFromApi.foliosApplicableToDate.updated,
                    "fundClassCategory": drawdownMasterMakerEntryFromApi.fundClassCategory.updated,
                    "fundCode": false,
                    "fundName": false,
                    "isActive": drawdownMasterMakerEntryFromApi.isActive.updated,
                    "percentageOfDD": drawdownMasterMakerEntryFromApi.percentageOfDD.updated,
                    "startDate": drawdownMasterMakerEntryFromApi.startDate.updated,
                    "totalCommitment": drawdownMasterMakerEntryFromApi.totalCommitment.updated,
                    "updateFlag": drawdownMasterMakerEntryFromApi.updateFlag,
                };

                drawdownMaster = {
                    "drawdownMasterFormState": drawdownMasterData,
                    "drawdownMasterUpdateState": drawdownMasterUpdateData,
                };
            })
            .catch((error) => {
                console.log(error);
            });

        dispatch(setOpenBackdrop(false));

        return drawdownMaster; 
    };

    return fetchDrawdownMaster;
}

export default useFetchDrawdownMaster;
