import { BankMasterDetails } from "../../../redux/AifMaster/BankMaster/Maker/initialState";
import {
    UpdateState as CheckerUpdateState
} from "../../../pages/AIFMaster/BankMaster/Checker/CheckerBankMasterForm/helpers/initializeUpdateState";
import {
    UpdateState as MakerUpdateState
} from "../../../pages/AIFMaster/BankMaster/Maker/MakerBankMasterForm/helpers/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostBankMaster() {
    const dispatch = useDispatch();

    const postBankMaster = async (
        bankMasterState: BankMasterDetails,
        sourceUser: string,
        updateExistingData: "0" | "1",
        userId: string,
        userRole: "C" | "M",
        updateState: MakerUpdateState | CheckerUpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "accountType": {
                "updated": updateState.accountType,
                "value": bankMasterState.accountType
            },
            "bankAccountName": {
                "updated": updateState.bankAccountName,
                "value": bankMasterState.bankAccountName
            },
            "bankAccountNumber": {
                "updated": updateState.bankAccountNumber,
                "value": bankMasterState.bankAccountNumber
            },
            "bankCode": {
                "updated": updateState.bankCode,
                "value": bankMasterState.bankCode
            },
            "bankName": {
                "updated": updateState.corporateBankName,
                "value": bankMasterState.corporateBankName
            },
            "bicOrSwiftCode": {
                "updated": updateState.bicSwiftCode,
                "value": bankMasterState.bicSwiftCode
            },
            "branchName": {
                "updated": updateState.branchName,
                "value": bankMasterState.branchName
            },
            "chequeUpload": {
                "format": bankMasterState.proofFileFormat,
                "path": bankMasterState.proofFileS3Key,
                "size": bankMasterState.proofFileSize,
            },
            "city": {
                "updated": updateState.city,
                "value": bankMasterState.city
            },
            "clientCode": bankMasterState.companyCode,
            "clientName": bankMasterState.companyName,
            "corporateId": {
                "updated": updateState.corporateId,
                "value": bankMasterState.corporateId
            },
            "currency": {
                "updated": updateState.currency,
                "value": bankMasterState.currency
            },
            "defaultAccount": {
                "updated": updateState.defaultAccount,
                "value": bankMasterState.defaultAccount
            },
            "dormant": {
                "updated": updateState.dormant,
                "value": bankMasterState.dormant
            },
            "dormantDate": {
                "updated": updateState.dormantDate,
                "value": bankMasterState.dormantDate
            },
            "fundCode": bankMasterState.fundCode,
            "fundName": bankMasterState.fundName,
            "ifscOrRtgsCode": {
                "updated": updateState.bankIfscRtgsCode,
                "value": bankMasterState.bankIfscRtgsCode
            },
            "isActive": {
                "updated": updateState.isActive,
                "value": bankMasterState.isActive
            },
            "ownershipType": {
                "updated": updateState.ownershipType,
                "value": bankMasterState.ownershipType
            },
            "pennyDropStatus": {
                "updated": false,
                "value": false
            },
            "remarks": {
                "updated": updateState.remarks,
                "value": bankMasterState.remarks
            },
            "role": userRole,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "updateFlag": updateExistingData,
            // "userId": userRole === "M" ? "1001" : userRole === "C" ? "2001" : null,
            "userId": userId,
            "verifiedOn": currentData
        };

        const axiosConfig = {
            "data": data,
            "url": "/bankmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postBankMaster;
}

export default usePostBankMaster;
