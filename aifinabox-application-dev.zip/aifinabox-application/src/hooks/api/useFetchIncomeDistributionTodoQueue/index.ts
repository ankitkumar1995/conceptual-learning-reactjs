import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface CheckerApiResultDataItem {
    fundName: string;
    createdBy: string;
    createdOn: string;
    batchNo: string;
    transactionNo: string;
    totalNoOfRecords: number;
}
interface AuditorApiResultDataItem {
    fundName: string;
    createdBy: string;
    createdOn: string;
    batchNo: string;
    transactionNo: string;
    totalNoOfRecords: number;
}

export interface QueueItem {
    fundName: string;
    createdBy: string;
    creationOn: string;
    batchNo: string;
    transactionNo: string;
    totalNoOfRecords: number;
}

function useFetchIncomeDistributionTodoQueue() {
    const dispatch = useDispatch();

    const fetchIncomeDistributionTodoQueue = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role:  "C" |"A" | "M", 
        pageIndex: number, 
        queueLength: number,
    ): Promise<{
        ToDoQueue: QueueItem[];
        investorQueueItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let checkerInvestorQueue: QueueItem[] = [];
        let auditorInvestorQueue: QueueItem[] = [];
        let investorQueueItemCount = 0;

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/todoqueue?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&role=${role}&pageIndex=${pageIndex}&queueLength=${queueLength}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                investorQueueItemCount = responseData.count;

                checkerInvestorQueue = responseData.result.map((queueItem: {"contextDetails": CheckerApiResultDataItem;}) => {
                    const cardItem = queueItem.contextDetails;
                    const {
                        fundName,
                        createdBy,
                        createdOn,
                        batchNo,
                        totalNoOfRecords,
                        transactionNo,
                    } = cardItem;
                    
                    return ({
                        "batchNumber": batchNo,
                        "createdBy": createdBy,
                        "creationDate": createdOn,
                        "fundName": fundName,
                        "totalRecords": totalNoOfRecords,
                        "transactionNo": transactionNo,
                    });
                });

                auditorInvestorQueue = responseData.result.map((queueItem: {"contextDetails": AuditorApiResultDataItem;}) => {
                    const cardItem = queueItem.contextDetails;
                    const {
                        fundName,
                        createdBy,
                        createdOn,
                        batchNo,
                        totalNoOfRecords,
                        transactionNo
                    } = cardItem;
                    
                    return ({
                        "batchNumber": batchNo,
                        "createdBy": createdBy,
                        "creationDate": createdOn,
                        "fundName": fundName,
                        "totalRecords": totalNoOfRecords,
                        "transactionNo": transactionNo,
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "ToDoQueue": (role === "C") ? checkerInvestorQueue : auditorInvestorQueue,
            "investorQueueItemCount": investorQueueItemCount,
        };
    };
    
    return fetchIncomeDistributionTodoQueue;
}

export default useFetchIncomeDistributionTodoQueue;
