import { 
    ClassMasterDetails, 
    initialClassMasterDetailsFormState 
} from "../../../redux/AifMaster/ClassMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState 
} from "../../../redux/AifMaster/ClassMaster/Update/initialState";
import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FetchClassMaster {
    classMasterState: ClassMasterDetails;
    classMasterMakerState: ClassMasterDetails;
    classMasterUpdateState: UpdateState;
};

function useFetchRejectClassMaster() {
    const dispatch = useDispatch();

    let classMasterData: ClassMasterDetails = initialClassMasterDetailsFormState;
    let classMasterMakerData: ClassMasterDetails = initialClassMasterDetailsFormState;
    let classMasterDataUpdate: UpdateState = initializeUpdateState;
    let classMaster: FetchClassMaster;

    const fetchRejectClassMaster = async (
        bankAccountNumber: string,
        bankName: string, 
        classCode: string,
        clientCode: string,
        fundCode: string,
        masterName: MasterName, 
        planCode: string,
        role:  "C" | "M",
    ): Promise<FetchClassMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/reject?bankAccountNumber=${bankAccountNumber}&bankName=${bankName}&classCode=${classCode}&clientCode=${clientCode}&fundCode=${fundCode}&role=${role}&masterName=${masterName}&planCode=${planCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const classMasterMakerEntryFromApi = responseData[0];
                const classMasterMakerEntryFromApiMakerForm = responseData[0]["makerDetails"];

                classMasterData = {
                    "additionalFee": classMasterMakerEntryFromApi.fundClassAdditionalFee.value,
                    "carryPercentage": classMasterMakerEntryFromApi.fundClassCarryPercentage.value,
                    "catchupPercentage": classMasterMakerEntryFromApi.fundClassCatchupPercentage.value,
                    "classCode": classMasterMakerEntryFromApi.classCode.value,
                    "clientCode": classMasterMakerEntryFromApi.clientCode,
                    "companyName": classMasterMakerEntryFromApi.clientName,
                    "currency": classMasterMakerEntryFromApi.fundClassCurrency.value,
                    "description": classMasterMakerEntryFromApi.fundClassDescription.value,
                    "faceValue": classMasterMakerEntryFromApi.fundClassFaceValue.value,
                    "fundClassCategory": classMasterMakerEntryFromApi.fundClassCategory.value,
                    "fundCode": classMasterMakerEntryFromApi.fundCode,
                    "fundName": classMasterMakerEntryFromApi.fundName,
                    "fundPlanCode": classMasterMakerEntryFromApi.planCode,
                    "fundPlanName": classMasterMakerEntryFromApi.planName,
                    "fundSponsorClass": classMasterMakerEntryFromApi.fundSponsorClass.value,
                    "gstRate": classMasterMakerEntryFromApi.fundClassGstRate.value,
                    "highWaterMark": classMasterMakerEntryFromApi.highWaterMark.value,
                    "hurdleRate": classMasterMakerEntryFromApi.fundClassHurdleRate.value,
                    "incomeDistFrequency": classMasterMakerEntryFromApi.incomeDistFrequency.value,
                    "isActive": classMasterMakerEntryFromApi.isActive.value,
                    "isinCode": classMasterMakerEntryFromApi.isinCode.value,
                    "managementFee": classMasterMakerEntryFromApi.fundClassManagementFee.value,
                    "maxAmount": classMasterMakerEntryFromApi.fundClassMaxAmount.value,
                    "maxReturn": classMasterMakerEntryFromApi.fundClassMaxReturn.value,
                    "minAmount": classMasterMakerEntryFromApi.fundClassMinAmount.value,
                    "orgFee": classMasterMakerEntryFromApi.fundClassOrgFee.value,
                    "perFeePercentage": classMasterMakerEntryFromApi.fundClassPerFeePercentage.value,
                    "performanceFee": classMasterMakerEntryFromApi.fundClassPerformanceFee.value,
                    "preferredReturn": classMasterMakerEntryFromApi.fundClassPreferredReturn.value,
                    "setUpFee": classMasterMakerEntryFromApi.setupFee.value,
                    "shareRatio": classMasterMakerEntryFromApi.fundClassShareRatio.value,
                };
                classMasterMakerData = {
                    "additionalFee": classMasterMakerEntryFromApiMakerForm.fundClassAdditionalFee.value,
                    "carryPercentage": classMasterMakerEntryFromApiMakerForm.fundClassCarryPercentage.value,
                    "catchupPercentage": classMasterMakerEntryFromApiMakerForm.fundClassCatchupPercentage.value,
                    "classCode": classMasterMakerEntryFromApiMakerForm.classCode.value,
                    "clientCode": classMasterMakerEntryFromApiMakerForm.clientCode,
                    "companyName": classMasterMakerEntryFromApiMakerForm.clientName,
                    "currency": classMasterMakerEntryFromApiMakerForm.fundClassCurrency.value,
                    "description": classMasterMakerEntryFromApiMakerForm.fundClassDescription.value,
                    "faceValue": classMasterMakerEntryFromApiMakerForm.fundClassFaceValue.value,
                    "fundClassCategory": classMasterMakerEntryFromApiMakerForm.fundClassCategory.value,
                    "fundCode": classMasterMakerEntryFromApiMakerForm.fundCode,
                    "fundName": classMasterMakerEntryFromApiMakerForm.fundName,
                    "fundPlanCode": classMasterMakerEntryFromApiMakerForm.planCode,
                    "fundPlanName": classMasterMakerEntryFromApiMakerForm.planName,
                    "fundSponsorClass": classMasterMakerEntryFromApiMakerForm.fundSponsorClass.value,
                    "gstRate": classMasterMakerEntryFromApiMakerForm.fundClassGstRate.value,
                    "highWaterMark": classMasterMakerEntryFromApiMakerForm.highWaterMark.value,
                    "hurdleRate": classMasterMakerEntryFromApiMakerForm.fundClassHurdleRate.value,
                    "incomeDistFrequency": classMasterMakerEntryFromApiMakerForm.incomeDistFrequency.value,
                    "isActive": classMasterMakerEntryFromApiMakerForm.isActive.value,
                    "isinCode": classMasterMakerEntryFromApiMakerForm.isinCode.value,
                    "managementFee": classMasterMakerEntryFromApiMakerForm.fundClassManagementFee.value,
                    "maxAmount": classMasterMakerEntryFromApiMakerForm.fundClassMaxAmount.value,
                    "maxReturn": classMasterMakerEntryFromApiMakerForm.fundClassMaxReturn.value,
                    "minAmount": classMasterMakerEntryFromApiMakerForm.fundClassMinAmount.value,
                    "orgFee": classMasterMakerEntryFromApiMakerForm.fundClassOrgFee.value,
                    "perFeePercentage": classMasterMakerEntryFromApiMakerForm.fundClassPerFeePercentage.value,
                    "performanceFee": classMasterMakerEntryFromApiMakerForm.fundClassPerformanceFee.value,
                    "preferredReturn": classMasterMakerEntryFromApiMakerForm.fundClassPreferredReturn.value,
                    "setUpFee": classMasterMakerEntryFromApiMakerForm.setupFee.value,
                    "shareRatio": classMasterMakerEntryFromApiMakerForm.fundClassShareRatio.value,
                };

                classMasterDataUpdate = {
                    "additionalFee": classMasterMakerEntryFromApi.fundClassAdditionalFee.update,
                    "carryPercentage": classMasterMakerEntryFromApi.fundClassCarryPercentage.update,
                    "catchupPercentage": classMasterMakerEntryFromApi.fundClassCatchupPercentage.update,
                    "classCode": classMasterMakerEntryFromApi.classCode.update,
                    "currency": classMasterMakerEntryFromApi.fundClassCurrency.update,
                    "description": classMasterMakerEntryFromApi.fundClassDescription.update,
                    "faceValue": classMasterMakerEntryFromApi.fundClassFaceValue.update,
                    "fundClassCategory": classMasterMakerEntryFromApi.fundClassCategory.update,
                    "fundSponsorClass": classMasterMakerEntryFromApi.fundSponsorClass.update,
                    "gstRate": classMasterMakerEntryFromApi.fundClassGstRate.update,
                    "highWaterMark": classMasterMakerEntryFromApi.highWaterMark.update,
                    "hurdleRate": classMasterMakerEntryFromApi.fundClassHurdleRate.update,
                    "incomeDistFrequency": classMasterMakerEntryFromApi.incomeDistFrequency.update,
                    "isActive": classMasterMakerEntryFromApi.isActive.update,
                    "isinCode": classMasterMakerEntryFromApi.isinCode.update,
                    "managementFee": classMasterMakerEntryFromApi.fundClassManagementFee.update,
                    "maxAmount": classMasterMakerEntryFromApi.fundClassMaxAmount.update,
                    "maxReturn": classMasterMakerEntryFromApi.fundClassMaxReturn.update,
                    "minAmount": classMasterMakerEntryFromApi.fundClassMinAmount.update,
                    "orgFee": classMasterMakerEntryFromApi.fundClassOrgFee.update,
                    "perFeePercentage": classMasterMakerEntryFromApi.fundClassPerFeePercentage.update,
                    "performanceFee": classMasterMakerEntryFromApi.fundClassPerformanceFee.update,
                    "preferredReturn": classMasterMakerEntryFromApi.fundClassPreferredReturn.update,
                    "setUpFee": classMasterMakerEntryFromApi.setupFee.update,
                    "shareRatio": classMasterMakerEntryFromApi.fundClassShareRatio.update,
                    "updateFlag": classMasterMakerEntryFromApi.updateFlag,
                };

                classMaster = {
                    "classMasterMakerState": classMasterMakerData,
                    "classMasterState": classMasterData,
                    "classMasterUpdateState": classMasterDataUpdate,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classMaster; 
    };

    return fetchRejectClassMaster;
}

export default useFetchRejectClassMaster;
