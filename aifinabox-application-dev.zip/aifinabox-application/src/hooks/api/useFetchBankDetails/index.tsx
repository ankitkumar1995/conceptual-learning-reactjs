import {
    BankDetailsType
} from "../../../pages/AIFMaster/BankMaster/Maker/MakerBankMasterForm/interfaces/bankDetails";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchBankDetails() {
    const dispatch = useDispatch();

    const fetchBankDetails = async (
        clientCode: string,
        ifscOrRtgsCode: string,
    ): Promise<BankDetailsType[]> => {
        dispatch(setOpenBackdrop(true));

        let bankDetails: BankDetailsType[] = [];

        const axiosConfig = {
            "url": `/bankdetails?clientCode=${clientCode}&ifscOrRtgsCode=${ifscOrRtgsCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                bankDetails = response.data;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankDetails; 
    };

    return fetchBankDetails;
}

export default useFetchBankDetails;
