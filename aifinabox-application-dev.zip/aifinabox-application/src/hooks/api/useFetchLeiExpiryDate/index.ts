import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchLeiExpiryDate() {
    const dispatch = useDispatch();

    const fetchLeiExpiryDate = async (
        leiNumber: string,
    ): Promise<string> => {
        dispatch(setOpenBackdrop(true));

        let leiExpiryDate: string = "";

        const axiosConfig = {
            "url": `lei?lei=${leiNumber}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const {expiryDate} = responseData;
                leiExpiryDate = expiryDate;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return leiExpiryDate; 
    };

    return fetchLeiExpiryDate;
}

export default useFetchLeiExpiryDate;
