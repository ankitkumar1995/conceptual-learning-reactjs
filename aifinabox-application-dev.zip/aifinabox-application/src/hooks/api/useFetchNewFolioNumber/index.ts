import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface FolioNumber {
    newFolioNumber: string;
}

function useFetchNewFolioNumber() {
    const dispatch = useDispatch();

    const fetchNewFolioNumber = async (
        seriesCode: string,
    ): Promise<FolioNumber> => {
        dispatch(setOpenBackdrop(true));

        let newFolioNumber: FolioNumber = {
            "newFolioNumber": "",
        };

        const axiosConfig = {
            "url": `/sequencenumber?seriesCode=${seriesCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;

                newFolioNumber = {
                    "newFolioNumber": responseData,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return newFolioNumber;
    };

    return fetchNewFolioNumber;
}

export default useFetchNewFolioNumber;
