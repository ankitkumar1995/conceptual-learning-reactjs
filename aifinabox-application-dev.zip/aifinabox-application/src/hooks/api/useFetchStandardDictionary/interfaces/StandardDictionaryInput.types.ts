export interface StandardDictionaryInput {
    dictionaryCode: string;
    response: string[];
}
