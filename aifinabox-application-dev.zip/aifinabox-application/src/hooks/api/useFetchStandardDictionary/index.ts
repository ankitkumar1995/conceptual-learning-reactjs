import { MenuItem } from "../../../interfaces/MenuItem.types";
import { STANDARD_DICTIONARY_CODES } from "./constants";
import { StandardDictionaryCode } from "./interfaces/StandardDictionaryCode.types";
import { StandardDictionaryInput } from "./interfaces/StandardDictionaryInput.types";
import actionProvider from "./helpers/actionProvider";
import masterAxiosInstance from "../../../axios/instances/masterFetchAxiosInstance";
import { useDispatch } from "react-redux";
import { useEffect } from "react";

function useFetchStandardDictionary() {
    const dispatch = useDispatch();

    const standardDictionaryAxiosData = JSON.stringify({
        "dictionaryType": STANDARD_DICTIONARY_CODES,
    });

    const standardDictionaryAxiosConfig = {
        "data": standardDictionaryAxiosData,
        "method": "post",
        "url": "/standarddictionary",
    };

    useEffect(() => {
        masterAxiosInstance(standardDictionaryAxiosConfig)
            .then((response) => {
                const { standardDictionary } = response.data;

                standardDictionary.map((field: StandardDictionaryInput) => {
                    const {
                        dictionaryCode,
                        response,
                    } = field;

                    let updatedResponse = response.filter((res: any) => {
                        return (res !== "");
                    });

                    if (dictionaryCode === "TRNTYP") {
                        const menuItems: MenuItem[] = updatedResponse.map((res: any) => {
                            // if (res === "")
                            //     return ({
                            //         "label": "Select",
                            //         "value": "",
                            //     });
    
                            return ({
                                "label": res.description,
                                "value": res.code,
                            });
                        });

                        const action = actionProvider(dictionaryCode as StandardDictionaryCode);
                        if (action) dispatch(action(menuItems));

                        return;
                    }
                    const menuItems: MenuItem[] = updatedResponse.map((value: string) => {
                        // if (value === "")
                        //     return ({
                        //         "label": "Select",
                        //         "value": "",
                        //     });

                        return ({
                            "label": value,
                            "value": value,
                        });
                    });

                    const action = actionProvider(dictionaryCode as StandardDictionaryCode);
                    if (action) dispatch(action(menuItems));
                });
            })
            .catch((error) => {
                console.error(error);
            });
    }, []);
}

export default useFetchStandardDictionary;
