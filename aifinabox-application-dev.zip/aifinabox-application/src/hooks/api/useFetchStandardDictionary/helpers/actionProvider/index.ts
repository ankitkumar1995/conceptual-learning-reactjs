import {
    setAccountTypeMenuItems,
    setAllotmentMethodMenuItems,
    setBankAccountTypeMenuItems,
    setClientTypeMenuItems,
    setDebitTypeMenuItems,
    setDistributionFrequencyMenuItems,
    setDistributorTypeMenuItems,
    setEmailIdPertainToMenuItems,
    setEntityConstituionTypeMenuItems,
    setFatcaPartAMenuItems,
    setFatcaPartBMenuItems,
    setForexSourceMenuItems,
    setFundBusinessTypeMenuItems,
    setFundCategoryMenuItems,
    setFundClassCategoryMenuItems,
    setFundCustodianCodeMenuItems,
    setFundDDTreatmentMenuItems,
    setFundDepositoryTypeMenuItems,
    setFundNatureMenuItems,
    setFundPLCompMethodMenuItems,
    setFundPeriodMenuItems,
    setFundStampDutyBorneMenuItems,
    setFundSubCategory1MenuItems,
    setFundSubCategory2MenuItems,
    setFundSubCategory3MenuItems,
    setFundTopupTreatmentMenuItems,
    setGenderMenuItems,
    setGiinNotAvailableMenuItems,
    setGuardianRelationshipMenuItems,
    setHolderOccupationDetailsMenuItems,
    setHonorificsMenuItems,
    setIncomeSlabOrGrossAnnualIncomeMenuItems,
    setIndividualHolderTaxStatusMenuItems,
    setIndividualInvestorCategoryMenuItems,
    setInvestorTypeMenuItems,
    setInvolvedInMentionServicesMenuItems,
    setKraAddressTypeForIndividualMenuItems,
    setKraAddressTypeForNonIndividualMenuItems,
    setKraNameMenuItems,
    setMobileNumberPertainToEntityMenuItems,
    setMobileNumberPertainToFamilyFlagMenuItems,
    setModeOfAllotmentMenuItems,
    setModeOfHoldingMenuItems,
    setNatureOfRelationMenuItems,
    setNavRatioMethodMenuItems,
    setNomineeDetailsMenuItems,
    setNomineeRelationshipMenuItems,
    setNonIndividualBankTypeMenuItem,
    setNonIndividualHolderTaxStatusMenuItems,
    setNonIndividualInvestorCategoryMenuItems,
    setNonResidentIndianBankTypeMenuItem,
    setNumberOfInstallmentsMenuItems,
    setOccupationTypeMenuItems,
    setOwnershipTypeMenuItems,
    setPaymentTypeMenuItems,
    setPoaTypeMenuItems,
    setPoliticallyExposedPersonMenuItems,
    setResidentIndianBankTypeMenuItem,
    setRoundMethodMenuItems,
    setSalutationMenuItems,
    setServiceModelMenuItems,
    setSipFrequencyMenuItems,
    setStateMenuItems,
    setTaxIdTypeMenuItems,
    setTransactionTypeMenuItems,
    setTrustTypeMenuItems,
    setUboCategoryMenuItems,
    setUboCodeMenuItems,
    setValuationSequenceMenuItems,
} from "../../../../../redux/SelectInputMenuItems/reducer";

import { StandardDictionaryCode } from "../../interfaces/StandardDictionaryCode.types";

function actionProvider(dictionaryCode: StandardDictionaryCode) {
    switch (dictionaryCode) {
    case "ACCTYPE":
        return setAccountTypeMenuItems;

    case "ALTMTHD":
        return setAllotmentMethodMenuItems;

    case "BACCTYP":
        return setBankAccountTypeMenuItems;

    case "CLNTYP":
        return setClientTypeMenuItems;

    case "DEBTYP":
        return setDebitTypeMenuItems;

    case "DISTYP":
        return setDistributorTypeMenuItems;

    case "ENCSTYP":
        return setEntityConstituionTypeMenuItems;

    case "FATCAA":
        return setFatcaPartAMenuItems;

    case "FATCAB":
        return setFatcaPartBMenuItems;

    case "HNRFCS":
        return setHonorificsMenuItems;

    case "KRANAME":
        return setKraNameMenuItems;

    case "FNDCLSCAT": 
        return setFundClassCategoryMenuItems;

    case "FNDPRD":
        return setFundPeriodMenuItems;

    case "FNDBTYP":
        return setFundBusinessTypeMenuItems;

    case "SRVCMOD":
        return setServiceModelMenuItems;

    case "FNDCAT": 
        return setFundCategoryMenuItems;

    case "FCAT1": 
        return setFundSubCategory1MenuItems;

    case "FCAT2":
        return setFundSubCategory2MenuItems;

    case "FCAT3":
        return setFundSubCategory3MenuItems;

    case "FNDNAT":
        return setFundNatureMenuItems;

    case "FNDDEPTYP":
        return setFundDepositoryTypeMenuItems;

    case "FNDPLCOMP":
        return setFundPLCompMethodMenuItems;

    case "VALSEQ":
        return setValuationSequenceMenuItems;

    case "RNDMTHD":
        return setRoundMethodMenuItems;

    case "FNDTPT":
        return setFundTopupTreatmentMenuItems;

    case "FDDTRMNT":
        return setFundDDTreatmentMenuItems;

    case "DSTFRQ":
        return setDistributionFrequencyMenuItems;

    case "FRXSRC":
        return setForexSourceMenuItems;

    case "MNPT":
        return setEmailIdPertainToMenuItems;

    case "MNPTFF":
        return setMobileNumberPertainToFamilyFlagMenuItems;

    case "MODOFA":
        return setModeOfAllotmentMenuItems;

    case "MODOFH":
        return setModeOfHoldingMenuItems;

    case "NATOR":
        return setNatureOfRelationMenuItems;

    case "NIMPT":
        return setMobileNumberPertainToEntityMenuItems;

    case "NOFINS":
        return setNumberOfInstallmentsMenuItems;

    case "NOMDET":
        return setNomineeDetailsMenuItems;

    case "NOMREL":
        return setNomineeRelationshipMenuItems;

    case "NVRTMTHD":
        return setNavRatioMethodMenuItems;

    case "FNDSTMP":
        return setFundStampDutyBorneMenuItems;

    case "FNDCUSTCD":
        return setFundCustodianCodeMenuItems;

    case "GENDER":
        return setGenderMenuItems;

    case "GIINNA":
        return setGiinNotAvailableMenuItems;

    case "GRDRSP":
        return setGuardianRelationshipMenuItems;

    case "INVCATI":
        return setIndividualInvestorCategoryMenuItems;

    case "INVCATN":
        return setNonIndividualInvestorCategoryMenuItems;

    case "INVMS":
        return setInvolvedInMentionServicesMenuItems;

    case "INVTYP":
        return setInvestorTypeMenuItems;

    case "NRIBT":
        return setNonResidentIndianBankTypeMenuItem;

    case "OCCTYP":
        return setOccupationTypeMenuItems;

    case "OWNTYP":
        return setOwnershipTypeMenuItems;

    case "PAYTYP":
        return setPaymentTypeMenuItems;

    case "PEP":
        return setPoliticallyExposedPersonMenuItems;

    case "PHISGA":
        return setIncomeSlabOrGrossAnnualIncomeMenuItems;

    case "PHOCCD":
        return setHolderOccupationDetailsMenuItems;

    case "PHTXSTI":
        return setIndividualHolderTaxStatusMenuItems;

    case "PHTXSTN":
        return setNonIndividualHolderTaxStatusMenuItems;

    case "POATYP":
        return setPoaTypeMenuItems;

    case "RIBT":
        return setResidentIndianBankTypeMenuItem;

    case "SALUTN":
        return setSalutationMenuItems;

    case "SCOAN":
        return setUboCodeMenuItems;

    case "SIPFRQ":
        return setSipFrequencyMenuItems;

    case "SUT":
        return setStateMenuItems;

    case "TRNTYP":
        return setTransactionTypeMenuItems;

    case "TRSTYP":
        return setTrustTypeMenuItems;

    case "TXIDTYP":
        return setTaxIdTypeMenuItems;

    case "TYPKRAI":
        return setKraAddressTypeForIndividualMenuItems;

    case "TYPKRAN":
        return setKraAddressTypeForNonIndividualMenuItems;

    case "UBOCAT":
        return setUboCategoryMenuItems;

    case "NIBT":
        return setNonIndividualBankTypeMenuItem;
    }
}

export default actionProvider;
