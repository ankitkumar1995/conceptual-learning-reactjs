import { MasterName } from "../interfaces/MasterName.types";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FundDetails {
    fundCategory: MenuItem;
    fundCode: MenuItem;
    fundName: MenuItem;
}

function useFetchUnEndorsedTransaction() {
    const dispatch = useDispatch();

    const fetchUnEndorsedTransaction = async (
        clientId: string,
        transactionType: string,    //"MFG" | "MFP",
        fundCode: string,
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        let templateURL: string = "";

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/unendorsedtransactions?clientId=${clientId}&fundCode=${fundCode}&transactionType=${transactionType}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                templateURL = responseData.download;
                
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return  templateURL; 
    };

    return fetchUnEndorsedTransaction;
}

export default useFetchUnEndorsedTransaction;
