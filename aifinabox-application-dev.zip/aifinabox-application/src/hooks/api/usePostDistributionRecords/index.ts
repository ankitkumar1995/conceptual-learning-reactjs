import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostDistributionRecords() {
    const dispatch = useDispatch();

    const postDistributionRecords = async (
        records: []
    ) => {
        let responseData;
        dispatch(setOpenBackdrop(true));

        const data = records;

        const axiosConfig = {
            "data": data,
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/distributionrecords`,
        };

        await databasePostAxiosInstance(axiosConfig)
            .then((response) => {
                responseData = response.data;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
        return responseData;
    };
    
    return postDistributionRecords;
}

export default usePostDistributionRecords;
