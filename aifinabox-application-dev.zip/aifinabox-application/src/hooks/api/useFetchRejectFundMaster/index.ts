import { 
    FundMasterDetails, 
    initialFundMasterDetailsFormState 
} from "../../../redux/AifMaster/FundMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState,
} from "../../../redux/AifMaster/FundMaster/Update/initialState";
import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";



export interface FundMaster {
    fundMasterFormState: FundMasterDetails;
    fundMasterMakerFormState: FundMasterDetails;
    fundMasterUpdateState: UpdateState;
}

function useFetchRejectFundMaster() {
    const dispatch = useDispatch();

    let fundMasterData: FundMasterDetails = initialFundMasterDetailsFormState;
    let fundMasterMakerData: FundMasterDetails = initialFundMasterDetailsFormState;
    let fundMasterUpdateData: UpdateState = initializeUpdateState();
    let fundMaster: FundMaster;

    const fetchRejectBankMaster = async (
        bankAccountNumber: string,
        bankName: string, 
        classCode: string,
        clientCode: string,
        fundCode: string,
        masterName: MasterName, 
        planCode: string,
        role:  "C" | "M" | "A",
    ): Promise<FundMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/reject?bankAccountNumber=${bankAccountNumber}&bankName=${bankName}&classCode=${classCode}&clientCode=${clientCode}&fundCode=${fundCode}&masterName=${masterName}&planCode=${planCode}&role=${role}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const fundMasterMakerEntryFromApi = responseData[0];
                const fundMasterMakerEntryFromMakerForm = responseData[0]["makerDetails"];

                fundMasterData = {
                    "fundAdditionalInformation": {
                        "defaulterPenalty": fundMasterMakerEntryFromApi.defaulterPenaltyApplicableOrNotApplicable.value,
                        "distributionFrequency": fundMasterMakerEntryFromApi.distributionFrequency.value,
                        "dormant": fundMasterMakerEntryFromApi.isDormant.value,
                        "dormantDate": fundMasterMakerEntryFromApi.dormantDate.value,
                        "forexSource": fundMasterMakerEntryFromApi.forexSource.value,
                        "fundAdditionalFee": fundMasterMakerEntryFromApi.fundAdditionalFee.value,
                        "fundCommitmentApplicability": fundMasterMakerEntryFromApi.fundCommitmentApplicability.value,
                        "fundManagementFee": fundMasterMakerEntryFromApi.fundManagementFee.value,
                        "fundStampDutyBorne": fundMasterMakerEntryFromApi.fundStampDutyBourne.value,
                        "fundTrusteeFee": fundMasterMakerEntryFromApi.fundTrusteeFee.value,
                        "goodsServiceTax": fundMasterMakerEntryFromApi.goodsAndServiceTax.value,
                        "gpSharingRation": fundMasterMakerEntryFromApi.gpSharingRation.value,
                        "highWaterMark": fundMasterMakerEntryFromApi.highWaterMark.value,
                        "hurdleRate": fundMasterMakerEntryFromApi.hurdleRate.value,
                        "hurdleStartDate": fundMasterMakerEntryFromApi.hurdleStartDate.value,
                        "isActive": fundMasterMakerEntryFromApi.isActive.value,
                        "navRadioMethod": fundMasterMakerEntryFromApi.navRatioMethod.value,
                        "operatingExpenses": fundMasterMakerEntryFromApi.operatingExpensesApplicableOrNotApplicable.value,
                        "preferredRateOfReturn": fundMasterMakerEntryFromApi.preferredRateOfReturnApplicableOrNotApplicable.value,
                        "setupFee": fundMasterMakerEntryFromApi.setupFee.value,
                    },
                    "fundBasicDetails": {
                        "companyCode": fundMasterMakerEntryFromApi.clientCode,
                        "companyName": fundMasterMakerEntryFromApi.clientName,
                        "fundBusinessType": fundMasterMakerEntryFromApi.fundBusinessType.value,
                        "fundCategory": fundMasterMakerEntryFromApi.fundCategory,
                        "fundClientId": fundMasterMakerEntryFromApi.fundClientID.value,
                        "fundCode": fundMasterMakerEntryFromApi.fundCode,
                        "fundCurrency": fundMasterMakerEntryFromApi.fundCurrency.value,
                        "fundDepositoryType": fundMasterMakerEntryFromApi.fundDepositoryType.value,
                        "fundDomicile": fundMasterMakerEntryFromApi.fundDomicile.value,
                        "fundDpId": fundMasterMakerEntryFromApi.fundDPID.value,
                        "fundFaceValue": fundMasterMakerEntryFromApi.fundFaceValue.value,
                        "fundFrom": fundMasterMakerEntryFromApi.fundFrom.value,
                        "fundIsinNumber": fundMasterMakerEntryFromApi.fundISINNumber.value,
                        "fundName": fundMasterMakerEntryFromApi.fundName.value,
                        "fundNature": fundMasterMakerEntryFromApi.fundNature.value,
                        "fundPeriod": fundMasterMakerEntryFromApi.fundPeriodValue.value,
                        "fundPeriodSuffix": fundMasterMakerEntryFromApi.fundPeriodType.value,
                        "fundRegistrationNumber": fundMasterMakerEntryFromApi.fundRegistrationNumber.value,
                        "fundShortName": fundMasterMakerEntryFromApi.fundShortName.value,
                        "fundSubCategory": fundMasterMakerEntryFromApi.fundSubCategory,
                        "gstin": fundMasterMakerEntryFromApi.gstin,
                        "panOrTin": fundMasterMakerEntryFromApi.fundPanOrTin.value,
                        "serviceModel": fundMasterMakerEntryFromApi.serviceModel,
                    },
                    "fundSpecificDetails": {
                        "fundAccountantContactNumber": fundMasterMakerEntryFromApi.fundAccountantContactNumber.value,
                        "fundAccountantContactNumberPrefix": fundMasterMakerEntryFromApi.fundAccountantContactCountryCode.value,
                        "fundAccountantEmail": fundMasterMakerEntryFromApi.fundAccountantEmail.value,
                        "fundAccountantName": fundMasterMakerEntryFromApi.fundAccountantName.value,
                        "fundCustodianCode": fundMasterMakerEntryFromApi.fundCustodianCode.value,
                        "fundEndDate": fundMasterMakerEntryFromApi.fundEndDate.value,
                        "fundInitialContribution": fundMasterMakerEntryFromApi.fundInitialContributionPercentage.value,
                        "fundInitialContributionAmount": fundMasterMakerEntryFromApi.fundInitialContributionAmount.value,
                        "fundInitialContributionCloseDate": fundMasterMakerEntryFromApi.fundInitialContributionCloseDate.value,
                        "fundInitialContributionStartDate": fundMasterMakerEntryFromApi.fundInitialContributionStartDate.value,
                        "fundInvestmentManager": fundMasterMakerEntryFromApi.fundInvestmentManager.value,
                        "fundMaturityDate": fundMasterMakerEntryFromApi.fundMaturityDate.value,
                        "fundMaxInvestors": fundMasterMakerEntryFromApi.fundMaxInvestors.value,
                        "fundRtaCode": fundMasterMakerEntryFromApi.fundRTACode.value,
                        "fundSize": fundMasterMakerEntryFromApi.fundSizeCorpus.value,
                        "fundSponsorName": fundMasterMakerEntryFromApi.fundSponsorName.value,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundSpecificStartDate.value,
                        "fundTrusteeName": fundMasterMakerEntryFromApi.fundTrusteeName.value,
                        "legalAdvisorName": fundMasterMakerEntryFromApi.legalAdvisorName.value,
                        "taxAdvisorName": fundMasterMakerEntryFromApi.taxAdvisorName.value,
                        "transferAgentAccountantEmail": fundMasterMakerEntryFromApi.transferAgentAccountantEmail.value,
                        "transferAgentContactNumber": fundMasterMakerEntryFromApi.transferAgentContactNumber.value,
                        "transferAgentContactNumberPrefix": fundMasterMakerEntryFromApi.transferAgentContactCountryCode.value,
                        "transferAgentName": fundMasterMakerEntryFromApi.transferAgentName.value,
                    }, 
                    "fundValuationInformation": {
                        "fundCurrentDate": fundMasterMakerEntryFromApi.fundCurrentDate.value,
                        "fundCurrentYearEnd": fundMasterMakerEntryFromApi.fundCurrentYearEnd.value,
                        "fundDDNoticePeriod": fundMasterMakerEntryFromApi.fundDDNoticePeriod.value,
                        "fundDDPenaltyCharges": fundMasterMakerEntryFromApi.fundDDPenaltyCharges.value,
                        "fundDDTreatment": fundMasterMakerEntryFromApi.fundDDTreatment.value,
                        "fundNextDate": fundMasterMakerEntryFromApi.fundNextDate.value,
                        "fundPlCompMethod": fundMasterMakerEntryFromApi.fundPLCompMethod.value,
                        "fundPreviousDate": fundMasterMakerEntryFromApi.fundPreviousDate.value,
                        "fundPreviousYearEnd": fundMasterMakerEntryFromApi.fundPreviousYearEnd.value,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundValuationStartDate.value,
                        "fundTopupTreatment": fundMasterMakerEntryFromApi.fundTopupTreatment.value,
                        "navFrequency": fundMasterMakerEntryFromApi.navFrequency.value,
                        "navPubFrequency": fundMasterMakerEntryFromApi.navPubFrequency.value,
                        "navPublishType": "",
                        "nextNavDate": fundMasterMakerEntryFromApi.nextNAVDate.value,
                        "nextNavPubDate": fundMasterMakerEntryFromApi.nextNAVPubDate.value,
                        "prevNavDate": fundMasterMakerEntryFromApi.prevNAVDate.value,
                        "prevNavPubDate": fundMasterMakerEntryFromApi.prevNAVPubDate.value,
                        "roundDecimals": fundMasterMakerEntryFromApi.roundDecimals.value,
                        "roundMethod": fundMasterMakerEntryFromApi.roundMethod.value,
                        "unitDecimals": fundMasterMakerEntryFromApi.unitDecimals.value,
                        "valuationSequence": fundMasterMakerEntryFromApi.valuationSequence.value,
                    },
                };
                
                fundMasterMakerData = {
                    "fundAdditionalInformation": {
                        "defaulterPenalty": fundMasterMakerEntryFromMakerForm.defaulterPenaltyApplicableOrNotApplicable.value,
                        "distributionFrequency": fundMasterMakerEntryFromMakerForm.distributionFrequency.value,
                        "dormant": fundMasterMakerEntryFromMakerForm.isDormant.value,
                        "dormantDate": fundMasterMakerEntryFromMakerForm.dormantDate.value,
                        "forexSource": fundMasterMakerEntryFromMakerForm.forexSource.value,
                        "fundAdditionalFee": fundMasterMakerEntryFromMakerForm.fundAdditionalFee.value,
                        "fundCommitmentApplicability": fundMasterMakerEntryFromMakerForm.fundCommitmentApplicability.value,
                        "fundManagementFee": fundMasterMakerEntryFromMakerForm.fundManagementFee.value,
                        "fundStampDutyBorne": fundMasterMakerEntryFromMakerForm.fundStampDutyBourne.value,
                        "fundTrusteeFee": fundMasterMakerEntryFromMakerForm.fundTrusteeFee.value,
                        "goodsServiceTax": fundMasterMakerEntryFromMakerForm.goodsAndServiceTax.value,
                        "gpSharingRation": fundMasterMakerEntryFromMakerForm.gpSharingRation.value,
                        "highWaterMark": fundMasterMakerEntryFromMakerForm.highWaterMark.value,
                        "hurdleRate": fundMasterMakerEntryFromMakerForm.hurdleRate.value,
                        "hurdleStartDate": fundMasterMakerEntryFromMakerForm.hurdleStartDate.value,
                        "isActive": fundMasterMakerEntryFromMakerForm.isActive.value,
                        "navRadioMethod": fundMasterMakerEntryFromMakerForm.navRatioMethod.value,
                        "operatingExpenses": fundMasterMakerEntryFromMakerForm.operatingExpensesApplicableOrNotApplicable.value,
                        "preferredRateOfReturn": fundMasterMakerEntryFromMakerForm.preferredRateOfReturnApplicableOrNotApplicable.value,
                        "setupFee": fundMasterMakerEntryFromMakerForm.setupFee.value,
                    },
                    "fundBasicDetails": {
                        "companyCode": fundMasterMakerEntryFromMakerForm.clientCode,
                        "companyName": fundMasterMakerEntryFromMakerForm.clientName,
                        "fundBusinessType": fundMasterMakerEntryFromMakerForm.fundBusinessType.value,
                        "fundCategory": fundMasterMakerEntryFromMakerForm.fundCategory,
                        "fundClientId": fundMasterMakerEntryFromMakerForm.fundClientID.value,
                        "fundCode": fundMasterMakerEntryFromMakerForm.fundCode,
                        "fundCurrency": fundMasterMakerEntryFromMakerForm.fundCurrency.value,
                        "fundDepositoryType": fundMasterMakerEntryFromMakerForm.fundDepositoryType.value,
                        "fundDomicile": fundMasterMakerEntryFromMakerForm.fundDomicile.value,
                        "fundDpId": fundMasterMakerEntryFromMakerForm.fundDPID.value,
                        "fundFaceValue": fundMasterMakerEntryFromMakerForm.fundFaceValue.value,
                        "fundFrom": fundMasterMakerEntryFromMakerForm.fundFrom.value,
                        "fundIsinNumber": fundMasterMakerEntryFromMakerForm.fundISINNumber.value,
                        "fundName": fundMasterMakerEntryFromMakerForm.fundName.value,
                        "fundNature": fundMasterMakerEntryFromMakerForm.fundNature.value,
                        "fundPeriod": fundMasterMakerEntryFromMakerForm.fundPeriodValue.value,
                        "fundPeriodSuffix": fundMasterMakerEntryFromMakerForm.fundPeriodType.value,
                        "fundRegistrationNumber": fundMasterMakerEntryFromMakerForm.fundRegistrationNumber.value,
                        "fundShortName": fundMasterMakerEntryFromMakerForm.fundShortName.value,
                        "fundSubCategory": fundMasterMakerEntryFromMakerForm.fundSubCategory,
                        "gstin": fundMasterMakerEntryFromMakerForm.gstin,
                        "panOrTin": fundMasterMakerEntryFromMakerForm.fundPanOrTin.value,
                        "serviceModel": fundMasterMakerEntryFromMakerForm.serviceModel,
                    },
                    "fundSpecificDetails": {
                        "fundAccountantContactNumber": fundMasterMakerEntryFromMakerForm.fundAccountantContactNumber.value,
                        "fundAccountantContactNumberPrefix": fundMasterMakerEntryFromMakerForm.fundAccountantContactCountryCode.value,
                        "fundAccountantEmail": fundMasterMakerEntryFromMakerForm.fundAccountantEmail.value,
                        "fundAccountantName": fundMasterMakerEntryFromMakerForm.fundAccountantName.value,
                        "fundCustodianCode": fundMasterMakerEntryFromMakerForm.fundCustodianCode.value,
                        "fundEndDate": fundMasterMakerEntryFromMakerForm.fundEndDate.value,
                        "fundInitialContribution": fundMasterMakerEntryFromMakerForm.fundInitialContributionPercentage.value,
                        "fundInitialContributionAmount": fundMasterMakerEntryFromMakerForm.fundInitialContributionAmount.value,
                        "fundInitialContributionCloseDate": fundMasterMakerEntryFromMakerForm.fundInitialContributionCloseDate.value,
                        "fundInitialContributionStartDate": fundMasterMakerEntryFromMakerForm.fundInitialContributionStartDate.value,
                        "fundInvestmentManager": fundMasterMakerEntryFromMakerForm.fundInvestmentManager.value,
                        "fundMaturityDate": fundMasterMakerEntryFromMakerForm.fundMaturityDate.value,
                        "fundMaxInvestors": fundMasterMakerEntryFromMakerForm.fundMaxInvestors.value,
                        "fundRtaCode": fundMasterMakerEntryFromMakerForm.fundRTACode.value,
                        "fundSize": fundMasterMakerEntryFromMakerForm.fundSizeCorpus.value,
                        "fundSponsorName": fundMasterMakerEntryFromMakerForm.fundSponsorName.value,
                        "fundStartDate": fundMasterMakerEntryFromMakerForm.fundSpecificStartDate.value,
                        "fundTrusteeName": fundMasterMakerEntryFromMakerForm.fundTrusteeName.value,
                        "legalAdvisorName": fundMasterMakerEntryFromMakerForm.legalAdvisorName.value,
                        "taxAdvisorName": fundMasterMakerEntryFromMakerForm.taxAdvisorName.value,
                        "transferAgentAccountantEmail": fundMasterMakerEntryFromMakerForm.transferAgentAccountantEmail.value,
                        "transferAgentContactNumber": fundMasterMakerEntryFromMakerForm.transferAgentContactNumber.value,
                        "transferAgentContactNumberPrefix": fundMasterMakerEntryFromMakerForm.transferAgentContactCountryCode.value,
                        "transferAgentName": fundMasterMakerEntryFromMakerForm.transferAgentName.value,
                    }, 
                    "fundValuationInformation": {
                        "fundCurrentDate": fundMasterMakerEntryFromMakerForm.fundCurrentDate.value,
                        "fundCurrentYearEnd": fundMasterMakerEntryFromMakerForm.fundCurrentYearEnd.value,
                        "fundDDNoticePeriod": fundMasterMakerEntryFromMakerForm.fundDDNoticePeriod.value,
                        "fundDDPenaltyCharges": fundMasterMakerEntryFromMakerForm.fundDDPenaltyCharges.value,
                        "fundDDTreatment": fundMasterMakerEntryFromMakerForm.fundDDTreatment.value,
                        "fundNextDate": fundMasterMakerEntryFromMakerForm.fundNextDate.value,
                        "fundPlCompMethod": fundMasterMakerEntryFromMakerForm.fundPLCompMethod.value,
                        "fundPreviousDate": fundMasterMakerEntryFromMakerForm.fundPreviousDate.value,
                        "fundPreviousYearEnd": fundMasterMakerEntryFromMakerForm.fundPreviousYearEnd.value,
                        "fundStartDate": fundMasterMakerEntryFromMakerForm.fundValuationStartDate.value,
                        "fundTopupTreatment": fundMasterMakerEntryFromMakerForm.fundTopupTreatment.value,
                        "navFrequency": fundMasterMakerEntryFromMakerForm.navFrequency.value,
                        "navPubFrequency": fundMasterMakerEntryFromMakerForm.navPubFrequency.value,
                        "navPublishType": "",
                        "nextNavDate": fundMasterMakerEntryFromMakerForm.nextNAVDate.value,
                        "nextNavPubDate": fundMasterMakerEntryFromMakerForm.nextNAVPubDate.value,
                        "prevNavDate": fundMasterMakerEntryFromMakerForm.prevNAVDate.value,
                        "prevNavPubDate": fundMasterMakerEntryFromMakerForm.prevNAVPubDate.value,
                        "roundDecimals": fundMasterMakerEntryFromMakerForm.roundDecimals.value,
                        "roundMethod": fundMasterMakerEntryFromMakerForm.roundMethod.value,
                        "unitDecimals": fundMasterMakerEntryFromMakerForm.unitDecimals.value,
                        "valuationSequence": fundMasterMakerEntryFromMakerForm.valuationSequence.value,
                    },
                };


                fundMaster = {
                    "fundMasterFormState": fundMasterData,
                    "fundMasterMakerFormState": fundMasterMakerData,
                    "fundMasterUpdateState": fundMasterUpdateData,
                };
            })
            .catch((error) => {
                console.error(error);
            });
            
        dispatch(setOpenBackdrop(false));
            
        return fundMaster; 
    };

    return fetchRejectBankMaster;
}

export default useFetchRejectFundMaster;
