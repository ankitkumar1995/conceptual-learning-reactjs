import { 
    MakerInitialContributionDetails, 
    makerInitialContributionDetailsFormState 
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";
import { useDispatch, useSelector } from "react-redux";

import { PaymentBankDetails } from "../useGetInvestor/interfaces/GetInvestor.types";
import { getInitialContributionInfo } from "../useGetInitialContribution";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

export interface UserIdsType {
    auditorId: string | null;
    makerId: string | null;
    checkerId: string | null;
    qualityCheckerId: string | null;
}

interface GetInitialContributionResponseType {
    initialContributionDetails: MakerInitialContributionDetails;
    userIds: UserIdsType;
}

export interface InitialContributionInfo {
    "initialContributionDetails": MakerInitialContributionDetails;
    "userIds": UserIdsType;
}

function useGetRejectInitialContribution() {
    const dispatch = useDispatch();

    let initialContributionInfo: InitialContributionInfo ;

    const getRejectInitialContribution = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<GetInitialContributionResponseType> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/reject?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response.data.rejectedDetails;
                const responseMakerData = response.data.makerDetails;
                const initialContributionDetailsFromApi = responseData[0];
                const initialContributionMakerDetailsFromApi = responseMakerData[0];

                initialContributionInfo = getInitialContributionInfo(initialContributionDetailsFromApi);

            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "initialContributionDetails": initialContributionInfo.initialContributionDetails,
            "userIds": initialContributionInfo.userIds,
        }; 
    };

    return getRejectInitialContribution;
}

export default useGetRejectInitialContribution;
