import {
    TopUpDetails,
    topUpDetailsFormState
} from "../../../redux/InitiateTransaction/TopUp/Maker/Forms/initialState";
import { useDispatch, useSelector } from "react-redux";

import { PaymentBankDetails } from "../useGetInvestor/interfaces/GetInvestor.types";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

export interface UserIdsType {
    auditorId: string | null;
    makerId: string | null;
    checkerId: string | null;
    qualityCheckerId: string | null;
}

interface FetchTopUpResponseType {
    topUpDetails: TopUpDetails;
    userIds: UserIdsType;
}

export interface TopUpInfo {
    "topUpDetails": TopUpDetails;
    "userIds": UserIdsType;
}

const isFieldValueNull = (field: string | null) => {
    if (field === null || field === undefined || (typeof field === "string" && field?.trim() === ""))
        return "";
    else
        return field;
};

export interface ApiResponse {
    _id: string;
    activityStatus: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    createdBy: string;
    createdFrom: string;
    createdOn: string;
    currentStage: string;
    documentFormat: string;
    documentPath: string;
    documentSize: number;
    documentType: string;
    lastUpdatedBy: string;
    lastUpdatedFrom: string;
    lastUpdatedOn: string;
    mimeType: string;
    processCode: string;
    sourceUser: string;
    transactionCode: string;
    transactionNo: string;
    transactionType: string;
    workDate: string;
}

export function fetchTopUpInfo(
    topUpDetailsFromApi: any, 
): TopUpInfo {

    let userIds: UserIdsType;
    let topUpData: TopUpDetails = topUpDetailsFormState;

    const isPaymentDetailsArrayEmpty = (holder: PaymentBankDetails) => {
        if (
            holder?.foreignBankAccount &&
            holder?.isForeignBankAcct &&
            holder?.nationalBankAccount &&
            holder?.paymentBankIsRegBank
        ) {
            return true;
        }
        else {
            return false;
        }
    };

    const paymentDetailsArray = (holder: PaymentBankDetails) => {
        return (
            {
                "accountType": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.paymentForeignBankAccType :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccType :
                        "",
                "isForeignBankAccount": holder?.isForeignBankAcct ?? "",
                "lastFourDigitsOfAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.lastFourDigitsOfRegForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.lastFourDigOfRegBankAccountNo :
                        "",
                "micrCode": holder?.nationalBankAccount[0]?.paymentBankMicr ?? "",
                "paymentBankAccountName": holder?.nationalBankAccount[0]?.paymentBankAccName ?? "",
                "paymentBankAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.regPaymentForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccNo :
                        "",
                "paymentBankAddress": holder?.foreignBankAccount[0]?.paymentBankAddr ?? "",
                "paymentBankBranch": holder?.foreignBankAccount[0]?.paymentBankBranch ?? "",
                "paymentBankIbanCode": holder?.foreignBankAccount[0]?.paymentBankIbanCode ?? "",
                "paymentBankIfscCode": holder?.nationalBankAccount[0]?.paymentBankIfsc ?? "",
                "paymentBankName": holder?.foreignBankAccount[0]?.paymentBankName ?? "",
                "paymentBankUtrNumber": holder?.nationalBankAccount[0]?.paymentBankUtrNo ?? "",
                "paymentChequeDetails": holder?.nationalBankAccount[0]?.paymentBankChqRefNo ?
                    holder?.nationalBankAccount[0]?.paymentBankChqRefNo?.map((cheque: any) => {
                        return {
                            "chequeAmount": cheque.chequeAmount ?? "",
                            "chequeReferenceNumber": cheque.chequeRefNo ?? "",
                        };
                    }) : [],
                "paymentType": holder?.nationalBankAccount[0]?.paymentType ?? "",
                "pennyDropStatus": holder?.nationalBankAccount[0]?.paymentBankPennyDropStatus ?? "",
                "pennyDropValidationDate": holder?.nationalBankAccount[0]?.pennyDropValidationDt ?? "",
                "sameAsRegisteredBank": holder?.paymentBankIsRegBank ?? "",
                "swiftOrBicCode": holder?.foreignBankAccount[0]?.paymentBankSwiftAndBic ?? "",
            }
        );
    };

    const paymentBankDetails = [];

    if (isPaymentDetailsArrayEmpty(topUpDetailsFromApi?.paymentBankDetails?.primaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(topUpDetailsFromApi?.paymentBankDetails?.primaryHolderPaymentBank));

    if (isPaymentDetailsArrayEmpty(topUpDetailsFromApi?.paymentBankDetails?.secondaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(topUpDetailsFromApi?.paymentBankDetails.secondaryHolderPaymentBank));
    
    if (isPaymentDetailsArrayEmpty(topUpDetailsFromApi?.paymentBankDetails?.thirdHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(topUpDetailsFromApi?.paymentBankDetails.thirdHolderPaymentBank));

    topUpData = {
        "accreditationFlag": topUpDetailsFromApi?.accreditationFlag ?? false,
        "allotmentMode": isFieldValueNull(topUpDetailsFromApi?.allotmentMode?.modeOfAllotment) ?? null,
        "allotmentModeClientId": isFieldValueNull(topUpDetailsFromApi?.allotmentMode?.clientId) ?? null,
        "amcRmCode": isFieldValueNull(topUpDetailsFromApi?.distributorDetails?.amcRmCode) ?? null,
        "amcRmName": isFieldValueNull(topUpDetailsFromApi?.distributorDetails?.amcRmName) ?? null,
        "anyApprovalMailFromAmc": isFieldValueNull(topUpDetailsFromApi?.documentsProvided?.amcApproval) ?? null,
        "bankProofOrChequeCopy": isFieldValueNull(topUpDetailsFromApi?.documentsProvided?.bankProofOrChequeCopy) ?? null,
        "className": isFieldValueNull(topUpDetailsFromApi?.investmentDetails?.class) ?? null,
        "clientId": isFieldValueNull(topUpDetailsFromApi?.clientId) ?? null,
        "createNewFolio": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.createNewFolio) ?? null,
        "distributorCode": isFieldValueNull(topUpDetailsFromApi?.distributorDetails?.distributorCode) ?? null,
        "distributorName": isFieldValueNull(topUpDetailsFromApi?.distributorDetails?.distributorName) ?? null,
        "distributorOrDirect": isFieldValueNull(topUpDetailsFromApi?.distributorDetails?.distributorType) ?? null,
        "dpId": isFieldValueNull(topUpDetailsFromApi?.allotmentMode?.dPId) ?? null,
        "exchangeRate": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.exchngRate) ?? null,
        "existingCommitmentAmount": topUpDetailsFromApi?.contributionDetails?.existingCommitmentAmt ?? null,
        "folioNumber": isFieldValueNull(topUpDetailsFromApi?.folioNo) ?? null,
        "fundBusinessType": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.fundBusinessType) ?? null,
        "fundCurrencyAmount": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.fundCurrencyAmount) ?? null,
        "fundFrequency": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.fundCurrency) ?? null,
        "fundInitContribPercent": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.fundInitContribPercent) ?? null,
        "fundTopUpTreatment": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.fundTopUpTreatment) ?? null,
        "gstOrServiceTax": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.gst) ?? null,
        "gstOrServiceTaxWaiver": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.gstWaiver) ?? null,
        "gstWaiverApprovalEmailFile": null,
        "gstWaiverApprovalEmailFileFormat": isFieldValueNull(topUpDetailsFromApi?.gstWaiverAttachment?.documentFormat) ?? null,
        "gstWaiverApprovalEmailFileS3Key": isFieldValueNull(topUpDetailsFromApi?.gstWaiverApprovalEmailFileS3Key) ?? null,
        "gstWaiverApprovalEmailFileS3SignedURL": isFieldValueNull(topUpDetailsFromApi?.gstWaiverAttachment?.documentPath) ?? null,
        'gstWaiverApprovalEmailFileSize': isFieldValueNull(topUpDetailsFromApi?.gstWaiverAttachment?.documentSize) ?? null,
        "ihNumber": isFieldValueNull(topUpDetailsFromApi?.transactionNo) ?? null,
        "initContribAmt": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.initContribAmt) ?? null,
        "invType": isFieldValueNull(topUpDetailsFromApi?.invType) ?? null,
        "investorCategory": isFieldValueNull(topUpDetailsFromApi?.invCategory) ?? null,
        "investorName": isFieldValueNull(topUpDetailsFromApi?.invName) ?? null,
        "isInNumber": isFieldValueNull(topUpDetailsFromApi?.investmentDetails?.schemeIsinNo) ?? null,
        "modeOfHolding": isFieldValueNull(topUpDetailsFromApi?.modeOfHolding) ?? null,
        "name": isFieldValueNull(topUpDetailsFromApi?.poa?.nameOfPoa) ?? null,
        "otherFee": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.otherFee) ?? null,
        "panOrTaxId": isFieldValueNull(topUpDetailsFromApi?.taxId) ?? null,
        "panOrTaxIdNumber": isFieldValueNull(topUpDetailsFromApi?.poa?.poaTaxIdNo) ?? null,
        "parentTransactionNo": isFieldValueNull(topUpDetailsFromApi?.parentTransactionNo) ?? null,
        "paymentBankDetails": paymentBankDetails ?? [],
        "poaNotaryAggrementCopy": isFieldValueNull(topUpDetailsFromApi?.documentsProvided?.poaNotaryAgreementCopy) ?? null,
        "primaryHolderContribution": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.primaryHolderContrib) ?? null,
        "primaryHolderPercentage": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.primaryHolderPercent) ?? null,
        "productType": isFieldValueNull(topUpDetailsFromApi?.investmentDetails?.productType) ?? null,
        "repositoryType": isFieldValueNull(topUpDetailsFromApi?.allotmentMode?.repositoryType) ?? null,
        "schemeCode": isFieldValueNull(topUpDetailsFromApi?.investmentDetails?.schemeCode) ?? null,
        "schemeName": isFieldValueNull(topUpDetailsFromApi?.investmentDetails?.schemeName) ?? null,
        "secHolderRelatshpWithPrimaryHolder": isFieldValueNull(topUpDetailsFromApi?.secHolderRelatshpWithPrimaryHolder) ?? null,
        "secondHolderContribution": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.secondHolderContrib) ?? null,
        "secondHolderPercentage": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.secondHolderPercent) ?? null,
        "setupFeeAmount": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.setupFeeAmt) ?? null,
        "setupFeePercentage": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.setupFeePercent) ?? null,
        "thirdHolderContribution": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.thirdHolderContrib) ?? null,
        "thirdHolderPercentage": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.thirdHolderPercent) ?? null,
        "thirdHolderRelatshpWithPrimaryHolder": isFieldValueNull(topUpDetailsFromApi?.thirdHolderRelatshpWithPrimaryHolder) ?? null,
        "topUpCommitmentAmount": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.topUpCommitmentAmt) ?? null,
        "topUpContributionAmount": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.topUpContributionAmt) ?? null,
        "topUpEligibleClass": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.topUpEligibleClass) ?? null,
        "topUpEntry": topUpDetailsFromApi?.contributionDetails?.topUp ?? [],
        "topUpRequestLetter": isFieldValueNull(topUpDetailsFromApi?.documentsProvided?.topUpRequestLetter) ?? null,
        "totalSetupFee": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.totalSetupFee) ?? null,
        "transactionCurrency": isFieldValueNull(topUpDetailsFromApi?.contributionDetails?.transactionCurrency) ?? null,
        "type": isFieldValueNull(topUpDetailsFromApi?.poa?.poaType) ?? null,
        "updateFlag": isFieldValueNull(topUpDetailsFromApi?.updateFlag),
    };

    userIds = {
        "auditorId": topUpDetailsFromApi?.auditorId ?? null,
        "checkerId": topUpDetailsFromApi?.checkerId ?? null,
        "makerId": topUpDetailsFromApi?.makerId ?? null,
        "qualityCheckerId": topUpDetailsFromApi?.qualityCheckerId ?? null,
    };

    return {
        "topUpDetails": topUpData,
        "userIds": userIds
    };

}

function useFetchTopUp() {
    const dispatch = useDispatch();

    // let initialContributionInfo: ApiResponse;
    let topUpInfo: TopUpInfo ;

    const fetchTopUpDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<FetchTopUpResponseType> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/initcontrib?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const topUpDetailsFromApi = responseData[0];

                topUpInfo = fetchTopUpInfo(topUpDetailsFromApi);

            })
            .catch((error) => {
                console.error("error", error);
            });

        dispatch(setOpenBackdrop(false));
        
        return {
            "topUpDetails": topUpInfo.topUpDetails,
            "userIds": topUpInfo.userIds,
        }; 
    };

    return fetchTopUpDetails;
}

export default useFetchTopUp;
