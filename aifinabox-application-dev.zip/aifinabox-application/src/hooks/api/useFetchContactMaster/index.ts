import {
    ContactMasterDetails,
    initialContactMasterDetailsFormState
} from "../../../redux/AifMaster/ContactMaster/Maker/initialState";
import initializeUpdateState, {
    UpdateState
} from "../../../redux/AifMaster/ContactMaster/Update/initialState";

import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface Status {
    updated: boolean;
    value: string;
}

interface EmailDetails {
    emailId: Status;
}

interface PhoneDetails {
    mobileDialCode: string;
    mobileNumber: Status;
}

interface ContactPerson {
    contactPersonName: Status;
    designation: string | Status;
    emailDetails: EmailDetails[];
    phoneDetails: PhoneDetails[];
    role: string;
}

interface ContactMaster {
    contactMasterMakerEntry: ContactMasterDetails;
    contactMasterMakerUpdateEntry: UpdateState;
}

function useFetchContactMaster() {
    const dispatch = useDispatch();

    let contactMasterMakerEntry: ContactMasterDetails = initialContactMasterDetailsFormState;
    let contactMasterMakerUpdateEntry: UpdateState = initializeUpdateState();
    let contactMaster: ContactMaster;
    const fetchContactMaster = async (
        clientCode: string,
        updateFlag: "1" | "0",
        userId: string
    ): Promise<ContactMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/contactmaster?clientCode=${clientCode}&updateFlag=${updateFlag}&userId=${userId}`,
        };

        const parseSpoc = (contact: ContactPerson, index:number):ContactMasterDetails  => {
            const [prefix, ...name] = contact.contactPersonName.value.split(' ');

            return {
                [`spoc${index}ContactNumber`]: contact.phoneDetails[0].mobileNumber.value,
                [`spoc${index}ContactNumberPrefix`]: contact.phoneDetails[0].mobileDialCode,
                [`spoc${index}EmailId`]: contact.emailDetails[0].emailId.value,
                [`spoc${index}Name`]: name.join(' '),
                [`spoc${index}NamePrefix`]: prefix,
            } as unknown as ContactMasterDetails;
        };

        const parseContact = (contact: ContactPerson):ContactMasterDetails  => {
            const [prefix, ...name] = contact.contactPersonName.value.split(' ');

            return {
                [`aifContactNumber`]: contact.phoneDetails[0].mobileNumber.value,
                [`aifContactNumberPrefix`]: contact.phoneDetails[0].mobileDialCode,
                [`aifEmailId`]: contact.emailDetails[0].emailId.value,
                [`contactPersonName`]: name.join(' '),
                [`contactPersonNamePrefix`]: prefix,
            } as unknown as ContactMasterDetails;
        };

        const parseCompliance = (contact: ContactPerson):ContactMasterDetails  => {
            const [prefix, ...name] = contact.contactPersonName.value.split(' ');
            const designation = contact.designation as Status;
            return {
                [`complianceOfficeContact`]: contact.phoneDetails[0].mobileNumber.value,
                [`complianceOfficeContactPrefix`]: contact.phoneDetails[0].mobileDialCode,
                [`complianceOfficeDesignation`]: designation.value,
                [`complianceOfficeEmailId`]: contact.emailDetails[0].emailId.value,
                [`complianceOfficeName`]: name.join(' '),
                [`complianceOfficeNamePrefix`]: prefix,
            } as unknown as ContactMasterDetails;
        };
        const parseSpocUpdate = (contact: ContactPerson, index:number):UpdateState  => {
            return {
                [`spoc${index}ContactNumber`]: contact.phoneDetails[0].mobileNumber.updated,
                [`spoc${index}EmailId`]: contact.emailDetails[0].emailId.updated,
                [`spoc${index}Name`]: contact.contactPersonName.updated,
            } as unknown as UpdateState;
        };
        const parseContactUpdate = (contact: ContactPerson):UpdateState  => {
            return {
                [`aifContactNumber`]: contact.phoneDetails[0].mobileNumber.updated,
                [`aifEmailId`]: contact.emailDetails[0].emailId.updated,
                [`contactPersonName`]: contact.contactPersonName.updated,
            } as unknown as UpdateState;
        };
        const parseComplianceUpdate = (contact: ContactPerson):UpdateState  => {
            const designation = contact.designation as Status;
            return {
                [`complianceOfficeContact`]: contact.phoneDetails[0].mobileNumber.updated,
                [`complianceOfficeDesignation`]: designation.updated,
                [`complianceOfficeEmailId`]: contact.emailDetails[0].emailId.updated,
                [`complianceOfficeName`]: contact.contactPersonName.updated,
            } as unknown as UpdateState;
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const contactMasterMakerEntryFromApi = responseData[0];

                const {
                    clientCode,
                    clientName,
                    clientType,
                    updateFlag
                } = contactMasterMakerEntryFromApi;

                const [
                    contact, 
                    spoc1, 
                    spoc2, 
                    spoc3, 
                    compliance
                ] = contactMasterMakerEntryFromApi.contactDetails;
            
                contactMasterMakerEntry = {
                    ...contactMasterMakerEntry,
                    ...parseContact(contact),
                    ...parseSpoc(spoc1, 1),
                    ...parseSpoc(spoc2, 2),
                    ...parseSpoc(spoc3, 3),
                    ...parseCompliance(compliance),
                    "aifCompanyName": clientName,
                    "clientCode": clientCode,
                    "clientType": clientType
                };

                contactMasterMakerUpdateEntry = {
                    ...parseContactUpdate(contact),
                    ...parseSpocUpdate(spoc1, 1),
                    ...parseSpocUpdate(spoc2, 2),
                    ...parseSpocUpdate(spoc3, 3),
                    ...parseComplianceUpdate(compliance),
                    "updateFlag": updateFlag 
                };
                contactMaster = {
                    contactMasterMakerEntry,
                    contactMasterMakerUpdateEntry
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return contactMaster; 
    };

    return fetchContactMaster;
}

export default useFetchContactMaster;
