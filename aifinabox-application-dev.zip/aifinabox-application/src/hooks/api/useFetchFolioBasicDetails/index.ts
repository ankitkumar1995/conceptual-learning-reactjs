import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FolioBasicDetails {
    clientId: string;
    clientName: string;
    frozenFolioFlag: boolean;
    accreditationFlag: boolean;
    adviceType: string;
    amcRmCode: string;
    amcRmName: string;
    clId: string;
    className: string;
    distributorCode: string;
    distributorName: string;
    dpId: string;
    invCategory: string;
    invName: string;
    invType: string;
    modeOfAllotment: string;
    modeOfHolding: string;
    nameOfPoa: string;
    parentTransactionNo: string;
    poaTaxIdNo: string;
    poaType: string;
    repositoryType: string;
    schemeCode: string;
    schemeIsinNo: string;
    schemeName: string;
    secHolderRelatshpWithPrimaryHolder: string;
    taxId: string;
    thirdHolderRelatshpWithPrimaryHolder: string;
    errorMessage: string;
    nameOfTheEntity: string;
}

function useFetchFolioBasicDetails() {
    const dispatch = useDispatch();

    const fetchFolioBasicDetails = async (
        clientId: string,
        folio: string,
    ): Promise<FolioBasicDetails> => {
        dispatch(setOpenBackdrop(true));

        let folioBasicDetails: FolioBasicDetails = {
            "accreditationFlag": false,
            "adviceType": "",
            "amcRmCode": "",
            "amcRmName": "",
            "clId": "",
            "className": "",
            "clientId": "",
            "clientName": "",
            "distributorCode": "",
            "distributorName": "",
            "dpId": "",
            "errorMessage": "",
            "frozenFolioFlag": false,
            "invCategory": "",
            "invName": "",
            "invType": "",
            "modeOfAllotment": "",
            "modeOfHolding": "",
            "nameOfPoa": "",
            "nameOfTheEntity": "",
            "parentTransactionNo": "",
            "poaTaxIdNo": "",
            "poaType": "",
            "repositoryType": "",
            "schemeCode": "",
            "schemeIsinNo": "",
            "schemeName": "",
            "secHolderRelatshpWithPrimaryHolder": "",
            "taxId": "",
            "thirdHolderRelatshpWithPrimaryHolder": "",
        };

        const axiosConfig = {
            "url": `/foliobasicdetails?clientId=${clientId}&folioNo=${folio}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data[0];
                
                folioBasicDetails.accreditationFlag = responseData.accreditationFlag;
                folioBasicDetails.adviceType = responseData.adviceType;
                folioBasicDetails.amcRmCode = responseData.amcRmCode;
                folioBasicDetails.amcRmName = responseData.amcRmName;
                folioBasicDetails.clId = responseData.clId;
                folioBasicDetails.className = responseData.className;
                folioBasicDetails.clientId = responseData.clientId;
                folioBasicDetails.clientName = responseData.clientName;
                folioBasicDetails.distributorCode = responseData.distributorCode;
                folioBasicDetails.distributorName = responseData.distributorName;
                folioBasicDetails.dpId = responseData.dpId;
                folioBasicDetails.frozenFolioFlag = responseData.frozenFolioFlag;
                folioBasicDetails.invCategory = responseData.invCategory;
                folioBasicDetails.invName = responseData.invName;
                folioBasicDetails.invType = responseData.invType;
                folioBasicDetails.modeOfAllotment = responseData.modeOfAllotment;
                folioBasicDetails.modeOfHolding = responseData.modeOfHolding;
                folioBasicDetails.nameOfPoa = responseData.nameofPoa;
                folioBasicDetails.parentTransactionNo = responseData.parentTransactionNo;
                folioBasicDetails.poaTaxIdNo = responseData.poaTaxIdNo;
                folioBasicDetails.poaType = responseData.poaType;
                folioBasicDetails.repositoryType = responseData.repositoryType;
                folioBasicDetails.schemeCode = responseData.schemeCode;
                folioBasicDetails.schemeIsinNo = responseData.schemeIsinNo;
                folioBasicDetails.schemeName = responseData.schemeName;
                folioBasicDetails.secHolderRelatshpWithPrimaryHolder = responseData.secHolderRelatshpWithPrimaryHolder;
                folioBasicDetails.taxId = responseData.taxId;
                folioBasicDetails.thirdHolderRelatshpWithPrimaryHolder = responseData.thirdHolderRelatshpWithPrimaryHolder;
                folioBasicDetails.nameOfTheEntity = responseData.nameOfTheEntity;
            })
            .catch((error) => {
                const errorMessage = error?.response?.data?.message;
                folioBasicDetails.errorMessage = errorMessage;
            });

        dispatch(setOpenBackdrop(false));

        return folioBasicDetails;
    };

    return fetchFolioBasicDetails;
}

export default useFetchFolioBasicDetails;
