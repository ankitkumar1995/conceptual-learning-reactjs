import {
    setCountryNameMenuItems,
    setCountryPhoneCodeMenuItems,
    setCurrencyMenuItems,
    setNationalityMenuItems,
} from "../../../redux/SelectInputMenuItems/reducer";

import { MenuItem } from "../../../interfaces/MenuItem.types";
import masterAxiosInstance from "../../../axios/instances/masterFetchAxiosInstance";
import { useDispatch } from "react-redux";
import { useEffect } from "react";

interface Country {
    countryCode: [];
    countryName: [];
    currencies: [];
    phoneCode: [];
    nationality: [];
}

function useFetchCountries() {
    const dispatch = useDispatch();

    const axiosConfig = {
        "method": "get",
        "url": "/country",
    };

    useEffect(() => {
        masterAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const countries = responseData.body;
                const phoneCodeData= countries && countries.phoneCode && [...new Set(countries.phoneCode)];
                const nationalityData= countries && countries.nationality && [...new Set(countries.nationality)];
                let countryNameMenuItems: MenuItem[] = [];
                let countryPhoneCodeMenuItems: MenuItem[] = [];
                let currencyMenuItems: MenuItem[] = [];
                let nationalityMenuItems: MenuItem[] = [];

                countryNameMenuItems = countries.countryName.map((countryName: string) => ({
                    "label": countryName,
                    "value": countryName,
                }) as MenuItem);

                countryPhoneCodeMenuItems = phoneCodeData.map((phoneCode: string) => ({
                    "label": phoneCode.charAt(0) === "-" ? `${phoneCode}`: `+${phoneCode}`,
                    "value": phoneCode.charAt(0) === "-" ? `${phoneCode}`: `+${phoneCode}`,
                }) as MenuItem);

                currencyMenuItems = countries.currencies.map((currency: string) => ({
                    "label": currency,
                    "value": currency,
                }) as MenuItem);

                nationalityMenuItems = nationalityData.map((nationality: string) => ({
                    "label": nationality,
                    "value": nationality,
                }) as MenuItem);
                
                dispatch(setCountryNameMenuItems(countryNameMenuItems));
                dispatch(setCountryPhoneCodeMenuItems(countryPhoneCodeMenuItems));
                dispatch(setCurrencyMenuItems(currencyMenuItems));
                dispatch(setNationalityMenuItems(nationalityMenuItems));
            })
            .catch((error) => {
                console.error(error);
            });
    }, []);
}

export default useFetchCountries;
