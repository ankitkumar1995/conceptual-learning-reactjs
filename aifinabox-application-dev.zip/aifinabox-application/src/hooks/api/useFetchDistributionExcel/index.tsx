import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDistributionExcel () {
    const dispatch = useDispatch();

    const fetchTemplate = async (
        fundCode: string,
        clientId: string
    ): Promise<{
        "url": string;
    }> => {
        dispatch(setOpenBackdrop(true));

        let resUrl: string = "";

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/distributionexceltemplate?fundCode=${fundCode}&clientId=${clientId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => { 
                const responseData = response.data;
                resUrl = responseData.url;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
        
        dispatch(setOpenBackdrop(false));

        return {
            "url": resUrl,
        };
    };

    return fetchTemplate;
};

export default useFetchDistributionExcel;
