import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface EventIdData {
    eventId: string;
}

function useFetchEventIds() {
    const dispatch = useDispatch();

    const fetchEventIds = async (
        clientCode: string,
        fundCode: string,
        fundClassCategory: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let eventIds: MenuItem[] = [];

        const axiosConfig = {
            "url": `/eventid?clientCode=${clientCode}&fundCode=${fundCode}&fundClassCategory=${fundClassCategory}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const eventIdsData = responseData;

                eventIds = eventIdsData.map((eventIdData: EventIdData) => ({
                    "label": `${eventIdData.eventId}`,
                    "value": eventIdData.eventId,
                }) as MenuItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return eventIds;
    };

    return fetchEventIds;
}

export default useFetchEventIds;
