import {
    ASLDetailsForm,
    initialASLDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ASLDetailsForm/initialState";
import {
    BankDetailsForm,
    initialBankDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/BankDetailsForm/initialState";
import {
    BasicDetailsForm,
    initialBasicDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/BasicDetailsForm/initialState";
import {
    CommitteeMemberDetailsForm,
    initialCommitteeMemberDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/CommitteeMemberDetailsForm/initialState";
import {
    ContactPersonDetailsForm,
    initialContactPersonDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ContactPersonDetailsForm/initialState";
import {
    ContributionDetailsForm,
    initialContributionDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ContributionDetailsForm/initialState";
import {
    DirectorDetailsForm,
    initialDirectorDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DirectorDetailsForm/initialState";
import {
    DistributorDetailsForm,
    initialDistributorDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DistributorDetailsForm/initialState";
import {
    DocumentDetailsForm,
    initialDocumentDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DocumentDetailsForm/initialState";
import {
    EntityDetailsForm,
    initialEntityDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/EntityDetailsForm/initialState";
import {
    EntityFatcaAndCrsDetailsForm,
    initialEntityFatcaAndCrsDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/EntityFatcaAndCrsDetailsForm/initialState";
import {
    FatcaAndCrsDetailsForm,
    initialFatcaAndCrsDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/IndividualFatcaAndCrsDetailsForm/initialState";
import GetInvestorType, {
    Address,
    EmailId,
    PaymentBankDetails,
    RegAddr
} from "./interfaces/GetInvestor.types";
import {
    GuardianDetailsForm,
    initialGuardianDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/GuardianDetailsForm/initialState";
import {
    HolderDetailsForm,
    initialHolderDetailsFormState,
    initializeHolderDetails
} from "../../../redux/InvestorOnboarding/Maker/SubForms/HolderDetailsForm/initialState";
import {
    InvestmentDetailsForm,
    initialInvestmentDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/InvestmentDetailsForm/initialState";
import {
    KartaDetailsForm,
    initialKartaDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/KartaDetailsForm/initialState";
import {
    ModeOfAllotmentDetailsForm,
    initialModeOfAllotmentDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ModeOfAllotmentDetailsForm/initialState";
import {
    NomineeDetailsForm,
    initialNomineeDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/NomineeDetailsForm/initialState";
import {
    OTMDetailsForm,
    initializeOTMDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/OTMDetailsForm/initialState";
import {
    PartnersDetailsForm,
    initialPartnersDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PartnersDetailsForm/initialState";
import {
    PowerOfAttorneyDetailsForm,
    initialPowerOfAttorneyDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PowerOfAttorneyDetailsForm/initialState";
import {
    PrimaryHolderDetailsForm,
    initialPrimaryHolderDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PrimaryHolderDetailsForm/initialState";
import {
    PromoterDetailsForm,
    initialPromoterDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PromoterDetailsForm/initialState";
import {
    SipDetailsForm,
    initialSipDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/SipDetailsForm/initialState";
import {
    TrusteeDetailsForm,
    initialTrusteeDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/TrusteeDetailsForm/initialState";
import {
    UboDetailsForm,
    initialUboDetailsFormState
} from "../../../redux/InvestorOnboarding/Maker/SubForms/UboDetailsForm/initialState";
import { useDispatch, useSelector } from "react-redux";

import { MakerSubForms } from "../../../redux/InvestorOnboarding/Maker/SubForms";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import { RootState } from "../../../redux/store";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import {
    initializeBankDetails
} from "../../../pages/InvestorOnboarding/Maker/Form/SubForms/BankDetailsForm/interface/BankDetails";
import { nanoid } from "@reduxjs/toolkit";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

function getPrefixOrSuffix(inputString: string) {
    const delimiterIndex = inputString.indexOf(" ");
    const prefix = inputString.substring(0, delimiterIndex);
    const suffix = inputString.substring(delimiterIndex + 1);
    return { prefix, suffix };
}

export interface UserIdsType {
    auditorId: string | null;
    makerId: string | null;
    checkerId: string | null;
    qualityCheckerId: string | null;
}

export interface GetInvestorResponseType {
    investorDetailsForms: MakerSubForms;
    userIds: UserIdsType;
    transactionContribNo: string;
    transactionSipNo: string;
    txnType: string;
    txnCode: string;
}

interface GetInvestorMakerResponse {
    transactionContribNo: string;
    transactionSipNo: string;
    txnType: string;
    txnCode: string;
}

export interface InvestorInfo {
    "investorDetails": MakerSubForms;
    "userIds": UserIdsType;
}

export function getInvestorInfo(
    investorDetailsFromApi: GetInvestorType, 
    uboCategoryMenuItems: MenuItem[], 
    OccupationDetailsMenuItems: MenuItem[],
    occupationTypeMenuItems: MenuItem[], 
): InvestorInfo {

    let investorDetails: MakerSubForms;
    let userIds: UserIdsType;
    let aslDetailsData: ASLDetailsForm = initialASLDetailsFormState;
    let bankDetailsData: BankDetailsForm = initialBankDetailsFormState;
    let basicDetailsData: BasicDetailsForm = initialBasicDetailsFormState;
    let committeeMemberDetailsData: CommitteeMemberDetailsForm = initialCommitteeMemberDetailsFormState;
    let contactPersonDetailsData: ContactPersonDetailsForm = initialContactPersonDetailsFormState;
    let contributionDetailsData: ContributionDetailsForm = initialContributionDetailsFormState;
    let directorDetailsData: DirectorDetailsForm = initialDirectorDetailsFormState;
    let distributorDetailsData: DistributorDetailsForm = initialDistributorDetailsFormState;
    let documentDetailsData: DocumentDetailsForm = initialDocumentDetailsFormState;
    let entityDetailsData: EntityDetailsForm = initialEntityDetailsFormState;
    let entityFatcaAndCrsDetailsData: EntityFatcaAndCrsDetailsForm = initialEntityFatcaAndCrsDetailsFormState;
    let fatcaAndCrsDetailsData: FatcaAndCrsDetailsForm = initialFatcaAndCrsDetailsFormState;
    let guardianDetailsData: GuardianDetailsForm = initialGuardianDetailsFormState;
    let holderDetailsFormData: HolderDetailsForm = initialHolderDetailsFormState;
    let investmentDetailsData: InvestmentDetailsForm = initialInvestmentDetailsFormState;
    let kartaDetailsData: KartaDetailsForm = initialKartaDetailsFormState;
    let modeOfAllotmentDetailsData: ModeOfAllotmentDetailsForm = initialModeOfAllotmentDetailsFormState;
    let nomineeDetailsData: NomineeDetailsForm = initialNomineeDetailsFormState;
    let otmDetailsData: OTMDetailsForm = initializeOTMDetailsFormState;
    let partnerDetailsData: PartnersDetailsForm = initialPartnersDetailsFormState;
    let powerOfAttorneyDetailsData: PowerOfAttorneyDetailsForm = initialPowerOfAttorneyDetailsFormState;
    let primaryHolderDetailsData: PrimaryHolderDetailsForm = initialPrimaryHolderDetailsFormState();
    let promoterDetailsData: PromoterDetailsForm = initialPromoterDetailsFormState;
    let sipDetailsData: SipDetailsForm = initialSipDetailsFormState;
    let trusteeDetailsData: TrusteeDetailsForm = initialTrusteeDetailsFormState;
    let uboDetailsData: UboDetailsForm = initialUboDetailsFormState;

    const guardianOverseasAddress = investorDetailsFromApi?.guardianDetails?.address.find((add:Address) => add.isOverseasAddr);
    const guardianPermanentAddress = investorDetailsFromApi?.guardianDetails?.address.find((add:Address) => !add.isOverseasAddr);
    const entityCorAddress = investorDetailsFromApi?.entityDetails?.regAddr.find((add:RegAddr) => add.isCorrespAddr);
    const entityRegAddress = investorDetailsFromApi?.entityDetails?.regAddr.find((add:RegAddr) => !add.isCorrespAddr);

    const isPaymentDetailsArrayEmpty = (holder: PaymentBankDetails) => {
        if (
            holder?.foreignBankAccount &&
            holder?.isForeignBankAcct &&
            holder?.nationalBankAccount &&
            holder?.paymentBankIsRegBank
        ) {
            return true;
        }
        else {
            return false;
        }
    };

    const bankDetailsArray = (holder: any) => {
        return (
            holder?.map((bank: any) => {
                const CheckForeignAccount = () => {
                    const isForeign = bank.isForeignAcc;
                    if (isForeign) {
                        return bank.foreignBankAccount[0];
                    } else {
                        return bank.nationalBankAccount[0];
                    }
                };

                return {
                    "bankAccountNumber": !(bank.isForeignAcc) ? CheckForeignAccount().accNo ?? "" : "",
                    "bankAccountType": CheckForeignAccount().bankAccType ?? "",
                    "bankAddress": CheckForeignAccount().bankAddr ?? "",
                    "bankBranch": CheckForeignAccount().bankBranch ?? "",
                    "bankName": CheckForeignAccount().bankName ?? "",
                    "foreignBankAccountNumber": (bank.isForeignAcc) ? CheckForeignAccount().accNo ?? "" : "",
                    "foreignBankAccountProofRecieved": CheckForeignAccount().accProofFlag ?? "",
                    "ibanCode": CheckForeignAccount().ibanCode ?? "",
                    "ifscCode": CheckForeignAccount().ifsc ?? "",
                    "isItForeignBankAccount": bank.isForeignAcc ? "Yes" : "No",
                    "makeAsDefaultAccount": CheckForeignAccount().defaultAcc ? "Yes" : "No",
                    "micrCode": CheckForeignAccount().micr ?? "",
                    "pennyDropStatus": CheckForeignAccount().pennyDropStatus ?? "",
                    "pennyDropValidationDate": CheckForeignAccount().pennyDropValidationDt ?? "",
                    "swiftOrBicCode": CheckForeignAccount().swiftAndBic ?? "",
                };
            })
        );
    };
    
    const holderDetailsArray = (holder: any) => {
        return {
            "aadharNumber": holder?.aadharNo ?? "",
            "ckycOrKinNumber": holder?.ckycNo ?? "",
            "confirmEmailId": "",
            "confirmMobileNumber": "",
            "confirmMobileNumberPrefix": "",
            "confirmPanOrTaxIdNumber": "",
            "correspondenceAddress1": holder?.correspondenceAddrDetails?.[0].addr1 ?? "",
            "correspondenceAddress2": holder?.correspondenceAddrDetails?.[0].addr2 ?? "",
            "correspondenceAddress3": holder?.correspondenceAddrDetails?.[0].addr3 ?? "",
            "correspondenceCity": holder?.correspondenceAddrDetails?.[0].city ?? "",
            "correspondenceCountry": holder?.correspondenceAddrDetails?.[0].country ?? "",
            "correspondencePincode": holder?.correspondenceAddrDetails?.[0].pincode ?? "",
            "correspondenceState": holder?.correspondenceAddrDetails?.[0].state ?? "",
            "dateOfBirth": holder?.dob ?? "",
            "emailId": holder?.emailIds?.[0].emailId ?? "",
            "fatherOrSpouseName": holder?.fatherOrSpouseNameFlag === "Father" ? 
                holder?.fatherName ?? "" :
                holder?.spouseName ?? "",
            "fatherOrSpouseNameFlag": holder?.fatherOrSpouseNameFlag ?? "",
            "gender": holder?.gender ?? "",
            "holderTaxStatus": holder?.taxStatus ?? "",
            "key": nanoid(),
            "kraReferenceNumber": "",
            "landlineNumber": holder?.permanentAddrDetails?.[0].landlineNo ?? "",
            "mobileNumber": holder?.mobNo?.[0].mobNo ? getPrefixOrSuffix(holder?.mobNo[0].mobNo).suffix : "",
            "mobileNumberPrefix": holder?.mobNo?.[0].mobNo ? getPrefixOrSuffix(holder?.mobNo[0].mobNo).prefix : "",
            "motherName": holder?.motherName ?? "",
            "name": holder?.name ?? "",
            "namePrefix": holder?.salutation ?? "",
            "overseasAddress1": holder?.overseasAddrDetails?.[0].addr1 ?? "",
            "overseasAddress2": holder?.overseasAddrDetails?.[0].addr2 ?? "",
            "overseasAddress3": holder?.overseasAddrDetails?.[0].addr3 ?? "",
            "overseasCity": holder?.overseasAddrDetails?.[0].city ?? "",
            "overseasCountry": holder?.overseasAddrDetails?.[0].country ?? "",
            "overseasPincode": holder?.overseasAddrDetails?.[0].pincode ?? "",
            "overseasState": holder?.overseasAddrDetails?.[0].state ?? "",
            "panOrTaxIdNumber": holder?.taxId ?? "",
            "passportExpiryDate": holder?.passportExpiryDt ?? "",
            "passportNumber": holder?.passportNo ?? "",
            "permanentAddress1": holder?.permanentAddrDetails?.[0].addr1 ?? "",
            "permanentAddress2": holder?.permanentAddrDetails?.[0].addr2 ?? "",
            "permanentAddress3": holder?.permanentAddrDetails?.[0].addr3 ?? "",
            "permanentCity": holder?.permanentAddrDetails?.[0].city ?? "",
            "permanentCountry": holder?.permanentAddrDetails?.[0].country ?? "",
            "permanentPincode": holder?.permanentAddrDetails?.[0].pincode ?? "",
            "permanentState": holder?.permanentAddrDetails?.[0].state ?? "",
            "relationshipWithPrimaryHolder": holder?.relatshpWithPrimaryHolder ?? "",
            "sameAsPermanentAddress": holder?.permanentAddrDetails?.[0].correspAddrSimilarityFlag ? "Yes" : "No",
        };
    };

    const otmDetailsArray = (holder: any) => {
        return holder?.map((otmHolderType: any) => {
            return {
                "accountType": otmHolderType.accType ?? "",
                "bankAccountNumber": otmHolderType.accNo ?? "",
                "bankName": otmHolderType.bankName ?? "",
                "debitType": otmHolderType.debitType ?? "",
                "fromDate": otmHolderType.fromDt ?? "",
                "ifscCode": otmHolderType.ifsc ?? "",
                "isOTMMatchedWithBankDetails": otmHolderType.isOtmBankDetailsPrimaryDetails ? "Yes" : "No",
                "lastFourAccountNumber": otmHolderType.lastFourDigitsOfRegBankAccNo ?? "",
                "micrCode": otmHolderType.micr ?? "",
                "otmAmount": otmHolderType.otmAmt ?? "",
                "pennyDropStatus": otmHolderType.pennyDropStatus ?? "",
                "pennyDropValidationDt": otmHolderType.pennyDropValidationDt ?? "",
                "sponsorBankCode": otmHolderType.sponsorBankCode ?? "",
                "toDate": otmHolderType.toDt ?? "",
                "uniqueReferenceNumber": otmHolderType.uniqRefNo ?? "",
                "utilityCode": otmHolderType.utilityCode ?? "",
            };
        });
    };

    const paymentDetailsArray = (holder: PaymentBankDetails) => {
        return (
            {
                "accountType": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.paymentForeignBankAccType :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccType :
                        "",
                "isForeignBankAccount": holder?.isForeignBankAcct ?? "",
                "lastFourDigitsOfAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.lastFourDigitsOfRegForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.lastFourDigOfRegBankAccountNo :
                        "",
                "micrCode": holder?.nationalBankAccount[0]?.paymentBankMicr ?? "",
                "paymentBankAccountName": holder?.nationalBankAccount[0]?.paymentBankAccName ?? "",
                "paymentBankAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.regPaymentForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccNo :
                        "",
                "paymentBankAddress": holder?.foreignBankAccount[0]?.paymentBankAddr ?? "",
                "paymentBankBranch": holder?.foreignBankAccount[0]?.paymentBankBranch ?? "",
                "paymentBankIbanCode": holder?.foreignBankAccount[0]?.paymentBankIbanCode ?? "",
                "paymentBankIfscCode": holder?.nationalBankAccount[0]?.paymentBankIfsc ?? "",
                "paymentBankName": holder?.foreignBankAccount[0]?.paymentBankName ?? "",
                "paymentBankUtrNumber": holder?.nationalBankAccount[0]?.paymentBankUtrNo ?? "",
                "paymentChequeDetails": holder?.nationalBankAccount[0]?.paymentBankChqRefNo ?
                    holder?.nationalBankAccount[0]?.paymentBankChqRefNo?.map((cheque) => {
                        return {
                            "chequeAmount": cheque.chequeAmount ?? "",
                            "chequeReferenceNumber": cheque.chequeRefNo ?? "",
                        };
                    }) : [],
                "paymentType": holder?.nationalBankAccount[0]?.paymentType ?? "",
                "pennyDropStatus": "",
                "pennyDropValidationDate": null,
                "sameAsRegisteredBank": holder?.paymentBankIsRegBank ?? "",
                "swiftOrBicCode": holder?.foreignBankAccount[0]?.paymentBankSwiftAndBic ?? "",
            }
        );
    };

    aslDetailsData = {
        "aslDetails": investorDetailsFromApi.asl.map((asl) => {
            return {
                "confirmPanTaxIdNo": "",
                "dateOfBirth": asl.dob ?? "",
                "gender": asl.gender ?? "",
                "key": nanoid(),
                "name": asl.name ?? "",
                "panOrTaxIdNumber": asl.taxIdNo ?? "",
                "politicallyExposedPerson": asl.isPep ? "Yes" : "No",
            };
        })
    };

    bankDetailsData = {
        "bankDetails": [
            bankDetailsArray(investorDetailsFromApi.bankDetails.primaryHolderBank),
            investorDetailsFromApi.bankDetails.secondHolderBankDetails 
                ? bankDetailsArray(investorDetailsFromApi.bankDetails.secondHolderBankDetails) 
                : [initializeBankDetails()],
            investorDetailsFromApi.bankDetails.thirdHolderBankDetails
                ? bankDetailsArray(investorDetailsFromApi.bankDetails.thirdHolderBankDetails)
                : [initializeBankDetails()],
        ]
    };

    basicDetailsData = {
        "accreditation": investorDetailsFromApi.basicDetails.accreditationFlag ? "Yes" : "No",
        "applicationId": investorDetailsFromApi.basicDetails.applnId ?? "",
        "confirmGuardianPanNumber": "",
        "confirmMobileNumber": "",
        "confirmMobileNumberPrefix": "",
        "confirmPanNumber": "",
        "dateOfBirth": investorDetailsFromApi.basicDetails.invType === "Individual" ? 
            investorDetailsFromApi.basicDetails.dob :
            investorDetailsFromApi.basicDetails.dateOfReg,
        "emailInfo":
            investorDetailsFromApi.basicDetails.emailIds.map((email: EmailId) => {
                return {
                    "confirmEmailId": "",
                    "emailId": email.emailId ?? "",
                    "emailIdPertainTo": email.emailIdPertainTo ?? ""
                };
            }),
        "guardianPanNumber": investorDetailsFromApi.basicDetails.guardianTaxId ?? "",
        "investorCategory": investorDetailsFromApi.basicDetails.invCategory ?? "",
        "investorType": investorDetailsFromApi.basicDetails.invType ?? "",
        "mobileNumber": investorDetailsFromApi?.basicDetails?.mobNo[0]?.mobNo ? getPrefixOrSuffix(investorDetailsFromApi?.basicDetails?.mobNo[0]?.mobNo).suffix : "",
        "mobileNumberPertainTo": investorDetailsFromApi?.basicDetails?.mobNo[0]?.mobNoPertainTo ?? "",
        "mobileNumberPrefix": investorDetailsFromApi?.basicDetails?.mobNo[0]?.mobNo ? getPrefixOrSuffix(investorDetailsFromApi?.basicDetails?.mobNo[0]?.mobNo).prefix : "",
        "modeOfHolding": investorDetailsFromApi.basicDetails.modeOfHolding ?? "",
        "panExemptedApprovalAttachment": "",
        "panExemptedApprovalAttachmentFile": null,
        "panExemptedApprovalAttachmentFileFormat": "",
        "panExemptedApprovalAttachmentFileS3Key": "",
        "panExemptedApprovalAttachmentFileS3SignedURL": "",
        "panExemptedApprovalAttachmentFileSize": "",
        "panExemptedInvestor": investorDetailsFromApi.basicDetails.taxIdExemptionFlag ? "Yes" : "No",
        "panNumber": investorDetailsFromApi.basicDetails.taxId ?? "",
        "placeOfRegistration": investorDetailsFromApi.basicDetails.placeOfReg ?? "",
        "poaNonPoa": investorDetailsFromApi.basicDetails.poaFlag ? "POA" : "Non-POA",
        "primaryHolderTaxStatus": investorDetailsFromApi.basicDetails.invTaxStatus ?? "",
        "productType": investorDetailsFromApi.basicDetails.prodType ?? "",
    };

    committeeMemberDetailsData = {
        "committees": investorDetailsFromApi.committeeDetails.map((committee: any) => {
            return {
                "confirmPanTaxIdNo": "",
                "dateOfBirth": committee.dob ?? "",
                "gender": committee.gender ?? "",
                "name": committee.name ?? "",
                "panTaxIdNo": committee.taxIdNo ?? "",
                "politicallyExposedMember": committee.isPep ? "Yes" : "No",
            };
        }),
        "deleteCommittee": 1,
        "numberOfCommittees": investorDetailsFromApi.committeeDetails.length,
    };

    contactPersonDetailsData = {
        "contactPerson": investorDetailsFromApi.contactPersonDetails.map((contactPerson: any) => {
            const mobileNumber = contactPerson?.mobNo[0]?.split(" ");
            return {
                "address1": contactPerson.addr1 ?? "",
                "address2": contactPerson.addr2 ?? "",
                "address3": contactPerson.addr3 ?? "",
                "city": contactPerson.city ?? "",
                "confirmEmailId": "",
                "confirmMobileNumber": "",
                "confirmMobileNumberPrefix": "",
                "country": contactPerson.country ?? "",
                "emailId": contactPerson.emailId[0] ?? "",
                "gender": contactPerson.gender ?? "",
                "key": nanoid(),
                "mobileNumber": contactPerson?.mobNo.length > 0 ? mobileNumber[1] : "",
                "mobileNumberPrefix": contactPerson?.mobNo.length > 0 ? mobileNumber[0] : "",
                "name": contactPerson.name ?? "",
                "namePrefix": contactPerson.salutation ?? "",
                "pincode": contactPerson.pincode ?? "",
                "state": contactPerson.state ?? "",
            };
        })
    };

    const paymentBankDetails = [];

    if (isPaymentDetailsArrayEmpty(investorDetailsFromApi.initialContribution.paymentBankDetails.primaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(investorDetailsFromApi.initialContribution.paymentBankDetails.primaryHolderPaymentBank));

    if (isPaymentDetailsArrayEmpty(investorDetailsFromApi.initialContribution.paymentBankDetails.secondaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(investorDetailsFromApi.initialContribution.paymentBankDetails.secondaryHolderPaymentBank));
    
    if (isPaymentDetailsArrayEmpty(investorDetailsFromApi.initialContribution.paymentBankDetails.thirdHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(investorDetailsFromApi.initialContribution.paymentBankDetails.thirdHolderPaymentBank));

    contributionDetailsData = {
        "collectionBankAccountNumber": investorDetailsFromApi.initialContribution.depositBankDetails.bankAccNo ?? "",
        "collectionBankIfscCode": investorDetailsFromApi.initialContribution.depositBankDetails.ifsc ?? "",
        "collectionBankName": investorDetailsFromApi.initialContribution.depositBankDetails.bankName ?? "",
        "commitmentAmount": investorDetailsFromApi.initialContribution.contributionDetails.commitmentAmount ?? "",
        "exchangeRate": investorDetailsFromApi.initialContribution.contributionDetails.exchngRate ?? "",
        "fundCurrency": investorDetailsFromApi.initialContribution.contributionDetails.fundCurrency ?? "",
        "fundCurrencyAmount": investorDetailsFromApi.initialContribution.contributionDetails.fundCurrencyAmount ?? "",
        "gstOrServiceTax": investorDetailsFromApi.initialContribution.contributionDetails.gst ?? "",
        "gstWaiver": investorDetailsFromApi.initialContribution.contributionDetails.gstWaiver ?? "",
        "gstWaiverApprovalEmail": "",
        "gstWaiverApprovalEmailFile": null,
        "gstWaiverApprovalEmailFileFormat": "",
        "gstWaiverApprovalEmailFileS3Key": "",
        "gstWaiverApprovalEmailFileS3SignedURL": "",
        'gstWaiverApprovalEmailFileSize': "",
        "initialContributionAmount": investorDetailsFromApi.initialContribution.contributionDetails.initContribAmt ?? "",
        "otherFee": investorDetailsFromApi.initialContribution.contributionDetails.otherFee ?? "",
        "paymentBankDetails": paymentBankDetails,
        "primaryHolderContribution": investorDetailsFromApi.initialContribution.contributionDetails.primaryHolderContrib ?? "",
        "primaryHolderPercentage": investorDetailsFromApi.initialContribution.contributionDetails.primaryHolderPercent ?? "",
        "secondHolderContribution": investorDetailsFromApi.initialContribution.contributionDetails.secondHolderContrib ?? "",
        "secondHolderPercentage": investorDetailsFromApi.initialContribution.contributionDetails.secondHolderPercent ?? "",
        "setupFeeAmount": investorDetailsFromApi.initialContribution.contributionDetails.setupFeeAmt ?? "",
        "setupFeePercentage": investorDetailsFromApi.initialContribution.contributionDetails.setupFeePercent ?? "",
        "thirdHolderContribution": investorDetailsFromApi.initialContribution.contributionDetails.thirdHolderContrib ?? "",
        "thirdHolderPercentage": investorDetailsFromApi.initialContribution.contributionDetails.thirdHolderPercent ?? "", 
        "totalSetupFee": investorDetailsFromApi.initialContribution.contributionDetails.totalSetupFee ?? "", 
        "transactionCurrency": investorDetailsFromApi.initialContribution.contributionDetails.transactionCurrency ?? "",
    };

    directorDetailsData = {
        "directores": investorDetailsFromApi.directorDetails.map((director: any) => {
            return {
                "confirmPanTaxIdNmuber": "",
                "dateOfBirth": director.dob ?? "",
                "directorIdentificationNumber": director.din ?? "",
                "gender": director.gender ?? "",
                "key": nanoid(),
                "name": director.name ?? "",
                "panTaxIdNmuber": director.taxIdNo ?? "",
                "politicallyExposedPerson": director.isPep ? "Yes" : "No",
            };
        })
    };

    distributorDetailsData = {
        "amcRmCode": investorDetailsFromApi.distributorDetails.amcRmCode ?? "",
        "amcRmEmailId": investorDetailsFromApi.distributorDetails.amcRmEmailIDs.map((email: string) => email),
        "amcRmName": investorDetailsFromApi.distributorDetails.amcRmName ?? "",
        "distributorCode": investorDetailsFromApi.distributorDetails.distributorCode ?? "",
        "distributorName": investorDetailsFromApi.distributorDetails.distributorName ?? "",
        "distributorRmCode": investorDetailsFromApi.distributorDetails.distributorRmCode ?? "",
        "distributorRmEmailId": investorDetailsFromApi.distributorDetails.distributorRmEmails.map((email: string) => email),
        "distributorRmMobileNumber": investorDetailsFromApi.distributorDetails.distributorRmMobNo ? getPrefixOrSuffix(investorDetailsFromApi.distributorDetails.distributorRmMobNo).suffix : "",
        "distributorRmMobileNumberPrefix": investorDetailsFromApi.distributorDetails.distributorRmMobNo ? getPrefixOrSuffix(investorDetailsFromApi.distributorDetails.distributorRmMobNo).prefix : "",
        "distributorRmName": investorDetailsFromApi.distributorDetails.distributorRmName ?? "",
        "distributorType": investorDetailsFromApi.distributorDetails.distributorType ?? "",
    };
    
    documentDetailsData = {
        "individual": {
            "mandatoryDocumentDetails": { "applicationFormAndContributionAgreement": investorDetailsFromApi.documentDetails.mandatoryDocumentProvided.applicationFormAndContributionAgreement ?? "No" }, 
            "minorAndGuardianDocumentDetails": investorDetailsFromApi.documentDetails.minorAndGuardianDocs,
            "otherDocumentDetails": investorDetailsFromApi.basicDetails.invType === "Individual" 
                ? ((investorDetailsFromApi.documentDetails.otherDocuments) as DocumentDetailsForm["individual"]["otherDocumentDetails"])
                : {
                    "accreditationCertificate": "No",
                    "clientMasterListForDematAllocation": "No",
                    "foreignPaymentBankAccountFormReceived": "No",
                    "kycModificationFormReceived": "No",
                    "otmOrNachForm": "No",
                    "panOrTaxIdExemptedGovernmentIssuedExceptionDocument": "No"
                },
            "poaDocumentDetails": investorDetailsFromApi.basicDetails.invType === "Individual"
                ? investorDetailsFromApi.documentDetails.poaDocs 
                : { "poaAuthorizedSignatoriesListIfNonIndividual": "No",
                    "poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual": "No",
                    "poaBoardResolutionIfNonIndividual": "No",
                    "powerOfAttorneyAgreementWithInvestor": "No",
                    "powerOfAttorneyKycDocuments": "No"
                },
            "primaryHolderDocumentDetails": investorDetailsFromApi.documentDetails.primaryHolderDocs,
            "secondaryHolderDocumentDetails": investorDetailsFromApi.documentDetails.secondHolderDocs,
            "thirdHolderDocumentDetails": investorDetailsFromApi.documentDetails.thirdHolderDocs,
        },
        "nonIndividual": {
            "armyOrGovernmentBodiesDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsGovtBodies,
            "banksOrInstitutionalInvestorsDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsInstitutionalInvestors,
            "corporateDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsCorporate,
            "foreignInstitutionalInvestors": investorDetailsFromApi.documentDetails.documentDetailsFII,
            "hufDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsHUF,
            "mandatoryDocumentsDetails": investorDetailsFromApi.basicDetails.invType === "Non-Individual" 
                ? (investorDetailsFromApi.documentDetails.mandatoryDocumentProvided) as DocumentDetailsForm["nonIndividual"]["mandatoryDocumentsDetails"] 
                : {
                    "addressProof": "No",
                    "applicationFormAndContributionAgreement": "No",
                    "bankProof": "No",
                    "copyOfEntityPanOrTaxId": "No",
                    "fatcaOrCrsDeclarationForm": "No",
                    "uboDeclarationForm": "No"
                },
            "otherDocumentDetails": investorDetailsFromApi.basicDetails.invType === "Non-Individual"
                ? investorDetailsFromApi.documentDetails.otherDocuments as DocumentDetailsForm["nonIndividual"]["otherDocumentDetails"]
                : {
                    "accreditationCertificate": "No",
                    "clientMasterListForDematAllocation": "No",
                    "foreignPaymentBankAccountProofReceived": "No",
                    "kycModificationFormReceived": "No",
                    "otmOrNachForm": "No",
                    "panOrTaxIdExemptedGovernmentIssuedExceptionDocument": "No"
                },
            "partnershipDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsPartnership,
            "poaDocumentDetails": investorDetailsFromApi.basicDetails.invType === "Non-Individual"
                ? investorDetailsFromApi.documentDetails.poaDocs
                : {
                    "poaAuthorizedSignatoriesListIfNonIndividual": "No",
                    "poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual": "No",
                    "poaBoardResolutionIfNonIndividual": "No",
                    "powerOfAttorneyAgreementWithInvestor": "No",
                    "powerOfAttorneyKycDocuments": "No"
                },
            "proprietorshipDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsProprietorship,
            "registeredSocietyDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsRegisteredSociety,
            "trustDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsTrust,
            "unincorporatedDocumentDetails": investorDetailsFromApi.documentDetails.documentDetailsUnincorporatedAssociation,
        },
    };
    
    entityDetailsData = {
        "accreditationNumber": investorDetailsFromApi.entityDetails.accreditationNo ?? "",
        "accreditationValidityDate": investorDetailsFromApi.entityDetails.accreditationValidityDt ?? "",
        "ckycOrKinNumber": investorDetailsFromApi.entityDetails.ckycNo ?? "",
        "corporateIdentificationNumber": investorDetailsFromApi.entityDetails.cin ?? "",
        "correspondanceAddress1": entityCorAddress?.addr1 ?? "",
        "correspondanceAddress2": entityCorAddress?.addr2 ?? "",
        "correspondanceAddress3": entityCorAddress?.addr3 ?? "",
        "correspondanceCity": entityCorAddress?.city ?? "",
        "correspondanceCountry": entityCorAddress?.country ?? "",
        "correspondancePinCode": entityCorAddress?.pincode ?? "",
        "correspondanceState": entityCorAddress?.state ?? "",
        "kraReferenceNumber": "", 
        "landlineNumber": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].landlineNo ?? "",
        "leiExpiryDate": investorDetailsFromApi.entityDetails.leiExpiryDt ?? "",
        "leiNumber": investorDetailsFromApi.entityDetails.leiNo ?? "",
        "nameOfTheEntity": investorDetailsFromApi.entityDetails.nameOfTheEntity ?? "",
        "overseasAddress1": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].addr1 ?? "",
        "overseasAddress2": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].addr2 ?? "",
        "overseasAddress3": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].addr3 ?? "",
        "overseasCity": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].city ?? "",
        "overseasCountry": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].country ?? "",
        "overseasPinCode": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].pincode ?? "",
        "overseasState": investorDetailsFromApi.entityDetails.overseasAddrDetails[0].state ?? "",
        "registeredAddress1": entityRegAddress?.addr1 ?? "",
        "registeredAddress2": entityRegAddress?.addr2 ?? "",
        "registeredAddress3": entityRegAddress?.addr3 ?? "",
        "registeredCity": entityRegAddress?.city ?? "",
        "registeredCountry": entityRegAddress?.country ?? "",
        "registeredPinCode": entityRegAddress?.pincode ?? "",
        "registeredState": entityRegAddress?.state ?? "",
        "sameAsRegisteredAddress": entityRegAddress?.correspSameAsRegAddr ? "Yes" : "No",
    };

    entityFatcaAndCrsDetailsData = {
        "cityOfIncorporation": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.cityOfInc ?? "",
        "countryOfIncorporation": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.ctryOfInc ?? "",
        "countryOtherThanIndia": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.ctryOfTaxRes ?? "",
        "entityConstitutionType": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.entityConstitutionType ?? "",
        "entityFatcaAndCrs": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.fatcaAndCrsFlag ? "Yes" : "No",
        "fatcaPartAToBeFilledBy": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partA.toBeFilledBy ?? "",
        "fatcaPartBToBeFilledBy": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.toBeFilledBy ?? "",
        "giinNotAvailable": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partA.giinNotAvbl ?? "",
        "giinNumber": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partA.giinNo ?? "",
        "grossAnnualIncome": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.grossAnnualIncome ?? "",
        "involvedInAnyOfTheMentionedServices": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.involvedInMentionedServices ?? "",
        "isTheAccountHolderGovernmentBody": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.govtBodyIntlOrgListedStockexchngFlag ? "Yes" : "No",
        "isTheAccountHolderIndianFinancialInstitution": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.isIndianFinInst ? "Yes" : "No",
        "nameOfBusiness": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.nameOfBusiness ?? "",
        "nameOfListedCompany": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.nameOfListedCo ?? "",
        "nameOfTheSponsoringEntity": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partA.nameOfSponseringEntity ?? "",
        "nameOfTheStockExchange": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.nameOfStkExchng ?? "",
        "natureOfBusiness": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.natureOfBusiness ?? "",
        "natureOfRelation": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.natureOfRel ?? "",
        "networth": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.networth ?? "",
        "networthAsOnDate": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.networthAsOnDt ?? "",
        "politicallyExposedPerson": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.isEntityPep ? "Yes" : "No",
        "subCategoryOfActiveNfe": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.partB.subcategoryOfActiveNfe ?? "",
        "taxPayerIdentificationNumber": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.taxPayerIdNo ?? "",
        "taxPayerIdentificationType": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.taxPayerIdType ?? "",
        "taxResidencyOtherThanIndia": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.isTaxResNotIndia ? "Yes" : "No",
        "typeOfAddressProvidedAtKra": investorDetailsFromApi.fatcaDetails.nonIndividualFatca.typeOfAddrAtKra ?? "",
    };
    
    fatcaAndCrsDetailsData = {
        "fatcaAndCrsDetails": [
            {
                "cityOrPlaceOfBirth": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.placeOfBirth ?? "",
                "countryOfBirth": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.ctryOfBirth ?? "",
                "countryOfTaxResindency": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.ctryOfTaxRes ?? "",
                "dateOfAnnualIncome": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.dateOfAnnIncome ?? "",
                "holderFatcaAndCrs": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.fatcaAndCrsFlag ? "Yes" : "No",
                "incomeSlabOrGrossAnnualIncome": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.grossAnnIncome ?? "",
                "key": nanoid(),
                "nationality": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.nationality ?? "",
                "occuptionDetails": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.primaryHolderFatca.occupation) ? 
                    investorDetailsFromApi.fatcaDetails.primaryHolderFatca.occupation :
                    "Others",
                "pleaseSpecify": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.primaryHolderFatca.occupation) ? "" : 
                    investorDetailsFromApi.fatcaDetails.primaryHolderFatca.occupation,
                "politicallyExposedPerson": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.isPep ? "Yes" : "No",
                "taxPayerIdentificationNumber": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.taxPayerIdNo ?? "",
                "taxPayerIdentificationType": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.taxPayerIdType ?? "",
                "taxResidencyOtherThanIndia": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.isTaxResNotIndia ? "Yes" : "No",
                "typeOfAddressProvidedAtKra": investorDetailsFromApi.fatcaDetails.primaryHolderFatca.typeOfAddrAtKra ?? "",
            },
            {
                "cityOrPlaceOfBirth": investorDetailsFromApi.fatcaDetails.guardianFatca.placeOfBirth ?? "",
                "countryOfBirth": investorDetailsFromApi.fatcaDetails.guardianFatca.ctryOfBirth ?? "",
                "countryOfTaxResindency": investorDetailsFromApi.fatcaDetails.guardianFatca.ctryOfTaxRes ?? "",
                "dateOfAnnualIncome": investorDetailsFromApi.fatcaDetails.guardianFatca.dateOfAnnIncome ?? "",
                "holderFatcaAndCrs": investorDetailsFromApi.fatcaDetails.guardianFatca.fatcaAndCrsFlag ? "Yes" : "No",
                "incomeSlabOrGrossAnnualIncome": investorDetailsFromApi.fatcaDetails.guardianFatca.grossAnnIncome ?? "",
                "key": nanoid(),
                "nationality": investorDetailsFromApi.fatcaDetails.guardianFatca.nationality ?? "",
                "occuptionDetails": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.guardianFatca.occupation) ? 
                    investorDetailsFromApi.fatcaDetails.guardianFatca.occupation :
                    "Others",
                "pleaseSpecify": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.guardianFatca.occupation) ? "" : 
                    investorDetailsFromApi.fatcaDetails.guardianFatca.occupation,
                "politicallyExposedPerson": investorDetailsFromApi.fatcaDetails.guardianFatca.isPep ? "Yes" : "No",
                "taxPayerIdentificationNumber": investorDetailsFromApi.fatcaDetails.guardianFatca.taxPayerIdNo ?? "",
                "taxPayerIdentificationType": investorDetailsFromApi.fatcaDetails.guardianFatca.taxPayerIdType ?? "",
                "taxResidencyOtherThanIndia": investorDetailsFromApi.fatcaDetails.guardianFatca.isTaxResNotIndia ? "Yes" : "No",
                "typeOfAddressProvidedAtKra": investorDetailsFromApi.fatcaDetails.guardianFatca.typeOfAddrAtKra ?? "",
            },
            {
                "cityOrPlaceOfBirth": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.placeOfBirth ?? "",
                "countryOfBirth": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.ctryOfBirth ?? "",
                "countryOfTaxResindency": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.ctryOfTaxRes ?? "",
                "dateOfAnnualIncome": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.dateOfAnnIncome ?? "",
                "holderFatcaAndCrs": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.fatcaAndCrsFlag ? "Yes" : "No",
                "incomeSlabOrGrossAnnualIncome": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.grossAnnIncome ?? "",
                "key": nanoid(),
                "nationality": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.nationality ?? "",
                "occuptionDetails": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.occupation) ? 
                    investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.occupation :
                    "Others",
                "pleaseSpecify": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.occupation) ? "" : 
                    investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.occupation,
                "politicallyExposedPerson": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.isPep ? "Yes" : "No",
                "taxPayerIdentificationNumber": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.taxPayerIdNo ?? "",
                "taxPayerIdentificationType": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.taxPayerIdType ?? "",
                "taxResidencyOtherThanIndia": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.isTaxResNotIndia ? "Yes" : "No",
                "typeOfAddressProvidedAtKra": investorDetailsFromApi.fatcaDetails.secondaryHolderFatca.typeOfAddrAtKra ?? "",
            },
            {
                "cityOrPlaceOfBirth": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.placeOfBirth ?? "",
                "countryOfBirth": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.ctryOfBirth ?? "",
                "countryOfTaxResindency": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.ctryOfTaxRes ?? "",
                "dateOfAnnualIncome": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.dateOfAnnIncome ?? "",
                "holderFatcaAndCrs": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.fatcaAndCrsFlag ? "Yes" : "No",
                "incomeSlabOrGrossAnnualIncome": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.grossAnnIncome ?? "",
                "key": nanoid(),
                "nationality": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.nationality ?? "",
                "occuptionDetails": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.thirdHolderFatca.occupation) ? 
                    investorDetailsFromApi.fatcaDetails.thirdHolderFatca.occupation :
                    "Others",
                "pleaseSpecify": OccupationDetailsMenuItems
                    .some(item => item.value === investorDetailsFromApi.fatcaDetails.thirdHolderFatca.occupation) ? "" : 
                    investorDetailsFromApi.fatcaDetails.thirdHolderFatca.occupation,
                "politicallyExposedPerson": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.isPep ? "Yes" : "No",
                "taxPayerIdentificationNumber": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.taxPayerIdNo ?? "",
                "taxPayerIdentificationType": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.taxPayerIdType ?? "",
                "taxResidencyOtherThanIndia": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.isTaxResNotIndia ? "Yes" : "No",
                "typeOfAddressProvidedAtKra": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.typeOfAddrAtKra ?? "",
            }
        ],
        "isThirdFatcaAndCrs": investorDetailsFromApi.fatcaDetails.thirdHolderFatca.typeOfAddrAtKra ? true : false,
            
    };

    investmentDetailsData = {
        "classOrPlan": investorDetailsFromApi.initialContribution.investmentDetails.class ?? "",
        "contributionAgreementDate": investorDetailsFromApi.initialContribution.investmentDetails.contribAgrmntDt ?? "",
        "schemeCode": investorDetailsFromApi.initialContribution.investmentDetails.schemeCode ?? "",
        "schemeIsinNumber": investorDetailsFromApi.initialContribution.investmentDetails.schemeIsinNo ?? "",
        "schemeName": investorDetailsFromApi.initialContribution.investmentDetails.schemeName ?? "",
        "transactionType": investorDetailsFromApi.initialContribution.investmentDetails.transactionType ?? "",
        "transactionTypeCode": investorDetailsFromApi.transactionCode ?? "",
    };

    guardianDetailsData = {
        "aadharNumber": investorDetailsFromApi.guardianDetails.aadharNo ?? "",
        "confirmOverseasEmailId": "",
        "confirmOverseasMobileNo": "",
        "confirmOverseasMobileNoPrefix": "",
        "dateOfBirth": investorDetailsFromApi.guardianDetails.dob ?? "",
        "gender": investorDetailsFromApi.guardianDetails.gender ?? "",
        "guardianName": investorDetailsFromApi.guardianDetails.name ?? "",
        "guardianNamePrefix": investorDetailsFromApi.guardianDetails.salutation ?? "",
        "guardianRelationship": investorDetailsFromApi.guardianDetails.relationship ?? "",
        "overseasAddress1": guardianOverseasAddress?.addr1 ?? "",
        "overseasAddress2": guardianOverseasAddress?.addr2 ?? "",
        "overseasAddress3": guardianOverseasAddress?.addr3 ?? "",
        "overseasCity": guardianOverseasAddress?.city ?? "",
        "overseasCkycKinNo": investorDetailsFromApi.guardianDetails.ckycNo ?? "",
        "overseasCountry": guardianOverseasAddress?.country ?? "",
        "overseasEmailId": investorDetailsFromApi.guardianDetails.emailIds[0].emailId ?? "",
        "overseasEmailIdPertainTo": investorDetailsFromApi.guardianDetails.emailIds[0].emailIdPertainTo ?? "",
        "overseasKraRefNo": "",
        "overseasLandlineNo": guardianOverseasAddress?.landlineNo ?? "",
        "overseasMobileNo": investorDetailsFromApi.guardianDetails.mobNo[0].mobNo ? getPrefixOrSuffix(investorDetailsFromApi.guardianDetails.mobNo[0].mobNo).suffix : "",
        "overseasMobileNoPertainTo": investorDetailsFromApi.guardianDetails.mobNo[0].mobNo ? investorDetailsFromApi.guardianDetails.mobNo[0].mobNoPertainTo : "",
        "overseasMobileNoPrefix": investorDetailsFromApi.guardianDetails.mobNo[0].mobNo ? getPrefixOrSuffix(investorDetailsFromApi.guardianDetails.mobNo[0].mobNo).prefix : "",
        "overseasPincode": guardianOverseasAddress?.pincode ?? "",
        "overseasState": guardianOverseasAddress?.state ?? "",
        "passportExpiryDate": investorDetailsFromApi.guardianDetails.passportExpiryDt ?? "",
        "passportNumber": investorDetailsFromApi.guardianDetails.passportNo ?? "",
        "permanentAddress1": guardianPermanentAddress?.addr1 ?? "",
        "permanentAddress2": guardianPermanentAddress?.addr2 ?? "",
        "permanentAddress3": guardianPermanentAddress?.addr3 ?? "",
        "permanentCity": guardianPermanentAddress?.city ?? "",
        "permanentCountry": guardianPermanentAddress?.country ?? "",
        "permanentPincode": guardianPermanentAddress?.pincode ?? "",
        "permanentState": guardianPermanentAddress?.state ?? "",
        "taxStatus": investorDetailsFromApi.guardianDetails.taxStatus ?? "",
    };
    
    holderDetailsFormData = {
        "holderDetails": [
            investorDetailsFromApi.secondaryHolderDetails ? holderDetailsArray(investorDetailsFromApi.secondaryHolderDetails) : initializeHolderDetails(),
            investorDetailsFromApi.thirdHolderDetails ? holderDetailsArray(investorDetailsFromApi.thirdHolderDetails) : initializeHolderDetails()
        ]
    };

    kartaDetailsData = {
        "kartaDetailsList": investorDetailsFromApi.kartaDetails.map((karta: any) => {
            return {
                "confirmPanOrTaxIdNumber": "",
                "dateOfBirth": karta.dob ?? "",
                "gender": karta.gender ?? "",
                "key": nanoid(),
                "name": karta.name ?? "",
                "panOrTaxIdNumber": karta.taxIdNo ?? "",
                "politicallyExposedPerson": karta.isPep ? "Yes" : "No",
            };
        }),
    };

    modeOfAllotmentDetailsData = {
        "allotmentMode": investorDetailsFromApi.allotmentMode.modeOfAllotment ?? "",
        "clientId": investorDetailsFromApi.allotmentMode.clientId ?? "",
        "dpId": investorDetailsFromApi.allotmentMode.dPId ?? "",
        "repositoryType": investorDetailsFromApi.allotmentMode.repositoryType ?? "",
    };

    nomineeDetailsData = {
        "nominees": investorDetailsFromApi.nomineeDetails.nominees.map((nomineesData: any) => {
            return {
                "allocationPercentage": nomineesData.allocationPercent ?? "",
                "confirmEmailId": "",
                "confirmMobileNumber": "",
                "confirmMobileNumberPrefix": "",
                "dateOfBirth": nomineesData.dtOfBirth ?? "",
                "emailId": nomineesData.emailId[0] ?? "",
                "guardianIdNumber": nomineesData.guardianIdNo ?? "",
                "guardianName": nomineesData.guardianName ?? "",
                "guardianRelationshipWithMinorNominee": nomineesData.guardianMinorNomineeRelatshp ?? "",
                "mobileNumber": nomineesData.mobNo[0] ? getPrefixOrSuffix(nomineesData.mobNo[0]).suffix : "",
                "mobileNumberPrefix": nomineesData.mobNo[0] ? getPrefixOrSuffix(nomineesData.mobNo[0]).prefix : "",
                "name": nomineesData.nomineeName ?? "",
                "nomineeIdProofNumber": nomineesData.nomineeIdProofNo ?? "",
                "nomineeRelationShip": nomineesData.nomineeRelatshp ?? "",
            };
        }),
        "numberOfNominees": investorDetailsFromApi.nomineeDetails.noOfNominees ?? "0",
        "wishToNominate": investorDetailsFromApi.nomineeDetails.nominees.length > 0 ? "Yes" : "No",
    };

    otmDetailsData = {
        "otmDetails": [
            otmDetailsArray(investorDetailsFromApi.sipReg[0].otmDetails.primaryInvOtm),
            investorDetailsFromApi.sipReg[0].otmDetails.secondaryHolderOtm &&
            otmDetailsArray(investorDetailsFromApi.sipReg[0].otmDetails.secondaryHolderOtm),
            investorDetailsFromApi.sipReg[0].otmDetails.thirdHolderOtm &&
            otmDetailsArray(investorDetailsFromApi.sipReg[0].otmDetails.thirdHolderOtm),
        ],
    };

    partnerDetailsData = {
        "partnerCount": investorDetailsFromApi.partnerDetails.length,
        "partnerInfo": investorDetailsFromApi.partnerDetails.map((partnerData: any) => {
            return {
                "confirmPartnerPan": "",
                "key": nanoid(),
                "partnerDateOfBirth": partnerData.dob ?? "",
                "partnerGender": partnerData.gender ?? "",
                "partnerName": partnerData.name ?? "",
                "partnerPan": partnerData.taxIdNo ?? "",
                "politicallyExposedPerson": partnerData.isPep ? "Yes" : "No",
            };
        })
    };

    powerOfAttorneyDetailsData = {
        "address2": investorDetailsFromApi.poa.poaAddr2 ?? "",
        "address3": investorDetailsFromApi.poa.poaAddr3 ?? "",
        "city": investorDetailsFromApi.poa.city ?? "",
        "confirmEmailId": "",
        "confirmMobileNumber": "",
        "confirmMobileNumberPrefix": "",
        "confirmPanOrTaxIdNumber": "",
        "country": investorDetailsFromApi.poa.country ?? "",
        "dateOfBirth": investorDetailsFromApi.poa.dob ?? investorDetailsFromApi.poa.incDt ?? "",
        "emailId": investorDetailsFromApi.poa.poaEmailIds[0] ?? "",
        "kinOrCkycNumber": investorDetailsFromApi.poa.poaCkycNo ?? "",
        "kraReference": "",
        "landlineNumber": investorDetailsFromApi.poa.landlineNo ?? "",
        "mobileNumber": investorDetailsFromApi.poa.poaMobNo[0] ? getPrefixOrSuffix(investorDetailsFromApi.poa.poaMobNo[0]).suffix : "",
        "mobileNumberPrefix": investorDetailsFromApi.poa.poaMobNo[0] ? getPrefixOrSuffix(investorDetailsFromApi.poa.poaMobNo[0]).prefix : "",
        "name": investorDetailsFromApi.poa.nameOfPoa ?? "",
        "panOrTaxIdNumber": investorDetailsFromApi.poa.poaTaxIdNo ?? "",
        "permanentAddress1": investorDetailsFromApi.poa.poaAddr1 ?? "",
        "pinCode": investorDetailsFromApi.poa.pincode ?? "",
        "state": investorDetailsFromApi.poa.state ?? "",
        "type": investorDetailsFromApi.poa.poaType ?? "",
    };

    primaryHolderDetailsData = {
        "aadharNumber": investorDetailsFromApi.primaryHolderDetails.aadharNo ?? "",
        "accreditationNumber": investorDetailsFromApi.primaryHolderDetails.accreditationNo ?? "",
        "accreditationValidityDate": investorDetailsFromApi.primaryHolderDetails.accreditationValidityDt ?? "",
        "ckycOrKinNumber": investorDetailsFromApi.primaryHolderDetails.ckycNo ?? "",
        "correspondenceAddress1": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].addr1 ?? "",
        "correspondenceAddress2": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].addr2 ?? "",
        "correspondenceAddress3": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].addr3 ?? "",
        "correspondenceCity": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].city ?? "",
        "correspondenceCountry": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].country ?? "",
        "correspondencePincode": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].pincode ?? "",
        "correspondenceState": investorDetailsFromApi.primaryHolderDetails.correspondenceAddrDetails[0].state ?? "",
        "fatherOrSpouseName": investorDetailsFromApi.primaryHolderDetails.fatherOrSpouseNameFlag === "Father" ? 
            investorDetailsFromApi.primaryHolderDetails.fatherName ?? "" :
            investorDetailsFromApi.primaryHolderDetails.spouseName ?? "",
        "fatherOrSpouseNameFlag": investorDetailsFromApi.primaryHolderDetails.fatherOrSpouseNameFlag ?? "",
        "gender": investorDetailsFromApi.primaryHolderDetails.gender ?? "",
        "kraReferenceNumber": "",
        "landlineNumber": investorDetailsFromApi.primaryHolderDetails.landlineNo ?? "",
        "motherName": investorDetailsFromApi.primaryHolderDetails.motherName ?? "",
        "nameOfPrimaryHolder": investorDetailsFromApi.primaryHolderDetails.name ?? "",
        "nameOfPrimaryHolderPrefix": investorDetailsFromApi.primaryHolderDetails.salutation ?? "",
        "overseasAddress1": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].addr1 ?? "",
        "overseasAddress2": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].addr2 ?? "",
        "overseasAddress3": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].addr3 ?? "",
        "overseasCity": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].city ?? "",
        "overseasCountry": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].country ?? "",
        "overseasPincode": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].pincode ?? "",
        "overseasState": investorDetailsFromApi.primaryHolderDetails.overseasAddrDetails[0].state ?? "",
        "passportExpiryDate": investorDetailsFromApi.primaryHolderDetails.passportExpiryDt ?? "",
        "passportNumber": investorDetailsFromApi.primaryHolderDetails.passportNo ?? "",
        "permanentAddress1": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].addr1 ?? "",
        "permanentAddress2": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].addr2 ?? "",
        "permanentAddress3": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].addr3 ?? "",
        "permanentCity": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].city ?? "",
        "permanentCountry": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].country ?? "",
        "permanentPincode": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].pincode ?? "",
        "permanentState": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].state ?? "",
        "sameAsPermanentAddress": investorDetailsFromApi.primaryHolderDetails.permanentAddrDetails[0].correspAddrSimilarityFlag ? "Yes" : "No",
    };

    promoterDetailsData = {
        "promoterDetails": investorDetailsFromApi.promoterDetails.map((promoter: any) => {
            return {
                "confirmPanOrTaxIdNumber": "",
                "dateOfBirth": promoter.dob ?? "",
                "gender": promoter.gender ?? "",
                "key": nanoid(),
                "name": promoter.name ?? "",
                "panOrTaxIdNumber": promoter.taxIdNo ?? "",
                "politicallyExposedPerson": promoter.isPep ? "Yes" : "No",
            };
        }),
    };

    sipDetailsData = {
        "endDate": investorDetailsFromApi.sipReg[0].sipDetails.endDt ?? "",
        "instalmentAmount": investorDetailsFromApi.sipReg[0].sipDetails.installmentAmt ?? "",
        "numberOfInstalments": investorDetailsFromApi.sipReg[0].sipDetails.nofInstallments ?? "",
        "sipFrequency": investorDetailsFromApi.sipReg[0].sipDetails.sipFreq ?? "",
        "startDate": investorDetailsFromApi.sipReg[0].sipDetails.startDt ?? "",
    };

    trusteeDetailsData = {
        "trusteeDetails": investorDetailsFromApi.trusteeDetails.map((trusteeData: any) => {
            return {
                "confirmPanOrTaxIdNumber": "",
                "dateOfBirth": trusteeData.dob ?? "",
                "gender": trusteeData.gender ?? "",
                "key": nanoid(),
                "name": trusteeData.name ?? "",
                "panOrTaxIdNumber": trusteeData.taxIdNo ?? "",
                "politicallyExposedPerson": trusteeData.isPep ? "Yes" : "No",
            };
        })
    };

    uboDetailsData = {
        "deleteUbo": 1,
        "numberOfUbos": investorDetailsFromApi.uboDeclaration.uboDetails.length,
        "otherUboCategory": uboCategoryMenuItems
            .some(item => item.value === investorDetailsFromApi.uboDeclaration.uboCategory) ? "" : 
            investorDetailsFromApi.uboDeclaration.uboCategory,
        "trustType": investorDetailsFromApi.uboDeclaration.trustType ?? "",
        "uboCategory": uboCategoryMenuItems
            .some(item => item.value === investorDetailsFromApi.uboDeclaration.uboCategory) ? 
            investorDetailsFromApi.uboDeclaration.uboCategory :
            "Others",
        "ubos": investorDetailsFromApi.uboDeclaration.uboDetails.map((ubo: any) => {
            return {
                "address": ubo.address ?? "",
                "addressType": ubo.addressType ?? "",
                "cityOfBirth": ubo.cityOfBirth ?? "",
                "confirmPanTaxIdNo": "",
                "country": ubo.country ?? "",
                "countryOfBirth": ubo.ctryOfBirth ?? "",
                "countryOfTaxResidency": ubo.ctryOfTaxRes ?? "",
                "dateOfBirth": ubo.dob ?? "",
                "fathersName": ubo.fatherName ?? "",
                "gender": ubo.gender ?? "",
                "name": ubo.nameOfUbo ?? "",
                "nationality": ubo.nationality ?? "",
                "occupationType": occupationTypeMenuItems
                    .some(item => item.value === ubo.occupationType) ? 
                    ubo.occupationType :
                    "Others",
                "otherOccupationType": occupationTypeMenuItems
                    .some(item => item.value === ubo.occupationType) ? "" : 
                    ubo.occupationType,
                "panTaxIdNo": ubo.taxIdNo ?? "",
                "percentageOfHolding": ubo.percentOfHolding ?? "",
                "pincode": ubo.zipCode ?? "",
                "politicallyExposedPerson": ubo.isPep ? "Yes" : "No",
                "state": ubo.state ?? "",
                "taxIdType": ubo.taxIdType ?? "",
                "uboCode": ubo.uboCode ?? "",
            };
        }),
    };

    investorDetails = {
        "aslDetailsForm": aslDetailsData,
        "bankDetailsForm": bankDetailsData,
        "basicDetailsForm": basicDetailsData,
        "committeeMemberDetailsForm": committeeMemberDetailsData,
        "contactDetailsForm": contactPersonDetailsData,
        "contributionDetailsForm": contributionDetailsData,
        "directorDetailsForm": directorDetailsData,
        "distributorDetailsForm": distributorDetailsData,
        "documentDetailsForm": documentDetailsData,
        "entityDetailsForm": entityDetailsData,
        "entityFatcaAndCrsDetailsForm": entityFatcaAndCrsDetailsData,
        "guardianDetailsForm": guardianDetailsData,
        "holderDetailsForm": holderDetailsFormData,
        "individualFatcaAndCrsDetailsForm": fatcaAndCrsDetailsData,
        "investmentDetailsForm": investmentDetailsData,
        "kartaDetailsForm": kartaDetailsData,
        "modeOfAllotmentForm": modeOfAllotmentDetailsData,
        "nomineeDetailsForm": nomineeDetailsData,
        "otmDetailsForm": otmDetailsData,
        "partnersDetailsForm": partnerDetailsData,
        "powerOfAttorneyDetailsForm": powerOfAttorneyDetailsData,
        "primaryHolderDetailsForm": primaryHolderDetailsData,
        "promoterDetailsForm": promoterDetailsData,
        "sipDetailsForm": sipDetailsData,
        "trusteeDetailsForm": trusteeDetailsData,
        "uboDetailsForm": uboDetailsData,
    };

    userIds = {
        "auditorId": investorDetailsFromApi.auditorId ?? null,
        "checkerId": investorDetailsFromApi.checkerId ?? null,
        "makerId": investorDetailsFromApi.makerId ?? null,
        "qualityCheckerId": investorDetailsFromApi.qualityCheckerId ?? null,
    };

    return {
        "investorDetails": investorDetails,
        "userIds": userIds
    };

}

function useGetInvestor() {
    const dispatch = useDispatch();

    let investorInfo: InvestorInfo ;
    let txnType = "", txnCode = ""; 
    let transactionContribNo = "";
    let transactionSipNo = "";

    const uboCategoryMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .uboCategoryMenuItems
    );

    const OccupationDetailsMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .holderOccupationDetailsMenuItems
    );

    const occupationTypeMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
                .occupationTypeMenuItems
    );

    const fetchInvestorDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<GetInvestorResponseType | GetInvestorMakerResponse> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/investor?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const investorDetailsFromApi: GetInvestorType = responseData[0];
                
                if (role !== "M") {
                    investorInfo = getInvestorInfo(investorDetailsFromApi, uboCategoryMenuItems, OccupationDetailsMenuItems, occupationTypeMenuItems);
                }

                txnCode = investorDetailsFromApi.transactionCode ?? "";                                     
                txnType = investorDetailsFromApi.transactionTypeName ?? investorDetailsFromApi.transactionType ?? "";    
                transactionContribNo = investorDetailsFromApi.initialContribution.transactionContribNo ?? "";
                transactionSipNo = investorDetailsFromApi.sipReg[0].transactionSipNo ?? "";
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        if (role === "M")
            return {
                "transactionContribNo": transactionContribNo,
                "transactionSipNo": transactionSipNo,
                "txnCode": txnCode,
                "txnType": txnType,
            };
            
        return {
            "investorDetailsForms": investorInfo.investorDetails,
            "transactionContribNo": transactionContribNo,
            "transactionSipNo": transactionSipNo,
            "txnCode": txnCode,
            "txnType": txnType,
            "userIds": investorInfo.userIds,
        }; 
    };

    return fetchInvestorDetails;
}

export default useGetInvestor;
