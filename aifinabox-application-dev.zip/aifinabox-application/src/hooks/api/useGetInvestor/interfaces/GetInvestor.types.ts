import {
    DocumentDetailsForm
} from "../../../../redux/InvestorOnboarding/Auditor/SubForms/DocumentDetailsForm/initialState";

interface GetInvestorType {
    _id: string;
    allotmentMode: AllotmentMode;
    asl: Asl[];
    auditorId: string | null;
    bankDetails: BankDetails;
    basicDetails: BasicDetails;
    clientId: string;
    clientName: string;
    committeeDetails: CommitteeDetail[];
    checkerId: string | null;
    contactPersonDetails: ContactPersonDetail[];
    currentStage: number;
    directorDetails: DirectorDetail[];
    distributorDetails: DistributorDetails;
    documentDetails: DocumentDetails;
    entityDetails: EntityDetails;
    fatcaDetails: FatcaDetails;
    folio: string;
    frozenFolioFlag: boolean;
    guardianDetails: GuardianDetails;
    initialContribution: InitialContribution;
    kartaDetails: KartaDetail[];
    makerId: string | null;
    nomineeDetails: NomineeDetails;
    partnerDetails: PartnerDetail[];
    poa: Poa;
    primaryHolderDetails: PrimaryHolderDetails;
    promoterDetails: PromoterDetail[];
    qualityCheckerId: string | null;
    recordStatus: number;
    revisionNo: number;
    role: string;
    secondaryHolderDetails: SecondaryHolderDetails;
    sipReg: SipReg[];
    sourceUser: string;
    thirdHolderDetails: ThirdHolderDetails;
    transactionNo: string;
    transactionCode: string;
    transactionType: string;
    transactionTypeName: string;
    trusteeDetails: TrusteeDetail[];
    uboDeclaration: UboDeclaration;
    updatedDate: string;
}

export interface BasicDetails {
    aadharLinkedOn: string;
    isAadharLinked: boolean;
    invType: string;
    invCategory: string;
    invTaxStatus: string;
    modeOfHolding: string;
    accreditationFlag: string;
    taxIdExemptionFlag: string;
    taxIdExemptionApprovalAttachment: string;
    taxId: string;
    panValidatedOn: string;
    prodType: string;
    dob: string;
    dateOfReg: string;
    placeOfReg: string;
    guardianTaxId: string;
    mobNo: MobNo[];
    emailIds: EmailId[];
    poaFlag: string;
    applnId: string;
}

export interface MobNo {
    mobNoPertainTo: string;
    mobNo: string;
}

export interface EmailId {
    emailIdPertainTo: string;
    emailId: string;
}

export interface Poa {
    poaType: string;
    poaTaxIdNo: string;
    dob: string;
    incDt: string;
    nameOfPoa: string;
    poaKraRef: string;
    poaCkycNo: string;
    poaMobNo: string;
    poaEmailIds: string[];
    landlineNo: string;
    poaAddr1: string;
    poaAddr2: string;
    poaAddr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    authorisedSignatories: AuthorisedSignatory[];
}

export interface AuthorisedSignatory {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface DistributorDetails {
    distributorType: string;
    amcRmName: string;
    amcRmCode: string;
    amcRmEmailIDs: [];
    distributorCode: string;
    distributorName: string;
    distributorRmName: string;
    distributorRmCode: string;
    distributorRmEmails: [];
    distributorRmMobNo: string;
}

export interface AllotmentMode {
    modeOfAllotment: string;
    repositoryType: string;
    dPId: string;
    clientId: string;
}

export interface PrimaryHolderDetails {
    name: string;
    salutation: string;
    gender: string;
    accreditationNo: string;
    accreditationValidityDt: string;
    motherName: string;
    aadharNo: string;
    passportNo: string;
    passportExpiryDt: string;
    fatherName: string;
    spouseName: string;
    fatherOrSpouseNameFlag: string;
    ckycNo: string;
    landlineNo: string;
    permanentAddrDetails: PermanentAddrDetail[];
    correspondenceAddrDetails: CorrespondenceAddrDetail[];
    overseasAddrDetails: OverseasAddrDetail[];
}

export interface PermanentAddrDetail {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    correspAddrSimilarityFlag: string;
}

export interface CorrespondenceAddrDetail {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface OverseasAddrDetail {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface SecondaryHolderDetails {
    taxStatus: string;
    relatshpWithPrimaryHolder: string;
    taxId: string;
    panValidatedOn: string;
    dob: string;
    name: string;
    salutation: string;
    gender: string;
    fatherName: string;
    spouseName: string;
    fatherOrSpouseNameFlag: string;
    motherName: string;
    aadharNo: string;
    passportNo: string;
    passportExpiryDt: string;
    mobNoHolder: string;
    mobNo: string;
    emailIdHolder: string;
    emailID: string;
    kraRefNo: string;
    ckycNo: string;
    permanentAddrDetails: PermanentAddrDetail2[];
    correspondenceAddrDetails: CorrespondenceAddrDetail2[];
    overseasAddrDetails: OverseasAddrDetail2[];
}

export interface PermanentAddrDetail2 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    correspAddrSimilarityFlag: string;
}

export interface CorrespondenceAddrDetail2 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface OverseasAddrDetail2 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface ThirdHolderDetails {
    thirdHolderTaxStatus: string;
    relatshpWithPrimaryHolder: string;
    taxId: string;
    panValidatedOn: string;
    dob: string;
    name: string;
    salutation: string;
    gender: string;
    fatherName: string;
    spouseName: string;
    fatherOrSpouseNameFlag: string;
    motherName: string;
    aadharNo: string;
    passportNo: string;
    passportExpiryDt: string;
    mobNoHolder: string;
    mobNo: string;
    emailIdHolder: string;
    emailID: string;
    kraRefNo: string;
    ckycNo: string;
    permanentAddrDetails: PermanentAddrDetail3[];
    correspondenceAddrDetails: CorrespondenceAddrDetail3[];
    overseasAddrDetails: OverseasAddrDetail3[];
}

export interface PermanentAddrDetail3 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    correspAddrSimilarityFlag: string;
}

export interface CorrespondenceAddrDetail3 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface OverseasAddrDetail3 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface GuardianDetails {
    taxStatus: string;
    name: string;
    relationship: string;
    dob: string;
    salutation: string;
    gender: string;
    aadharNo: string;
    passportNo: string;
    passportExpiryDt: string;
    address: Address[];
    mobNoHolder: string;
    mobNo: MobNo[];
    emailIdHolder: string;
    emailIds: EmailId[];
    kraRefNo: string;
    ckycNo: string;
}

export interface Address {
    "addr1": string;
    "addr2": string;
    "addr3": string;
    "city": string;
    "country": string;
    "isOverseasAddr": boolean;
    "landlineNo": string;
    "pincode": string;
    "state": string;
}

export interface NomineeDetails {
    noOfNominees: string;
    nominees: Nominee[];
}

export interface Nominee {
    nomineeName: string;
    dtOfBirth: string;
    nomineeRelatshp: string;
    allocationPercent: string;
    nomineeIdProofNo: string;
    mobNo: string;
    emailId: string;
    guardianName: string;
    guardianIdNo: string;
    guardianMinorNomineeRelatshp: string;
}

export interface EntityDetails {
    nameOfTheEntity: string;
    salutation: string;
    cin: string;
    leiNo: string;
    leiExpiryDt: string;
    accreditationNo: string;
    accreditationValidityDt: string;
    kraRefNo: string;
    ckycNo: string;
    regAddr: RegAddr[];
    overseasAddrDetails: OverseasAddrDetail4[];
}

export interface RegAddr {
    isCorrespAddr: boolean;
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    correspSameAsRegAddr: boolean;
}

export interface OverseasAddrDetail4 {
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
    landlineNo: string;
}

export interface ContactPersonDetail {
    name: string;
    salutation: string;
    gender: string;
    mobNo: string;
    emailId: string;
    addr1: string;
    addr2: string;
    addr3: string;
    pincode: string;
    city: string;
    state: string;
    country: string;
}

export interface BankDetails {
    primaryHolderBank: PrimaryHolderBank[];
    secondHolderBankDetails: SecondHolderBankDetail[];
    thirdHolderBankDetails: ThirdHolderBankDetail[];
}

export interface PrimaryHolderBank {
    isForeignAcc: string;
    nationalBankAccount: NationalBankAccount[];
    foreignBankAccount: ForeignBankAccount[];
}

export interface NationalBankAccount {
    accNo: string;
    ifsc: string;
    micr: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    defaultAcc: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface ForeignBankAccount {
    accNo: string;
    ibanCode: string;
    swiftCode: string;
    bicCode: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    accProofFlag: string;
    defaultAcc: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface SecondHolderBankDetail {
    isForeignAcc: string;
    nationalBankAccount: NationalBankAccount2[];
    foreignBankAccount: ForeignBankAccount2[];
}

export interface NationalBankAccount2 {
    accNo: string;
    ifsc: string;
    micr: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface ForeignBankAccount2 {
    accNo: string;
    ibanCode: string;
    swiftCode: string;
    bicCode: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    accProofFlag: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface ThirdHolderBankDetail {
    isForeignAcc: string;
    nationalBankAccount: NationalBankAccount3[];
    foreignBankAccount: ForeignBankAccount3[];
}

export interface NationalBankAccount3 {
    accNo: string;
    ifsc: string;
    micr: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface ForeignBankAccount3 {
    accNo: string;
    ibanCode: string;
    swiftCode: string;
    bicCode: string;
    bankAccType: string;
    bankName: string;
    bankBranch: string;
    bankAddr: string;
    accProofFlag: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface Asl {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface PromoterDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface PartnerDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface KartaDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface DirectorDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    din: string;
    isPep: string;
}

export interface TrusteeDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface CommitteeDetail {
    taxIdNo: string;
    dob: string;
    name: string;
    gender: string;
    isPep: string;
}

export interface UboDeclaration {
    uboCategory: string;
    trustType: string;
    uboDetails: UboDetail[];
}

export interface UboDetail {
    nameOfUbo: string;
    uboCode: string;
    ctryOfTaxRes: string;
    taxIdType: string;
    taxIdNo: string;
    address: string;
    state: string;
    country: string;
    zipCode: string;
    addressType: string;
    cityOfBirth: string;
    ctryOfBirth: string;
    occupationType: string;
    nationality: string;
    fatherName: string;
    gender: string;
    dob: string;
    percentOfHolding: string;
    isPep: string;
}

export interface FatcaDetails {
    primaryHolderFatca: PrimaryHolderFatca;
    secondaryHolderFatca: SecondaryHolderFatca;
    thirdHolderFatca: ThirdHolderFatca;
    guardianFatca: GuardianFatca;
    nonIndividualFatca: NonIndividualFatca;
}

export interface PrimaryHolderFatca {
    fatcaAndCrsFlag: string;
    isTaxResNotIndia: string;
    typeOfAddrAtKra: string;
    taxPayerIdNo: string;
    taxPayerIdType: string;
    ctryOfBirth: string;
    placeOfBirth: string;
    nationality: string;
    ctryOfTaxRes: string;
    grossAnnIncome: string;
    dateOfAnnIncome: string;
    isPep: string;
    occupation: string;
}

export interface SecondaryHolderFatca {
    fatcaAndCrsFlag: string;
    isTaxResNotIndia: string;
    typeOfAddrAtKra: string;
    taxPayerIdNo: string;
    taxPayerIdType: string;
    ctryOfBirth: string;
    placeOfBirth: string;
    nationality: string;
    ctryOfTaxRes: string;
    grossAnnIncome: string;
    dateOfAnnIncome: string;
    isPep: string;
    occupation: string;
}

export interface ThirdHolderFatca {
    fatcaAndCrsFlag: string;
    isTaxResNotIndia: string;
    typeOfAddrAtKra: string;
    taxPayerIdNo: string;
    taxPayerIdType: string;
    ctryOfBirth: string;
    placeOfBirth: string;
    nationality: string;
    ctryOfTaxRes: string;
    grossAnnIncome: string;
    dateOfAnnIncome: string;
    isPep: string;
    occupation: string;
}

export interface GuardianFatca {
    fatcaAndCrsFlag: string;
    isTaxResNotIndia: string;
    typeOfAddrAtKra: string;
    taxPayerIdNo: string;
    taxPayerIdType: string;
    ctryOfBirth: string;
    placeOfBirth: string;
    nationality: string;
    ctryOfTaxRes: string;
    grossAnnIncome: string;
    dateOfAnnIncome: string;
    isPep: string;
    occupation: string;
}

export interface NonIndividualFatca {
    fatcaAndCrsFlag: string;
    isTaxResNotIndia: string;
    typeOfAddrAtKra: string;
    taxPayerIdNo: string;
    taxPayerIdType: string;
    cityOfInc: string;
    ctryOfInc: string;
    entityConstitutionType: string;
    ctryOfTaxRes: string;
    govtBodyIntlOrgListedStockexchngFlag: string;
    isIndianFinInst: string;
    partA: PartA;
    partB: PartB;
}

export interface PartA {
    toBeFilledBy: string;
    giinNo: string;
    giinNotAvbl: string;
    nameOfSponseringEntity: string;
}

export interface PartB {
    toBeFilledBy: string;
    nameOfStkExchng: string;
    nameOfListedCo: string;
    natureOfRel: string;
    natureOfBusiness: string;
    subcategoryOfActiveNfe: string;
    nameOfBusiness: string;
    grossAnnualIncome: string;
    networth: string;
    networthAsOnDt: string;
    isEntityPep: string;
    involvedInMentionedServices: string;
}

export interface InitialContribution {
    transactionContribNo: string;
    endorsedFlag: boolean;
    investmentDetails: InvestmentDetails;
    contributionDetails: ContributionDetails;
    paymentBankDetails: {
        primaryHolderPaymentBank: PaymentBankDetails;
        secondaryHolderPaymentBank: PaymentBankDetails;
        thirdHolderPaymentBank: PaymentBankDetails;
    };
    depositBankDetails: DepositBankDetails;
}

export interface InvestmentDetails {
    schemeCode: string;
    schemeName: string;
    schemeIsinNo: string;
    prodType: string;
    class: string;
    contribAgrmntDt: string;
    transactionType: string;
}

export interface ContributionDetails {
    "fundCurrency": string;
    "transactionCurrency": string;
    "commitmentAmount": string;
    "initContribAmt": string;
    "exchngRate": string;
    "fundCurrencyAmount": string;
    "otherFee": string;
    "primaryHolderPercent": string;
    "primaryHolderContrib": string;
    "secondHolderPercent": string;
    "secondHolderContrib": string;
    "thirdHolderPercent": string;
    "thirdHolderContrib": string;
    "setupFeePercent": string;
    "setupFeeAmt": string;
    "gst": string;
    "gstWaiver": string;
    "gstWaiverAttachment":{
        "documentFormat": string;
        "documentPath": string;
        "documentSize": string;
    };
    "totalSetupFee": string;
    "paymentType": string;
}

export interface PaymentBankDetails {
    "foreignBankAccount": [
        {
            "lastFourDigitsOfRegForeignBankAccNo": string;
            "paymentBankAddr": string;
            "paymentBankBranch": string;
            "paymentBankIbanCode": string;
            "paymentBankName": string;
            "paymentBankSwiftAndBic": string;
            "paymentForeignBankAccType": string;
            "regPaymentForeignBankAccNo": string;
        }
    ];
    "isForeignBankAcct": string;
    "nationalBankAccount": [
        {
            "lastFourDigOfRegBankAccountNo": string;
            "paymentBankAccName": string;
            "paymentBankAccNo": string;
            "paymentBankAccType": string;
            "paymentBankChqRefNo": PaymentChequeDetails[];
            "paymentBankIfsc": string;
            "paymentBankMicr": string;
            "paymentBankPennyDropStatus": string;
            "paymentBankUtrNo": string;
            "paymentType": string;
            "pennyDropValidationDt": string;
        }
    ];
    "paymentBankIsRegBank": string;
}

export interface PaymentChequeDetails {
    "chequeAmount": string;
    "chequeRefNo": string;
}

export interface DepositBankDetails {
    ifsc: string;
    bankName: string;
    bankAccNo: string;
}

export interface SipReg {
    transactionSipNo: string;
    sipDetails: SipDetails;
    otmDetails: OtmDetails;
    endorsedFlag: boolean;
}

export interface SipDetails {
    sipFreq: string;
    startDt: string;
    endDt: string;
    installmentAmt: string;
    nofInstallments: string;
}

export interface OtmDetails {
    primaryInvOtm: PrimaryInvOtm[];
    secondaryHolderOtm: SecondaryHolderOtm[];
    thirdHolderOtm: ThirdHolderOtm[];
}

export interface PrimaryInvOtm {
    isOtmBankDetailsPrimaryDetails: string;
    lastFourDigitsOfRegBankAccNo: string;
    accType: string;
    ifsc: string;
    micr: string;
    bankName: string;
    accNo: string;
    otmAmt: string;
    fromDt: string;
    toDt: string;
    uniqRefNo: string;
    sponsorBankCode: string;
    utilityCode: string;
    debitType: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface SecondaryHolderOtm {
    isOtmBankDetailsPrimaryDetails: string;
    lastFourDigitsOfRegBankAccNo: string;
    accType: string;
    ifsc: string;
    micr: string;
    bankName: string;
    accNo: string;
    otmAmt: string;
    fromDt: string;
    toDt: string;
    uniqRefNo: string;
    sponsorBankCode: string;
    utilityCode: string;
    debitType: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface ThirdHolderOtm {
    isOtmBankDetailsPrimaryDetails: string;
    lastFourDigitsOfRegBankAccNo: string;
    accType: string;
    ifsc: string;
    micr: string;
    bankName: string;
    accNo: string;
    otmAmt: string;
    fromDt: string;
    toDt: string;
    uniqRefNo: string;
    sponsorBankCode: string;
    utilityCode: string;
    debitType: string;
    pennyDropStatus: string;
    pennyDropValidationDt: string;
}

export interface DocumentDetails {
    documentDetailsCorporate: DocumentDetailsForm["nonIndividual"]["corporateDocumentDetails"];
    documentDetailsFII: DocumentDetailsForm["nonIndividual"]["foreignInstitutionalInvestors"]; 
    documentDetailsGovtBodies: DocumentDetailsForm["nonIndividual"]["armyOrGovernmentBodiesDocumentDetails"];    
    documentDetailsHUF: DocumentDetailsForm["nonIndividual"]["hufDocumentDetails"];
    documentDetailsInstitutionalInvestors: DocumentDetailsForm["nonIndividual"]["banksOrInstitutionalInvestorsDocumentDetails"];
    documentDetailsPartnership: DocumentDetailsForm["nonIndividual"]["partnershipDocumentDetails"];
    documentDetailsProprietorship: DocumentDetailsForm["nonIndividual"]["proprietorshipDocumentDetails"];
    documentDetailsRegisteredSociety: DocumentDetailsForm["nonIndividual"]["registeredSocietyDocumentDetails"];
    documentDetailsTrust: DocumentDetailsForm["nonIndividual"]["trustDocumentDetails"];
    documentDetailsUnincorporatedAssociation: DocumentDetailsForm["nonIndividual"]["unincorporatedDocumentDetails"];
    mandatoryDocumentProvided: DocumentDetailsForm["individual"]["mandatoryDocumentDetails"] | DocumentDetailsForm["nonIndividual"]["mandatoryDocumentsDetails"];
    minorAndGuardianDocs: DocumentDetailsForm["individual"]["minorAndGuardianDocumentDetails"];
    otherDocuments: DocumentDetailsForm["individual"]["otherDocumentDetails"] | DocumentDetailsForm["nonIndividual"]["otherDocumentDetails"];
    poaDocs: DocumentDetailsForm["individual"]["poaDocumentDetails"] | DocumentDetailsForm["nonIndividual"]["poaDocumentDetails"];
    primaryHolderDocs: DocumentDetailsForm["individual"]["primaryHolderDocumentDetails"];
    secondHolderDocs: DocumentDetailsForm["individual"]["secondaryHolderDocumentDetails"];
    thirdHolderDocs: DocumentDetailsForm["individual"]["thirdHolderDocumentDetails"];
}

export default GetInvestorType;
