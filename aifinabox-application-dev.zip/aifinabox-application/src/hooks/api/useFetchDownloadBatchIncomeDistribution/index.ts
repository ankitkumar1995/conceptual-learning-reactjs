import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDownloadBatchIncomeDistribution() {
    const dispatch = useDispatch();

    const fetchDownloadBatchIncomeDistribution = async (
        batchNo: string,
        clientId: string,
        userRole: "C" | "A" | "M",
        processCode: string,
    ): Promise<{
      "url": string;
    }> => {
        dispatch(setOpenBackdrop(true));

        let resUrl: string = "";

        const axiosConfig = {
            "url": `/downloadbatchdetails?batchNo=${batchNo}&clientId=${clientId}&role=${userRole}&processCode=${processCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                resUrl = responseData.download;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
        return {
            "url": resUrl,
        };
    };
    
    return fetchDownloadBatchIncomeDistribution;
}

export default useFetchDownloadBatchIncomeDistribution;
