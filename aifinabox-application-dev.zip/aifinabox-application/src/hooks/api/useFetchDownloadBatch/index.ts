import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDownloadBatch() {
    const dispatch = useDispatch();

    const fetchDownloadBatch = async (
        clientId: string,
        role: "M" | "C" | "A",
        batchNo: string,
        
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        let templateURL: string = "";

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/downloadbatchdetails?clientId=${clientId}&role=${role}&batchNo=${batchNo}`,
        };
 
        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                templateURL = responseData.download;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return  templateURL; 
    };

    return fetchDownloadBatch;
}

export default useFetchDownloadBatch;
