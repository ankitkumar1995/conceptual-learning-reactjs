import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface QueueItems {
    _id: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    clientName: string;
    createdBy: string;
    createdOn: string;
    folioNumber: string;
    rejectRemarks?: string;
    sourceUser: string;
    transactionNo: string;
    transactionType: string;
}

export interface PendingItems {
    contextDetails: QueueItems;
}

interface ApiItems {
    _id: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    clientName: string;
    createdBy: string;
    creationDate: string;
    folioNo: string;
    rejectRemarks?: string;
    sourceUser: string;
    transactionNo: string;
    transactionType: string;
}

interface ApiResultDataItem {
    // contextDetails: ApiItems;
    _id: string;
    applicationId?: string;
    barcode?: string;
    branchId?: string;
    clientId: string;
    clientName?: string;
    createdBy?: string;
    createdOn?: string;
    rejectRemarks?: string;
    sourceUser?: string;
    transactionNo: string;
    transactionType?: string;
}

function useFetchRejectTodoQueueInitialContribution() {
    const dispatch = useDispatch();

    const fetchRejectTodoQueueInitialContribution = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userId: string,
        pageIndex: number,
        queueLength: number,
    ): Promise<{
        todoQueue: QueueItems[];
        itemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let todoQueue: QueueItems[] = [];
        let itemCount = 0;

        const axiosConfig = {
            "url": `/rejectqueue?stageCode=${stageCode}&userId=${userId}&pageIndex=${pageIndex}&queueLength=${queueLength}&clientId=${clientId}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response.data;
                const pendingItems = responseData.result;
                itemCount = responseData.count;
                todoQueue = pendingItems.map((items: ApiItems) => {
                    const {
                        _id,
                        applicationId,
                        barcode,
                        branchId,
                        clientId,
                        clientName,
                        createdBy,
                        creationDate,
                        folioNo,
                        rejectRemarks,
                        sourceUser,
                        transactionNo,
                        transactionType,
                    } = items;
                    
                    return ({
                        "applicationId": (applicationId ?? ""),
                        "barcode": (barcode ?? ""),
                        "branchId": (branchId ?? ""),
                        "clientId": (clientId ?? ""),
                        "clientName": (clientName ?? ""),
                        "createdBy": createdBy,
                        "createdOn": creationDate,
                        "folioNumber": (folioNo ?? ""),
                        "rejectRemarks": rejectRemarks,
                        "sourceUser": (sourceUser ?? ""),
                        "transactionNo": (transactionNo ?? ""),
                        "transactionType": (transactionType ?? ""),
                    });
                });
            })
            .catch((error) => {
                console.error("rejectTodoError", error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "itemCount": itemCount,
            "todoQueue": todoQueue,
        };
    };
    
    return fetchRejectTodoQueueInitialContribution;
}

export default useFetchRejectTodoQueueInitialContribution;
