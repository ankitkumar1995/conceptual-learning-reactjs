import {
    InvestorInfo,
    UserIdsType,
    getInvestorInfo
} from "../useGetInvestor";
import { useDispatch, useSelector } from "react-redux";

import GetInvestorType from "../useGetInvestor/interfaces/GetInvestor.types";
import { MakerSubForms } from "../../../redux/InvestorOnboarding/Maker/SubForms";
import { NigoDataResponse } from "./interfaces/InvestorNigo.types";
import { RootState } from "../../../redux/store";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

interface Result {
    "nigoData": NigoDataResponse[];
    "qcData": MakerSubForms;
    "userIds": UserIdsType;
    "transactionContribNo": string;
    "transactionSipNo": string;
}

function useFetchNigoData() {
    const dispatch = useDispatch();
    
    let investorInfo: InvestorInfo;
    
    const uboCategoryMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .uboCategoryMenuItems
    );

    const OccupationDetailsMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .holderOccupationDetailsMenuItems
    );

    const occupationTypeMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
                .occupationTypeMenuItems
    );

    const fetchInvestorDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<Result> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/investor?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        let nigoResponse: NigoDataResponse[] = [];
        let transactionContribNo = "";
        let transactionSipNo = "";

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                nigoResponse = responseData[0].QC;
                
                const investorDetailsFromApi: GetInvestorType = responseData[1];
                
                investorInfo = getInvestorInfo(investorDetailsFromApi, uboCategoryMenuItems, OccupationDetailsMenuItems, occupationTypeMenuItems);    
                transactionContribNo = investorDetailsFromApi.initialContribution.transactionContribNo ?? "";
                transactionSipNo = investorDetailsFromApi.sipReg[0].transactionSipNo ?? "";
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "nigoData": nigoResponse,
            "qcData": investorInfo.investorDetails,
            "transactionContribNo": transactionContribNo,
            "transactionSipNo": transactionSipNo,
            "userIds": investorInfo.userIds,
        }; 
    };

    return fetchInvestorDetails;
}

export default useFetchNigoData;
