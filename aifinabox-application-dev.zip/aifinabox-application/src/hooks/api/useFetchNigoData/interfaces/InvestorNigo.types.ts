
interface InvestorNigoResponse {
    "transactionNo": string;
    "clientId": string;
    "QC": NigoDataResponse[];
    "currentStage": number;
    "revisionNo": number;
}

export interface NigoDataResponse {
    makerEntry: string | boolean;
    checkerEntry: string | boolean;
    dataStatus: boolean;
    field: string;
    index: number;
}

export default InvestorNigoResponse;
