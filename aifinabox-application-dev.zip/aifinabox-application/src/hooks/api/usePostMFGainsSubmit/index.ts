/* eslint-disable sort-keys */
import {
    TableDataFields
} from "../../../redux/InitiateTransaction/MFGains/Checker/CheckerData/initialState";
import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostMFGainsSubmit() {
    const dispatch = useDispatch();

    const postMFGainsSubmit = async (
        batchNo: string,
        clientId: string,
        fileName: string,
        sourceFile: [],
        clientName: string,
        userId: string,
        sourceuser: string,
        processCode: string,
        stageCode: string,
        role: string,
        transactionType: string,
        totalRecords:number ,
        failedRecords: number,
        successRecords: number,
        tableData: TableDataFields[],
        uploadedBy: string,
        uploadedAt: string,
        fundName: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "batchNo": batchNo,
            "clientId": clientId,
            "clientName": clientName,
            "file": fileName,
            "processCode": processCode,
            "role": role,
            "sourceFile": sourceFile,
            "sourceUser": sourceuser,
            "stageCode": stageCode, 
            "userId": userId,
            "transactionType": transactionType,
            "summary": {
                "totalRecords": totalRecords?.toString(),
                "failedRecords": failedRecords?.toString(),
                "successRecords": successRecords?.toString(),
            },
            "records": tableData?.map((data) => {
                return (
                    (transactionType === "MFG") ? 
                        {
                            "remarks": data.remarks,
                            "clientId": clientId,
                            "folio": data.folio ,
                            "investorName": data.investorName ,
                            "schemeCode": data.schemeCode ,
                            "parentClass": data.parentClass ,
                            "parentIHNumber": data.parentIHNumber ,
                            "parentTransactionType": data.parentTransactionType ,
                            "transactionType": data.transactionType ,
                            "allotmentDate": data.allotmentDate ,                    
                            "MFGainAmount": data.MFGainAmount ,                            
                            "contributionAmount": data.contributionAmount ,
                            "returnsPerDay": data.returnsPerDay ,
                            "percentReturnsPerDay": data.percentReturnsPerDay ,
                            "perAnnumReturns": data.perAnnumReturns ,
                            "medianPerAnnumReturns": data.medianPerAnnumReturns ,
                            "beyond10Variance": data.beyond10Variance ,     
                            "status": data.status ,
                        } : 
                        {
                            "remarks": data.remarks,
                            "clientId": clientId,
                            "folio": data.folio ,
                            "investorName": data.investorName ,
                            "schemeCode": data.schemeCode ,
                            "parentClass": data.parentClass ,
                            "parentIHNumber": data.parentIHNumber ,
                            "parentTransactionType": data.parentTransactionType ,
                            "transactionType": data.transactionType ,
                            "allotmentDate": data.allotmentDate ,   
                            "MFPayoutAmount": data.MFPayoutAmount ,
                            "TDSAmount": data.TDSAmount ,
                            "TDSpercent": data.TDSpercent ,
                            "contributionAmount": data.contributionAmount ,
                            "returnsPerDay": data.returnsPerDay ,
                            "percentReturnsPerDay": data.percentReturnsPerDay ,
                            "perAnnumReturns": data.perAnnumReturns ,
                            "medianPerAnnumReturns": data.medianPerAnnumReturns ,
                            "beyond10Variance": data.beyond10Variance ,     
                            "status": data.status ,
                        }
                );
            }),
            "uploadedBy": uploadedBy,
            "uploadedAt": uploadedAt,
            "fundName": fundName,
        };

        console.log(data, 'DATA FOM POST HOOK');

        const axiosConfig = {
            "data": data,
            "url": "/initcontrib",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postMFGainsSubmit;
}

export default usePostMFGainsSubmit;
