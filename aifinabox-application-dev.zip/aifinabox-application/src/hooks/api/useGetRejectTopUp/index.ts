import { 
    MakerInitialContributionDetails, 
    makerInitialContributionDetailsFormState 
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";
import { useDispatch, useSelector } from "react-redux";

import { TopUpDetails } from "../../../redux/InitiateTransaction/TopUp/Maker/Forms/initialState";
import { fetchTopUpInfo } from "../useFetchTopUp";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

export interface UserIdsType {
    auditorId: string | null;
    makerId: string | null;
    checkerId: string | null;
    qualityCheckerId: string | null;
}

interface GetTopUpResponseType {
    topUpDetails: TopUpDetails;
    userIds: UserIdsType;
}

export interface TopUpInfo {
    "topUpDetails": TopUpDetails;
    "userIds": UserIdsType;
}

function useGetRejectTopUp() {
    const dispatch = useDispatch();

    let topUpInfo: TopUpInfo;

    const getRejectTopUp = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<GetTopUpResponseType> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/reject?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response.data.rejectedDetails;
                const responseMakerData = response.data.makerDetails;
                const topUpDetailsFromApi = responseData[0];
                const topUpMakerDetailsFromApi = responseMakerData[0];

                topUpInfo = fetchTopUpInfo(topUpDetailsFromApi);

            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "topUpDetails": topUpInfo.topUpDetails,
            "userIds": topUpInfo.userIds,
        }; 
    };

    return getRejectTopUp;
}

export default useGetRejectTopUp;
