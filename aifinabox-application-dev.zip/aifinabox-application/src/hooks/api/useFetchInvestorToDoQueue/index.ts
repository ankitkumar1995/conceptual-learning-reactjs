import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

// clientId=101 processCode=IOP stageCode=IOPIEN userId=v-shobheet.pandey@kfintech.com role=M pageIndex=0 queueLength=5

interface MakerApiResultDataItem {
    clientName: string;
    createdBy: string;
    createdOn: string;
    transactionNo: string;
    barcode: string;
}

interface CheckerApiResultDataItem {
    clientId: string;
    createdBy: string;
    creationDate: string;
    folio: string;
    transNum: string;
    userId: string;
}
interface AuditorApiResultDataItem {
    clientId: string;
    clientName: string;
    createdBy: string;
    creationDate: string;
    transNum: string;
    userId: string;
    folio: string;
}

export interface QueueItem {
    clientName: string;
    createdBy: string;
    creationDate: string;
    transactionNo: string;
    barcode: string;
    clientId?: string;
    rejectRemarks?: string;
}
export interface DrawDownQueueItem {
    folioNumber: string;
    fundCode: string;
    fundName: string;
    startDate: string;
    endDate: string;
    createdBy: string;
    creationDate: string;
}

function useFetchInvestorTodoQueue() {
    const dispatch = useDispatch();

    const fetchInvestorTodoQueue = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role: "M" | "C" | "Q" |"A", 
        pageIndex: number, 
        queueLength: number,
    ): Promise<{
        ToDoQueue: QueueItem[];
        investorQueueItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let makerInvestorQueue: QueueItem[] = [];
        let checkerInvestorQueue: QueueItem[] = [];
        let auditorInvestorQueue: QueueItem[] = [];
        let investorQueueItemCount = 0;

        const axiosConfig = {
            "url": `/investortodoqueue?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&role=${role}&pageIndex=${pageIndex}&queueLength=${queueLength}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                investorQueueItemCount = responseData.count;
                makerInvestorQueue = responseData.result.map((queueItem: {"contextDetails": MakerApiResultDataItem;}) => {
                    const cardItem = queueItem.contextDetails;

                    const {
                        clientName,
                        createdBy,
                        createdOn,
                        transactionNo,
                        barcode,
                    } = cardItem;
                    
                    return ({
                        "barcode": barcode,
                        "clientName": clientName,
                        "createdBy": createdBy,
                        "creationDate": createdOn,
                        "transactionNo": transactionNo,
                    });
                });

                checkerInvestorQueue = responseData.result.map((queueItem: {"contextDetails": CheckerApiResultDataItem;}) => {
                    const cardItem = queueItem.contextDetails;
                    const {
                        clientId,
                        createdBy,
                        creationDate,
                        transNum,
                        folio,
                    } = cardItem;
                    
                    return ({
                        "barcode": folio,
                        "clientName": clientId,
                        "createdBy": createdBy,
                        "creationDate": creationDate,
                        "transactionNo": transNum,
                    });
                });

                auditorInvestorQueue = responseData.result.map((queueItem: {"contextDetails": AuditorApiResultDataItem;}) => {
                    const cardItem = queueItem.contextDetails;

                    const {
                        clientId,
                        createdBy,
                        creationDate,
                        transNum,
                        folio
                    } = cardItem;
                    
                    return ({
                        "barcode": folio,
                        "clientName": clientId,
                        "createdBy": createdBy,
                        "creationDate": creationDate,
                        "transactionNo": transNum,
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "ToDoQueue": (role === "M") ? makerInvestorQueue : (role === "C") ? checkerInvestorQueue : auditorInvestorQueue,
            "investorQueueItemCount": investorQueueItemCount,
        };
    };
    
    return fetchInvestorTodoQueue;
}

export default useFetchInvestorTodoQueue;
