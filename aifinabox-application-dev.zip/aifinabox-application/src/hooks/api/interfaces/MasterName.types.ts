export type MasterName = 
    "client_master" |
    "class_master" |
    "contact_master" |
    "benchmark_master" |
    "dd_master" |
    "fund_master"| 
    "bank_master" |
    "plan_master";
