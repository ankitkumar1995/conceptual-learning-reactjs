import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FetchBankAccountsType {
    fundCode: string;
    fundName: string;
    bankAccountName: {
        value: string;
    };
    bankAccountNumber: {
        value: string;
    };
    accountType: {
        value: string;
    };
    defaultAccount: {
        value: string;
    };
    ownershipType: {
        value: string;
    };
    isActive: {
        value: string;
    };
    dormant: {
        value: string;
    };
    dormantDate: {
        value: string;
    };
    remarks: {
        value: string;
    };
}

function useFetchBankAccounts() {
    const dispatch = useDispatch();

    const fetchBankAccounts = async (
        clientCode: string,
        ifscOrRtgsCode: string,
    ): Promise<FetchBankAccountsType[]> => {
        dispatch(setOpenBackdrop(true));

        let bankAccounts: FetchBankAccountsType[] = [];

        const axiosConfig = {
            "url": `/bankaccounts?clientCode=${clientCode}&ifscOrRtgsCode=${ifscOrRtgsCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                bankAccounts = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankAccounts; 
    };

    return fetchBankAccounts;
}

export default useFetchBankAccounts;
