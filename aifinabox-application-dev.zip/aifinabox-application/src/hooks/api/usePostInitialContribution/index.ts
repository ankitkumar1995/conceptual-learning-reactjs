import { 
    MakerInitialContributionDetails, 
    PaymentBankDetails,
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";

import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

const isFieldValueNull = (field?: string | null) => {
    if (field === null || field === undefined || field?.trim() === "") 
        return null;
    else
        return field;
};

function usePostInitialContribution() {
    const dispatch = useDispatch();

    const postInitialContribution = async (
        initialContributionState: MakerInitialContributionDetails,
        sourceUser: string,
        userId: string,
        userRole: "C" | "M" | "Q" | "A",
        stageCode: string,
        updateFlag: string,
        clientId: string,
        transactionNo: string,
        transactionCode: string,
        transactionType: string,
        initContribUpdateDocumentFormat?: string,
        initContribUpdateDocumentPath?: string,
        initContribUpdateDocumentSize?: number,
    ) => {
        dispatch(setOpenBackdrop(true));

        const paymentHolderArray = (holder: PaymentBankDetails) => {
            return {
                "foreignBankAccount": holder ?
                    [
                        {
                            "lastFourDigitsOfRegForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAddr": isFieldValueNull(holder?.paymentBankAddress),
                            "paymentBankBranch": isFieldValueNull(holder?.paymentBankBranch),
                            "paymentBankIbanCode": isFieldValueNull(holder?.paymentBankIbanCode),
                            "paymentBankName": isFieldValueNull(holder?.paymentBankName),
                            "paymentBankSwiftAndBic": isFieldValueNull(holder?.swiftOrBicCode),
                            "paymentForeignBankAccType": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.accountType) : null,
                            "regPaymentForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                        }
                    ] : [],
                "isForeignBankAcct": isFieldValueNull(holder?.isForeignBankAccount),
                "nationalBankAccount": holder ?
                    [
                        {
                            "lastFourDigOfRegBankAccountNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAccName": isFieldValueNull(holder?.paymentBankAccountName),
                            "paymentBankAccNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                            "paymentBankAccType": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.accountType) : null,
                            "paymentBankChqRefNo": holder?.paymentChequeDetails.map((cheque) => {
                                return {
                                    "chequeAmount": isFieldValueNull(cheque.chequeAmount),
                                    "chequeRefNo": isFieldValueNull(cheque.chequeReferenceNumber)
                                };
                            }),
                            "paymentBankIfsc": isFieldValueNull(holder?.paymentBankIfscCode),
                            "paymentBankMicr": isFieldValueNull(holder?.micrCode),
                            "paymentBankPennyDropStatus": isFieldValueNull(holder?.pennyDropStatus),
                            "paymentBankUtrNo": isFieldValueNull(holder?.paymentBankUtrNumber),
                            "paymentType": isFieldValueNull(holder?.paymentType),
                            "pennyDropValidationDt": isFieldValueNull(holder?.pennyDropValidationDate),
                        }
                    ] : [],
                "paymentBankIsRegBank": holder?.isForeignBankAccount === "No" 
                    ? isFieldValueNull(holder?.sameAsRegisteredBank)
                    : null,
            };
        };
            
        const data = {
            "accreditationFlag": initialContributionState.accreditationFlag,
            "allotmentMode": {
                "clientId": isFieldValueNull(initialContributionState.clientId),
                "dPId": isFieldValueNull(initialContributionState.dpId),
                "modeOfAllotment": isFieldValueNull(initialContributionState.allotmentMode),
                "repositoryType": isFieldValueNull(initialContributionState.repositoryType),
            },
            "clientId": isFieldValueNull(clientId),
            "clientName": isFieldValueNull(initialContributionState.clientName),
            "contributionDetails": {
                "commitmentAmount": isFieldValueNull(initialContributionState.commitmentAmount),
                "exchngRate": isFieldValueNull(initialContributionState.exchangeRate),
                "fundCurrency": isFieldValueNull(initialContributionState.fundCurrency),
                "fundCurrencyAmount": isFieldValueNull(initialContributionState.fundCurrencyAmount),
                "gst": isFieldValueNull(initialContributionState.gstOrServiceTax),
                "gstWaiver": isFieldValueNull(initialContributionState.gstOrServiceTaxWaiver),
                "gstWaiverAttachment": {
                    "documentFormat": isFieldValueNull(initialContributionState.gstWaiverApprovalEmailFileFormat),
                    "documentPath": isFieldValueNull(initialContributionState.gstWaiverApprovalEmailFileS3SignedURL),
                    "documentSize": isFieldValueNull(initialContributionState.gstWaiverApprovalEmailFileSize),
                },
                "initContribAmt": isFieldValueNull(initialContributionState.contributionAmount),
                "otherFee": isFieldValueNull(initialContributionState.otherFee),
                "paymentType": isFieldValueNull(initialContributionState.paymentType),
                "primaryHolderContrib": isFieldValueNull(initialContributionState.primaryHolderContribution),
                "primaryHolderPercent": isFieldValueNull(initialContributionState.primaryHolderPercentage),
                "secondHolderContrib": isFieldValueNull(initialContributionState.secondHolderContribution),
                "secondHolderPercent": isFieldValueNull(initialContributionState.secondHolderPercentage),
                "setupFeeAmt": isFieldValueNull(initialContributionState.setupFeeAmount),
                "setupFeePercent": isFieldValueNull(initialContributionState.setupFeePercentage),
                "thirdHolderContrib": isFieldValueNull(initialContributionState.thirdHolderContribution),
                "thirdHolderPercent": isFieldValueNull(initialContributionState.thirdHolderPercentage),
                "totalSetupFee": isFieldValueNull(initialContributionState.totalSetupFee),
                "transactionCurrency": isFieldValueNull(initialContributionState.transactionCurrency),
            },
            "distributorDetails": {
                "adviceType": isFieldValueNull(initialContributionState.poaDistributorOrDirect),
                "amcRmCode": isFieldValueNull(initialContributionState.amcRmCode),
                "amcRmName": isFieldValueNull(initialContributionState.amcRmName),
                "distributorCode": isFieldValueNull(initialContributionState.distributorCode),
                "distributorName": isFieldValueNull(initialContributionState.distributorName)
            },
            "documentsProvided": {
                "amcApprovalMail": isFieldValueNull(initialContributionState.anyApprovalMailFromAmc),
                "bankProofOrCheqCopy": isFieldValueNull(initialContributionState.bankProofOrChequeCopy),
                "dematAllocClientMasterList": isFieldValueNull(initialContributionState.clientMasterListForDematAllocation),
                "initContribAnnexure": isFieldValueNull(initialContributionState.initialContributionAnnexure),
                "poaNotaryAgreementCopy": null, // Not-available
            },
            "folioNo": isFieldValueNull(initialContributionState.folioNumber),
            "frozenFolioFlag": initialContributionState.frozenFolioFlag,
            "guardianTaxId": isFieldValueNull(initialContributionState.guardianTaxId),
            "initContribUpdateForm": {
                "documentFormat": isFieldValueNull(initContribUpdateDocumentFormat),
                "documentPath": isFieldValueNull(initContribUpdateDocumentPath),
                "documentSize": initContribUpdateDocumentSize !== 0 ? initContribUpdateDocumentSize : null,
            },
            "invCategory": isFieldValueNull(initialContributionState.investorCategory),
            "invName": isFieldValueNull(initialContributionState.investorName),
            "invType": isFieldValueNull(initialContributionState.invType),
            "investmentDetails": {
                "class": isFieldValueNull(initialContributionState.className),
                "clientApproval": {
                    "documentFormat": null, // Not-available
                    "documentPath": null, // Not-available
                    "documentSize": null // Not-available
                },
                "productType": isFieldValueNull(initialContributionState.productType),
                "schemeCode": isFieldValueNull(initialContributionState.schemeCode),
                "schemeIsinNo": isFieldValueNull(initialContributionState.schemeIsinNumber),
                "schemeName": isFieldValueNull(initialContributionState.scheme),
            },
            "modeOfHolding": isFieldValueNull(initialContributionState.modeOfHolding),
            "parentTransactionNo": isFieldValueNull(initialContributionState.parentTransactionNo),
            "paymentBankDetails": {
                "primaryHolderPaymentBank": paymentHolderArray(initialContributionState.paymentBankDetails[0]),
                "secondaryHolderPaymentBank": paymentHolderArray(initialContributionState.paymentBankDetails[1]),
                "thirdHolderPaymentBank": paymentHolderArray(initialContributionState.paymentBankDetails[2]),
            },
            "poa": {
                "nameOfPoa": isFieldValueNull(initialContributionState.poaName),
                "poaTaxIdNo": isFieldValueNull(initialContributionState.poaPanOrTaxId),
                "poaType": isFieldValueNull(initialContributionState.poaType),
            },
            "processCode": "ICP",
            "role": isFieldValueNull(userRole),
            "secHolderRelatshpWithPrimaryHolder": isFieldValueNull(initialContributionState.secHolderRelatshpWithPrimaryHolder),
            "sourceUser": isFieldValueNull(sourceUser),
            "stageCode": stageCode,
            "taxId": isFieldValueNull(initialContributionState.panOrTaxId),
            "thirdHolderRelatshpWithPrimaryHolder": isFieldValueNull(initialContributionState.thirdHolderRelatshpWithPrimaryHolder),
            "transactionCode": isFieldValueNull(transactionCode),
            "transactionNo": transactionNo,
            "transactionType": isFieldValueNull(transactionType),
            "updateFlag": updateFlag,
            "userId": isFieldValueNull(userId),
        };

        const axiosConfig = {
            "data": data,
            "url": "/initcontrib",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postInitialContribution;
}

export default usePostInitialContribution;
