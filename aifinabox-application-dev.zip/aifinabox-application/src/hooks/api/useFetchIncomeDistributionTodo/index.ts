import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchIncomeDistributionTodo() {
    const dispatch = useDispatch();
    let uploadedMasterData: any;

    const fetchIncomeDistributionTodoQueue = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role: "M" | "C" |"A", 
        transactionNo: string
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/initcontrib?clientId=${clientId}&processCode=${processCode}&role=${role}&stageCode=${stageCode}&transactionNo=${transactionNo}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                uploadedMasterData = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return uploadedMasterData;
    };
    
    return fetchIncomeDistributionTodoQueue;
}

export default useFetchIncomeDistributionTodo;
