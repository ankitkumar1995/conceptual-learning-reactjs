import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDownloadSouceFileIncomeDistribution() {
    const dispatch = useDispatch();

    const fetchDownloadSourceFileIncomeDistribution = async (
        transactionNo: string,
        processCode: string,
    ): Promise<{
        "url": string[];
    }> => {
        dispatch(setOpenBackdrop(true));

        let resUrl: string[] = [];

        const axiosConfig = {
            "url": `/transactiondocument?transactionNo=${transactionNo}&processCode=${processCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                resUrl.push(responseData.url);
                console.log(resUrl);
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
        return {
            "url": resUrl,
        };
    };
    
    return fetchDownloadSourceFileIncomeDistribution;
}

export default useFetchDownloadSouceFileIncomeDistribution;
