import { 
    FundMasterDetails, 
    initialFundMasterDetailsFormState 
} from "../../../redux/AifMaster/FundMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState,
} from "../../../redux/AifMaster/FundMaster/Update/initialState";

import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FundMaster {
    fundMasterFormState: FundMasterDetails;
    fundMasterUpdateState: UpdateState;
}

function useFetchFundMaster () {
    const dispatch = useDispatch();

    let fundMasterData: FundMasterDetails = initialFundMasterDetailsFormState;
    let fundMasterUpdateData: UpdateState = initializeUpdateState();
    let fundMaster: FundMaster;

    const fetchFundMaster = async (
        companyCode: string,
        fundCode: string,
        role: "A" | "M" | "C",  
        userId: string,
    ): Promise<FundMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/fundmaster?clientCode=${companyCode}&fundCode=${fundCode}&role=${role}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const fundMasterMakerEntryFromApi = responseData[0];

                fundMasterData = {
                    "fundAdditionalInformation": {
                        "defaulterPenalty": fundMasterMakerEntryFromApi.defaulterPenaltyApplicableOrNotApplicable.value,
                        "distributionFrequency": fundMasterMakerEntryFromApi.distributionFrequency.value,
                        "dormant": fundMasterMakerEntryFromApi.isDormant.value,
                        "dormantDate": fundMasterMakerEntryFromApi.dormantDate.value,
                        "forexSource": fundMasterMakerEntryFromApi.forexSource.value,
                        "fundAdditionalFee": fundMasterMakerEntryFromApi.fundAdditionalFee.value,
                        "fundCommitmentApplicability": fundMasterMakerEntryFromApi.fundCommitmentApplicability.value,
                        "fundManagementFee": fundMasterMakerEntryFromApi.fundManagementFee.value,
                        "fundStampDutyBorne": fundMasterMakerEntryFromApi.fundStampDutyBourne.value,
                        "fundTrusteeFee": fundMasterMakerEntryFromApi.fundTrusteeFee.value,
                        "goodsServiceTax": fundMasterMakerEntryFromApi.goodsAndServiceTax.value,
                        "gpSharingRation": fundMasterMakerEntryFromApi.gpSharingRation.value,
                        "highWaterMark": fundMasterMakerEntryFromApi.highWaterMark.value,
                        "hurdleRate": fundMasterMakerEntryFromApi.hurdleRate.value,
                        "hurdleStartDate": fundMasterMakerEntryFromApi.hurdleStartDate.value,
                        "isActive": fundMasterMakerEntryFromApi.isActive.value,
                        "navRadioMethod": fundMasterMakerEntryFromApi.navRatioMethod.value,
                        "operatingExpenses": fundMasterMakerEntryFromApi.operatingExpensesApplicableOrNotApplicable.value,
                        "preferredRateOfReturn": fundMasterMakerEntryFromApi.preferredRateOfReturnApplicableOrNotApplicable.value,
                        "setupFee": fundMasterMakerEntryFromApi.setupFee.value,
                    },
                    "fundBasicDetails": {
                        "companyCode": fundMasterMakerEntryFromApi.clientCode,
                        "companyName": fundMasterMakerEntryFromApi.clientName,
                        "fundBusinessType": fundMasterMakerEntryFromApi.fundBusinessType.value,
                        "fundCategory": fundMasterMakerEntryFromApi.fundCategory,
                        "fundClientId": fundMasterMakerEntryFromApi.fundClientID.value,
                        "fundCode": fundMasterMakerEntryFromApi.fundCode,
                        "fundCurrency": fundMasterMakerEntryFromApi.fundCurrency.value,
                        "fundDepositoryType": fundMasterMakerEntryFromApi.fundDepositoryType.value,
                        "fundDomicile": fundMasterMakerEntryFromApi.fundDomicile.value,
                        "fundDpId": fundMasterMakerEntryFromApi.fundDPID.value,
                        "fundFaceValue": fundMasterMakerEntryFromApi.fundFaceValue.value,
                        "fundFrom": fundMasterMakerEntryFromApi.fundFrom.value,
                        "fundIsinNumber": fundMasterMakerEntryFromApi.fundISINNumber.value,
                        "fundName": fundMasterMakerEntryFromApi.fundName.value,
                        "fundNature": fundMasterMakerEntryFromApi.fundNature.value,
                        "fundPeriod": fundMasterMakerEntryFromApi.fundPeriodValue.value,
                        "fundPeriodSuffix": fundMasterMakerEntryFromApi.fundPeriodType.value,
                        "fundRegistrationNumber": fundMasterMakerEntryFromApi.fundRegistrationNumber.value,
                        "fundShortName": fundMasterMakerEntryFromApi.fundShortName.value,
                        "fundSubCategory": fundMasterMakerEntryFromApi.fundSubCategory,
                        "gstin": fundMasterMakerEntryFromApi.gstin,
                        "panOrTin": fundMasterMakerEntryFromApi.fundPanOrTin.value,
                        "serviceModel": fundMasterMakerEntryFromApi.serviceModel,
                    },
                    "fundSpecificDetails": {
                        "fundAccountantContactNumber": fundMasterMakerEntryFromApi.fundAccountantContactNumber.value,
                        "fundAccountantContactNumberPrefix": fundMasterMakerEntryFromApi.fundAccountantContactCountryCode.value,
                        "fundAccountantEmail": fundMasterMakerEntryFromApi.fundAccountantEmail.value,
                        "fundAccountantName": fundMasterMakerEntryFromApi.fundAccountantName.value,
                        "fundCustodianCode": fundMasterMakerEntryFromApi.fundCustodianCode.value,
                        "fundEndDate": fundMasterMakerEntryFromApi.fundEndDate.value,
                        "fundInitialContribution": fundMasterMakerEntryFromApi.fundInitialContributionPercentage.value,
                        "fundInitialContributionAmount": fundMasterMakerEntryFromApi.fundInitialContributionAmount.value,
                        "fundInitialContributionCloseDate": fundMasterMakerEntryFromApi.fundInitialContributionCloseDate.value,
                        "fundInitialContributionStartDate": fundMasterMakerEntryFromApi.fundInitialContributionStartDate.value,
                        "fundInvestmentManager": fundMasterMakerEntryFromApi.fundInvestmentManager.value,
                        "fundMaturityDate": fundMasterMakerEntryFromApi.fundMaturityDate.value,
                        "fundMaxInvestors": fundMasterMakerEntryFromApi.fundMaxInvestors.value,
                        "fundRtaCode": fundMasterMakerEntryFromApi.fundRTACode.value,
                        "fundSize": fundMasterMakerEntryFromApi.fundSizeCorpus.value,
                        "fundSponsorName": fundMasterMakerEntryFromApi.fundSponsorName.value,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundSpecificStartDate.value,
                        "fundTrusteeName": fundMasterMakerEntryFromApi.fundTrusteeName.value,
                        "legalAdvisorName": fundMasterMakerEntryFromApi.legalAdvisorName.value,
                        "taxAdvisorName": fundMasterMakerEntryFromApi.taxAdvisorName.value,
                        "transferAgentAccountantEmail": fundMasterMakerEntryFromApi.transferAgentAccountantEmail.value,
                        "transferAgentContactNumber": fundMasterMakerEntryFromApi.transferAgentContactNumber.value,
                        "transferAgentContactNumberPrefix": fundMasterMakerEntryFromApi.transferAgentContactCountryCode.value,
                        "transferAgentName": fundMasterMakerEntryFromApi.transferAgentName.value,
                    }, 
                    "fundValuationInformation": {
                        "fundCurrentDate": fundMasterMakerEntryFromApi.fundCurrentDate.value,
                        "fundCurrentYearEnd": fundMasterMakerEntryFromApi.fundCurrentYearEnd.value,
                        "fundDDNoticePeriod": fundMasterMakerEntryFromApi.fundDDNoticePeriod.value,
                        "fundDDPenaltyCharges": fundMasterMakerEntryFromApi.fundDDPenaltyCharges.value,
                        "fundDDTreatment": fundMasterMakerEntryFromApi.fundDDTreatment.value,
                        "fundNextDate": fundMasterMakerEntryFromApi.fundNextDate.value,
                        "fundPlCompMethod": fundMasterMakerEntryFromApi.fundPLCompMethod.value,
                        "fundPreviousDate": fundMasterMakerEntryFromApi.fundPreviousDate.value,
                        "fundPreviousYearEnd": fundMasterMakerEntryFromApi.fundPreviousYearEnd.value,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundValuationStartDate.value,
                        "fundTopupTreatment": fundMasterMakerEntryFromApi.fundTopupTreatment.value,
                        "navFrequency": fundMasterMakerEntryFromApi.navFrequency.value,
                        "navPubFrequency": fundMasterMakerEntryFromApi.navPubFrequency.value,
                        "navPublishType": "",
                        "nextNavDate": fundMasterMakerEntryFromApi.nextNAVDate.value,
                        "nextNavPubDate": fundMasterMakerEntryFromApi.nextNAVPubDate.value,
                        "prevNavDate": fundMasterMakerEntryFromApi.prevNAVDate.value,
                        "prevNavPubDate": fundMasterMakerEntryFromApi.prevNAVPubDate.value,
                        "roundDecimals": fundMasterMakerEntryFromApi.roundDecimals.value,
                        "roundMethod": fundMasterMakerEntryFromApi.roundMethod.value,
                        "unitDecimals": fundMasterMakerEntryFromApi.unitDecimals.value,
                        "valuationSequence": fundMasterMakerEntryFromApi.valuationSequence.value,
                    },
                };

                fundMasterUpdateData = {
                    "fundAdditionalInformationUpdateState": {
                        "defaulterPenalty": fundMasterMakerEntryFromApi.defaulterPenaltyApplicableOrNotApplicable.update,
                        "distributionFrequency": fundMasterMakerEntryFromApi.distributionFrequency.update,
                        "dormant": fundMasterMakerEntryFromApi.isDormant.update,
                        "dormantDate": fundMasterMakerEntryFromApi.dormantDate.update,
                        "forexSource": fundMasterMakerEntryFromApi.forexSource.update,
                        "fundAdditionalFee": fundMasterMakerEntryFromApi.fundAdditionalFee.update,
                        "fundCommitmentApplicability": fundMasterMakerEntryFromApi.fundCommitmentApplicability.update,
                        "fundManagementFee": fundMasterMakerEntryFromApi.fundManagementFee.update,
                        "fundStampDutyBorne": fundMasterMakerEntryFromApi.fundStampDutyBourne.update,
                        "fundTrusteeFee": fundMasterMakerEntryFromApi.fundTrusteeFee.update,
                        "goodsServiceTax": fundMasterMakerEntryFromApi.goodsAndServiceTax.update,
                        "gpSharingRation": fundMasterMakerEntryFromApi.gpSharingRation.update,
                        "highWaterMark": fundMasterMakerEntryFromApi.highWaterMark.update,
                        "hurdleRate": fundMasterMakerEntryFromApi.hurdleRate.update,
                        "hurdleStartDate": fundMasterMakerEntryFromApi.hurdleStartDate.update,
                        "isActive": fundMasterMakerEntryFromApi.isActive.update,
                        "navRadioMethod": fundMasterMakerEntryFromApi.navRatioMethod.update,
                        "operatingExpenses": fundMasterMakerEntryFromApi.operatingExpensesApplicableOrNotApplicable.update,
                        "preferredRateOfReturn": fundMasterMakerEntryFromApi.preferredRateOfReturnApplicableOrNotApplicable.update,
                        "setupFee": fundMasterMakerEntryFromApi.setupFee.update,
                    },
                    "fundBasicDetailsUpdateState": {
                        "fundBusinessType": fundMasterMakerEntryFromApi.fundBusinessType.update,
                        "fundCategory": fundMasterMakerEntryFromApi.fundCategory.update,
                        "fundClientId": fundMasterMakerEntryFromApi.fundClientID.update,
                        "fundCurrency": fundMasterMakerEntryFromApi.fundCurrency.update,
                        "fundDepositoryType": fundMasterMakerEntryFromApi.fundDepositoryType.update,
                        "fundDomicile": fundMasterMakerEntryFromApi.fundDomicile.update,
                        "fundDpId": fundMasterMakerEntryFromApi.fundDPID.update,
                        "fundFaceValue": fundMasterMakerEntryFromApi.fundFaceValue.update,
                        "fundFrom": fundMasterMakerEntryFromApi.fundFrom.update,
                        "fundIsinNumber": fundMasterMakerEntryFromApi.fundISINNumber.update,
                        "fundName": fundMasterMakerEntryFromApi.fundName.update,
                        "fundNature": fundMasterMakerEntryFromApi.fundNature.update,
                        "fundPeriod": fundMasterMakerEntryFromApi.fundPeriodValue.update,
                        "fundPeriodSuffix": fundMasterMakerEntryFromApi.fundPeriodType.update,
                        "fundRegistrationNumber": fundMasterMakerEntryFromApi.fundRegistrationNumber.update,
                        "fundShortName": fundMasterMakerEntryFromApi.fundShortName.update,
                        "fundSubCategory": fundMasterMakerEntryFromApi.fundSubCategory.update,
                        "panOrTin": fundMasterMakerEntryFromApi.fundPanOrTin.update,
                        "serviceModel": fundMasterMakerEntryFromApi.serviceModel.update,
                    }, 
                    "fundSpecificDetailsUpdateState": {
                        "fundAccountantContactNumber": fundMasterMakerEntryFromApi.fundAccountantContactNumber.update,
                        "fundAccountantContactNumberPrefix": fundMasterMakerEntryFromApi.fundAccountantContactCountryCode.update,
                        "fundAccountantEmail": fundMasterMakerEntryFromApi.fundAccountantEmail.update,
                        "fundAccountantName": fundMasterMakerEntryFromApi.fundAccountantName.update,
                        "fundCustodianCode": fundMasterMakerEntryFromApi.fundCustodianCode.update,
                        "fundEndDate": fundMasterMakerEntryFromApi.fundEndDate.update,
                        "fundInitialContribution": fundMasterMakerEntryFromApi.fundInitialContributionPercentage.update,
                        "fundInitialContributionAmount": fundMasterMakerEntryFromApi.fundInitialContributionAmount.update,
                        "fundInitialContributionCloseDate": fundMasterMakerEntryFromApi.fundInitialContributionCloseDate.update,
                        "fundInitialContributionStartDate": fundMasterMakerEntryFromApi.fundInitialContributionStartDate.update,
                        "fundInvestmentManager": fundMasterMakerEntryFromApi.fundInvestmentManager.update,
                        "fundMaturityDate": fundMasterMakerEntryFromApi.fundMaturityDate.update,
                        "fundMaxInvestors": fundMasterMakerEntryFromApi.fundMaxInvestors.update,
                        "fundRtaCode": fundMasterMakerEntryFromApi.fundRTACode.update,
                        "fundSize": fundMasterMakerEntryFromApi.fundSizeCorpus.update,
                        "fundSponsorName": fundMasterMakerEntryFromApi.fundSponsorName.update,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundSpecificStartDate.update,
                        "fundTrusteeName": fundMasterMakerEntryFromApi.fundTrusteeName.update,
                        "legalAdvisorName": fundMasterMakerEntryFromApi.legalAdvisorName.update,
                        "taxAdvisorName": fundMasterMakerEntryFromApi.taxAdvisorName.update,
                        "transferAgentAccountantEmail": fundMasterMakerEntryFromApi.transferAgentAccountantEmail.update,
                        "transferAgentContactNumber": fundMasterMakerEntryFromApi.transferAgentContactNumber.update,
                        "transferAgentContactNumberPrefix": fundMasterMakerEntryFromApi.transferAgentContactCountryCode.update,
                        "transferAgentName": fundMasterMakerEntryFromApi.transferAgentName.update,
                    },
                    "fundValuationInformationUpdateState": {
                        "fundCurrentDate": fundMasterMakerEntryFromApi.fundCurrentDate.update,
                        "fundCurrentYearEnd": fundMasterMakerEntryFromApi.fundCurrentYearEnd.update,
                        "fundDDNoticePeriod": fundMasterMakerEntryFromApi.fundDDNoticePeriod.update,
                        "fundDDPenaltyCharges": fundMasterMakerEntryFromApi.fundDDPenaltyCharges.update,
                        "fundDDTreatment": fundMasterMakerEntryFromApi.fundDDTreatment.update,
                        "fundNextDate": fundMasterMakerEntryFromApi.fundNextDate.update,
                        "fundPlCompMethod": fundMasterMakerEntryFromApi.fundPLCompMethod.update,
                        "fundPreviousDate": fundMasterMakerEntryFromApi.fundPreviousDate.update,
                        "fundPreviousYearEnd": fundMasterMakerEntryFromApi.fundPreviousYearEnd.update,
                        "fundStartDate": fundMasterMakerEntryFromApi.fundValuationStartDate.update,
                        "fundTopupTreatment": fundMasterMakerEntryFromApi.fundTopupTreatment.update,
                        "navFrequency": fundMasterMakerEntryFromApi.navFrequency.update,
                        "navPubFrequency": fundMasterMakerEntryFromApi.navPubFrequency.update,
                        "navPublishType": false,
                        "nextNavDate": fundMasterMakerEntryFromApi.nextNAVDate.update,
                        "nextNavPubDate": fundMasterMakerEntryFromApi.nextNAVPubDate.update,
                        "prevNavDate": fundMasterMakerEntryFromApi.prevNAVDate.update,
                        "prevNavPubDate": fundMasterMakerEntryFromApi.prevNAVPubDate.update,
                        "roundDecimals": fundMasterMakerEntryFromApi.roundDecimals.update,
                        "roundMethod": fundMasterMakerEntryFromApi.roundMethod.update,
                        "unitDecimals": fundMasterMakerEntryFromApi.unitDecimals.update,
                        "valuationSequence": fundMasterMakerEntryFromApi.valuationSequence.update,
                    },
                    "updateFlag": fundMasterMakerEntryFromApi.updateFlag,
                };

                fundMaster = {
                    "fundMasterFormState": fundMasterData,
                    "fundMasterUpdateState": fundMasterUpdateData,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return fundMaster;
    };

    return fetchFundMaster;
}

export  default useFetchFundMaster;
