import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface PendingCheckerItem {
    clientCode: string;
    clientName: string;
    clientType: string;
    createdOn: string;
    createdBy: string;
    fundCode: string;
    fundName: string;
    id: string;
}

interface ApiResultDataItem {
    _id: string;
    clientCode: string;
    clientName: string;
    clientType: string;
    fundCode: string;
    fundName: string;
    entryDate: string;
    sourceUser: string;
}

function useFetchCheckerQueue() {
    const dispatch = useDispatch();

    const fetchCheckerQueue = async (
        queueLength: number,
        pageIndex: number,
        masterName: MasterName,
        role: "C" | "A",
    ): Promise<{
        checkerQueue: PendingCheckerItem[];
        pendingCheckerItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let checkerQueue: PendingCheckerItem[] = [];
        let pendingCheckerItemCount = 0;

        const axiosConfig = {
            "url": `/todoqueue?queueLength=${5}&masterName=${masterName}&pageIndex=${pageIndex}&role=${role}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const pendingCheckerItems = responseData.result;
                
                pendingCheckerItemCount = responseData.count;
                checkerQueue = pendingCheckerItems.map((pendingCheckerItem: ApiResultDataItem) => ({
                    "clientCode": pendingCheckerItem.clientCode,
                    "clientName": pendingCheckerItem.clientName,
                    "clientType": pendingCheckerItem.clientType,
                    "createdBy": pendingCheckerItem.sourceUser,
                    "createdOn": pendingCheckerItem.entryDate,
                    "fundCode": pendingCheckerItem.fundCode,
                    "fundName": pendingCheckerItem.fundName,
                    "id": pendingCheckerItem._id,
                }) as PendingCheckerItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "checkerQueue": checkerQueue,
            "pendingCheckerItemCount": pendingCheckerItemCount,
        };
    };
    
    return fetchCheckerQueue;
}

export default useFetchCheckerQueue;
