import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDistributionRecords() {
    const dispatch = useDispatch();
    let distributionRecords: any;

    const fetchDistributionRecords = async (
        batchNo: string,
        pageIndex: number,
        queueLength: number,
        auditStatus?: string
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));
        let url = `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/distributionrecords?batchNo=${batchNo}&pageIndex=${pageIndex}&queueLength=${queueLength}`;

        if (auditStatus !== undefined && auditStatus.trim() !== "") {
            url += `&auditStatus=${auditStatus}`;
        }

        const axiosConfig = {
            "url": url,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                distributionRecords = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return distributionRecords;
    };
    
    return fetchDistributionRecords;
}

export default useFetchDistributionRecords;
