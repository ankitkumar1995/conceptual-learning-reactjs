import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostRejectInitialContribution() {
    const dispatch = useDispatch();

    const postRejectInitialContribution = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userRole: "C" | "M" | "A",
        userId: string,
        remarks: string,
        transactionNo: string,
        folio: string,
        sourceUser: string,
        clientName: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "clientId": clientId,
            "clientName": clientName,
            "folio": folio,
            "processCode": processCode,
            "rejectRemarks": remarks,
            "role": userRole,
            "sourceUser": sourceUser,
            "stageCode": stageCode,
            "transactionNo": transactionNo,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": "/reject",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postRejectInitialContribution;
}

export default usePostRejectInitialContribution;
