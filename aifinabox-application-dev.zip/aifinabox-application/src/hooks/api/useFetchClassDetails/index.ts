import { MasterName } from "../interfaces/MasterName.types";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface ClassData {
        auditorId: string;
        classCode: {
            value: string;
            update: boolean;
        };
        clientCode: string;
        clientName: string;
        currentStage: number;
        entryDate: string;
        fundClassAdditionalFee: {
            value: string;
            update: boolean;
        };
        fundClassCarryPercentage: {
            value: string;
            update: boolean;
        };
        fundClassCatchupPercentage: {
            value: string;
            update: boolean;
        };
        fundClassCategory: {
            value: string;
            update: boolean;
        };
        fundClassCurrency: {
            value: string;
            update: boolean;
        };
        fundClassDescription: {
            value: string;
            update: boolean;
        };
        fundClassFaceValue: {
            value: string;
            update: boolean;
        };
        fundClassGstRate: {
            value: string;
            update: boolean;
        };
        fundClassHurdleRate: {
            value: string;
            update: boolean;
        };
        fundClassManagementFee: {
            value: string;
            update: boolean;
        };
        fundClassMaxAmount: {
            value: string;
            update: boolean;
        };
        fundClassMaxReturn: {
            value: string;
            update: boolean;
        };
        fundClassMinAmount: {
            value: string;
            update: boolean;
        };
        fundClassOrgFee: {
            value: string;
            update: boolean;
        };
        fundClassPerFeePercentage: {
            value: string;
            update: boolean;
        };
        fundClassPerformanceFee: {
            value: string;
            update: boolean;
        };
        fundClassPreferredReturn: {
            value: string;
            update: boolean;
        };
        fundClassShareRatio: {
            value: string;
            update: boolean;
        };
        fundCode: string;
        fundName: string;
        fundSponsorClass: {
            value: string;
            update: boolean;
        };
        highWaterMark: {
            value: string;
            update: boolean;
        };
        _id: string;
        incomeDistFrequency: {
            value: string;
            update: boolean;
        };
        isActive: {
            value: string;
            update: boolean;
        };
        isinCode: {
            value: string;
            update: boolean;
        };
        planCode: string;
        planName: string;
        recordStatus: number;
        revisionNo: number;
        role: string;
        setupFee: {
            value: string;
            update: boolean;
        };
        sourceUser: string;
        status: string;
        updateFlag: string;
  }
  
function useFetchClassDetails() {
    const dispatch = useDispatch();

    const fetchClassCodes = async (
        clientCode: string,
        fundCode: string | null,
        planCode: string | null,
    ): Promise<ClassData[]> => {
        dispatch(setOpenBackdrop(true));

        let classCodes: ClassData[] = [];

        const axiosConfig = {
            "url": `/class?clientCode=${clientCode}&fundCode=${fundCode}&planCode=${planCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                classCodes = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classCodes; 
    };

    return fetchClassCodes;
}

export default useFetchClassDetails;
