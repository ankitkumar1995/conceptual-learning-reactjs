/* eslint-disable sort-keys */
interface InitContribUpdateForm {
    documentFormat: string | null;
    documentPath: string | null;
    documentSize: string | null;
};

interface PoaDetails {
    poaType: string;
    poaTaxIdNo: string;
    nameOfPoa: string;
};

interface AllotmentMode  {
    modeOfAllotment: string;
    repositoryType: string;
    dPId: string;
    clientId: string;
};

interface ClientApproval {
    documentFormat: string | null;
    documentPath: string | null;
    documentSize: string | null;
};

interface InvestmentDetails  {
    class: string;
    productType: string;
    schemeCode: string;
    schemeName: string;
    schemeIsinNo: string;
    clientApproval: ClientApproval;
};

interface DistributorDetails  {
    adviceType: string;
    amcRmName: string;
    amcRmCode: string;
    distributorCode: string;
    distributorName: string;
};

interface GstWaiverAttachment {
    documentFormat: string | null;
    documentPath: string | null;
    documentSize: string | null;
};

interface ContributionDetails  {
    fundCurrency: string;
    transactionCurrency: string;
    commitmentAmount: string;
    initContribAmt: string;
    exchngRate: string;
    fundCurrencyAmount: string;
    otherFee: string;
    primaryHolderPercent: string;
    primaryHolderContrib: string;
    secondHolderPercent: string;
    secondHolderContrib: string;
    thirdHolderPercent: string;
    thirdHolderContrib: string;
    setupFeePercent: string;
    setupFeeAmt: string;
    gst: string;
    gstWaiver: string;
    gstWaiverAttachment: GstWaiverAttachment;
    totalSetupFee: string;
    paymentType: string;
};

interface DocumentsProvided  {
    initContribAnnexure: string;
    bankProofOrCheqCopy: string;
    amcApprovalMail: string;
    dematAllocClientMasterList: string;
    poaNotaryAgreementCopy: string;
};

interface ForeignBankAccount {
    lastFourDigitsOfRegForeignBankAccNo: string;
    paymentBankAddr: string;
    paymentBankBranch: string;
    paymentBankIbanCode: string;
    paymentBankName: string;
    paymentBankSwiftAndBic: string;
    paymentForeignBankAccType: string;
    regPaymentForeignBankAccNo: string;
}
  
interface NationalBankAccount {
    lastFourDigOfRegBankAccountNo: string;
    paymentBankAccName: string;
    paymentBankAccNo: string;
    paymentBankAccType: string;
    paymentBankChqRefNo: {
      chequeAmount: string;
      chequeRefNo: string;
    }[];
    paymentBankIfsc: string;
    paymentBankMicr: string;
    paymentBankPennyDropStatus: string;
    paymentBankUtrNo: string;
    paymentType: string;
    pennyDropValidationDt: string;
}
  
interface PaymentBankDetails {
    primaryHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
    secondaryHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
    thirdHolderPaymentBank: {
      foreignBankAccount: ForeignBankAccount[];
      isForeignBankAcct: string | null;
      nationalBankAccount: NationalBankAccount[];
      paymentBankIsRegBank: string | null;
    };
}

export interface FolioDetails {
    id: string;
    clientId: string;
    clientName: string;
    transactionNo: string;
    parentTransactionNo: string | null;
    transactionType: string;
    transactionCode: string;
    taxId: string;
    guardianTaxId: string | null;
    folioNo: string;
    frozenFolioFlag: string | boolean;
    invName: string;
    invCategory: string;
    invType: string;
    modeOfHolding: string;
    poa: PoaDetails;
    initContribUpdateForm: InitContribUpdateForm;
    allotmentMode: AllotmentMode;
    investmentDetails: InvestmentDetails;
    distributorDetails: DistributorDetails;
    contributionDetails: ContributionDetails;
    paymentBankDetails: PaymentBankDetails;
    documentsProvided: DocumentsProvided;
    updateFlag: string;
    recordStatus: string | number;
    revisionNo: string;
    currentStage: string;
    stage: string;
    intiEntryUserId: string | null;
    secEntryUserId: string;
    ocUserId: string | null;
    auditorId: string | null;
    auditStatus: string | null;
    auditedOn: string | null;
    accreditationFlag: boolean;
    secHolderRelatshpWithPrimaryHolder: string | null;
    thirdHolderRelatshpWithPrimaryHolder: string | null;
}

export const initializeFolioDetailsState: FolioDetails = {
    "accreditationFlag": false,
    "id": "",
    "clientId": "",
    "clientName": "",
    "transactionNo": "",
    "parentTransactionNo": null,
    "transactionType": "",
    "transactionCode": "",
    "taxId": "",
    "guardianTaxId": null,
    "folioNo": "",
    "frozenFolioFlag": false,
    "invName": "",
    "invCategory": "",
    "invType": "",
    "modeOfHolding": "",
    "poa": {
        "poaType": "",
        "poaTaxIdNo": "",
        "nameOfPoa": "",
    },
    "initContribUpdateForm": {
        "documentFormat": null,
        "documentPath": null,
        "documentSize": null,
    },
    "allotmentMode": {
        "modeOfAllotment": "",
        "repositoryType": "",
        "dPId": "",
        "clientId": "",
    },
    "investmentDetails": {
        "class": "",
        "productType": "",
        "schemeCode": "",
        "schemeName": "",
        "schemeIsinNo": "",
        "clientApproval": {
            "documentFormat": null,
            "documentPath": null,
            "documentSize": null,
        },
    },
    "distributorDetails": {
        "adviceType": "",
        "amcRmName": "",
        "amcRmCode": "",
        "distributorCode": "",
        "distributorName": "",
    },
    "contributionDetails": {
        "fundCurrency": "",
        "transactionCurrency": "",
        "commitmentAmount": "",
        "initContribAmt": "",
        "exchngRate": "",
        "fundCurrencyAmount": "",
        "otherFee": "",
        "primaryHolderPercent": "",
        "primaryHolderContrib": "",
        "secondHolderPercent": "",
        "secondHolderContrib": "",
        "thirdHolderPercent": "",
        "thirdHolderContrib": "",
        "setupFeePercent": "",
        "setupFeeAmt": "",
        "gst": "",
        "gstWaiver": "",
        "gstWaiverAttachment": {
            "documentFormat": null,
            "documentPath": null,
            "documentSize": null,
        },
        "totalSetupFee": "",
        "paymentType": "",
    },
    "paymentBankDetails": {
        "primaryHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
        "secondaryHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
        "thirdHolderPaymentBank": {
            "foreignBankAccount": [],
            "isForeignBankAcct": null,
            "nationalBankAccount": [],
            "paymentBankIsRegBank": null,
        },
    },
    "documentsProvided": {
        "initContribAnnexure": "",
        "bankProofOrCheqCopy": "",
        "amcApprovalMail": "",
        "dematAllocClientMasterList": "",
        "poaNotaryAgreementCopy": "",
    },
    "updateFlag": "",
    "secHolderRelatshpWithPrimaryHolder": "",
    "recordStatus": 0,
    "thirdHolderRelatshpWithPrimaryHolder": "",
    "revisionNo": "",
    "currentStage": "",
    "auditStatus": null,
    "stage": "",
    "intiEntryUserId": null,
    "secEntryUserId": "",
    "ocUserId": null,
    "auditorId": null,
    "auditedOn": null,
};
