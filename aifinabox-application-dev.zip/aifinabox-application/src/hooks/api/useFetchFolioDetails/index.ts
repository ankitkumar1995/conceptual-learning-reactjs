import { FolioDetails, initializeFolioDetailsState } from "./interfaces";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export const isFieldValueNull = (field: string | null) => {
    if (field === null || field === undefined || field?.trim() === "")
        return "";
    else
        return field;
};

function useFetchFolioDetails() {
    const dispatch = useDispatch();

    const fetchFolioDetails = async (
        clientId: string,
        folio: string,
    ): Promise<FolioDetails> => {
        dispatch(setOpenBackdrop(true));

        let folioDetails: FolioDetails = initializeFolioDetailsState;

        const axiosConfig = {
            "url": `/foliodetails?clientId=${clientId}&folioNo=${folio}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data[0];
                folioDetails = responseData;
            })
            .catch((error) => {
                console.error(error);
            });
            
        dispatch(setOpenBackdrop(false));
            
        return folioDetails;
    };

    return fetchFolioDetails;
}

export default useFetchFolioDetails;
