import { MasterName } from "../interfaces/MasterName.types";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface BanksListData {
    ifscOrRtgsCode: {
        value: string; 
        updated: boolean;
    };
    bankName: {
        value: string; 
        updated: boolean;
    };
}

function useFetchBanksList() {
    const dispatch = useDispatch();

    const fetchBanksList = async (clientCode: string): Promise<BanksListData[]> => {
        dispatch(setOpenBackdrop(true));

        let bankAccounts: BanksListData[] = [];

        const axiosConfig = {
            "url": `/bankslist?clientCode=${clientCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                bankAccounts = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankAccounts; 
    };

    return fetchBanksList;
}

export default useFetchBanksList;
