import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ClassResponse {
    classCode: string;
    // fundClassDescription: string;
}

function useFetchTopUpClassCodeDetails() {
    const dispatch = useDispatch();

    const fetchTopUpClassCodeDetails = async (
        clientCode: string,
        fundCode: string,
        productType: string,
        classAmount: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let classCodes: MenuItem[] = [];

        //not getting data from current cliedId and product type so using static values

        const axiosConfig = {
            "url": `/classcode?clientCode=${clientCode}&fundCode=${fundCode}&productType=${productType}&classAmount=${classAmount}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData: ClassResponse[] = response.data;
                
                classCodes = responseData.map((classDetails) => {
                    return {
                        "label": classDetails.classCode,
                        "value": classDetails.classCode,
                    };
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classCodes; 
    };

    return fetchTopUpClassCodeDetails;
}

export default useFetchTopUpClassCodeDetails;
