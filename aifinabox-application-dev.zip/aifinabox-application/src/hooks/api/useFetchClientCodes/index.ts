import { MasterName } from "../interfaces/MasterName.types";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ClientCodeData {
    clientCode: string;
    clientName: string;
    clientType: string;
}

function useFetchClientCodes() {
    const dispatch = useDispatch();

    const fetchClientCodes = async (
        masterName: MasterName,
        updateExistingData: "0" | "1",
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let clientCodes: MenuItem[] = [];

        const axiosConfig = {
            "url": `/clientcodeslist?masterName=${masterName}&updateFlag=${updateExistingData}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const clientCodesData = responseData;

                clientCodes = clientCodesData.map((clientCodeData: ClientCodeData) => ({
                    "label": `${clientCodeData.clientCode} - ${clientCodeData.clientName}`,
                    "value": clientCodeData.clientCode,
                }) as MenuItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return clientCodes; 
    };

    return fetchClientCodes;
}

export default useFetchClientCodes;
