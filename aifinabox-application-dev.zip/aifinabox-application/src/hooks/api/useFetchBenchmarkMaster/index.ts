import { 
    BenchmarkMasterDetails, 
    initialBenchmarkMasterDetailsFormState 
} from "../../../redux/AifMaster/BenchmarkMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState 
} from "../../../redux/AifMaster/BenchmarkMaster/Update/initialState";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FetchBenchmarkMaster {
    benchmarkMasterState: BenchmarkMasterDetails;
    benchmarkMasterUpdateState: UpdateState;
};

function useFetchBenchmarkMaster() {
    const dispatch = useDispatch();

    let benchmarkMasterData: BenchmarkMasterDetails = initialBenchmarkMasterDetailsFormState;
    let benchmarkMasterDataUpdate: UpdateState = initializeUpdateState();
    let benchmarkMaster: FetchBenchmarkMaster;

    const fetchBenchmarkMaster = async (
        clientCode: string,
        updateExistingData: "0" | "1",
        userId: string,
    ): Promise<FetchBenchmarkMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/benchmarkmaster?clientCode=${clientCode}&updateFlag=${updateExistingData}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const benchmarkMasterMakerEntryFromApi = responseData[0];
                
                benchmarkMasterData = {
                    "benchmark": benchmarkMasterMakerEntryFromApi.benchmark.value,
                    "benchmarkType": benchmarkMasterMakerEntryFromApi.benchmarkType.value,
                    "clientCode": benchmarkMasterMakerEntryFromApi.clientCode,
                    "clientType": benchmarkMasterMakerEntryFromApi.clientType,
                    "companyName": benchmarkMasterMakerEntryFromApi.clientName,
                    "effectiveDate": benchmarkMasterMakerEntryFromApi.effectiveDate.value,
                    "isActive": benchmarkMasterMakerEntryFromApi.isActive.value,
                };

                benchmarkMasterDataUpdate = {
                    "benchmark": benchmarkMasterMakerEntryFromApi.benchmark.update,
                    "benchmarkType": benchmarkMasterMakerEntryFromApi.benchmarkType.update,
                    "clientCode": false,
                    "companyName": false,
                    "effectiveDate": benchmarkMasterMakerEntryFromApi.effectiveDate.update,
                    "isActive": benchmarkMasterMakerEntryFromApi.isActive.update,
                    "updateFlag": benchmarkMasterMakerEntryFromApi.updateFlag,
                };

                benchmarkMaster = {
                    "benchmarkMasterState": benchmarkMasterData,
                    "benchmarkMasterUpdateState": benchmarkMasterDataUpdate,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return benchmarkMaster; 
    };

    return fetchBenchmarkMaster;
}

export default useFetchBenchmarkMaster;
