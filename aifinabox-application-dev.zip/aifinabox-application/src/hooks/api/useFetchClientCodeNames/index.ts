import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { nanoid } from "@reduxjs/toolkit";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface IObjData {
    update: boolean;
    value: string;
}
export interface ClientCodeData {
    clientCode: string;
    clientName: string;
    // clientName: IObjData;
    // clientType: IObjData;
    id:string;
}

export function initializeClientCodeData(): ClientCodeData {
    return {
        "clientCode": "",
        "clientName": "",
        // "clientName": {"update": false,"value": ""},
        // "clientType": {"update": false,"value": ""},
        "id": "",
    };
}

function useFetchClientCodeNames() {
    const dispatch = useDispatch();

    const fetchClientCodeNames = async (
        masterName: MasterName,
        updateExistingData: "0" | "1",
    ): Promise<ClientCodeData[]> => {
        dispatch(setOpenBackdrop(true));

        let clientData: ClientCodeData[] = [];

        const axiosConfig = {
            "url": `/clientcodeslist?masterName=${masterName}&updateFlag=${updateExistingData}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                let result = responseData.map((data: ClientCodeData)=>({...data, "id": nanoid()}));
                clientData =result;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return clientData; 
    };

    return fetchClientCodeNames;
}

export default useFetchClientCodeNames;
