import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostExcelFileValidator() {
    const dispatch = useDispatch();

    const excelFileData = async (
        fileName: string,
        format: string,
        bucketName: string,
        key: string,
        size: string,
        batchNo: string,
        clientCode: string,
        clientName: string,
        role: string,
        userId: string,
        sourceUser: string
    ) => {
        let responseData;
        dispatch(setOpenBackdrop(true));

        const data = {
            "batchNo": batchNo,
            "bucketName": bucketName,
            "clientId": clientCode,
            "clientName": clientName,
            "fileName": fileName,
            "format": format,
            "key": key,
            "role": role,
            "size": size,
            "sourceUser": sourceUser,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/distributionexcelprocess`,
        };

        await databasePostAxiosInstance(axiosConfig)
            .then((response) => {
                responseData = response.data;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
        return responseData;
    };
    
    return excelFileData;
}

export default usePostExcelFileValidator;
