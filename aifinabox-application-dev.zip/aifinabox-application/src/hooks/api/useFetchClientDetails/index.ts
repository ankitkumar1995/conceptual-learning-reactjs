import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface ClientDetails {
    clientCode: string;
    clientName: string;
    clientType: string;
}

export interface ClientDetailsData {
    clientCode: string;
    clientName: string;
    clientType?: string;
}

function useFetchClientDetails() {
    const dispatch = useDispatch();

    const fetchClientDetails = async (
        masterName: MasterName,
        updateExistingData: "0" | "1",
    ): Promise<ClientDetails[]> => {
        dispatch(setOpenBackdrop(true));

        let clientCodes: ClientDetails[] = [];

        const axiosConfig = {
            "url": `/clientcodeslist?masterName=${masterName}&updateFlag=${updateExistingData}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const clientCodesData = responseData;

                clientCodes = clientCodesData.map((clientCodeData: ClientDetailsData) => ({
                    "clientCode": clientCodeData.clientCode,
                    "clientName": clientCodeData.clientName,
                    "clientType": (clientCodeData.clientType ?? ""),
                }) as ClientDetails);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return clientCodes; 
    };

    return fetchClientDetails;
}

export default useFetchClientDetails;
