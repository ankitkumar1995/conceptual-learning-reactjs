import { ImageUpload } from "../../../redux/ImageUpload/initialState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface Code {
    processCode: string;
    stageCode: string;
}

function usePostImageUpload () {
    const dispatch = useDispatch();

    function getCodeInfo ( transactionType: string ): Code {
        switch ( transactionType) {
        case "Investor On-Boarding":
            return {
                "processCode": "IOP",
                "stageCode": "IOPDUP"
            };

        case "Investor On-Boarding with Initial Contribution":
            return {
                "processCode": "IOP",
                "stageCode": "IOPDUP"
            };

        case "Investor On-Boarding with Initial Contribution and SIP":
            return {
                "processCode": "IOP",
                "stageCode": "IOPDUP"
            };

        case "Initial Contribution": 
            return {
                "processCode": "ICP",
                "stageCode": "ICPDUP"
            };

        case "Top Up": 
            return {
                "processCode": "TUP",
                "stageCode": "TUPDUP",
            };

        case "Draw Down":
            return {
                "processCode": "",
                "stageCode": "",
            };

        default :
            return {
                "processCode": "",
                "stageCode": "",
            };
        }
    }

    const postImageUpload = async (
        imageUploadDetails: ImageUpload,
        mimeType: string,
        userId: string,
        clientCode: string,
        sourceUser: string,
    ): Promise<{
        ihNumber: string;
    }> => {
        dispatch(setOpenBackdrop(true));

        let ihNumber = "";

        const codeInfo = getCodeInfo(imageUploadDetails.transactionType);

        const data = {
            "applicationId": null,
            "barcode": null,
            "branchCode": "BR01",
            "clientCode": clientCode,
            "documentFormat": imageUploadDetails.applicationFormFileFormat,
            "documentPath": imageUploadDetails.applicationFormFileS3Key,
            "documentSize": imageUploadDetails.applicationFormFileSize,
            "documentType": "APLCN",
            "mimeType": mimeType,
            "processCode": codeInfo.processCode,
            "role": "M",
            "sourceUser": sourceUser,
            "stageCode": codeInfo.stageCode,
            "transactionCode": imageUploadDetails.transactionTypeId,
            "transactionNo": imageUploadDetails.transactionNumber,
            "transactionType": imageUploadDetails.transactionType,
            "userId": userId
        };

        console.log("data----<<<<", data);

        const axiosConfig = {
            "data": data,
            "url": "/uploaddocument",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then((response) => { 
                ihNumber = response.data.transactionReferenceId;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
        
        dispatch(setOpenBackdrop(false));

        return {
            "ihNumber": ihNumber
        };
    };

    return postImageUpload;
};

export default usePostImageUpload;
