import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usePostRejectIncomeDistribution() {
    const dispatch = useDispatch();

    const postRejectIncomeDistribution = async (
        batchNo: string,
        clientId: string,
        processCode: string,
        stageCode: string,
        userRole: "C" | "A",
        userId: string,
        remarks: string,
        transactionNo: string,
        sourceUser: string,
        clientName: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "batchNo": batchNo,
            "clientId": clientId,
            "clientName": clientName,
            "processCode": processCode,
            "rejectRemarks": remarks,
            "role": userRole,
            "sourceUser": sourceUser,
            "stageCode": stageCode,
            "transactionNo": transactionNo,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": "/reject",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postRejectIncomeDistribution;
}

export default usePostRejectIncomeDistribution;
