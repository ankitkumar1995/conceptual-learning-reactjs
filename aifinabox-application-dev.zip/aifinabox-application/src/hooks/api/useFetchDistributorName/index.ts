import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface DistributorDetails {
    "name": string;
    "rmCode": string;
    "rmName": string;
}

function useFetchDistributorName() {
    const dispatch = useDispatch();

    const fetchDistributorName = async (
        distributorCode: string,
    ): Promise<DistributorDetails> => {
        dispatch(setOpenBackdrop(true));

        let distributorDetails: DistributorDetails = {
            "name": "",
            "rmCode": "",
            "rmName": "",
        };

        const axiosConfig = {
            "url": `distributorname?distributorCode=${distributorCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                console.log("Res",response);
                const responseData = response.data;

                distributorDetails = {
                    "name": responseData.abm_name,
                    "rmCode": responseData.abm_rmcode,
                    "rmName": responseData.abm_rmname,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return distributorDetails; 
    };

    return fetchDistributorName;
}

export default useFetchDistributorName;
