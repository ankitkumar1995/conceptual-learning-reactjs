import { 
    ClientMasterDetails, 
    initialClientMasterDetailsFormState 
} from "../../../redux/AifMaster/ClientMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState 
} from "../../../redux/AifMaster/ClientMaster/Update/initialState";

import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FetchClientMaster {
    clientMasterState: ClientMasterDetails;
    clientMasterUpdateState: UpdateState;
};

function useFetchClientMaster() {
    const dispatch = useDispatch();

    let clientMasterData: ClientMasterDetails = initialClientMasterDetailsFormState;
    let clientMasterDataUpdate: UpdateState = initializeUpdateState;
    let clientMaster: FetchClientMaster;


    const fetchClientMaster = async (
        clientCode: string,
        updateExistingData: "0" | "1",
        userId: string,
    ): Promise<FetchClientMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/clientmaster?clientCode=${clientCode}&updateFlag=${updateExistingData}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const clientMasterMakerEntryFromApi = responseData[0];

                clientMasterData = {
                    "address1": clientMasterMakerEntryFromApi.clientAddress.address1.value,
                    "address2": clientMasterMakerEntryFromApi.clientAddress.address2.value,
                    "address3": clientMasterMakerEntryFromApi.clientAddress.address3.value,
                    "agreementDate": clientMasterMakerEntryFromApi.agreementDate.value,
                    "city": clientMasterMakerEntryFromApi.clientAddress.city.value,
                    "ckycInstitutionCode": clientMasterMakerEntryFromApi.ckycDetails.ckycInstCode.value,
                    "ckycPassword": clientMasterMakerEntryFromApi.ckycDetails.ckycPassword.value,
                    "ckycUserId": clientMasterMakerEntryFromApi.ckycDetails.ckycUserId.value,
                    "ckycUserName": clientMasterMakerEntryFromApi.ckycDetails.ckycUserName.value,
                    "clientCode": clientMasterMakerEntryFromApi.clientCode,
                    "clientType": clientMasterMakerEntryFromApi.clientType.value,
                    "country": clientMasterMakerEntryFromApi.clientAddress.country.value,
                    "domicile": clientMasterMakerEntryFromApi.domicile.value,
                    "kraName": clientMasterMakerEntryFromApi.kraDetails.kraName.value,
                    "kraPassword": clientMasterMakerEntryFromApi.kraDetails.kraPassword.value,
                    "kraPosCode": clientMasterMakerEntryFromApi.kraDetails.kraPOSCode.value,
                    "kraUserId": clientMasterMakerEntryFromApi.kraDetails.kraLoginId.value,
                    "kraUserName": clientMasterMakerEntryFromApi.kraDetails.kraUserName.value, 
                    "landlineNumber": clientMasterMakerEntryFromApi.clientContactDetails.landlineNo.value,
                    "legalEntityIdentificationCode": clientMasterMakerEntryFromApi.legalEntIdCode,
                    "legalEntityIdentificationCodeValidity": clientMasterMakerEntryFromApi.legalEntIdCodeValidity.value,
                    "logoFile": null,
                    "logoFileFormat": clientMasterMakerEntryFromApi.clientLogoPath.format,
                    "logoFileS3Key": clientMasterMakerEntryFromApi.clientLogoPath.path,
                    "logoFileS3SignedURL": "",
                    "logoFileSize": clientMasterMakerEntryFromApi.clientLogoPath.size,
                    "name": clientMasterMakerEntryFromApi.clientName.value,
                    "permanentAccountNumber": clientMasterMakerEntryFromApi.taxDetails.pan.value,
                    "pin": clientMasterMakerEntryFromApi.clientAddress.pin.value,
                    "state": clientMasterMakerEntryFromApi.clientAddress.state.value,
                    "taxIdentificationNumber": clientMasterMakerEntryFromApi.taxDetails.taxIdNo.value,
                };

                clientMasterDataUpdate = {
                    "address1": clientMasterMakerEntryFromApi.clientAddress.address1.update,
                    "address2": clientMasterMakerEntryFromApi.clientAddress.address2.update,
                    "address3": clientMasterMakerEntryFromApi.clientAddress.address3.update,
                    "agreementDate": clientMasterMakerEntryFromApi.agreementDate.update,
                    "city": clientMasterMakerEntryFromApi.clientAddress.city.update,
                    "ckycInstitutionCode": clientMasterMakerEntryFromApi.ckycDetails.ckycInstCode.update,
                    "ckycPassword": clientMasterMakerEntryFromApi.ckycDetails.ckycPassword.update,
                    "ckycUserId": clientMasterMakerEntryFromApi.ckycDetails.ckycUserId.update,
                    "ckycUserName": clientMasterMakerEntryFromApi.ckycDetails.ckycUserName.update,
                    "clientType": clientMasterMakerEntryFromApi.clientType.update,
                    "country": clientMasterMakerEntryFromApi.clientAddress.country.update,
                    "domicile": clientMasterMakerEntryFromApi.domicile.update,
                    "kraName": clientMasterMakerEntryFromApi.kraDetails.kraName.update,
                    "kraPassword": clientMasterMakerEntryFromApi.kraDetails.kraPassword.update,
                    "kraPosCode": clientMasterMakerEntryFromApi.kraDetails.kraPOSCode.update,
                    "kraUserId": clientMasterMakerEntryFromApi.kraDetails.kraLoginId.update,
                    "kraUserName": clientMasterMakerEntryFromApi.kraDetails.kraUserName.update, 
                    "landlineNumber": clientMasterMakerEntryFromApi.clientContactDetails.landlineNo.update,
                    "legalEntityIdentificationCodeValidity": clientMasterMakerEntryFromApi.legalEntIdCodeValidity.update,
                    "name": clientMasterMakerEntryFromApi.clientName.update,
                    "permanentAccountNumber": clientMasterMakerEntryFromApi.taxDetails.pan.update,
                    "pin": clientMasterMakerEntryFromApi.clientAddress.pin.update,
                    "state": clientMasterMakerEntryFromApi.clientAddress.state.update,
                    "taxIdentificationNumber": clientMasterMakerEntryFromApi.taxDetails.taxIdNo.update,
                    "updateFlag": clientMasterMakerEntryFromApi.updateFlag
                };

                clientMaster = {
                    "clientMasterState": clientMasterData,
                    "clientMasterUpdateState": clientMasterDataUpdate,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return clientMaster; 
    };

    return fetchClientMaster;
}

export default useFetchClientMaster;
