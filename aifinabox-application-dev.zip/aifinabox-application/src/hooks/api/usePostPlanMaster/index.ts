import { PlanMasterDetails } from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import {
    UpdateState
} from "../../../pages/AIFMaster/PlanMaster/Maker/MakerPlanMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostPlanMaster() {
    const dispatch = useDispatch();

    const postPlanMaster = async (
        makerPlanCode: string,
        sourceUser: string,
        planMasterState: PlanMasterDetails,
        updateExistingData: "0" | "1",
        userId: string,
        userRole: "C" | "M",
        updateStatus: UpdateState,
        // fundPlanDescriptionUpdate: string, 
        // fundPlanSIPUpdate: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            // "checkerId": userRole === "C" ? "2001" : null,
            "clientCode": planMasterState.clientCode,
            "clientName": planMasterState.companyName,
            "clientType": "trust",
            "currentStage": 2,
            "entryDate": currentData,
            "fundCode": planMasterState.fundCode,
            "fundName": planMasterState.fundName,
            // "makerId": userRole === "M" ? "1001" : null,
            "makerPlanCode": userRole === "M" ? null : makerPlanCode,
            "planCategory":
            {
                "update": updateStatus.fundPlanCategory,
                "value": planMasterState.fundPlanCategory
            },
            "planCode":
            {
                "update": updateStatus.fundPlanCode,
                "value": planMasterState.fundPlanCode
                
            },
            "planDescription":
            {
                "update": updateStatus.fundPlanDescription,
                "value": planMasterState.fundPlanDescription
                
            },
            "recordStatus": 1,
            "revisionNumber": 1,
            "role": userRole,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "status": "I",
            "updateFlag": updateExistingData,
            // "userId": userRole === "C" ? "2001" : "1001"
            "userId": userId
        };
        
        const axiosConfig = {
            "data": data,
            "url": "/planmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postPlanMaster;
}

export default usePostPlanMaster;
