import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface BankAccNumberData {
    bankAccountNumber: {
        value: string;
    };
}

function useFetchBankAccountNumbers() {
    const dispatch = useDispatch();

    const fetchBankAccountNumbers = async (
        clientCode: string,
        ifscOrRtgsCode: string,
        fundCode: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let bankAccountNumbers: MenuItem[] = [];

        const axiosConfig = {
            "url": `/bankaccountnumbers?clientCode=${clientCode}&fundCode=${fundCode}&ifscOrRtgsCode=${ifscOrRtgsCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const bankAccNumbersData = responseData;

                bankAccountNumbers = bankAccNumbersData.map((bankAcc: BankAccNumberData) => ({
                    "label": bankAcc.bankAccountNumber.value,
                    "value": bankAcc.bankAccountNumber.value,
                }) as MenuItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankAccountNumbers; 
    };

    return fetchBankAccountNumbers;
}

export default useFetchBankAccountNumbers;
