import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface SchemeResponse {
    fundCurrency: string;
    fundInitialContributionPercentage: string;
    fundNature: string;
    fundEndDate: string | null;
    fundISINNumber: string;
    gst: string;
    fundBusinessType: string;
}

function useFetchSchemeIsinNumber() {
    const dispatch = useDispatch();

    const fetchSchemeIsinNumber = async (
        clientCode: string,
        fundCode: string,
    ): Promise<SchemeResponse> => {
        dispatch(setOpenBackdrop(true));

        let schemeResponse: SchemeResponse = {
            "fundBusinessType": "",
            "fundCurrency": "",
            "fundEndDate": "",
            "fundISINNumber": "",
            "fundInitialContributionPercentage": "",
            "fundNature": "",
            "gst": "",
        };

        const axiosConfig = {
            "url": `/funddetails?clientCode=${clientCode}&fundCode=${fundCode}`
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data[0];
                
                schemeResponse = {
                    "fundBusinessType": responseData.fundBusinessType,
                    "fundCurrency": responseData.fundCurrency,
                    "fundEndDate": responseData.fundEndDate,
                    "fundISINNumber": responseData.fundISINNumber,
                    "fundInitialContributionPercentage": responseData.fundInitialContributionPercentage,
                    "fundNature": responseData.fundNature,
                    "gst": responseData.gst
                };

            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return schemeResponse; 
    };

    return fetchSchemeIsinNumber;
}

export default useFetchSchemeIsinNumber;
