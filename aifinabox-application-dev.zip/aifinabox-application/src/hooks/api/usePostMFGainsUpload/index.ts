import { ImageUpload } from "../../../redux/ImageUpload/initialState";
import {
    MFGainsFileUpload
} from "../../../redux/InitiateTransaction/MFGains/Maker/UploadFile/initialState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface Code {
    processCode: string;
    stageCode: string;
}

function usePostMFGainsUpload () {
    const dispatch = useDispatch();

    function getCodeInfo ( transactionType: string ): Code {
        switch ( transactionType) {
        case "MFG":
            return {
                "processCode": "MFG",
                "stageCode": "MFPIEN"
            };

        case "MFP":
            return {
                "processCode": "MFP",
                "stageCode": "MFPIEN"
            };
       
        default :
            return {
                "processCode": "",
                "stageCode": "",
            };
        }
    }
 
    const postMFGainsUpload = async (
        // fileUploadDetails: MFGainsFileUpload,
        s3Key: string,
        userId: string,
        clientId: string,
        sourceUser: string,
        batchNumber: string,
        transactionType: string,
    ): Promise<
        any
    > => {
        dispatch(setOpenBackdrop(true));

        let responseData;

        const data = {
            "batchNo": batchNumber,
            "clientId": clientId,
            "file": s3Key,
            "role": "M",            
            "sourceUser": sourceUser,
            "transactionType": transactionType,
            "userId": userId,
        };

        console.log("data----<<<<", data);

        const axiosConfig = {
            "data": data,
            "url": "/validatemfupload",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then((response) => { 
                responseData = response.data;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
        
        dispatch(setOpenBackdrop(false));

        return responseData;
    };

    return postMFGainsUpload;
};

export default usePostMFGainsUpload;
