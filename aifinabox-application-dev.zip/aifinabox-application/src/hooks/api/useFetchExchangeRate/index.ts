import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchExchangeRate() {
    const dispatch = useDispatch();

    const fetchExchangeRate = async (
        transactionCurrency: string,
        baseCurrency: string,
    ): Promise<number> => {
        dispatch(setOpenBackdrop(true));

        let exchngRate: number = 0;

        const axiosConfig = {
            "url": `/exchangerate?transactionCurrency=${transactionCurrency}&baseCurrency=${baseCurrency}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const resData= response?.data;
                exchngRate = resData?.exchangeRate;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return exchngRate;
    };

    return fetchExchangeRate;
}

export default useFetchExchangeRate;
