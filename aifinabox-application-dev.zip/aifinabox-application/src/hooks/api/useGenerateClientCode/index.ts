import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useGenerateClientCode() {
    const dispatch = useDispatch();

    const generateClientCode = async (): Promise<string> => {
        dispatch(setOpenBackdrop(true));

        let clientCode = "";

        const axiosConfig = {
            "url": "/generateclientcode",
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                clientCode = response.data;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return clientCode;
    };
    
    return generateClientCode;
}

export default useGenerateClientCode;
