import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface PendingCheckerItem {
    classCode: string;
    className: string;
    clientCode: string;
    clientName: string;
    createdBy: string;
    createdOn: string;
    fundClassCategory?: string;
    fundCode: string;
    fundName: string;
    eventId: string;
    id: string;
    planCode: string;
    planDescription: string;
    planName: string;
    bankAccountNumber?:string;
    bankName?: string;
    ifscOrRtgsCode: string;
    rejectRemarks: string;
}

interface ApiResultDataItem {
    _id: string;
    classCode?: string;
    className?: string;
    clientCode: string;
    clientName: string;
    entryDate: string;
    fundClassCategory?: string;
    fundCode?: string;
    fundName?: string;
    eventId?: string;
    planCode?: string;
    planDescription?: string;
    planName?: string;
    sourceUser: string;
    bankAccountNumber?:string;
    bankName?: string;
    ifscOrRtgsCode: string;
}

function useFetchTodoQueue() {
    const dispatch = useDispatch();

    const fetchTodoQueue = async (
        queueLength: number,
        pageIndex: number,
        masterName: MasterName,
        role: "C" | "A",
        userId: string,
    ): Promise<{
        checkerQueue: PendingCheckerItem[];
        pendingCheckerItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let checkerQueue: PendingCheckerItem[] = [];
        let pendingCheckerItemCount = 0;
        // let userId = "";
        // if (role === "A")
        //     userId = "3001";
        // if (role === "C")
        //     userId = "2001";

        const axiosConfig = {
            "url": `/todoqueue?queueLength=${queueLength}&masterName=${masterName}&pageIndex=${pageIndex}&role=${role}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const pendingCheckerItems = responseData.result;
                
                pendingCheckerItemCount = responseData.count;
                checkerQueue = pendingCheckerItems.map((pendingCheckerItem: ApiResultDataItem) => {
                    const {
                        _id,
                        bankAccountNumber,
                        bankName,
                        classCode,
                        className,
                        clientCode,
                        clientName,
                        entryDate,
                        fundClassCategory,
                        fundCode,
                        fundName,
                        eventId,
                        ifscOrRtgsCode,
                        planCode,
                        planDescription,
                        planName,
                        sourceUser,
                    } = pendingCheckerItem;
                    
                    return ({
                        "bankAccountNumber": (bankAccountNumber ?? ""),
                        "bankName": (bankName ?? ""),
                        "classCode": (classCode ?? ""),
                        "className": (className ?? ""),
                        "clientCode": clientCode,
                        "clientName": clientName,
                        "createdBy": sourceUser,
                        "createdOn": entryDate,
                        "eventId": (eventId ?? ""),
                        "fundClassCategory": (fundClassCategory ?? ""),
                        "fundCode": (fundCode ?? ""),
                        "fundName": (fundName ?? ""),
                        "id": _id,
                        "ifscOrRtgsCode": (ifscOrRtgsCode ?? ""),
                        "planCode": (planCode ?? ""),
                        "planDescription": (planDescription ?? ""),
                        "planName": (planName ?? ""),
                        "rejectRemarks": ""
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "checkerQueue": checkerQueue,
            "pendingCheckerItemCount": pendingCheckerItemCount,
        };
    };
    
    return fetchTodoQueue;
}

export default useFetchTodoQueue;
