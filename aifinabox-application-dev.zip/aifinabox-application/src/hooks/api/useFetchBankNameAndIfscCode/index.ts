import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface BankNameAndIfscCodeData {
    bankName: {
        value: string;
    };
    ifscOrRtgsCode: {
        value: string;
    };
}

export interface BankData {
    bankNames: string[];
    ifscCodes: MenuItem[];
}

function useFetchBankNameAndIfscCode() {
    const dispatch = useDispatch();

    const fetchBankNameAndIfscCode = async (
        clientCode: string,
        fundCode: string,
    ): Promise<BankData[]> => {
        dispatch(setOpenBackdrop(true));

        let bankDetails: BankData[] = [];
        let ifsc:MenuItem[] = [];
        let bank: string[] =[];
        const axiosConfig = {
            "url": `/banknames?clientCode=${clientCode}&fundCode=${fundCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const bankAndIfscData : BankNameAndIfscCodeData[] = responseData;

                bankAndIfscData.forEach((bankAccDetails: BankNameAndIfscCodeData) => {
                    ifsc.push({
                        "label": bankAccDetails.ifscOrRtgsCode.value,
                        "value": bankAccDetails.ifscOrRtgsCode.value,
                    });
                    
                    bank.push(bankAccDetails.bankName.value);
                });

                bankDetails.push({
                    "bankNames": bank,
                    "ifscCodes": ifsc, 
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankDetails;
    };

    return fetchBankNameAndIfscCode;
}

export default useFetchBankNameAndIfscCode;
