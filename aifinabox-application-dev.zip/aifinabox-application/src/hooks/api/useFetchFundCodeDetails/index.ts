import { MasterName } from "../interfaces/MasterName.types";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FundDetails {
    fundCategory: MenuItem;
    fundCode: MenuItem;
    fundName: MenuItem;
}

function useFetchFundDetails() {
    const dispatch = useDispatch();

    const fetchFundDetails = async (
        clientCode: string,
        role: "C" | "M",
        ddFlag?: boolean
    ): Promise<FundDetails[]> => {
        dispatch(setOpenBackdrop(true));

        let fundDetails: FundDetails[] = [];

        const axiosConfig = {
            "url": `/fundcodedetails?clientCode=${clientCode}&role=${role}&ddFlag=${ddFlag}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const _fundDetails = responseData;

                fundDetails = _fundDetails.map((fund: any) => ({
                    "fundCategory": {
                        "label": fund.fundCategory,
                        "value": fund.fundCategory,
                    },
                    "fundCode": {
                        "label": fund.fundCode,
                        "value": fund.fundCode,
                    },
                    "fundName": {
                        "label": fund.fundName,
                        "value": fund.fundName,
                    },
                }) as FundDetails);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return  fundDetails; 
    };

    return fetchFundDetails;
}

export default useFetchFundDetails;
