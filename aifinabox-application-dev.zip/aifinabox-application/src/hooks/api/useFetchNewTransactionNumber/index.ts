import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface TransactionNumber {
    newTransactionNumber: string;
}

function useFetchNewTransactionNumber() {
    const dispatch = useDispatch();

    const fetchNewTransactionNumber = async (
        seriesCode: string,
    ): Promise<TransactionNumber> => {
        dispatch(setOpenBackdrop(true));

        let newTransactionNumber: TransactionNumber = {
            "newTransactionNumber": "",
        };

        const axiosConfig = {
            "url": `/sequencenumber?seriesCode=${seriesCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;

                newTransactionNumber = {
                    "newTransactionNumber": responseData,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return newTransactionNumber;
    };

    return fetchNewTransactionNumber;
}

export default useFetchNewTransactionNumber;
