import { MenuItem } from "../../../interfaces/MenuItem.types";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchFolioListsInitialContribution() {
    const dispatch = useDispatch();

    const fetchFolioLists = async (
        clientCode: string,
        pan: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let folioLists: MenuItem[] = [];

        const axiosConfig = {
            "url": `/folioslist?pan=${pan}&clientId=${clientCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const folioListsData = responseData;

                folioLists = folioListsData.map((folio: string) => ({
                    "label": `${folio}`,
                    "value": folio,
                }) as MenuItem);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return folioLists;
    };

    return fetchFolioLists;
}

export default useFetchFolioListsInitialContribution;
