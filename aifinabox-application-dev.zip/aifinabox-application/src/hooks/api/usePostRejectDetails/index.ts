import { MasterName } from "../interfaces/MasterName.types";
import { PlanMasterDetails } from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import {
    UpdateState
} from "../../../pages/AIFMaster/PlanMaster/Maker/MakerPlanMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";


dayjs.extend(utc);
dayjs.extend(timezone);

interface IPayload{
    "bankAccountNumber": string;
    "bankName": string;
    "classCode": string;
    "clientCode": string;
    "entryDate": string;
    "eventId": string;
    "fundCode": string;
    "masterName": MasterName;
    "planCode": "A1";
    "role": string;
}

function usePostRejectDetails() {
    const dispatch = useDispatch();

    const rejectPostDetails = async (
        bankAccountNumber: string,
        bankName: string,
        classCode: string,
        clientCode: string,
        fundCode: string,
        masterName: MasterName,
        planCode: string,
        role: "C" | "M" | "A",
        rejectRemarkText: string,
        userId: string,
        sourceUser: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "bankAccountNumber": bankAccountNumber ? bankAccountNumber : "",
            "bankName": bankName ? bankName  : "",
            "classCode": classCode ? classCode : "",
            "clientCode": clientCode ?  clientCode  : "",
            "entryDate": currentData,
            "eventId": "",
            "fundCode": fundCode ? fundCode : "",
            "masterName": masterName,
            "planCode": planCode ? planCode :  "",
            "rejectRemarks": rejectRemarkText,
            "role": role,
            "sourceUser": sourceUser,
            "userId": userId
        };
        
        const axiosConfig = {
            "data": data,
            "url": "/reject",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return rejectPostDetails;
}

export default usePostRejectDetails;
