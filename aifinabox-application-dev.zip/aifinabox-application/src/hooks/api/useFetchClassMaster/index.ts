import { 
    ClassMasterDetails, 
    initialClassMasterDetailsFormState 
} from "../../../redux/AifMaster/ClassMaster/Maker/initialState";
import initializeUpdateState, { 
    UpdateState 
} from "../../../redux/AifMaster/ClassMaster/Update/initialState";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FetchClassMaster {
    classMasterState: ClassMasterDetails;
    classMasterUpdateState: UpdateState;
};

function useFetchClassMaster() {
    const dispatch = useDispatch();

    let classMasterData: ClassMasterDetails = initialClassMasterDetailsFormState;
    let classMasterDataUpdate: UpdateState = initializeUpdateState;
    let classMaster: FetchClassMaster;

    const fetchClassMaster = async (
        classCode: string,
        clientCode: string,
        fundCode: string,
        planCode: string,
        role: "M" | "C" | "A",
        userId: string,
    ): Promise<FetchClassMaster> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/classMaster?clientCode=${clientCode}&fundCode=${fundCode}&classCode=${classCode}&planCode=${planCode}&role=${role}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const classMasterMakerEntryFromApi = responseData[0];

                classMasterData = {
                    "additionalFee": classMasterMakerEntryFromApi.fundClassAdditionalFee.value,
                    "carryPercentage": classMasterMakerEntryFromApi.fundClassCarryPercentage.value,
                    "catchupPercentage": classMasterMakerEntryFromApi.fundClassCatchupPercentage.value,
                    "classCode": classMasterMakerEntryFromApi.classCode.value,
                    "clientCode": classMasterMakerEntryFromApi.clientCode,
                    "companyName": classMasterMakerEntryFromApi.clientName,
                    "currency": classMasterMakerEntryFromApi.fundClassCurrency.value,
                    "description": classMasterMakerEntryFromApi.fundClassDescription.value,
                    "faceValue": classMasterMakerEntryFromApi.fundClassFaceValue.value,
                    "fundClassCategory": classMasterMakerEntryFromApi.fundClassCategory.value,
                    "fundCode": classMasterMakerEntryFromApi.fundCode,
                    "fundName": classMasterMakerEntryFromApi.fundName,
                    "fundPlanCode": classMasterMakerEntryFromApi.planCode,
                    "fundPlanName": classMasterMakerEntryFromApi.planName,
                    "fundSponsorClass": classMasterMakerEntryFromApi.fundSponsorClass.value,
                    "gstRate": classMasterMakerEntryFromApi.fundClassGstRate.value,
                    "highWaterMark": classMasterMakerEntryFromApi.highWaterMark.value,
                    "hurdleRate": classMasterMakerEntryFromApi.fundClassHurdleRate.value,
                    "incomeDistFrequency": classMasterMakerEntryFromApi.incomeDistFrequency.value,
                    "isActive": classMasterMakerEntryFromApi.isActive.value,
                    "isinCode": classMasterMakerEntryFromApi.isinCode.value,
                    "managementFee": classMasterMakerEntryFromApi.fundClassManagementFee.value,
                    "maxAmount": classMasterMakerEntryFromApi.fundClassMaxAmount.value,
                    "maxReturn": classMasterMakerEntryFromApi.fundClassMaxReturn.value,
                    "minAmount": classMasterMakerEntryFromApi.fundClassMinAmount.value,
                    "orgFee": classMasterMakerEntryFromApi.fundClassOrgFee.value,
                    "perFeePercentage": classMasterMakerEntryFromApi.fundClassPerFeePercentage.value,
                    "performanceFee": classMasterMakerEntryFromApi.fundClassPerformanceFee.value,
                    "preferredReturn": classMasterMakerEntryFromApi.fundClassPreferredReturn.value,
                    "setUpFee": classMasterMakerEntryFromApi.setupFee.value,
                    "shareRatio": classMasterMakerEntryFromApi.fundClassShareRatio.value,
                };

                classMasterDataUpdate = {
                    "additionalFee": classMasterMakerEntryFromApi.fundClassAdditionalFee.update,
                    "carryPercentage": classMasterMakerEntryFromApi.fundClassCarryPercentage.update,
                    "catchupPercentage": classMasterMakerEntryFromApi.fundClassCatchupPercentage.update,
                    "classCode": classMasterMakerEntryFromApi.classCode.update,
                    "currency": classMasterMakerEntryFromApi.fundClassCurrency.update,
                    "description": classMasterMakerEntryFromApi.fundClassDescription.update,
                    "faceValue": classMasterMakerEntryFromApi.fundClassFaceValue.update,
                    "fundClassCategory": classMasterMakerEntryFromApi.fundClassCategory.update,
                    "fundSponsorClass": classMasterMakerEntryFromApi.fundSponsorClass.update,
                    "gstRate": classMasterMakerEntryFromApi.fundClassGstRate.update,
                    "highWaterMark": classMasterMakerEntryFromApi.highWaterMark.update,
                    "hurdleRate": classMasterMakerEntryFromApi.fundClassHurdleRate.update,
                    "incomeDistFrequency": classMasterMakerEntryFromApi.incomeDistFrequency.update,
                    "isActive": classMasterMakerEntryFromApi.isActive.update,
                    "isinCode": classMasterMakerEntryFromApi.isinCode.update,
                    "managementFee": classMasterMakerEntryFromApi.fundClassManagementFee.update,
                    "maxAmount": classMasterMakerEntryFromApi.fundClassMaxAmount.update,
                    "maxReturn": classMasterMakerEntryFromApi.fundClassMaxReturn.update,
                    "minAmount": classMasterMakerEntryFromApi.fundClassMinAmount.update,
                    "orgFee": classMasterMakerEntryFromApi.fundClassOrgFee.update,
                    "perFeePercentage": classMasterMakerEntryFromApi.fundClassPerFeePercentage.update,
                    "performanceFee": classMasterMakerEntryFromApi.fundClassPerformanceFee.update,
                    "preferredReturn": classMasterMakerEntryFromApi.fundClassPreferredReturn.update,
                    "setUpFee": classMasterMakerEntryFromApi.setupFee.update,
                    "shareRatio": classMasterMakerEntryFromApi.fundClassShareRatio.update,
                    "updateFlag": classMasterMakerEntryFromApi.updateFlag,
                };

                classMaster = {
                    "classMasterState": classMasterData,
                    "classMasterUpdateState": classMasterDataUpdate,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classMaster; 
    };

    return fetchClassMaster;
}

export default useFetchClassMaster;
