import { ClassMasterDetails } from "../../../redux/AifMaster/ClassMaster/Maker/initialState";
import { 
    UpdateState 
} from "../../../pages/AIFMaster/ClassMaster/Maker/MakerClassMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostClassMaster() {
    const dispatch = useDispatch();

    const postClassMaster = async (
        classMasterState: ClassMasterDetails,
        sourceUser: string,
        updateExistingData: "0" | "1",
        userId: string,
        userRole: "A" | "C" | "M",
        updateStatus: UpdateState,
        makerClassCode: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = 
        {
            "classCode": {
                "update": updateStatus.classCode,
                "value": classMasterState.classCode
            },
            "clientCode": classMasterState.clientCode,
            "clientName": classMasterState.companyName,
            "entryDate": currentData,            
            "fundClassAdditionalFee": {
                "update": updateStatus.additionalFee,
                "value": classMasterState.additionalFee
            },
            "fundClassCarryPercentage": {
                "update": updateStatus.carryPercentage,
                "value": classMasterState.carryPercentage
            },
            "fundClassCatchupPercentage": {
                "update": updateStatus.catchupPercentage,
                "value": classMasterState.catchupPercentage
            },
            "fundClassCategory": {
                "update": updateStatus.fundClassCategory,
                "value": classMasterState.fundClassCategory
            },
            "fundClassCurrency": {
                "update": updateStatus.currency,
                "value": classMasterState.currency
            },
            "fundClassDescription": {
                "update": updateStatus.description,
                "value": classMasterState.description
            },
            "fundClassFaceValue": {
                "update": updateStatus.faceValue,
                "value": classMasterState.faceValue
            },
            "fundClassGstRate": {
                "update": updateStatus.gstRate,
                "value": classMasterState.gstRate
            },
            "fundClassHurdleRate": {
                "update": updateStatus.hurdleRate,
                "value": classMasterState.hurdleRate
            },
            "fundClassManagementFee": {
                "update": updateStatus.managementFee,
                "value": classMasterState.managementFee
            },
            "fundClassMaxAmount": {
                "update": updateStatus.maxAmount,
                "value": classMasterState.maxAmount
            },
            "fundClassMaxReturn": {
                "update": updateStatus.maxReturn,
                "value": classMasterState.maxReturn
            },
            "fundClassMinAmount": {
                "update": updateStatus.minAmount,
                "value": classMasterState.minAmount
            },
            "fundClassOrgFee": {
                "update": updateStatus.orgFee,
                "value": classMasterState.orgFee
            },
            "fundClassPerFeePercentage": {
                "update": updateStatus.perFeePercentage,
                "value": classMasterState.perFeePercentage
            },
            "fundClassPerformanceFee": {
                "update": updateStatus.performanceFee,
                "value": classMasterState.performanceFee
            },
            "fundClassPreferredReturn": {
                "update": updateStatus.preferredReturn,
                "value": classMasterState.preferredReturn
            },
            "fundClassShareRatio": {
                "update": updateStatus.shareRatio,
                "value": classMasterState.shareRatio
            },
            "fundCode": classMasterState.fundCode,
            "fundName": classMasterState.fundName,
            "fundSponsorClass": {
                "update": updateStatus.fundSponsorClass,
                "value": classMasterState.fundSponsorClass
            },
            "highWaterMark": {
                "update": updateStatus.highWaterMark,
                "value": classMasterState.highWaterMark
            },
            "incomeDistFrequency": {
                "update": updateStatus.incomeDistFrequency,
                "value": classMasterState.incomeDistFrequency
            },
            "isActive": {
                "update": updateStatus.isActive,
                "value": classMasterState.isActive
            },
            "isinCode": {
                "update": updateStatus.isinCode,
                "value": classMasterState.isinCode
            },
            "makerClassCode": makerClassCode === "" ? null : makerClassCode,
            "planCode": classMasterState.fundPlanCode,
            "planName": classMasterState.fundPlanName,
            "role": userRole,
            "setupFee": {
                "update": updateStatus.setUpFee,
                "value": classMasterState.setUpFee
            },
            // "sourceUser": "Local",            
            "sourceUser": sourceUser,            
            "updateFlag": updateExistingData,
            // "userId": userRole === "M" ? "1001" : userRole === "C" ? "2001" : userRole === "A" ? "3001" : null,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": "/classMaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postClassMaster;
}

export default usePostClassMaster;
