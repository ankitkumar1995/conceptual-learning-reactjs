import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useGenerateEventId() {
    const dispatch = useDispatch();

    const generateEventId = async (): Promise<string> => {
        dispatch(setOpenBackdrop(true));

        let eventId = "";

        const axiosConfig = {
            "url": "/generateeventid",
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                eventId = response.data;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return eventId;
    };
    
    return generateEventId;
}
    
export default useGenerateEventId;
