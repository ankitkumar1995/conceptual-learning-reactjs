import { 
    MakerInitialContributionDetails, 
    makerInitialContributionDetailsFormState 
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";
import { useDispatch, useSelector } from "react-redux";

import { PaymentBankDetails } from "../useGetInvestor/interfaces/GetInvestor.types";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

export interface UserIdsType {
    auditorId: string | null;
    makerId: string | null;
    checkerId: string | null;
    qualityCheckerId: string | null;
}

interface GetInitialContributionResponseType {
    initialContributionDetails: MakerInitialContributionDetails;
    userIds: UserIdsType;
}

export interface InitialContributionInfo {
    "initialContributionDetails": MakerInitialContributionDetails;
    "userIds": UserIdsType;
}

const isFieldValueNull = (field: string | null) => {
    if (field === null || field === undefined || field?.trim() === "")
        return "";
    else
        return field;
};

export interface ApiResponse {
    _id: string;
    activityStatus: string;
    applicationId: string;
    barcode: string;
    branchId: string;
    clientId: string;
    createdBy: string;
    createdFrom: string;
    createdOn: string;
    currentStage: string;
    documentFormat: string;
    documentPath: string;
    documentSize: number;
    documentType: string;
    lastUpdatedBy: string;
    lastUpdatedFrom: string;
    lastUpdatedOn: string;
    mimeType: string;
    processCode: string;
    sourceUser: string;
    transactionCode: string;
    transactionNo: string;
    transactionType: string;
    workDate: string;
}

export function getInitialContributionInfo(
    initialContributionDetailsFromApi: any, 
): InitialContributionInfo {

    let userIds: UserIdsType;
    let initialContributionData: MakerInitialContributionDetails = makerInitialContributionDetailsFormState;

    const isPaymentDetailsArrayEmpty = (holder: PaymentBankDetails) => {
        if (
            // holder?.foreignBankAccount &&
            holder?.isForeignBankAcct &&
            holder?.nationalBankAccount 
            // &&
            // holder?.paymentBankIsRegBank
        ) {
            return true;
        }
        else {
            return false;
        }
    };

    const paymentDetailsArray = (holder: PaymentBankDetails) => {
        return (
            {
                "accountType": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.paymentForeignBankAccType :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccType :
                        "",
                "isForeignBankAccount": holder?.isForeignBankAcct ?? "",
                "lastFourDigitsOfAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.lastFourDigitsOfRegForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.lastFourDigOfRegBankAccountNo :
                        "",
                "micrCode": holder?.nationalBankAccount[0]?.paymentBankMicr ?? "",
                "paymentBankAccountName": holder?.nationalBankAccount[0]?.paymentBankAccName ?? "",
                "paymentBankAccountNumber": holder?.isForeignBankAcct === "Yes" ?
                    holder?.foreignBankAccount[0]?.regPaymentForeignBankAccNo :
                    holder?.isForeignBankAcct === "No" ?
                        holder?.nationalBankAccount[0]?.paymentBankAccNo :
                        "",
                "paymentBankAddress": holder?.foreignBankAccount[0]?.paymentBankAddr ?? "",
                "paymentBankBranch": holder?.foreignBankAccount[0]?.paymentBankBranch ?? "",
                "paymentBankIbanCode": holder?.foreignBankAccount[0]?.paymentBankIbanCode ?? "",
                "paymentBankIfscCode": holder?.nationalBankAccount[0]?.paymentBankIfsc ?? "",
                "paymentBankName": holder?.foreignBankAccount[0]?.paymentBankName ?? "",
                "paymentBankUtrNumber": holder?.nationalBankAccount[0]?.paymentBankUtrNo ?? "",
                "paymentChequeDetails": holder?.nationalBankAccount[0]?.paymentBankChqRefNo ?
                    holder?.nationalBankAccount[0]?.paymentBankChqRefNo?.map((cheque) => {
                        return {
                            "chequeAmount": cheque.chequeAmount ?? "",
                            "chequeReferenceNumber": cheque.chequeRefNo ?? "",
                        };
                    }) : [],
                "paymentType": holder?.nationalBankAccount[0]?.paymentType ?? "",
                "pennyDropStatus": "",
                "pennyDropValidationDate": null,
                "sameAsRegisteredBank": holder?.paymentBankIsRegBank ?? "",
                "swiftOrBicCode": holder?.foreignBankAccount[0]?.paymentBankSwiftAndBic ?? "",
            }
        );
    };

    const paymentBankDetails = [];

    if (isPaymentDetailsArrayEmpty(initialContributionDetailsFromApi?.paymentBankDetails?.primaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(initialContributionDetailsFromApi?.paymentBankDetails?.primaryHolderPaymentBank));

    if (isPaymentDetailsArrayEmpty(initialContributionDetailsFromApi?.paymentBankDetails?.secondaryHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(initialContributionDetailsFromApi?.paymentBankDetails?.secondaryHolderPaymentBank));
    
    if (isPaymentDetailsArrayEmpty(initialContributionDetailsFromApi?.paymentBankDetails?.thirdHolderPaymentBank))
        paymentBankDetails.push(paymentDetailsArray(initialContributionDetailsFromApi?.paymentBankDetails?.thirdHolderPaymentBank));

    initialContributionData = {
        "accreditationFlag": initialContributionDetailsFromApi?.accreditationFlag ?? null,
        "aifCompanyApprovalFile": null,
        "aifCompanyApprovalFileFormat": "",
        "aifCompanyApprovalFileS3Key": "",
        "aifCompanyApprovalFileS3SignedURL": "",
        "aifCompanyApprovalFileSize": "",
        "allotmentMode": isFieldValueNull(initialContributionDetailsFromApi?.allotmentMode?.modeOfAllotment) ?? null,
        "amcRmCode": isFieldValueNull(initialContributionDetailsFromApi?.distributorDetails?.amcRmCode) ?? null,
        "amcRmName": isFieldValueNull(initialContributionDetailsFromApi?.distributorDetails?.amcRmName) ?? null,
        "anyApprovalMailFromAmc": isFieldValueNull(initialContributionDetailsFromApi?.documentsProvided?.amcApprovalMail),
        "bankProofOrChequeCopy": isFieldValueNull(initialContributionDetailsFromApi?.documentsProvided?.bankProofOrCheqCopy),
        "className": isFieldValueNull(initialContributionDetailsFromApi?.investmentDetails?.class) ?? null,
        "clientId": isFieldValueNull(initialContributionDetailsFromApi?.allotmentMode?.clientId) ?? null,
        "clientMasterListForDematAllocation": isFieldValueNull(initialContributionDetailsFromApi?.documentsProvided?.dematAllocClientMasterList),
        "clientName": isFieldValueNull(initialContributionDetailsFromApi?.clientName) ?? null,
        "commitmentAmount": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.commitmentAmount) ?? null,
        "contributionAmount": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.initContribAmt) ?? null,
        "distributorCode": isFieldValueNull(initialContributionDetailsFromApi?.distributorDetails?.distributorCode) ?? null,
        "distributorName": isFieldValueNull(initialContributionDetailsFromApi?.distributorDetails?.distributorName) ?? null,
        "dpId": isFieldValueNull(initialContributionDetailsFromApi?.allotmentMode?.dPId) ?? null,
        "exchangeRate": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.exchngRate) ?? null,
        "folioNumber": isFieldValueNull(initialContributionDetailsFromApi?.folioNo) ?? null,
        "frozenFolioFlag": initialContributionDetailsFromApi?.frozenFolioFlag ?? null,
        "fundCurrency": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.fundCurrency) ?? null,
        "fundCurrencyAmount": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.fundCurrencyAmount) ?? null,
        "gstOrServiceTax": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.gst) ?? null,
        "gstOrServiceTaxWaiver": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.gstWaiver) ?? null,
        "gstWaiverApprovalEmailFile": null,
        "gstWaiverApprovalEmailFileFormat": isFieldValueNull(initialContributionDetailsFromApi?.gstWaiverApprovalEmailFileFormat) ?? null,
        "gstWaiverApprovalEmailFileS3Key": isFieldValueNull(initialContributionDetailsFromApi?.gstWaiverApprovalEmailFileS3Key) ?? null,
        "gstWaiverApprovalEmailFileS3SignedURL": isFieldValueNull(initialContributionDetailsFromApi?.gstWaiverApprovalEmailFileS3SignedURL) ?? null,
        'gstWaiverApprovalEmailFileSize': isFieldValueNull(initialContributionDetailsFromApi?.gstWaiverApprovalEmailFileSize) ?? null,
        "guardianTaxId": isFieldValueNull(initialContributionDetailsFromApi?.guardianTaxId) ?? null,
        "ihNumber": isFieldValueNull(initialContributionDetailsFromApi?.transactionNo) ?? null,
        "initialContributionAnnexure": isFieldValueNull(initialContributionDetailsFromApi?.documentsProvided?.initContribAnnexure),
        "invType": isFieldValueNull(initialContributionDetailsFromApi?.invType) ?? null,
        "investorCategory": isFieldValueNull(initialContributionDetailsFromApi?.invCategory) ?? null,
        "investorName": isFieldValueNull(initialContributionDetailsFromApi?.invName) ?? null,
        "modeOfHolding": isFieldValueNull(initialContributionDetailsFromApi?.modeOfHolding) ?? null,
        "otherFee": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.otherFee) ?? null,
        "panOrTaxId": isFieldValueNull(initialContributionDetailsFromApi?.taxId) ?? null,
        "parentTransactionNo": isFieldValueNull(initialContributionDetailsFromApi?.parentTransactionNo) ?? null,
        "paymentBankDetails": paymentBankDetails,
        "paymentType": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.paymentType) ?? null,
        "poaDistributorOrDirect": isFieldValueNull(initialContributionDetailsFromApi?.distributorDetails?.adviceType) ,
        "poaName": isFieldValueNull(initialContributionDetailsFromApi?.poa?.nameOfPoa) ?? null,
        "poaPanOrTaxId": isFieldValueNull(initialContributionDetailsFromApi?.poa?.poaTaxIdNo) ?? null,
        "poaType": isFieldValueNull(initialContributionDetailsFromApi?.poa?.poaType) ?? null,
        "primaryHolderContribution": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.primaryHolderContrib) ?? null,
        "primaryHolderPercentage": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.primaryHolderPercent) ?? null,
        "productType": isFieldValueNull(initialContributionDetailsFromApi?.investmentDetails?.productType) ?? null,
        "repositoryType": isFieldValueNull(initialContributionDetailsFromApi?.allotmentMode?.repositoryType) ?? null,
        "scheme": isFieldValueNull(initialContributionDetailsFromApi?.investmentDetails?.schemeName) ?? null,
        "schemeCode": isFieldValueNull(initialContributionDetailsFromApi?.investmentDetails?.schemeCode) ?? null,
        "schemeIsinNumber": isFieldValueNull(initialContributionDetailsFromApi?.investmentDetails?.schemeIsinNo) ?? null,
        "secHolderRelatshpWithPrimaryHolder": isFieldValueNull(initialContributionDetailsFromApi?.secHolderRelatshpWithPrimaryHolder) ?? null,
        "secondHolderContribution": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.secondHolderContrib) ?? null,
        "secondHolderPercentage": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.secondHolderPercent) ?? null,
        "setupFeeAmount": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.setupFeeAmt) ?? null,
        "setupFeePercentage": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.setupFeePercent) ?? null,
        "taxId": isFieldValueNull(initialContributionDetailsFromApi?.taxId) ?? null,
        "thirdHolderContribution": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.thirdHolderContrib) ?? null,
        "thirdHolderPercentage": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.thirdHolderPercent) ?? null,
        "thirdHolderRelatshpWithPrimaryHolder": isFieldValueNull(initialContributionDetailsFromApi?.thirdHolderRelatshpWithPrimaryHolder) ?? null,
        "totalSetupFee": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.totalSetupFee) ?? null,
        "transactionCode": isFieldValueNull(initialContributionDetailsFromApi?.transactionCode) ?? null,
        "transactionCurrency": isFieldValueNull(initialContributionDetailsFromApi?.contributionDetails?.transactionCurrency) ?? null,
        "transactionType": isFieldValueNull(initialContributionDetailsFromApi?.transactionType) ?? null,
        "updateFlag": isFieldValueNull(initialContributionDetailsFromApi?.updateFlag),
    };

    userIds = {
        "auditorId": initialContributionDetailsFromApi?.auditorId ?? null,
        "checkerId": initialContributionDetailsFromApi?.checkerId ?? null,
        "makerId": initialContributionDetailsFromApi?.makerId ?? null,
        "qualityCheckerId": initialContributionDetailsFromApi?.qualityCheckerId ?? null,
    };

    return {
        "initialContributionDetails": initialContributionData,
        "userIds": userIds
    };

}

function useGetInitialContribution() {
    const dispatch = useDispatch();

    let initialContributionInfo: InitialContributionInfo ;

    const fetchInitialContributionDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<GetInitialContributionResponseType> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/initcontrib?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {

                const responseData = response.data;
                const initialContributionDetailsFromApi = responseData[0];

                initialContributionInfo = getInitialContributionInfo(initialContributionDetailsFromApi);

            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "initialContributionDetails": initialContributionInfo.initialContributionDetails,
            "userIds": initialContributionInfo.userIds,
        }; 
    };

    return fetchInitialContributionDetails;
}

export default useGetInitialContribution;
