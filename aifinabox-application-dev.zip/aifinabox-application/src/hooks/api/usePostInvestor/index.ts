import {
    ASLDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ASLDetailsForm/initialState";
import {
    BankDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/BankDetailsForm/initialState";
import {
    BasicDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/BasicDetailsForm/initialState";
import {
    CommitteeMemberDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/CommitteeMemberDetailsForm/initialState";
import {
    ContactPersonDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ContactPersonDetailsForm/initialState";
import {
    ContributionDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ContributionDetailsForm/initialState";
import {
    DirectorDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DirectorDetailsForm/initialState";
import {
    DistributorDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DistributorDetailsForm/initialState";
import {
    DocumentDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/DocumentDetailsForm/initialState";
import {
    EntityDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/EntityDetailsForm/initialState";
import {
    EntityFatcaAndCrsDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/EntityFatcaAndCrsDetailsForm/initialState";
import {
    FatcaAndCrsDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/IndividualFatcaAndCrsDetailsForm/initialState";
import {
    GuardianDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/GuardianDetailsForm/initialState";
import {
    HolderDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/HolderDetailsForm/initialState";
import {
    InvestmentDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/InvestmentDetailsForm/initialState";
import {
    KartaDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/KartaDetailsForm/initialState";
import {
    ModeOfAllotmentDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/ModeOfAllotmentDetailsForm/initialState";
import {
    NomineeDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/NomineeDetailsForm/initialState";
import {
    OTMDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/OTMDetailsForm/initialState";
import {
    PartnersDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PartnersDetailsForm/initialState";
import {
    PaymentBankDetails
} from "../../../pages/InvestorOnboarding/Maker/Form/SubForms/ContributionDetailsForm/interfaces/PaymentBankDetails";
import {
    PowerOfAttorneyDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PowerOfAttorneyDetailsForm/initialState";
import {
    PrimaryHolderDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PrimaryHolderDetailsForm/initialState";
import {
    PromoterDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/PromoterDetailsForm/initialState";
import {
    SipDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/SipDetailsForm/initialState";
import {
    TrusteeDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/TrusteeDetailsForm/initialState";
import {
    UboDetailsForm
} from "../../../redux/InvestorOnboarding/Maker/SubForms/UboDetailsForm/initialState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

const isFieldValueNull = (field: string | null) => {
    if (field === null || field === undefined || field?.trim() === "") 
        return null;
    else
        return field;
};

function usePostInvestor() {
    const dispatch = useDispatch();

    const postInvestor = async (
        aslDetailsData: ASLDetailsForm,
        bankDetailsData: BankDetailsForm,
        basicDetailsData: BasicDetailsForm,
        committeeMemberDetailsData: CommitteeMemberDetailsForm,
        contactPersonDetailsData: ContactPersonDetailsForm,
        contributionDetailsData: ContributionDetailsForm,
        directorDetailsData: DirectorDetailsForm,
        distributorDetailsData: DistributorDetailsForm,
        documentDetailsData: DocumentDetailsForm,
        entityDetailsData: EntityDetailsForm,
        entityFatcaAndCrsDetailsData: EntityFatcaAndCrsDetailsForm,
        fatcaAndCrsDetailsData: FatcaAndCrsDetailsForm,
        guardianDetailsData: GuardianDetailsForm,
        holderDetailsFormData: HolderDetailsForm,
        investmentDetailsData: InvestmentDetailsForm,
        kartaDetailsData: KartaDetailsForm,
        modeOfAllotmentDetailsData: ModeOfAllotmentDetailsForm,
        nomineeDetailsData: NomineeDetailsForm,
        otmDetailsData: OTMDetailsForm,
        partnerDetailsData: PartnersDetailsForm,
        powerOfAttorneyDetailsData: PowerOfAttorneyDetailsForm,
        primaryHolderDetailsData: PrimaryHolderDetailsForm,
        promoterDetailsData: PromoterDetailsForm,
        sipDetailsData: SipDetailsForm,
        transactionNo: string,
        trusteeDetailsData: TrusteeDetailsForm,
        uboDetailsData: UboDetailsForm,
        clientId: string,
        clientName: string,
        folio: string | null,
        processCode: string,
        stageCode: string,
        userId: string,
        userRole: string,
        auditorId: string | null,
        checkerId: string | null,
        makerId: string | null,
        qualityCheckerId: string | null,
        sourceUser: string,
        transactionTypeCode: string,
        transactionTypeName: string,
        transactionContribNo: string | null,
        transactionSipNo: string | null,
    ) => {
        dispatch(setOpenBackdrop(true));

        const { aslDetails } = aslDetailsData;
        const { bankDetails } = bankDetailsData;
        const { committees } = committeeMemberDetailsData;
        const { kartaDetailsList } = kartaDetailsData;
        const { promoterDetails  } = promoterDetailsData;
        const { directores } = directorDetailsData;
        const { contactPerson } = contactPersonDetailsData;
        const { ubos } = uboDetailsData;
        const { holderDetails } = holderDetailsFormData;
        const { otmDetails } = otmDetailsData;
        const { fatcaAndCrsDetails } = fatcaAndCrsDetailsData;
        const { partnerInfo } = partnerDetailsData;
        const { trusteeDetails } = trusteeDetailsData;
        const { nominees } = nomineeDetailsData;

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const paymentHolderArray = (holder: PaymentBankDetails) => {
            return {
                "foreignBankAccount": holder ?
                    [
                        {
                            "lastFourDigitsOfRegForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAddr": isFieldValueNull(holder?.paymentBankAddress),
                            "paymentBankBranch": isFieldValueNull(holder?.paymentBankBranch),
                            "paymentBankIbanCode": isFieldValueNull(holder?.paymentBankIbanCode),
                            "paymentBankName": isFieldValueNull(holder?.paymentBankName),
                            "paymentBankSwiftAndBic": isFieldValueNull(holder?.swiftOrBicCode),
                            "paymentForeignBankAccType": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.accountType) : null,
                            "regPaymentForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                        }
                    ] : [],
                "isForeignBankAcct": isFieldValueNull(holder?.isForeignBankAccount),
                "nationalBankAccount": holder ?
                    [
                        {
                            "lastFourDigOfRegBankAccountNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAccName": isFieldValueNull(holder?.paymentBankAccountName),
                            "paymentBankAccNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                            "paymentBankAccType": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.accountType) : null,
                            "paymentBankChqRefNo": holder?.paymentChequeDetails.map((cheque) => {
                                return {
                                    "chequeAmount": isFieldValueNull(cheque.chequeAmount),
                                    "chequeRefNo": isFieldValueNull(cheque.chequeReferenceNumber)
                                };
                            }),
                            "paymentBankIfsc": isFieldValueNull(holder?.paymentBankIfscCode),
                            "paymentBankMicr": isFieldValueNull(holder?.micrCode),
                            "paymentBankPennyDropStatus": isFieldValueNull(holder?.pennyDropStatus),
                            "paymentBankUtrNo": isFieldValueNull(holder?.paymentBankUtrNumber),
                            "paymentType": isFieldValueNull(holder?.paymentType),
                            "pennyDropValidationDt": isFieldValueNull(holder?.pennyDropValidationDate),
                        }
                    ] : [],
                "paymentBankIsRegBank": isFieldValueNull(holder?.sameAsRegisteredBank),
            };
        };

        const data = {
            "allotmentMode": {
                "clientId": isFieldValueNull(modeOfAllotmentDetailsData.clientId),
                "dPId": isFieldValueNull(modeOfAllotmentDetailsData.dpId),
                "modeOfAllotment": isFieldValueNull(modeOfAllotmentDetailsData.allotmentMode),
                "repositoryType": isFieldValueNull(modeOfAllotmentDetailsData.repositoryType),
            },
            "asl": aslDetails.map((asl) => {
                return {
                    "dob": isFieldValueNull(asl.dateOfBirth),
                    "gender": isFieldValueNull(asl.gender),
                    "isPep": asl.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(asl.name),
                    "taxIdNo": isFieldValueNull(asl.panOrTaxIdNumber),
                };
            }),
            "auditorId": auditorId,
            "bankDetails": 
                {
                    "primaryHolderBank": bankDetails[0].map((bank) => {
                        return {
                            "foreignBankAccount": bank.isItForeignBankAccount === "Yes" ? 
                                [{
                                    "accNo": isFieldValueNull(bank.foreignBankAccountNumber),
                                    "accProofFlag": bank.foreignBankAccountProofRecieved === "Yes",
                                    "bankAccType": isFieldValueNull(bank.bankAccountType),
                                    "bankAddr": isFieldValueNull(bank.bankAddress),
                                    "bankBranch": isFieldValueNull(bank.bankBranch),
                                    "bankName": isFieldValueNull(bank.bankName),
                                    "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                    "ibanCode": isFieldValueNull(bank.ibanCode),
                                    "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                    "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                    "swiftAndBic": isFieldValueNull(bank.swiftOrBicCode),
                                }] : [],
                            "isForeignAcc": bank.isItForeignBankAccount === "Yes",
                            "nationalBankAccount": bank.isItForeignBankAccount === "No" ? 
                                [{
                                    "accNo": isFieldValueNull(bank.bankAccountNumber),
                                    "bankAccType": isFieldValueNull(bank.bankAccountType),
                                    "bankAddr": isFieldValueNull(bank.bankAddress),
                                    "bankBranch": isFieldValueNull(bank.bankBranch),
                                    "bankName": isFieldValueNull(bank.bankName),
                                    "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                    "ifsc": isFieldValueNull(bank.ifscCode),
                                    "micr": isFieldValueNull(bank.micrCode),
                                    "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                    "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                }] : [],
                        };
                    }),
                    "secondHolderBankDetails": bankDetails.length > 1 ?
                        bankDetails[1].map((bank) => {
                            return {
                                "foreignBankAccount": bank.isItForeignBankAccount === "Yes" ? 
                                    [{
                                        "accNo": isFieldValueNull(bank.foreignBankAccountNumber),
                                        "accProofFlag": bank.foreignBankAccountProofRecieved === "Yes",
                                        "bankAccType": isFieldValueNull(bank.bankAccountType),
                                        "bankAddr": isFieldValueNull(bank.bankAddress),
                                        "bankBranch": isFieldValueNull(bank.bankBranch),
                                        "bankName": isFieldValueNull(bank.bankName),
                                        "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                        "ibanCode": isFieldValueNull(bank.ibanCode),
                                        "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                        "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                        "swiftAndBic": isFieldValueNull(bank.swiftOrBicCode),
                                    }] : [],
                                "isForeignAcc": bank.isItForeignBankAccount === "Yes",
                                "nationalBankAccount": bank.isItForeignBankAccount === "No" ? 
                                    [{
                                        "accNo": isFieldValueNull(bank.bankAccountNumber),
                                        "bankAccType": isFieldValueNull(bank.bankAccountType),
                                        "bankAddr": isFieldValueNull(bank.bankAddress),
                                        "bankBranch": isFieldValueNull(bank.bankBranch),
                                        "bankName": isFieldValueNull(bank.bankName),
                                        "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                        "ifsc": isFieldValueNull(bank.ifscCode),
                                        "micr": isFieldValueNull(bank.micrCode),
                                        "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                        "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                    }] : [],
                            };
                        }): [],
                    "thirdHolderBankDetails": bankDetails.length > 2 ?
                        bankDetails[2].map((bank) => {
                            return {
                                "foreignBankAccount": bank.isItForeignBankAccount === "Yes" ? 
                                    [{
                                        "accNo": isFieldValueNull(bank.foreignBankAccountNumber),
                                        "accProofFlag": bank.foreignBankAccountProofRecieved === "Yes",
                                        "bankAccType": isFieldValueNull(bank.bankAccountType),
                                        "bankAddr": isFieldValueNull(bank.bankAddress),
                                        "bankBranch": isFieldValueNull(bank.bankBranch),
                                        "bankName": isFieldValueNull(bank.bankName),
                                        "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                        "ibanCode": isFieldValueNull(bank.ibanCode),
                                        "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                        "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                        "swiftAndBic": isFieldValueNull(bank.swiftOrBicCode),
                                    }] : [],
                                "isForeignAcc": bank.isItForeignBankAccount === "Yes",
                                "nationalBankAccount": bank.isItForeignBankAccount === "No" ? 
                                    [{
                                        "accNo": isFieldValueNull(bank.bankAccountNumber),
                                        "bankAccType": isFieldValueNull(bank.bankAccountType),
                                        "bankAddr": isFieldValueNull(bank.bankAddress),
                                        "bankBranch": isFieldValueNull(bank.bankBranch),
                                        "bankName": isFieldValueNull(bank.bankName),
                                        "defaultAcc": bank.makeAsDefaultAccount === "Yes",
                                        "ifsc": isFieldValueNull(bank.ifscCode),
                                        "micr": isFieldValueNull(bank.micrCode),
                                        "pennyDropStatus": isFieldValueNull(bank.pennyDropStatus),
                                        "pennyDropValidationDt": isFieldValueNull(bank.pennyDropValidationDate),
                                    }] : [],
                            };
                        }): [],
                },
            "basicDetails": {
                "aadharLinkedOn": null, //(will contain the date sent by ITD API)
                "accreditationFlag": basicDetailsData.accreditation === "Yes",
                "applnId": isFieldValueNull(basicDetailsData.applicationId),
                "dateOfReg": basicDetailsData.investorType === "Individual" ? null : isFieldValueNull(basicDetailsData.dateOfBirth),
                "dob": basicDetailsData.investorType === "Individual" ? isFieldValueNull(basicDetailsData.dateOfBirth) : null,
                "emailIds": basicDetailsData.emailInfo.map((email) => {
                    return {
                        "emailId": isFieldValueNull(email.emailId),
                        "emailIdPertainTo": isFieldValueNull(email.emailIdPertainTo)
                    };
                }),
                "guardianTaxId": isFieldValueNull(basicDetailsData.guardianPanNumber),
                "invCategory": isFieldValueNull(basicDetailsData.investorCategory),
                "invTaxStatus": isFieldValueNull(basicDetailsData.primaryHolderTaxStatus),
                "invType": isFieldValueNull(basicDetailsData.investorType),
                "isAadharLinked": false, //(will contain the value sent by ITD API for aadharLink status)
                "mobNo": [
                    {
                        "mobNo": isFieldValueNull(basicDetailsData.mobileNumberPrefix + " " + basicDetailsData.mobileNumber),
                        "mobNoPertainTo": isFieldValueNull(basicDetailsData.mobileNumberPertainTo)
                    },
                ],
                "modeOfHolding": isFieldValueNull(basicDetailsData.modeOfHolding),
                "panValidatedOn": null, //(today's date i.e., when KRA API is called)
                "placeOfReg": isFieldValueNull(basicDetailsData.placeOfRegistration),
                "poaFlag": basicDetailsData.poaNonPoa === "POA",
                "prodType": isFieldValueNull(basicDetailsData.productType),
                "taxId": isFieldValueNull(basicDetailsData.panNumber),
                "taxIdExemptionApprovalAttachment": basicDetailsData.panExemptedApprovalAttachmentFileS3SignedURL.length ? true : false,
                "taxIdExemptionFlag": basicDetailsData.panExemptedInvestor === "Yes"
            },
            "checkerId": checkerId,
            "clientId": clientId,
            "clientName": clientName,
            "committeeDetails": committees.map((committee) => {
                return {
                    "dob": isFieldValueNull(committee.dateOfBirth),
                    "gender": isFieldValueNull(committee.gender),
                    "isPep": committee.politicallyExposedMember === "Yes",
                    "name": isFieldValueNull(committee.name),
                    "taxIdNo": isFieldValueNull(committee.panTaxIdNo)
                };
            }),
            "contactPersonDetails": contactPerson.map((person) => {
                return {
                    "addr1": isFieldValueNull(person.address1),
                    "addr2": isFieldValueNull(person.address2),
                    "addr3": isFieldValueNull(person.address3),
                    "city": isFieldValueNull(person.city),
                    "country": isFieldValueNull(person.country),
                    "emailId": person.emailId ? [person.emailId] : [],
                    "gender": isFieldValueNull(person.gender),
                    "mobNo": person.mobileNumber ? [person.mobileNumberPrefix + " " + person.mobileNumber] : [],
                    "name": isFieldValueNull(person.name),
                    "pincode": isFieldValueNull(person.pincode),
                    "salutation": isFieldValueNull(person.namePrefix),
                    "state": isFieldValueNull(person.state),
                };
            }),
            "createdBy": "",
            "createdDate": "",
            "createdFrom": "",
            "directorDetails": directores.map((director) => {
                return {
                    "din": isFieldValueNull(director.directorIdentificationNumber),
                    "dob": isFieldValueNull(director.dateOfBirth),
                    "gender": isFieldValueNull(director.gender),
                    "isPep": director.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(director.name),
                    "taxIdNo": isFieldValueNull(director.panTaxIdNmuber),
                };
            }),
            "distributorDetails": {
                "amcRmCode": isFieldValueNull(distributorDetailsData.amcRmCode),
                "amcRmEmailIDs": distributorDetailsData.amcRmEmailId,
                "amcRmName": isFieldValueNull(distributorDetailsData.amcRmName),
                "distributorCode": isFieldValueNull(distributorDetailsData.distributorCode),
                "distributorName": isFieldValueNull(distributorDetailsData.distributorName),
                "distributorRmCode": isFieldValueNull(distributorDetailsData.distributorRmCode),
                "distributorRmEmails": distributorDetailsData.distributorRmEmailId,
                "distributorRmMobNo": isFieldValueNull(distributorDetailsData.distributorRmMobileNumberPrefix + " " + distributorDetailsData.distributorRmMobileNumber),
                "distributorRmName": isFieldValueNull(distributorDetailsData.distributorRmName),
                "distributorType": isFieldValueNull(distributorDetailsData.distributorType)
            },
            "documentDetails": {
                "documentDetailsCorporate": {
                    "boardResolution": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.boardResolution),
                    "certificateOfIncorporationOrRegistrationCertificate": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.certificateOfIncorporationOrRegistrationCertificate),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "kycDocumentsOfDirectorsOrPromoters": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.kycDocumentsOfDirectorsOrPromoters),
                    "lastTwoYearAuditedReport": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.lastTwoYearAuditedReport),
                    "latestShareholdingPatternOnLettersHead": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.latestShareholdingPatternOnLettersHead),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                    "listOfDirectors": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.listOfDirectors),
                    "memorandumAndArticlesOfAssociation": isFieldValueNull(documentDetailsData.nonIndividual.corporateDocumentDetails.memorandumAndArticlesOfAssociation),
                },	
                "documentDetailsFII": {	                
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.foreignInstitutionalInvestors.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.foreignInstitutionalInvestors.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "copyOfSebiRegistrationReport": isFieldValueNull(documentDetailsData.nonIndividual.foreignInstitutionalInvestors.copyOfSebiRegistrationReport),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.foreignInstitutionalInvestors.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                },	      
                "documentDetailsGovtBodies": {	                
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.armyOrGovernmentBodiesDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.armyOrGovernmentBodiesDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.armyOrGovernmentBodiesDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                    "selfCertificationOnLetterhead": isFieldValueNull(documentDetailsData.nonIndividual.armyOrGovernmentBodiesDocumentDetails.selfCertificationOnLetterhead),
                },
                "documentDetailsHUF": {	                
                    "deedOfDeclarationOfHufOrListOfCoparcener": isFieldValueNull(documentDetailsData.nonIndividual.hufDocumentDetails.deedOfDeclarationOfHufOrListOfCoparcener),
                    "hufDeedOrDeedOfDeclarationOfHufByKarta": isFieldValueNull(documentDetailsData.nonIndividual.hufDocumentDetails.hufDeedOrDeedOfDeclarationOfHufByKarta),
                    "kartaAddressProof": isFieldValueNull(documentDetailsData.nonIndividual.hufDocumentDetails.kartaAddressProof),
                    "kartaPanOrTaxIdProof": isFieldValueNull(documentDetailsData.nonIndividual.hufDocumentDetails.kartaPanOrTaxIdProof),
                    "listOfCoPartners": isFieldValueNull(documentDetailsData.nonIndividual.hufDocumentDetails.listOfCoPartners),
                },
                "documentDetailsInstitutionalInvestors": {	                
                    "balanceSheetForLastTwoFinancialYears": isFieldValueNull(documentDetailsData.nonIndividual.banksOrInstitutionalInvestorsDocumentDetails.balanceSheetForLastTwoFinancialYears),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.banksOrInstitutionalInvestorsDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.banksOrInstitutionalInvestorsDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "copyOfRegistrationOrAnnualReport": isFieldValueNull(documentDetailsData.nonIndividual.banksOrInstitutionalInvestorsDocumentDetails.copyOfRegistrationOrAnnualReport),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.banksOrInstitutionalInvestorsDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                },
                "documentDetailsPartnership": {	                
                    "boardResolution": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.boardResolution),
                    "certificateOfIncorporationOrRegistrationCertificate": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.certificateOfIncorporationOrRegistrationCertificate),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "kycDocumentsOfPartners": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.kycDocumentsOfPartners),
                    "lastTwoYearAuditedReport": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.lastTwoYearAuditedReport),
                    "latestShareholdingPatternOnLettersHead": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.latestShareholdingPatternOnLettersHead),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                    "listOfPartnersWithSpecimenSignature": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.listOfPartnersWithSpecimenSignature),
                    "partnershipAgreementOrPartnershipDeed": isFieldValueNull(documentDetailsData.nonIndividual.partnershipDocumentDetails.partnershipAgreementOrPartnershipDeed),
                },	  
                "documentDetailsProprietorship": {	                             
                    "incorporationOrEstablishmentDocumentsOfProprietorshipFirm": isFieldValueNull(documentDetailsData.nonIndividual.proprietorshipDocumentDetails.incorporationOrEstablishmentDocumentsOfProprietorshipFirm),
                    "kycDocumentsOfProprietor": isFieldValueNull(documentDetailsData.nonIndividual.proprietorshipDocumentDetails.kycDocumentsOfProprietor),
                    "selfAttestedCopyOfPanOrTaxIdAndAddressProof": isFieldValueNull(documentDetailsData.nonIndividual.proprietorshipDocumentDetails.selfAttestedCopyOfPanOrTaxIdAndAddressProof),
                }, 
                "documentDetailsRegisteredSociety": {
                    "boardResolution": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.boardResolution),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "lastTwoYearAuditedReport": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.lastTwoYearAuditedReport),
                    "latestShareholdingPatternOnLettersHead": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.latestShareholdingPatternOnLettersHead),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                    "listOfCommitteeMembersWithProofs": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.listOfCommitteeMembersWithProofs),
                    "trueCopyOfSocietyRulesAndByeLawsCertifiedByChairman": isFieldValueNull(documentDetailsData.nonIndividual.registeredSocietyDocumentDetails.trueCopyOfSocietyRulesAndByeLawsCertifiedByChairman),
                },
                "documentDetailsTrust": {
                    "boardResolution": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.boardResolution),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "incorporationOrEstablishmentDocuments": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.incorporationOrEstablishmentDocuments),
                    "kycDocumentsOfTrusteeAndSettlers": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.kycDocumentsOfTrusteeAndSettlers),
                    "lastTwoYearAuditedReport": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.lastTwoYearAuditedReport),
                    "latestShareholdingPatternOnLettersHead": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.latestShareholdingPatternOnLettersHead),
                    "listOfAuthorizedSignatoriesWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.listOfAuthorizedSignatoriesWithSpecimenSignatures),
                    "trustDeed": isFieldValueNull(documentDetailsData.nonIndividual.trustDocumentDetails.trustDeed),
                },
                "documentDetailsUnincorporatedAssociation": {	            
                    "authorizedSignatoriesListWithSpecimenSignatures": isFieldValueNull(documentDetailsData.nonIndividual.unincorporatedDocumentDetails.authorizedSignatoriesListWithSpecimenSignatures),
                    "copyOfAddressProofOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.unincorporatedDocumentDetails.copyOfAddressProofOfAuthorizedSignatory),
                    "copyOfPanOrTaxIdOfAuthorizedSignatory": isFieldValueNull(documentDetailsData.nonIndividual.unincorporatedDocumentDetails.copyOfPanOrTaxIdOfAuthorizedSignatory),
                    "proofOfExistenceOrConstitutionDoc": isFieldValueNull(documentDetailsData.nonIndividual.unincorporatedDocumentDetails.proofOfExistenceOrConstitutionDoc),
                    "resolutionOfTheManagingBodyAndPowerOfAttorneyGrantedToTransactBusinessOnItsBehalf": isFieldValueNull(documentDetailsData.nonIndividual.unincorporatedDocumentDetails.resolutionOfTheManagingBodyAndPowerOfAttorneyGrantedToTransactBusinessOnItsBehalf),
                },	       
                "mandatoryDocumentProvided": 
                    basicDetailsData.investorType === "Individual" ?
                        {
                            "addressProof": null,
                            "applicationFormAndContributionAgreement": isFieldValueNull(documentDetailsData.individual.mandatoryDocumentDetails.applicationFormAndContributionAgreement) ?? null,
                            "bankProof": null,
                            "copyOfEntityPanOrTaxId": null,
                            "fatcaOrCrsDeclarationForm": null,
                            "uboDeclarationForm": null,
                        } :
                        {
                            "addressProof": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.addressProof) ?? null,
                            "applicationFormAndContributionAgreement": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.applicationFormAndContributionAgreement) ?? null,
                            "bankProof": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.bankProof) ?? null,
                            "copyOfEntityPanOrTaxId": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.copyOfEntityPanOrTaxId) ?? null,
                            "fatcaOrCrsDeclarationForm": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.fatcaOrCrsDeclarationForm) ?? null,
                            "uboDeclarationForm": isFieldValueNull(documentDetailsData.nonIndividual.mandatoryDocumentsDetails.uboDeclarationForm) ?? null,
                        },    
                "minorAndGuardianDocs": {	                
                    "courtAppointedLegalGuardianDocumentDetails": isFieldValueNull(documentDetailsData.individual.minorAndGuardianDocumentDetails.courtAppointedLegalGuardianDocumentDetails),
                    "guardianOverseasAddressProof": isFieldValueNull(documentDetailsData.individual.minorAndGuardianDocumentDetails.guardianOverseasAddressProof),
                    "minorDobProof": isFieldValueNull(documentDetailsData.individual.minorAndGuardianDocumentDetails.minorDobProof),
                    "selfAttestedProofOfAddress": isFieldValueNull(documentDetailsData.individual.minorAndGuardianDocumentDetails.selfAttestedProofOfAddress),
                    "selfAttestedProofOfIdentity": isFieldValueNull(documentDetailsData.individual.minorAndGuardianDocumentDetails.selfAttestedProofOfIdentity),
                },	   
                "otherDocuments":             
                    basicDetailsData.investorType === "Individual" ?
                        {
                            "accreditationCertificate": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.accreditationCertificate),
                            "clientMasterListForDematAllocation": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.clientMasterListForDematAllocation),
                            "foreignPaymentBankAccountFormReceived": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.foreignPaymentBankAccountFormReceived),
                            "kycModificationFormReceived": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.kycModificationFormReceived),
                            "otmOrNachForm": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.otmOrNachForm),
                            "panOrTaxIdExemptedGovernmentIssuedExceptionDocument": isFieldValueNull(documentDetailsData.individual.otherDocumentDetails.panOrTaxIdExemptedGovernmentIssuedExceptionDocument), 
                        } :
                        {
                            "accreditationCertificate": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.accreditationCertificate),
                            "clientMasterListForDematAllocation": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.clientMasterListForDematAllocation),
                            "foreignPaymentBankAccountProofReceived": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.foreignPaymentBankAccountProofReceived),
                            "kycModificationFormReceived": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.kycModificationFormReceived),
                            "otmOrNachForm": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.otmOrNachForm),
                            "panOrTaxIdExemptedGovernmentIssuedExceptionDocument": isFieldValueNull(documentDetailsData.nonIndividual.otherDocumentDetails.panOrTaxIdExemptedGovernmentIssuedExceptionDocument), 
                        },
                "poaDocs":
                    basicDetailsData.investorType === "Individual" ?
                        {
                            "poaAuthorizedSignatoriesListIfNonIndividual": isFieldValueNull(documentDetailsData.individual.poaDocumentDetails.poaAuthorizedSignatoriesListIfNonIndividual),
                            "poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual": isFieldValueNull(documentDetailsData.individual.poaDocumentDetails.poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual),
                            "poaBoardResolutionIfNonIndividual": isFieldValueNull(documentDetailsData.individual.poaDocumentDetails.poaBoardResolutionIfNonIndividual),
                            "powerOfAttorneyAgreementWithInvestor": isFieldValueNull(documentDetailsData.individual.poaDocumentDetails.powerOfAttorneyAgreementWithInvestor),
                            "powerOfAttorneyKycDocuments": isFieldValueNull(documentDetailsData.individual.poaDocumentDetails.powerOfAttorneyKycDocuments),
                        } :
                        {
                            "poaAuthorizedSignatoriesListIfNonIndividual": isFieldValueNull(documentDetailsData.nonIndividual.poaDocumentDetails.poaAuthorizedSignatoriesListIfNonIndividual),
                            "poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual": isFieldValueNull(documentDetailsData.nonIndividual.poaDocumentDetails.poaAuthorizedSignatoriesListKycDocumentsIfNonIndividual),
                            "poaBoardResolutionIfNonIndividual": isFieldValueNull(documentDetailsData.nonIndividual.poaDocumentDetails.poaBoardResolutionIfNonIndividual),
                            "powerOfAttorneyAgreementWithInvestor": isFieldValueNull(documentDetailsData.nonIndividual.poaDocumentDetails.powerOfAttorneyAgreementWithInvestor),
                            "powerOfAttorneyKycDocuments": isFieldValueNull(documentDetailsData.nonIndividual.poaDocumentDetails.powerOfAttorneyKycDocuments),
                        },	                
                "primaryHolderDocs": {	                
                    "bankProofOrCancelledCheque": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.bankProofOrCancelledCheque),
                    "fatcaCrsDeclarationForm": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.fatcaCrsDeclarationForm),
                    "governmentIssuedOverseasAddressProofOfPrimaryHolder": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.governmentIssuedOverseasAddressProofOfPrimaryHolder),
                    "ociCardOfPrimaryHolderDoc": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.ociCardOfPrimaryHolderDoc),
                    "pioCardOfPrimaryHolder": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.pioCardOfPrimaryHolder),
                    "selfAttestedProofOfAddress": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.selfAttestedProofOfAddress),
                    "selfAttestedProofOfIdentity": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.selfAttestedProofOfIdentity),
                    "trcOrForm10fOrTinCertificateOrForm10A": isFieldValueNull(documentDetailsData.individual.primaryHolderDocumentDetails.trcOrForm10fOrTinCertificateOrForm10A),
                },	               
                "secondHolderDocs": {	         
                    "bankProofOrCancelledCheque": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.bankProofOrCancelledCheque),
                    "fatcaCrsDeclarationForm": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.fatcaCrsDeclarationForm),
                    "governmentIssuedOverseasAddressProofOfSecondaryHolder": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.governmentIssuedOverseasAddressProofOfSecondaryHolder),
                    "ociCardOfSecondaryHolderDoc": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.ociCardOfSecondaryHolderDoc),
                    "pioCardOfSecondaryHolder": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.pioCardOfSecondaryHolder),
                    "selfAttestedProofOfAddress": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.selfAttestedProofOfAddress),
                    "selfAttestedProofOfIdentity": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.selfAttestedProofOfIdentity),
                    "trcOrForm10fOrTinCertificateOrForm10A": isFieldValueNull(documentDetailsData.individual.secondaryHolderDocumentDetails.trcOrForm10fOrTinCertificateOrForm10A),
                },	              
                "thirdHolderDocs": {	     
                    "bankProofOrCancelledCheque": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.bankProofOrCancelledCheque),
                    "fatcaCrsDeclarationForm": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.fatcaCrsDeclarationForm),
                    "governmentIssuedOverseasAddressProofOfThirdHolder": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.governmentIssuedOverseasAddressProofOfThirdHolder),
                    "ociCardOfThirdHolderDoc": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.ociCardOfThirdHolderDoc),
                    "pioCardOfThirdHolder": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.pioCardOfThirdHolder),
                    "selfAttestedProofOfAddress": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.selfAttestedProofOfAddress),
                    "selfAttestedProofOfIdentity": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.selfAttestedProofOfIdentity),
                    "trcOrForm10fOrTinCertificateOrForm10A": isFieldValueNull(documentDetailsData.individual.thirdHolderDocumentDetails.trcOrForm10fOrTinCertificateOrForm10A),
                },
            },
            "entityDetails": {
                "accreditationNo": isFieldValueNull(entityDetailsData.accreditationNumber),
                "accreditationValidityDt": isFieldValueNull(entityDetailsData.accreditationValidityDate),
                "cin": isFieldValueNull(entityDetailsData.corporateIdentificationNumber),
                "ckycNo": isFieldValueNull(entityDetailsData.ckycOrKinNumber),
                "leiExpiryDt": isFieldValueNull(entityDetailsData.leiExpiryDate),
                "leiNo": isFieldValueNull(entityDetailsData.leiNumber),
                "nameOfTheEntity": isFieldValueNull(entityDetailsData.nameOfTheEntity),
                "overseasAddrDetails": [
                    {
                        "addr1": isFieldValueNull(entityDetailsData.overseasAddress1),
                        "addr2": isFieldValueNull(entityDetailsData.overseasAddress2),
                        "addr3": isFieldValueNull(entityDetailsData.overseasAddress3),
                        "city": isFieldValueNull(entityDetailsData.overseasCity),
                        "country": isFieldValueNull(entityDetailsData.overseasCountry),
                        "landlineNo": isFieldValueNull(entityDetailsData.landlineNumber),
                        "pincode": isFieldValueNull(entityDetailsData.overseasPinCode),
                        "state": isFieldValueNull(entityDetailsData.overseasState),
                    }
                ],
                "regAddr": [
                    {
                        "addr1": isFieldValueNull(entityDetailsData.registeredAddress1),
                        "addr2": isFieldValueNull(entityDetailsData.registeredAddress2),
                        "addr3": isFieldValueNull(entityDetailsData.registeredAddress3),
                        "city": isFieldValueNull(entityDetailsData.registeredCity),
                        "correspSameAsRegAddr": entityDetailsData.sameAsRegisteredAddress === "Yes",
                        "country": isFieldValueNull(entityDetailsData.registeredCountry),
                        "isCorrespAddr": false,
                        "landlineNo": null,
                        "pincode": isFieldValueNull(entityDetailsData.registeredPinCode),
                        "state": isFieldValueNull(entityDetailsData.registeredState),
                    },
                    {
                        "addr1": isFieldValueNull(entityDetailsData.correspondanceAddress1),
                        "addr2": isFieldValueNull(entityDetailsData.correspondanceAddress2),
                        "addr3": isFieldValueNull(entityDetailsData.correspondanceAddress3),
                        "city": isFieldValueNull(entityDetailsData.correspondanceCity),
                        "correspSameAsRegAddr": entityDetailsData.sameAsRegisteredAddress === "Yes",
                        "country": isFieldValueNull(entityDetailsData.correspondanceCountry),
                        "isCorrespAddr": true,
                        "landlineNo": null,
                        "pincode": isFieldValueNull(entityDetailsData.correspondancePinCode),
                        "state": isFieldValueNull(entityDetailsData.correspondanceState),
                    }
                ],
                "salutation": "M/S",
            },
            "fatcaDetails": {
                "guardianFatca": 
                (basicDetailsData.investorType === "Individual" && 
                basicDetailsData.primaryHolderTaxStatus.toLowerCase().includes("minor") && 
                basicDetailsData.modeOfHolding === "Single")
                    ?
                    {
                        "ctryOfBirth": isFieldValueNull(fatcaAndCrsDetails[1].countryOfBirth),
                        "ctryOfTaxRes": isFieldValueNull(fatcaAndCrsDetails[1].countryOfTaxResindency),
                        "dateOfAnnIncome": isFieldValueNull(fatcaAndCrsDetails[1].dateOfAnnualIncome),
                        "fatcaAndCrsFlag": fatcaAndCrsDetails[1].holderFatcaAndCrs === "Yes",
                        "grossAnnIncome": isFieldValueNull(fatcaAndCrsDetails[1].incomeSlabOrGrossAnnualIncome),
                        "isPep": fatcaAndCrsDetails[1].politicallyExposedPerson === "Yes",
                        "isTaxResNotIndia": fatcaAndCrsDetails[1].taxResidencyOtherThanIndia === "Yes",
                        "nationality": isFieldValueNull(fatcaAndCrsDetails[1].nationality),
                        "occupation": fatcaAndCrsDetails[1].occuptionDetails === "Others" ? 
                            isFieldValueNull(fatcaAndCrsDetails[1].pleaseSpecify) : 
                            isFieldValueNull(fatcaAndCrsDetails[1].occuptionDetails),
                        "placeOfBirth": isFieldValueNull(fatcaAndCrsDetails[1].cityOrPlaceOfBirth),
                        "taxPayerIdNo": isFieldValueNull(fatcaAndCrsDetails[1].taxPayerIdentificationNumber),
                        "taxPayerIdType": isFieldValueNull(fatcaAndCrsDetails[1].taxPayerIdentificationType),
                        "typeOfAddrAtKra": isFieldValueNull(fatcaAndCrsDetails[1].typeOfAddressProvidedAtKra),
                    }
                    : 
                    {
                        "ctryOfBirth": null,
                        "ctryOfTaxRes": null,
                        "dateOfAnnIncome": null,
                        "fatcaAndCrsFlag": null,
                        "grossAnnIncome": null,
                        "isPep": null,
                        "isTaxResNotIndia": null,
                        "nationality": null,
                        "placeOfBirth": null,
                        "taxPayerIdNo": null,
                        "taxPayerIdType": null,
                        "typeOfAddrAtKra": null,
                    },

                "nonIndividualFatca": {
                    "cityOfInc": isFieldValueNull(entityFatcaAndCrsDetailsData.cityOfIncorporation),
                    "ctryOfInc": isFieldValueNull(entityFatcaAndCrsDetailsData.countryOfIncorporation),
                    "ctryOfTaxRes": isFieldValueNull(entityFatcaAndCrsDetailsData.countryOtherThanIndia),
                    "entityConstitutionType": isFieldValueNull(entityFatcaAndCrsDetailsData.entityConstitutionType),
                    "fatcaAndCrsFlag": entityFatcaAndCrsDetailsData.entityFatcaAndCrs === "Yes",
                    "govtBodyIntlOrgListedStockexchngFlag": entityFatcaAndCrsDetailsData.isTheAccountHolderGovernmentBody === "Yes",
                    "isIndianFinInst": entityFatcaAndCrsDetailsData.isTheAccountHolderIndianFinancialInstitution === "Yes",
                    "isTaxResNotIndia": entityFatcaAndCrsDetailsData.taxResidencyOtherThanIndia === "Yes",
                    "partA": {
                        "giinNo": isFieldValueNull(entityFatcaAndCrsDetailsData.giinNumber),
                        "giinNotAvbl": isFieldValueNull(entityFatcaAndCrsDetailsData.giinNotAvailable),
                        "nameOfSponseringEntity": isFieldValueNull(entityFatcaAndCrsDetailsData.nameOfTheSponsoringEntity),
                        "toBeFilledBy": isFieldValueNull(entityFatcaAndCrsDetailsData.fatcaPartAToBeFilledBy),
                    },
                    "partB": {
                        "grossAnnualIncome": isFieldValueNull(entityFatcaAndCrsDetailsData.grossAnnualIncome),
                        "involvedInMentionedServices": isFieldValueNull(entityFatcaAndCrsDetailsData.involvedInAnyOfTheMentionedServices),
                        "isEntityPep": entityFatcaAndCrsDetailsData.politicallyExposedPerson === "Yes",
                        "nameOfBusiness": isFieldValueNull(entityFatcaAndCrsDetailsData.nameOfBusiness),
                        "nameOfListedCo": isFieldValueNull(entityFatcaAndCrsDetailsData.nameOfListedCompany),
                        "nameOfStkExchng": isFieldValueNull(entityFatcaAndCrsDetailsData.nameOfTheStockExchange),
                        "natureOfBusiness": isFieldValueNull(entityFatcaAndCrsDetailsData.natureOfBusiness),
                        "natureOfRel": isFieldValueNull(entityFatcaAndCrsDetailsData.natureOfRelation),
                        "networth": isFieldValueNull(entityFatcaAndCrsDetailsData.networth),
                        "networthAsOnDt": isFieldValueNull(entityFatcaAndCrsDetailsData.networthAsOnDate),
                        "subcategoryOfActiveNfe": isFieldValueNull(entityFatcaAndCrsDetailsData.subCategoryOfActiveNfe),
                        "toBeFilledBy": isFieldValueNull(entityFatcaAndCrsDetailsData.fatcaPartBToBeFilledBy),
                    },
                    "taxPayerIdNo": isFieldValueNull(entityFatcaAndCrsDetailsData.taxPayerIdentificationNumber),
                    "taxPayerIdType": isFieldValueNull(entityFatcaAndCrsDetailsData.taxPayerIdentificationType),
                    "typeOfAddrAtKra": isFieldValueNull(entityFatcaAndCrsDetailsData.typeOfAddressProvidedAtKra),
                },
                "primaryHolderFatca": {
                    "ctryOfBirth": isFieldValueNull(fatcaAndCrsDetails[0].countryOfBirth),
                    "ctryOfTaxRes": isFieldValueNull(fatcaAndCrsDetails[0].countryOfTaxResindency),
                    "dateOfAnnIncome": isFieldValueNull(fatcaAndCrsDetails[0].dateOfAnnualIncome),
                    "fatcaAndCrsFlag": fatcaAndCrsDetails[0].holderFatcaAndCrs === "Yes",
                    "grossAnnIncome": isFieldValueNull(fatcaAndCrsDetails[0].incomeSlabOrGrossAnnualIncome),
                    "isPep": fatcaAndCrsDetails[0].politicallyExposedPerson === "Yes",
                    "isTaxResNotIndia": fatcaAndCrsDetails[0].taxResidencyOtherThanIndia === "Yes",
                    "nationality": isFieldValueNull(fatcaAndCrsDetails[0].nationality),
                    "occupation": fatcaAndCrsDetails[0].occuptionDetails === "Others" ? 
                        isFieldValueNull(fatcaAndCrsDetails[0].pleaseSpecify) : 
                        isFieldValueNull(fatcaAndCrsDetails[0].occuptionDetails),
                    "placeOfBirth": isFieldValueNull(fatcaAndCrsDetails[0].cityOrPlaceOfBirth),
                    "taxPayerIdNo": isFieldValueNull(fatcaAndCrsDetails[0].taxPayerIdentificationNumber),
                    "taxPayerIdType": isFieldValueNull(fatcaAndCrsDetails[0].taxPayerIdentificationType),
                    "typeOfAddrAtKra": isFieldValueNull(fatcaAndCrsDetails[0].typeOfAddressProvidedAtKra),
                },
                "secondaryHolderFatca": 
                    basicDetailsData.investorType === "Individual" && 
                    basicDetailsData.investorCategory === "Resident Indian" || 
                    basicDetailsData.investorCategory === "Non-Resident Indian" || 
                    basicDetailsData.investorCategory === "Foreign National" && 
                    basicDetailsData.modeOfHolding === "Jointly" 
                        ?
                        {
                            "ctryOfBirth": isFieldValueNull(fatcaAndCrsDetails[2].countryOfBirth),
                            "ctryOfTaxRes": isFieldValueNull(fatcaAndCrsDetails[2].countryOfTaxResindency),
                            "dateOfAnnIncome": isFieldValueNull(fatcaAndCrsDetails[2].dateOfAnnualIncome),
                            "fatcaAndCrsFlag": fatcaAndCrsDetails[2].holderFatcaAndCrs === "Yes",
                            "grossAnnIncome": isFieldValueNull(fatcaAndCrsDetails[2].incomeSlabOrGrossAnnualIncome),
                            "isPep": fatcaAndCrsDetails[2].politicallyExposedPerson === "Yes",
                            "isTaxResNotIndia": fatcaAndCrsDetails[2].taxResidencyOtherThanIndia === "Yes",
                            "nationality": isFieldValueNull(fatcaAndCrsDetails[2].nationality),
                            "occupation": fatcaAndCrsDetails[2].occuptionDetails === "Others" ? 
                                isFieldValueNull(fatcaAndCrsDetails[2].pleaseSpecify) : 
                                isFieldValueNull(fatcaAndCrsDetails[2].occuptionDetails),
                            "placeOfBirth": isFieldValueNull(fatcaAndCrsDetails[2].cityOrPlaceOfBirth),
                            "taxPayerIdNo": isFieldValueNull(fatcaAndCrsDetails[2].taxPayerIdentificationNumber),
                            "taxPayerIdType": isFieldValueNull(fatcaAndCrsDetails[2].taxPayerIdentificationType),
                            "typeOfAddrAtKra": isFieldValueNull(fatcaAndCrsDetails[2].typeOfAddressProvidedAtKra),
                        }
                        : 
                        {
                            "ctryOfBirth": null,
                            "ctryOfTaxRes": null,
                            "dateOfAnnIncome": null,
                            "fatcaAndCrsFlag": null,
                            "grossAnnIncome": null,
                            "isPep": null,
                            "isTaxResNotIndia": null,
                            "nationality": null,
                            "placeOfBirth": null,
                            "taxPayerIdNo": null,
                            "taxPayerIdType": null,
                            "typeOfAddrAtKra": null,
                        },

                "thirdHolderFatca": 
                    basicDetailsData.investorType === "Individual" && 
                    basicDetailsData.investorCategory === "Resident Indian" || 
                    basicDetailsData.investorCategory === "Non-Resident Indian" || 
                    basicDetailsData.investorCategory === "Foreign National" && 
                    basicDetailsData.modeOfHolding === "Jointly" 
                        ?
                        {
                            "ctryOfBirth": isFieldValueNull(fatcaAndCrsDetails[3].countryOfBirth),
                            "ctryOfTaxRes": isFieldValueNull(fatcaAndCrsDetails[3].countryOfTaxResindency),
                            "dateOfAnnIncome": isFieldValueNull(fatcaAndCrsDetails[3].dateOfAnnualIncome),
                            "fatcaAndCrsFlag": fatcaAndCrsDetails[3].holderFatcaAndCrs === "Yes",
                            "grossAnnIncome": isFieldValueNull(fatcaAndCrsDetails[3].incomeSlabOrGrossAnnualIncome),
                            "isPep": fatcaAndCrsDetails[3].politicallyExposedPerson === "Yes",
                            "isTaxResNotIndia": fatcaAndCrsDetails[3].taxResidencyOtherThanIndia === "Yes",
                            "nationality": isFieldValueNull(fatcaAndCrsDetails[3].nationality),
                            "occupation": fatcaAndCrsDetails[3].occuptionDetails === "Others" ? 
                                isFieldValueNull(fatcaAndCrsDetails[3].pleaseSpecify) : 
                                isFieldValueNull(fatcaAndCrsDetails[3].occuptionDetails),
                            "placeOfBirth": isFieldValueNull(fatcaAndCrsDetails[3].cityOrPlaceOfBirth),
                            "taxPayerIdNo": isFieldValueNull(fatcaAndCrsDetails[3].taxPayerIdentificationNumber),
                            "taxPayerIdType": isFieldValueNull(fatcaAndCrsDetails[3].taxPayerIdentificationType),
                            "typeOfAddrAtKra": isFieldValueNull(fatcaAndCrsDetails[3].typeOfAddressProvidedAtKra),
                        }
                        : 
                        {
                            "ctryOfBirth": null,
                            "ctryOfTaxRes": null,
                            "dateOfAnnIncome": null,
                            "fatcaAndCrsFlag": null,
                            "grossAnnIncome": null,
                            "isPep": null,
                            "isTaxResNotIndia": null,
                            "nationality": null,
                            "placeOfBirth": null,
                            "taxPayerIdNo": null,
                            "taxPayerIdType": null,
                            "typeOfAddrAtKra": null,
                        },
            },
            "folio": folio,
            "frozenFolioFlag": false,
            "guardianDetails": {
                "aadharNo": isFieldValueNull(guardianDetailsData.aadharNumber),
                "address": [
                    {
                        "addr1": isFieldValueNull(guardianDetailsData.permanentAddress1),
                        "addr2": isFieldValueNull(guardianDetailsData.permanentAddress2),
                        "addr3": isFieldValueNull(guardianDetailsData.permanentAddress3),
                        "city": isFieldValueNull(guardianDetailsData.permanentCity),
                        "country": isFieldValueNull(guardianDetailsData.permanentCountry),
                        "isOverseasAddr": false,
                        "landlineNo": null,
                        "pincode": isFieldValueNull(guardianDetailsData.permanentPincode),
                        "state": isFieldValueNull(guardianDetailsData.permanentState)
                    },
                    {
                        "addr1": isFieldValueNull(guardianDetailsData.overseasAddress1),
                        "addr2": isFieldValueNull(guardianDetailsData.overseasAddress2),
                        "addr3": isFieldValueNull(guardianDetailsData.overseasAddress3),
                        "city": isFieldValueNull(guardianDetailsData.overseasCity),
                        "country": isFieldValueNull(guardianDetailsData.overseasCountry),
                        "isOverseasAddr": true,
                        "landlineNo": isFieldValueNull(guardianDetailsData.overseasLandlineNo),
                        "pincode": isFieldValueNull(guardianDetailsData.overseasPincode),
                        "state": isFieldValueNull(guardianDetailsData.overseasState)
                    }
                ],
                "ckycNo": isFieldValueNull(guardianDetailsData.overseasCkycKinNo),
                "dob": isFieldValueNull(guardianDetailsData.dateOfBirth),
                "emailIds": [
                    {
                        "emailId": isFieldValueNull(guardianDetailsData.overseasEmailId),
                        "emailIdPertainTo": isFieldValueNull(guardianDetailsData.overseasEmailIdPertainTo),
                    }
                ],
                "gender": isFieldValueNull(guardianDetailsData.gender),
                "mobNo": [
                    {
                        "mobNo": isFieldValueNull(guardianDetailsData.overseasMobileNoPrefix + " " + guardianDetailsData.overseasMobileNo),
                        "mobNoPertainTo": isFieldValueNull(guardianDetailsData.overseasMobileNoPertainTo),
                    }
                ],
                "name": isFieldValueNull(guardianDetailsData.guardianName),
                "passportExpiryDt": isFieldValueNull(guardianDetailsData.passportExpiryDate),
                "passportNo": isFieldValueNull(guardianDetailsData.passportNumber),
                "relationship": isFieldValueNull(guardianDetailsData.guardianRelationship),
                "salutation": isFieldValueNull(guardianDetailsData.guardianNamePrefix),
                "taxStatus": isFieldValueNull(guardianDetailsData.taxStatus)
            },
            "initialContribution": {
                "contributionDetails": {
                    "commitmentAmount": isFieldValueNull(contributionDetailsData.commitmentAmount),
                    "exchngRate": isFieldValueNull(contributionDetailsData.exchangeRate),
                    "fundCurrency": isFieldValueNull(contributionDetailsData.fundCurrency),
                    "fundCurrencyAmount": isFieldValueNull(contributionDetailsData.fundCurrencyAmount),
                    "gst": isFieldValueNull(contributionDetailsData.gstOrServiceTax),
                    "gstWaiver": isFieldValueNull(contributionDetailsData.gstWaiver),
                    "gstWaiverAttachment": {
                        "documentFormat": isFieldValueNull(contributionDetailsData.gstWaiverApprovalEmailFileFormat),
                        "documentPath": isFieldValueNull(contributionDetailsData.gstWaiverApprovalEmailFileS3Key),
                        "documentSize": isFieldValueNull(contributionDetailsData.gstWaiverApprovalEmailFileSize)
                    },
                    "initContribAmt": isFieldValueNull(contributionDetailsData.initialContributionAmount),
                    "otherFee": isFieldValueNull(contributionDetailsData.otherFee),
                    "paymentType": null,
                    "primaryHolderContrib": isFieldValueNull(contributionDetailsData.primaryHolderContribution),
                    "primaryHolderPercent": isFieldValueNull(contributionDetailsData.primaryHolderPercentage),
                    "secondHolderContrib": isFieldValueNull(contributionDetailsData.secondHolderContribution),
                    "secondHolderPercent": isFieldValueNull(contributionDetailsData.secondHolderPercentage),
                    "setupFeeAmt": isFieldValueNull(contributionDetailsData.setupFeeAmount),
                    "setupFeePercent": isFieldValueNull(contributionDetailsData.setupFeePercentage),
                    "thirdHolderContrib": isFieldValueNull(contributionDetailsData.thirdHolderContribution),
                    "thirdHolderPercent": isFieldValueNull(contributionDetailsData.thirdHolderPercentage),
                    "totalSetupFee": isFieldValueNull(contributionDetailsData.totalSetupFee),
                    "transactionCurrency": isFieldValueNull(contributionDetailsData.transactionCurrency),
                },
                "depositBankDetails": {
                    "bankAccNo": isFieldValueNull(contributionDetailsData.collectionBankAccountNumber),
                    "bankName": isFieldValueNull(contributionDetailsData.collectionBankName),
                    "ifsc": isFieldValueNull(contributionDetailsData.collectionBankIfscCode),
                },
                "endorsedFlag": false,
                "investmentDetails": {
                    "class": isFieldValueNull(investmentDetailsData.classOrPlan),
                    "contribAgrmntDt": isFieldValueNull(investmentDetailsData.contributionAgreementDate),
                    "schemeCode": isFieldValueNull(investmentDetailsData.schemeCode),
                    "schemeIsinNo": isFieldValueNull(investmentDetailsData.schemeIsinNumber),
                    "schemeName": isFieldValueNull(investmentDetailsData.schemeName),
                    "transactionType": isFieldValueNull(investmentDetailsData.transactionType),
                },
                "paymentBankDetails": {
                    "primaryHolderPaymentBank": paymentHolderArray(contributionDetailsData.paymentBankDetails[0]),
                    "secondaryHolderPaymentBank": paymentHolderArray(contributionDetailsData.paymentBankDetails[1]),
                    "thirdHolderPaymentBank": paymentHolderArray(contributionDetailsData.paymentBankDetails[2]),
                },
                "transactionContribNo": transactionContribNo,
            },
            "kartaDetails": kartaDetailsList.map((karta) => {
                return {
                    "dob": isFieldValueNull(karta.dateOfBirth),
                    "gender": isFieldValueNull(karta.gender),
                    "isPep": karta.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(karta.name),
                    "taxIdNo": isFieldValueNull(karta.panOrTaxIdNumber),
                };
            }),
            "lastUpdatedBy": "",
            "lastUpdatedDate": "",
            "lastUpdatedFrom": "",
            "makerId": makerId,
            "nomineeDetails": {
                "noOfNominees": isFieldValueNull(nomineeDetailsData.numberOfNominees),
                "nominees": nominees.length > 0 ? 
                    nominees.map((nomineeData) => {
                        return {
                            "allocationPercent": isFieldValueNull(nomineeData.allocationPercentage),
                            "dtOfBirth": isFieldValueNull(nomineeData.dateOfBirth),
                            "emailId": nomineeData.emailId ? [nomineeData.emailId] : [],
                            "guardianIdNo": isFieldValueNull(nomineeData.guardianIdNumber),
                            "guardianMinorNomineeRelatshp": isFieldValueNull(nomineeData.guardianRelationshipWithMinorNominee),
                            "guardianName": isFieldValueNull(nomineeData.guardianName),
                            "mobNo": nomineeData.mobileNumber ? [nomineeData.mobileNumberPrefix + " " + nomineeData.mobileNumber] : [],
                            "nomineeIdProofNo": isFieldValueNull(nomineeData.nomineeIdProofNumber),
                            "nomineeName": isFieldValueNull(nomineeData.name),
                            "nomineeRelatshp": isFieldValueNull(nomineeData.nomineeRelationShip),
                        };
                    }) : [],
            },
            "partnerDetails": partnerInfo.map((partnerData) => {
                return {
                    "dob": isFieldValueNull(partnerData.partnerDateOfBirth),
                    "gender": isFieldValueNull(partnerData.partnerGender),
                    "isPep": partnerData.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(partnerData.partnerName),
                    "taxIdNo": isFieldValueNull(partnerData.partnerPan),
                };
            }),
            "poa": {
                "authorisedSignatories": [],
                "city": isFieldValueNull(powerOfAttorneyDetailsData.city),
                "country": isFieldValueNull(powerOfAttorneyDetailsData.country),
                "dob": basicDetailsData.investorType === "Individual" ? isFieldValueNull(powerOfAttorneyDetailsData.dateOfBirth) : null,
                "incDt": basicDetailsData.investorType === "Individual" ? null : isFieldValueNull(powerOfAttorneyDetailsData.dateOfBirth),
                "landlineNo": isFieldValueNull(powerOfAttorneyDetailsData.landlineNumber),
                "nameOfPoa": isFieldValueNull(powerOfAttorneyDetailsData.name),
                "panValidatedOn": null,
                "pincode": isFieldValueNull(powerOfAttorneyDetailsData.pinCode),
                "poaAddr1": isFieldValueNull(powerOfAttorneyDetailsData.permanentAddress1),
                "poaAddr2": isFieldValueNull(powerOfAttorneyDetailsData.address2),
                "poaAddr3": isFieldValueNull(powerOfAttorneyDetailsData.address3),
                "poaCkycNo": isFieldValueNull(powerOfAttorneyDetailsData.kinOrCkycNumber),
                "poaEmailIds": powerOfAttorneyDetailsData.emailId ? [powerOfAttorneyDetailsData.emailId] : [],
                "poaMobNo": powerOfAttorneyDetailsData.mobileNumber ? [powerOfAttorneyDetailsData.mobileNumberPrefix + " " + powerOfAttorneyDetailsData.mobileNumber] : [],
                "poaTaxIdNo": isFieldValueNull(powerOfAttorneyDetailsData.panOrTaxIdNumber),
                "poaType": isFieldValueNull(powerOfAttorneyDetailsData.type),
                "state": isFieldValueNull(powerOfAttorneyDetailsData.state)
            },
            "primaryHolderDetails": {
                "aadharNo": isFieldValueNull(primaryHolderDetailsData.aadharNumber),
                "accreditationNo": isFieldValueNull(primaryHolderDetailsData.accreditationNumber),
                "accreditationValidityDt": isFieldValueNull(primaryHolderDetailsData.accreditationValidityDate),
                "ckycNo": isFieldValueNull(primaryHolderDetailsData.ckycOrKinNumber),
                "correspondenceAddrDetails": [
                    {
                        "addr1": isFieldValueNull(primaryHolderDetailsData.correspondenceAddress1),
                        "addr2": isFieldValueNull(primaryHolderDetailsData.correspondenceAddress2),
                        "addr3": isFieldValueNull(primaryHolderDetailsData.correspondenceAddress3),
                        "city": isFieldValueNull(primaryHolderDetailsData.correspondenceCity),
                        "country": isFieldValueNull(primaryHolderDetailsData.correspondenceCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(primaryHolderDetailsData.correspondencePincode),
                        "state": isFieldValueNull(primaryHolderDetailsData.correspondenceState),
                    },
                ],
                "fatherName": primaryHolderDetailsData.fatherOrSpouseNameFlag === "Father" ? isFieldValueNull(primaryHolderDetailsData.fatherOrSpouseName) : null,
                "fatherOrSpouseNameFlag": isFieldValueNull(primaryHolderDetailsData.fatherOrSpouseNameFlag),
                "gender": isFieldValueNull(primaryHolderDetailsData.gender),
                "motherName": isFieldValueNull(primaryHolderDetailsData.motherName),
                "name": isFieldValueNull(primaryHolderDetailsData.nameOfPrimaryHolder),
                "overseasAddrDetails": [
                    {
                        "addr1": isFieldValueNull(primaryHolderDetailsData.overseasAddress1),
                        "addr2": isFieldValueNull(primaryHolderDetailsData.overseasAddress2),
                        "addr3": isFieldValueNull(primaryHolderDetailsData.overseasAddress3),
                        "city": isFieldValueNull(primaryHolderDetailsData.overseasCity),
                        "country": isFieldValueNull(primaryHolderDetailsData.overseasCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(primaryHolderDetailsData.overseasPincode),
                        "state": isFieldValueNull(primaryHolderDetailsData.overseasState),
                    },
                ],
                "passportExpiryDt": isFieldValueNull(primaryHolderDetailsData.passportExpiryDate),
                "passportNo": isFieldValueNull(primaryHolderDetailsData.passportNumber),
                "permanentAddrDetails": [
                    {
                        "addr1": isFieldValueNull(primaryHolderDetailsData.permanentAddress1),
                        "addr2": isFieldValueNull(primaryHolderDetailsData.permanentAddress2),
                        "addr3": isFieldValueNull(primaryHolderDetailsData.permanentAddress3),
                        "city": isFieldValueNull(primaryHolderDetailsData.permanentCity),
                        "correspAddrSimilarityFlag": primaryHolderDetailsData.sameAsPermanentAddress === "Yes",
                        "country": isFieldValueNull(primaryHolderDetailsData.permanentCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(primaryHolderDetailsData.permanentPincode),
                        "state": isFieldValueNull(primaryHolderDetailsData.permanentState),
                    },
                ],
                "salutation": isFieldValueNull(primaryHolderDetailsData.nameOfPrimaryHolderPrefix),
                "spouseName": primaryHolderDetailsData.fatherOrSpouseNameFlag === "Father" ? null : isFieldValueNull(primaryHolderDetailsData.fatherOrSpouseName),
            },
            "processCode": processCode,
            "promoterDetails": promoterDetails.map((promoter) => {
                return {
                    "dob": isFieldValueNull(promoter.dateOfBirth),
                    "gender": isFieldValueNull(promoter.gender),
                    "isPep": promoter.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(promoter.name),
                    "taxIdNo": isFieldValueNull(promoter.panOrTaxIdNumber),
                };
            }),
            "qualityCheckerId": qualityCheckerId,
            "role": userRole,
            "secondaryHolderDetails": {
                "aadharLinkedOn": null, //(will contain the date sent by ITD API)
                "aadharNo": isFieldValueNull(holderDetails[0].aadharNumber),
                "ckycNo": isFieldValueNull(holderDetails[0].ckycOrKinNumber),
                "correspondenceAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[0].correspondenceAddress1),
                        "addr2": isFieldValueNull(holderDetails[0].correspondenceAddress2),
                        "addr3": isFieldValueNull(holderDetails[0].correspondenceAddress3),
                        "city": isFieldValueNull(holderDetails[0].correspondenceCity),
                        "country": isFieldValueNull(holderDetails[0].correspondenceCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(holderDetails[0].correspondencePincode),
                        "state": isFieldValueNull(holderDetails[0].correspondenceState),
                    },
                ],
                "dob": isFieldValueNull(holderDetails[0].dateOfBirth),
                "emailIds": [
                    {
                        "emailId": isFieldValueNull(holderDetails[0].emailId),
                        "emailIdPertainTo": null,
                    }
                ],
                "fatherName": holderDetails[0].fatherOrSpouseNameFlag === "Father" ? isFieldValueNull(holderDetails[0].fatherOrSpouseName) : null,
                "fatherOrSpouseNameFlag": isFieldValueNull(holderDetails[0].fatherOrSpouseNameFlag),
                "gender": isFieldValueNull(holderDetails[0].gender),
                "isAadharLinked": false, //(will contain the value sent by ITD API for aadharLink status)
                "mobNo": [
                    {
                        "mobNo": isFieldValueNull(holderDetails[0].mobileNumberPrefix + " " + holderDetails[0].mobileNumber),
                        "mobNoPertainTo": null,
                    }
                ],
                "motherName": isFieldValueNull(holderDetails[0].motherName),
                "name": isFieldValueNull(holderDetails[0].name),
                "overseasAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[0].overseasAddress1),
                        "addr2": isFieldValueNull(holderDetails[0].overseasAddress2),
                        "addr3": isFieldValueNull(holderDetails[0].overseasAddress3),
                        "city": isFieldValueNull(holderDetails[0].overseasCity),
                        "country": isFieldValueNull(holderDetails[0].overseasCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(holderDetails[0].overseasPincode),
                        "state": isFieldValueNull(holderDetails[0].overseasState),
                    },
                ],
                "panValidatedOn": null, //(today's date i.e., when KRA API is called)
                "passportExpiryDt": isFieldValueNull(holderDetails[0].passportExpiryDate),
                "passportNo": isFieldValueNull(holderDetails[0].passportNumber),
                "permanentAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[0].permanentAddress1),
                        "addr2": isFieldValueNull(holderDetails[0].permanentAddress2),
                        "addr3": isFieldValueNull(holderDetails[0].permanentAddress3),
                        "city": isFieldValueNull(holderDetails[0].permanentCity),
                        "correspAddrSimilarityFlag": holderDetails[0].sameAsPermanentAddress === "Yes",
                        "country": isFieldValueNull(holderDetails[0].permanentCountry),
                        "landlineNo": isFieldValueNull(holderDetails[0].landlineNumber),
                        "pincode": isFieldValueNull(holderDetails[0].permanentPincode),
                        "state": isFieldValueNull(holderDetails[0].permanentState),
                    },
                ],
                "relatshpWithPrimaryHolder": isFieldValueNull(holderDetails[0].relationshipWithPrimaryHolder),
                "salutation": isFieldValueNull(holderDetails[0].namePrefix),
                "spouseName": holderDetails[0].fatherOrSpouseNameFlag === "Father" ? null : isFieldValueNull(holderDetails[0].fatherOrSpouseName),
                "taxId": isFieldValueNull(holderDetails[0].panOrTaxIdNumber),
                "taxStatus": isFieldValueNull(holderDetails[0].holderTaxStatus),
            },
            "sipReg": [
                {
                    "endorsedFlag": false,
                    "otmDetails": {
                        "primaryInvOtm": otmDetails[0].map((primary) => {
                            return {
                                "accNo": isFieldValueNull(primary.bankAccountNumber),
                                "accType": isFieldValueNull(primary.accountType),
                                "bankName": isFieldValueNull(primary.bankName),
                                "debitType": isFieldValueNull(primary.debitType),
                                "fromDt": isFieldValueNull(primary.fromDate),
                                "ifsc": isFieldValueNull(primary.ifscCode),
                                "isOtmBankDetailsPrimaryDetails": primary.isOTMMatchedWithBankDetails === "Yes",
                                "lastFourDigitsOfRegBankAccNo": isFieldValueNull(primary.lastFourAccountNumber),
                                "micr": isFieldValueNull(primary.micrCode),
                                "otmAmt": isFieldValueNull(primary.otmAmount),
                                "pennyDropStatus": null,
                                "pennyDropValidationDt": null,
                                "sponsorBankCode": isFieldValueNull(primary.sponsorBankCode),
                                "toDt": isFieldValueNull(primary.toDate),
                                "uniqRefNo": isFieldValueNull(primary.uniqueReferenceNumber),
                                "utilityCode": isFieldValueNull(primary.utilityCode),
                            };
                        }),
                        "secondaryHolderOtm": otmDetails[1] ?
                            otmDetails[1].map((secondary) => {
                                return {
                                    "accNo": isFieldValueNull(secondary.bankAccountNumber),
                                    "accType": isFieldValueNull(secondary.accountType),
                                    "bankName": isFieldValueNull(secondary.bankName),
                                    "debitType": isFieldValueNull(secondary.debitType),
                                    "fromDt": isFieldValueNull(secondary.fromDate),
                                    "ifsc": isFieldValueNull(secondary.ifscCode),
                                    "isOtmBankDetailsPrimaryDetails": secondary.isOTMMatchedWithBankDetails === "Yes",
                                    "lastFourDigitsOfRegBankAccNo": isFieldValueNull(secondary.lastFourAccountNumber),
                                    "micr": isFieldValueNull(secondary.micrCode),
                                    "otmAmt": isFieldValueNull(secondary.otmAmount),
                                    "pennyDropStatus": null,
                                    "pennyDropValidationDt": null,
                                    "sponsorBankCode": isFieldValueNull(secondary.sponsorBankCode),
                                    "toDt": isFieldValueNull(secondary.toDate),
                                    "uniqRefNo": isFieldValueNull(secondary.uniqueReferenceNumber),
                                    "utilityCode": isFieldValueNull(secondary.utilityCode),
                                };
                            })
                            : [],
                        "thirdHolderOtm": otmDetails[2] ?
                            otmDetails[2].map((third) => {
                                return {
                                    "accNo": isFieldValueNull(third.bankAccountNumber),
                                    "accType": isFieldValueNull(third.accountType),
                                    "bankName": isFieldValueNull(third.bankName),
                                    "debitType": isFieldValueNull(third.debitType),
                                    "fromDt": isFieldValueNull(third.fromDate),
                                    "ifsc": isFieldValueNull(third.ifscCode),
                                    "isOtmBankDetailsPrimaryDetails": third.isOTMMatchedWithBankDetails === "Yes",
                                    "lastFourDigitsOfRegBankAccNo": isFieldValueNull(third.lastFourAccountNumber),
                                    "micr": isFieldValueNull(third.micrCode),
                                    "otmAmt": isFieldValueNull(third.otmAmount),
                                    "pennyDropStatus": null,
                                    "pennyDropValidationDt": null,
                                    "sponsorBankCode": isFieldValueNull(third.sponsorBankCode),
                                    "toDt": isFieldValueNull(third.toDate),
                                    "uniqRefNo": isFieldValueNull(third.uniqueReferenceNumber),
                                    "utilityCode": isFieldValueNull(third.utilityCode),
                                };
                            })
                            : [],
                    },
                    "sipDetails": {
                        "endDt": isFieldValueNull(sipDetailsData.endDate),
                        "installmentAmt": isFieldValueNull(sipDetailsData.instalmentAmount),
                        "nofInstallments": isFieldValueNull(sipDetailsData.numberOfInstalments),
                        "sipFreq": isFieldValueNull(sipDetailsData.sipFrequency),
                        "startDt": isFieldValueNull(sipDetailsData.startDate),
                    },
                    "transactionSipNo": transactionSipNo,
                },
            ],
            "sourceUser": sourceUser,
            "stageCode": stageCode,
            "thirdHolderDetails": {
                "aadharLinkedOn": null, //(will contain the date sent by ITD API)
                "aadharNo": isFieldValueNull(holderDetails[1] && holderDetails[1]?.aadharNumber),
                "ckycNo": isFieldValueNull(holderDetails[1] && holderDetails[1]?.ckycOrKinNumber),
                "correspondenceAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceAddress1),
                        "addr2": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceAddress2),
                        "addr3": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceAddress3),
                        "city": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceCity),
                        "country": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondencePincode),
                        "state": isFieldValueNull(holderDetails[1] && holderDetails[1]?.correspondenceState),
                    },
                ],
                "dob": isFieldValueNull(holderDetails[1] && holderDetails[1]?.dateOfBirth),
                "emailIds": [
                    {
                        "emailId": isFieldValueNull(holderDetails[1] && holderDetails[1]?.emailId),
                        "emailIdPertainTo": null,
                    }
                ],
                "fatherName": holderDetails[1]?.fatherOrSpouseNameFlag === "Father" ? isFieldValueNull(holderDetails[1]?.fatherOrSpouseName) : null,
                "fatherOrSpouseNameFlag": isFieldValueNull(holderDetails[1]?.fatherOrSpouseNameFlag),
                "gender": isFieldValueNull(holderDetails[1] && holderDetails[1]?.gender),
                "isAadharLinked": false, //(will contain the value sent by ITD API for aadharLink status)
                "mobNo": [
                    {
                        "mobNo": isFieldValueNull(holderDetails[1]?.mobileNumberPrefix + " " + holderDetails[1]?.mobileNumber),
                        // "mobNo": isFieldValueNull(holderDetails[1] && holderDetails[1]?.mobileNumberPrefix + " " + holderDetails[1] && holderDetails[1]?.mobileNumber),
                        "mobNoPertainTo": null,
                    }
                ],
                "motherName": isFieldValueNull(holderDetails[1] && holderDetails[1]?.motherName),
                "name": isFieldValueNull(holderDetails[1] && holderDetails[1]?.name),
                "overseasAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasAddress1),
                        "addr2": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasAddress2),
                        "addr3": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasAddress3),
                        "city": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasCity),
                        "country": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasCountry),
                        "landlineNo": null,
                        "pincode": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasPincode),
                        "state": isFieldValueNull(holderDetails[1] && holderDetails[1]?.overseasState),
                    },
                ],
                "panValidatedOn": null, //(today's date i.e., when KRA API is called)
                "passportExpiryDt": isFieldValueNull(holderDetails[1] && holderDetails[1]?.passportExpiryDate),
                "passportNo": isFieldValueNull(holderDetails[1] && holderDetails[1]?.passportNumber),
                "permanentAddrDetails": [
                    {
                        "addr1": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentAddress1),
                        "addr2": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentAddress2),
                        "addr3": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentAddress3),
                        "city": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentCity),
                        "correspAddrSimilarityFlag": holderDetails[0].sameAsPermanentAddress === "Yes",
                        "country": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentCountry),
                        "landlineNo": isFieldValueNull(holderDetails[1] && holderDetails[1]?.landlineNumber),
                        "pincode": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentPincode),
                        "state": isFieldValueNull(holderDetails[1] && holderDetails[1]?.permanentState),
                    },
                ],
                "relatshpWithPrimaryHolder": isFieldValueNull(holderDetails[1] && holderDetails[1]?.relationshipWithPrimaryHolder),
                "salutation": isFieldValueNull(holderDetails[1] && holderDetails[1]?.namePrefix),
                "spouseName": holderDetails[1]?.fatherOrSpouseNameFlag === "Father" ? null : isFieldValueNull(holderDetails[1]?.fatherOrSpouseName),
                "taxId": isFieldValueNull(holderDetails[1] && holderDetails[1]?.panOrTaxIdNumber),
                "taxStatus": isFieldValueNull(holderDetails[1] && holderDetails[1]?.holderTaxStatus),
            },
            "transactionCode": transactionTypeCode,
            "transactionNo": transactionNo,
            "transactionTypeName": transactionTypeName,
            "trusteeDetails": trusteeDetails.map((trusteeData) => {
                return {
                    "dob": isFieldValueNull(trusteeData.dateOfBirth),
                    "gender": isFieldValueNull(trusteeData.gender),
                    "isPep": trusteeData.politicallyExposedPerson === "Yes",
                    "name": isFieldValueNull(trusteeData.name),
                    "taxIdNo": isFieldValueNull(trusteeData.panOrTaxIdNumber),
                };
            }),
            "uboDeclaration": {
                "trustType": isFieldValueNull(uboDetailsData.trustType),
                "uboCategory": uboDetailsData.uboCategory === "Others" ? 
                    isFieldValueNull(uboDetailsData.otherUboCategory) : 
                    isFieldValueNull(uboDetailsData.uboCategory),
                "uboDetails": ubos.map((ubo) => {
                    return {
                        "address": isFieldValueNull(ubo.address),
                        "addressType": isFieldValueNull(ubo.addressType),
                        "cityOfBirth": isFieldValueNull(ubo.cityOfBirth),
                        "country": isFieldValueNull(ubo.country),
                        "ctryOfBirth": isFieldValueNull(ubo.countryOfBirth),
                        "ctryOfTaxRes": isFieldValueNull(ubo.countryOfTaxResidency),
                        "dob": isFieldValueNull(ubo.dateOfBirth),
                        "fatherName": isFieldValueNull(ubo.fathersName),
                        "gender": isFieldValueNull(ubo.gender),
                        "isPep": ubo.politicallyExposedPerson === "Yes",
                        "nameOfUbo": isFieldValueNull(ubo.name),
                        "nationality": isFieldValueNull(ubo.nationality),
                        "occupationType": (ubo.occupationType === "Others") 
                            ? isFieldValueNull(ubo.otherOccupationType) 
                            : isFieldValueNull(ubo.occupationType),
                        "percentOfHolding": isFieldValueNull(ubo.percentageOfHolding),
                        "state": isFieldValueNull(ubo.state),
                        "taxIdNo": isFieldValueNull(ubo.panTaxIdNo),
                        "taxIdType": isFieldValueNull(ubo.taxIdType),
                        "uboCode": isFieldValueNull(ubo.uboCode),
                        "zipCode": isFieldValueNull(ubo.pincode)
                    };
                }),
            },            
            "userId": userId,
        };
        console.log(data, "post investor payload");

        const axiosConfig = {
            "data": data,
            "url": "/investor",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postInvestor;
}

export default usePostInvestor;
