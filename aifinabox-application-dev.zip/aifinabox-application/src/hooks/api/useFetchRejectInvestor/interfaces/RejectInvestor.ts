interface RejectInvestorType {
}

export default RejectInvestorType;
