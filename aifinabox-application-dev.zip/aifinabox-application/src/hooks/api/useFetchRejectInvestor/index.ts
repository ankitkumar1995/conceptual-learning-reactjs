import {
    GetInvestorResponseType,
    InvestorInfo,
    getInvestorInfo
} from "../useGetInvestor";
import { useDispatch, useSelector } from "react-redux";

import GetInvestorType from "../useGetInvestor/interfaces/GetInvestor.types";
import { RootState } from "../../../redux/store";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

function useFetchRejectInvestor() {
    const dispatch = useDispatch();

    let investorInfo: InvestorInfo ;
    let txnType = "", txnCode = "";
    let transactionContribNo = "";
    let transactionSipNo = "";
    
    const uboCategoryMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .uboCategoryMenuItems
    );

    const OccupationDetailsMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
                .holderOccupationDetailsMenuItems
    );

    const occupationTypeMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
                .occupationTypeMenuItems
    );

    const fetchInvestorDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<GetInvestorResponseType> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/investorreject?transactionNo=${transactionNo}&clientId=${clientId}&role=${role}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data?.rejectedDetails;
                const investorDetailsFromApi: GetInvestorType = responseData[0];

                investorInfo = getInvestorInfo(investorDetailsFromApi, uboCategoryMenuItems, OccupationDetailsMenuItems, occupationTypeMenuItems);

                txnCode = investorDetailsFromApi.transactionCode ?? "";                                     
                txnType = investorDetailsFromApi.transactionTypeName ?? investorDetailsFromApi.transactionType ?? "";     
                transactionContribNo = investorDetailsFromApi?.initialContribution?.transactionContribNo ?? "";
                transactionSipNo = investorDetailsFromApi?.sipReg[0]?.transactionSipNo ?? "";
            
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "investorDetailsForms": investorInfo.investorDetails,
            "transactionContribNo": transactionContribNo,
            "transactionSipNo": transactionSipNo,
            "txnCode": txnCode,
            "txnType": txnType,
            "userIds": investorInfo.userIds,
        }; 
    };

    return fetchInvestorDetails;
}

export default useFetchRejectInvestor;
