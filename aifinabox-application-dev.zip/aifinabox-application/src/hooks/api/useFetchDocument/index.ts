import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchDocument () {
    const dispatch = useDispatch();

    const fetchDocument = async (
        transactionNo: string
    ): Promise<{
        "mimeType": string;
        "url": string;
    }> => {
        dispatch(setOpenBackdrop(true));

        let resUrl: string = "";
        let resMimeType: string = "";

        const axiosConfig = {
            "url": `/transactiondocument?transactionNo=${transactionNo}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => { 
                const responseData = response.data;
                const responseBody = responseData.body;
                const result = JSON.parse(responseBody);
                resUrl = result.url;
                resMimeType = result.mimeType;
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
        
        dispatch(setOpenBackdrop(false));

        return {
            "mimeType": resMimeType,
            "url": resUrl,
        };
    };

    return fetchDocument;
};

export default useFetchDocument;
