import { 
    InitialContributionInfo, 
    UserIdsType, 
    getInitialContributionInfo 
} from "../useGetInitialContribution";
import { TopUpInfo, fetchTopUpInfo } from "../useFetchTopUp";
import { useDispatch, useSelector } from "react-redux";

import GetInvestorType from "../useGetInvestor/interfaces/GetInvestor.types";
import { 
    MakerInitialContributionDetails 
} from "../../../redux/InitiateTransaction/InitialContribution/Maker/Forms/initialState";
import { NigoDataResponse } from "./interfaces/TopUpNigo.types";
import { TopUpDetails } from "../../../redux/InitiateTransaction/TopUp/Maker/Forms/initialState";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

interface Result {
    "nigoData": NigoDataResponse[];
    "qcData": TopUpDetails;
    "userIds": UserIdsType;
}

function useFetchNigoDataTopUp() {
    const dispatch = useDispatch();
    
    let topUpInfo: TopUpInfo ;

    const fetchTopUpDetails = async (
        transactionNo: string,
        userId: string,
        role: string,
        clientId: string,
        processCode: string,
        stageCode: string,
    ): Promise<Result> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/initcontrib?transactionNo=${transactionNo}&role=${role}&userId=${userId}&clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}`,
        };

        let nigoResponse: NigoDataResponse[] = [];

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                nigoResponse = responseData[0].QC;

                const investorDetailsFromApi = responseData[1];
                
                topUpInfo = fetchTopUpInfo(investorDetailsFromApi);
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "nigoData": nigoResponse,
            "qcData": topUpInfo.topUpDetails,
            "userIds": topUpInfo.userIds,
        }; 
    };

    return fetchTopUpDetails;
}

export default useFetchNigoDataTopUp;
