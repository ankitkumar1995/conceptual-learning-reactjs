import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function useFetchBatchNumber() {
    const dispatch = useDispatch();

    const fetchBatchNumber = async (
        seriesCode: string,
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        let batchNumber:string = "";

        const axiosConfig = {
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT2}/sequencenumber?seriesCode=${seriesCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                batchNumber = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return batchNumber;
    };

    return fetchBatchNumber;
}

export default useFetchBatchNumber;
