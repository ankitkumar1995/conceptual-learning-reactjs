import masterAxiosInstance from "../../../axios/instances/masterFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface BankNameData {
    "address_line_01": string;
    "bank_name": string;
    "city_name": string;
    "micr_number": string;
    "bankAddress"?: string;
}

function useFetchBankName() {
    const dispatch = useDispatch();

    const fetchBankName = async ( bankIfscRtgsCode: string ): Promise<BankNameData> => {
        dispatch(setOpenBackdrop(true));

        let bankAccounts: BankNameData = {
            "address_line_01": "",
            "bankAddress": "",
            "bank_name": "",
            "city_name": "",
            "micr_number": ""
        };

        const axiosConfig = {
            "url": `/bankname?ifsc=${bankIfscRtgsCode}`,
        };

        await masterAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = JSON.parse(response.data.body);
                bankAccounts = responseData.result[0];
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return bankAccounts; 
    };

    return fetchBankName;
}

export default useFetchBankName;
