import { ContactMasterDetails } from "../../../redux/AifMaster/ContactMaster/Maker/initialState";
import {
    UpdateState
} from "../../../pages/AIFMaster/ContactMaster/Maker/MakerContactMasterForm/helpers/initializeUpdateState";

import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

const mergeString = (prefix:string,name:string) => {
    const merge = prefix + "" + name;
    if (merge.length === 0){
        return "";
    }
    return prefix + " " + name;
    
};

function usePostContactMaster() {
    const dispatch = useDispatch();

    const postContactMaster = async (
        contactMasterDetails: ContactMasterDetails,
        sourceUser: string,
        updateFlag: "1" | "0",
        userId: string,
        userRole: "C" | "M",
        updateStatus: UpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "aifDialCode": contactMasterDetails.aifContactNumberPrefix,
            "clientCode": contactMasterDetails.clientCode,
            "clientName": contactMasterDetails.aifCompanyName,
            "clientType": contactMasterDetails.clientType,
            "complianceOfficeContact": {
                "updated": updateStatus.complianceOfficeContact,
                "value": contactMasterDetails.complianceOfficeContact,
            },
            "complianceOfficeDesignation": {
                "updated": updateStatus.complianceOfficeDesignation,
                "value": contactMasterDetails.complianceOfficeDesignation,
            },
            "complianceOfficeDialCode": contactMasterDetails.complianceOfficeContactPrefix,
            "complianceOfficeEmailId": {
                "updated": updateStatus.complianceOfficeEmailId,
                "value": contactMasterDetails.complianceOfficeEmailId,
            },
            "complianceOfficeName": {
                "updated": updateStatus.complianceOfficeName || updateStatus.complianceOfficeName,
                "value": mergeString(contactMasterDetails.complianceOfficeNamePrefix, contactMasterDetails.complianceOfficeName)
            },
            "contactNoOfAIF": {
                "updated": updateStatus.aifContactNumber,
                "value": contactMasterDetails.aifContactNumber,
            },
            "contactPersonDesignation": "Prime",
            "contactPersonName": {
                "updated": updateStatus.contactPersonNamePrefix || updateStatus.contactPersonName,
                "value": mergeString(contactMasterDetails.contactPersonNamePrefix, contactMasterDetails.contactPersonName)
            },
            "emailIdOfAIF": {
                "updated": updateStatus.aifEmailId,
                "value": contactMasterDetails.aifEmailId,
            },
            "entryDate": currentData,
            "role": userRole,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "spoc1ContactNo": {
                "updated": updateStatus.spoc1ContactNumber,
                "value": contactMasterDetails.spoc1ContactNumber,
            },
            "spoc1Designation": "SPOC1",
            "spoc1DialCode": contactMasterDetails.spoc1ContactNumberPrefix,
            "spoc1EmailId": {
                "updated": updateStatus.spoc1EmailId,
                "value": contactMasterDetails.spoc1EmailId,
            },
            "spoc1Name": {
                "updated": updateStatus.spoc1NamePrefix || updateStatus.spoc1Name,
                "value": mergeString(contactMasterDetails.spoc1NamePrefix, contactMasterDetails.spoc1Name)
            },
            "spoc1Role": "SPOC1",
            "spoc2ContactNo": {
                "updated": updateStatus.spoc2ContactNumber,
                "value": contactMasterDetails.spoc2ContactNumber,
            },
            "spoc2Designation": "SPOC2",
            "spoc2DialCode": contactMasterDetails.spoc2ContactNumberPrefix,
            "spoc2EmailId": {
                "updated": updateStatus.spoc2EmailId,
                "value": contactMasterDetails.spoc2EmailId,
            },
            "spoc2Name": {
                "updated": updateStatus.spoc2NamePrefix || updateStatus.spoc2Name,
                "value": mergeString(contactMasterDetails.spoc2NamePrefix, contactMasterDetails.spoc2Name)
            },
            "spoc2Role": "SPOC2",
            "spoc3ContactNo": {
                "updated": updateStatus.spoc3ContactNumber,
                "value": contactMasterDetails.spoc3ContactNumber,
            },
            "spoc3Designation": "SPOC3",
            "spoc3DialCode": contactMasterDetails.spoc3ContactNumberPrefix,
            "spoc3EmailId": {
                "updated": updateStatus.spoc3EmailId,
                "value": contactMasterDetails.spoc3EmailId,
            },
            "spoc3Name": {
                "updated": updateStatus.spoc3NamePrefix || updateStatus.spoc3Name,
                "value": mergeString(contactMasterDetails.spoc3NamePrefix,contactMasterDetails.spoc3Name)
            },
            "spoc3Role": "SPOC3",
            "updateFlag": updateFlag,
            // "userId": userRole === "C" ? "2001" : "1001"
            "userId": userId
        };
        
        const axiosConfig = {
            "data": data,
            "url": "/contactmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });
            
        dispatch(setOpenBackdrop(false));
    };

    return postContactMaster;
}

export default usePostContactMaster;
