import { 
    PlanMasterDetails, 
    initialPlanMasterDetailsFormState 
} from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { nanoid } from "@reduxjs/toolkit";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";
interface IObjData {
    update: boolean;
    value: string;
}
export interface FundCodeData {
    fundCode: string;
    // fundName: IObjData;
    fundName: string;
    id: string;
}

interface FundResponse {
    [x: string]: any;
    fundCodeData: MenuItem[];
    fundData: FundCodeData[];
}

export function initializeFundCodeData(): FundCodeData {
    return {
        "fundCode": "",
        // "fundName": {"update": false,"value": ""},
        "fundName": "",
        "id": "",
    };
}

function useFetchFundCodeDetails() {
    const dispatch = useDispatch();

    let fundCodeData: MenuItem[] = [];
    let fundData: FundCodeData[]  = [];
    let finalResult: FundResponse = {
        "fundCodeData": [],
        "fundData": []
    };
    const fetchFundCodeDetails = async (
        clientCode: string,
        role: "C" | "M",
    ): Promise<FundResponse> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/fundcodedetails?clientCode=${clientCode}&role=${role}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const planMasterMakerEntryFromApi = responseData;
                fundCodeData=responseData.map((data: FundCodeData) => ({"label": data.fundCode,
                    "value": data.fundCode,}) as MenuItem);
                fundData=responseData.map((data: FundCodeData)=>({...data, "id": nanoid()}));
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        finalResult = {fundCodeData, fundData};
        return finalResult; 
    };

    return fetchFundCodeDetails;
}

export default useFetchFundCodeDetails;
