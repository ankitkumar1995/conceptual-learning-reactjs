import {
    PaymentBankDetails,
    TopUpDetails
} from "../../../redux/InitiateTransaction/TopUp/Maker/Forms/initialState";
import { useDispatch, useSelector } from "react-redux";

import { RootState } from "../../../redux/store";
import initiateTransactionPostAxiosInstance from "../../../axios/instances/initiateTransactionPostAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";

const isFieldValueNull = (field: string | null) => {
    if (field === null || field === undefined ||  (typeof field === "string" && field?.trim() === "")) 
        return null;
    else
        return field;
};

function usePostTopUp() {
    const dispatch = useDispatch();

    const postTopUp = async (
        topUpState: TopUpDetails,
        sourceUser: string,
        userId: string,
        clientId: string,
        clientName: string,
        userRole: "C" | "M" | "Q" | "A",
        processCode: string,
        stageCode: string,
        updateFlag: string,
        transactionNo: string,
        topUpUpdateDocumentFormat?: string,
        topUpUpdateDocumentPath?: string,
        topUpUpdateDocumentSize?: number,
    ) => {
        dispatch(setOpenBackdrop(true));

        const paymentHolderArray = (holder: PaymentBankDetails) => {
            return {
                "foreignBankAccount": holder ?
                    [
                        {
                            "lastFourDigitsOfRegForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAddr": isFieldValueNull(holder?.paymentBankAddress),
                            "paymentBankBranch": isFieldValueNull(holder?.paymentBankBranch),
                            "paymentBankIbanCode": isFieldValueNull(holder?.paymentBankIbanCode),
                            "paymentBankName": isFieldValueNull(holder?.paymentBankName),
                            "paymentBankSwiftAndBic": isFieldValueNull(holder?.swiftOrBicCode),
                            "paymentForeignBankAccType": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.accountType) : null,
                            "regPaymentForeignBankAccNo": holder?.isForeignBankAccount === "Yes" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                        }
                    ] : [],
                "isForeignBankAcct": isFieldValueNull(holder?.isForeignBankAccount),
                "nationalBankAccount": holder ?
                    [
                        {
                            "lastFourDigOfRegBankAccountNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.lastFourDigitsOfAccountNumber) : null,
                            "paymentBankAccName": isFieldValueNull(holder?.paymentBankAccountName),
                            "paymentBankAccNo": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.paymentBankAccountNumber) : null,
                            "paymentBankAccType": holder?.isForeignBankAccount === "No" ? isFieldValueNull(holder?.accountType) : null,
                            "paymentBankChqRefNo": holder?.paymentChequeDetails.map((cheque) => {
                                return {
                                    "chequeAmount": isFieldValueNull(cheque.chequeAmount),
                                    "chequeRefNo": isFieldValueNull(cheque.chequeReferenceNumber)
                                };
                            }),
                            "paymentBankIfsc": isFieldValueNull(holder?.paymentBankIfscCode),
                            "paymentBankMicr": isFieldValueNull(holder?.micrCode),
                            "paymentBankPennyDropStatus": isFieldValueNull(holder?.pennyDropStatus),
                            "paymentBankUtrNo": isFieldValueNull(holder?.paymentBankUtrNumber),
                            "paymentType": isFieldValueNull(holder?.paymentType),
                            "pennyDropValidationDt": isFieldValueNull(holder?.pennyDropValidationDate),
                        }
                    ] : [],
                "paymentBankIsRegBank": holder?.isForeignBankAccount === "No" 
                    ? isFieldValueNull(holder?.sameAsRegisteredBank)
                    : null,
            };
        };
        
        const data = {
            "accreditationFlag": topUpState.accreditationFlag,
            "allotmentMode": {
                "clientId": isFieldValueNull(topUpState.allotmentModeClientId),
                "dPId": isFieldValueNull(topUpState.dpId),
                "modeOfAllotment": isFieldValueNull(topUpState.allotmentMode),
                "repositoryType": isFieldValueNull(topUpState.repositoryType),
            },
            "clientId": isFieldValueNull(clientId),
            "clientName": isFieldValueNull(clientName),
            "contributionDetails": {
                "exchngRate": isFieldValueNull(topUpState.exchangeRate),
                "existingCommitmentAmt": isFieldValueNull(topUpState.existingCommitmentAmount),
                "fundBusinessType": isFieldValueNull(topUpState.fundBusinessType), // need to fetch from fund details
                "fundCurrency": isFieldValueNull(topUpState.fundFrequency),
                "fundCurrencyAmount": isFieldValueNull(topUpState.fundCurrencyAmount),
                "fundInitContribPercent": isFieldValueNull(topUpState.fundInitContribPercent), // need to fetch from fund details
                "fundTopUpTreatment": isFieldValueNull(topUpState.fundTopUpTreatment),
                "gst": isFieldValueNull(topUpState.gstOrServiceTax),
                "gstWaiver": isFieldValueNull(topUpState.gstOrServiceTaxWaiver),
                "gstWaiverAttachment": {
                    "documentFormat": isFieldValueNull(topUpState.gstWaiverApprovalEmailFileFormat),
                    "documentPath": isFieldValueNull(topUpState.gstWaiverApprovalEmailFileS3SignedURL),
                    "documentSize": isFieldValueNull(topUpState.gstWaiverApprovalEmailFileSize),
                },
                "initContribAmt": isFieldValueNull(topUpState.initContribAmt), // need to fetch from the folio details api
                "otherFee": isFieldValueNull(topUpState.otherFee),
                "paymentType": null,
                "primaryHolderContrib": isFieldValueNull(topUpState.primaryHolderContribution),
                "primaryHolderPercent": isFieldValueNull(topUpState.primaryHolderPercentage),
                "secondHolderContrib": isFieldValueNull(topUpState.secondHolderContribution),
                "secondHolderPercent": isFieldValueNull(topUpState.secondHolderPercentage),
                "setupFeeAmt": isFieldValueNull(topUpState.setupFeeAmount),
                "setupFeePercent": isFieldValueNull(topUpState.setupFeePercentage),
                "thirdHolderContrib": isFieldValueNull(topUpState.thirdHolderContribution),
                "thirdHolderPercent": isFieldValueNull(topUpState.thirdHolderPercentage),
                "topUp": topUpState?.topUpEntry,
                "topUpCommitmentAmt": isFieldValueNull(topUpState.topUpCommitmentAmount),
                "topUpContributionAmt": isFieldValueNull(topUpState.topUpContributionAmount),
                "totalSetupFee": isFieldValueNull(topUpState.totalSetupFee),
                "transactionCurrency": isFieldValueNull(topUpState.transactionCurrency),
            },
            "distributorDetails": {
                "amcRmCode": isFieldValueNull(topUpState.amcRmCode),
                "amcRmName": isFieldValueNull(topUpState.amcRmName),
                "distributorCode": isFieldValueNull(topUpState.distributorCode),
                "distributorName": isFieldValueNull(topUpState.distributorName),
                "distributorType": isFieldValueNull(topUpState.distributorOrDirect),
            },
            "documentsProvided": {
                "amcApproval": isFieldValueNull(topUpState.anyApprovalMailFromAmc),
                "bankProofOrChequeCopy": isFieldValueNull(topUpState.bankProofOrChequeCopy),
                "initContribForm": null, // not available
                "poaNotaryAgreementCopy": isFieldValueNull(topUpState.poaNotaryAggrementCopy),
                "topUpRequestLetter": isFieldValueNull(topUpState.topUpRequestLetter),
            },
            "endorsedFlag": false,
            "folioNo": isFieldValueNull(topUpState.folioNumber),
            "invCategory": isFieldValueNull(topUpState.investorCategory),
            "invName": isFieldValueNull(topUpState.investorName),
            "invType": isFieldValueNull(topUpState.invType),
            "investmentDetails": {
                "class": isFieldValueNull(topUpState.className),
                "productType": isFieldValueNull(topUpState.productType),
                "schemeCode": isFieldValueNull(topUpState.schemeCode),
                "schemeIsinNo": isFieldValueNull(topUpState.isInNumber),
                "schemeName": isFieldValueNull(topUpState.schemeName),
            },
            "modeOfHolding": isFieldValueNull(topUpState.modeOfHolding),
            "parentTransactionNo": isFieldValueNull(topUpState.parentTransactionNo),
            "paymentBankDetails": {
                "primaryHolderPaymentBank": paymentHolderArray(topUpState.paymentBankDetails[0]),
                "secondaryHolderPaymentBank": paymentHolderArray(topUpState.paymentBankDetails[1]),
                "thirdHolderPaymentBank": paymentHolderArray(topUpState.paymentBankDetails[2]),
            },
            "poa": {
                "nameOfPoa": isFieldValueNull(topUpState.name),
                "poaTaxIdNo": isFieldValueNull(topUpState.panOrTaxIdNumber),
                "poaType": isFieldValueNull(topUpState.type),
            },
            "processCode": processCode,
            "role": userRole,
            "secHolderRelatshpWithPrimaryHolder": isFieldValueNull(topUpState.secHolderRelatshpWithPrimaryHolder),
            "sourceUser": isFieldValueNull(sourceUser),
            "stageCode": stageCode,
            "taxId": isFieldValueNull(topUpState.panOrTaxId),
            "thirdHolderRelatshpWithPrimaryHolder": isFieldValueNull(topUpState.thirdHolderRelatshpWithPrimaryHolder),
            "transactionNo": transactionNo,
            "updateFlag": updateFlag,
            "updatedDocuments": [
                {
                    "documentFormat": topUpUpdateDocumentFormat, // Not Available
                    "documentPath": topUpUpdateDocumentPath, // Not Available
                    "documentSize": topUpUpdateDocumentSize !== 0 ? topUpUpdateDocumentSize : null,  // Not Available
                    "timestamp": null // Not Available
                }
            ],
            "userId": isFieldValueNull(userId),

        };

        console.log("payload", data);
        
        const axiosConfig = {
            "data": data,
            "url": "/initcontrib",
        };

        await initiateTransactionPostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postTopUp;
}

export default usePostTopUp;
