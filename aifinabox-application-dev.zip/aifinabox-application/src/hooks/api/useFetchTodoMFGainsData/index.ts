import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usefetchTodoMFGainsData() {
    const dispatch = useDispatch();
    let uploadedMasterData: any;

    const fetchTodoMFGainsData = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role: "C" |"A", 
        batchNo: string
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        //clientId=101&processCode=ICP&stageCode=ICPSEN&userId=3001&role=C&batchNo=500000008253
        const axiosConfig = {
            "url": `/initcontrib?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&role=${role}&batchNo=${batchNo}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                uploadedMasterData = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return uploadedMasterData;
    };
    
    return fetchTodoMFGainsData;
}

export default usefetchTodoMFGainsData;
