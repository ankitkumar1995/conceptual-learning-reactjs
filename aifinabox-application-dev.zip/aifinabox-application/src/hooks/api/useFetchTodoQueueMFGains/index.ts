import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface QueueItems {
    _id: string;
    applicationId: string;
    clientId: string;
    clientName: string;
    createdBy: string;
    createdOn: string;
    folioNumber: string;
    rejectRemarks?: string;
    sourceUser: string;
    batchNumber: string;
    fundName: string;
}

export interface PendingItems {
    contextDetails: QueueItems;
}

interface ApiItems {
    _id: string;
    applicationId: string;
    clientId: string;
    clientName?: string;
    createdBy: string;
    createdOn: string;
    folioNo: string;
    rejectRemarks?: string;
    sourceUser: string;
    batchNo: string;    
    fundName: string;
    totalRecords: number;
}

interface ApiResultDataItem {
    contextDetails: ApiItems;
}

function useFetchTodoMFGainsQueue() {
    const dispatch = useDispatch();
 
    const fetchTodoMFGainsQueue = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        userId: string,
        pageIndex: number,
        queueLength: number,
        role: "C" | "A",
    ): Promise<{
        todoQueue: QueueItems[];
        itemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let todoQueue: QueueItems[] = [];
        let itemCount = 0;

        const axiosConfig = {
            "url": `/todoqueue?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&pageIndex=${pageIndex}&queueLength=${queueLength}&role=${role}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const pendingItems = responseData.result;
                
                itemCount = responseData.count;
                todoQueue = pendingItems.map((items: ApiResultDataItem) => {
                    const {
                        _id,
                        applicationId,
                        clientId,
                        createdBy,
                        createdOn,
                        folioNo,
                        sourceUser,
                        batchNo,
                        fundName,
                        totalRecords,
                    } = items.contextDetails;
                    
                    return ({
                        "applicationId": (applicationId ?? ""),
                        "batchNumber": (batchNo ?? ""),                        
                        "clientId": (clientId ?? ""),
                        "createdBy": createdBy,
                        "createdOn": createdOn,
                        "folioNumber": (folioNo ?? ""),
                        "fundName": (fundName ?? ""),
                        "sourceUser": (sourceUser ?? ""),
                        "totalRecords": (totalRecords ?? ""),
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "itemCount": itemCount,
            "todoQueue": todoQueue,
        };
    };
    
    return fetchTodoMFGainsQueue;
}

export default useFetchTodoMFGainsQueue;
