import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ClassResponse {
    classCode: string;
    fundClassDescription: string;
}

function useFetchClassCodeDetails() {
    const dispatch = useDispatch();

    const fetchClassCodeDetails = async (
        productType: string,
        fundCode: string,
        clientCode: string,
    ): Promise<MenuItem[]> => {
        dispatch(setOpenBackdrop(true));

        let classCodes: MenuItem[] = [];

        const axiosConfig = {
            "url": `/classcode?productType=${productType}&fundCode=${fundCode}&clientCode=${clientCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData: ClassResponse[] = response.data;
                
                classCodes = responseData.map((classDetails) => {
                    return {
                        "label": `${classDetails.classCode} - ${classDetails.fundClassDescription}`,
                        "value": classDetails.classCode,
                    };
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classCodes; 
    };

    return fetchClassCodeDetails;
}

export default useFetchClassCodeDetails;
