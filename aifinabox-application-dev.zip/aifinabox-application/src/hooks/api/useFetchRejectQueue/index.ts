import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface IObj {
    update: boolean;
    value: string;
}
export interface PendingRejectedItem {
    bankAccountNumber: string;
    bankName: string;
    classCode: string;
    className: string;
    clientCode: string;
    clientName: string;
    createdOn: string;
    fundCode: string;
    fundName: string;
    planCode: string;
    planName: string;
    rejectRemarks: string;
    createdBy: string;
    ifscOrRtgsCode: string;
}

interface ApiResultDataItem {
    bankAccountNumber: string;
    bankName: string;
    classCode: string;
    className: string;
    clientCode: string;
    clientName: string;
    entryDate: string;
    fundCode: string;
    fundName: string;
    planCode: string;
    planName: string;
    rejectRemarks:string;
    sourceUser: string;
    ifscOrRtgsCode?: string;
}

function useFetchRejectQueue() {
    const dispatch = useDispatch();

    const fetchTodoQueue = async (
        queueLength: number,
        clientCode: string,
        pageIndex: number,
        masterName: MasterName,
        rejectedBy: "A"  | "C",
        role: "C" | "A" | "M",
        userId: string,
    ): Promise<{
        rejectQueue: PendingRejectedItem[];
        pendingRejectItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let rejectQueue: PendingRejectedItem[] = [];
        let pendingRejectItemCount = 0;
        // let userId = "";
        // if (role === "A")
        //     userId = "2001";
        // if (role === "C")
        //     userId = "2001";
        // if  (role === "M"){
        //     userId  = "1001";
        // }
        const axiosConfig = {
            "url": `/rejectqueue?queueLength=${queueLength}&clientCode=${clientCode}&masterName=${masterName}&pageIndex=${pageIndex}&role=${role}&rejectedBy=${rejectedBy}&userId=${userId}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const pendingRejectItems = responseData.result;

                pendingRejectItemCount = responseData.count;
                rejectQueue = pendingRejectItems.map((pendingRejectedItem: ApiResultDataItem) => {
                    const {
                        bankAccountNumber,
                        bankName,
                        classCode,
                        className,
                        clientCode,
                        clientName,
                        entryDate,
                        fundCode,
                        fundName,
                        planCode,
                        planName,
                        rejectRemarks,
                        sourceUser,
                        ifscOrRtgsCode,
                    } = pendingRejectedItem;
                    
                    return ({
                        "bankAccountNumber": (bankAccountNumber ?? ""),
                        "bankName": (bankName ?? ""),
                        "classCode": (classCode ?? ""),
                        "className": (className ?? ""),
                        "clientCode": clientCode,
                        "clientName": clientName,
                        "createdBy": sourceUser,
                        "createdOn": entryDate,
                        "fundCode": (fundCode ?? ""),
                        "fundName": (fundName ?? ""),
                        "ifscOrRtgsCode": (ifscOrRtgsCode ?? ""),
                        "planCode": (planCode ?? ""),
                        "planName": (planName ?? ""),
                        "rejectRemarks": (rejectRemarks ?? ""),
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        

        return {
            "pendingRejectItemCount": pendingRejectItemCount,
            "rejectQueue": rejectQueue,      
        };
    };
    
    dispatch(setOpenBackdrop(false));
    return fetchTodoQueue;
}

export default useFetchRejectQueue;
