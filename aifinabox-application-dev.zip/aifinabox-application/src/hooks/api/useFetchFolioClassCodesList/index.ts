import { MenuItem } from "../../../interfaces/MenuItem.types";
import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface FolioClassDetails {
    folios?: MenuItem[];
    classCodes?: MenuItem[];
}

interface FolioClassDetailsResponse {
    folios?: string[];
    classCodes?: string[];
}

function useFetchFolioClassCodesList() {
    const dispatch = useDispatch();

    const fetchFolioClassCodesList = async (
        clientCode: string,
        fundCode: string,
        folioNo: string[],
        classCode: string[],
    ): Promise<FolioClassDetails> => {
        dispatch(setOpenBackdrop(true));

        let folioClassDetails: FolioClassDetails = { "classCodes": undefined, "folios": undefined };

        const folioNos = folioNo.length > 0 ? JSON.stringify(folioNo) : "";
        const classCodes = classCode.length>0 ? JSON.stringify(classCode): "";

        const axiosConfig = {
            "url": `/folioclasscodelist?clientCode=${clientCode}&fundCode=${fundCode}&folioNo=${folioNos}&classCode=${classCodes}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData: FolioClassDetailsResponse = response.data;

                folioClassDetails.classCodes = responseData?.classCodes?.map((classCode) => ({
                    "label": classCode ?? "",
                    "value": classCode ?? "",
                }));

                folioClassDetails.folios = responseData?.folios?.map((folio) => ({
                    "label": folio ?? "",
                    "value": folio ?? "",
                }));
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return  folioClassDetails; 
    };
    return fetchFolioClassCodesList;
}

export default useFetchFolioClassCodesList;
