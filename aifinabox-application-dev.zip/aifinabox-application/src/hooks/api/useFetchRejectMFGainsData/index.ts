import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

function usefetchRejectMFGainsData() {
    const dispatch = useDispatch();
    let uploadedMasterData: any;

    const fetchRejectMFGainsData = async (
        clientId: string, 
        processCode: string, 
        stageCode: string, 
        userId: string, 
        role: "M" | "C" |"A", 
        batchNo: string,
        self: boolean=false,
    ): Promise<any> => {
        dispatch(setOpenBackdrop(true));

        //clientId=101&processCode=ICP&stageCode=ICPSEN&userId=3001&role=C&batchNo=500000008253
        const axiosConfig = {
            "url": `/reject?clientId=${clientId}&processCode=${processCode}&stageCode=${stageCode}&userId=${userId}&role=${role}&batchNo=${batchNo}&self=${self}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                uploadedMasterData = responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        return uploadedMasterData;
    };
    
    return fetchRejectMFGainsData;
}

export default usefetchRejectMFGainsData;
