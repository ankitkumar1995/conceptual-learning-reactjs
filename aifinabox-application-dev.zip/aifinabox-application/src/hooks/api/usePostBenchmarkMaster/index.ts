import { BenchmarkMasterDetails } from "../../../redux/AifMaster/BenchmarkMaster/Maker/initialState";
import { 
    UpdateState 
} from "../../../pages/AIFMaster/BenchmarkMaster/Maker/MakerBenchmarkMasterForm/helper/initializeUpdateState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostBenchmarkMaster() {
    const dispatch = useDispatch();

    const postBenchmarkMaster = async (
        benchmarkMasterState: BenchmarkMasterDetails,
        sourceUser: string,
        updateExistingData: "0" | "1",
        userId: string,
        userRole: "C" | "M",
        updateStatus: UpdateState,
    ) => {
        dispatch(setOpenBackdrop(true));

        const currentData = 
            dayjs()
                .utc()
                .local()
                .format("DD/MM/YYYY");

        const data = {
            "benchmark": {
                "update": updateStatus.benchmark,
                "value": benchmarkMasterState.benchmark,
            },
            "benchmarkType": {
                "update": updateStatus.benchmarkType,
                "value": benchmarkMasterState.benchmarkType,
            },
            "clientCode": benchmarkMasterState.clientCode,
            "clientName": benchmarkMasterState.companyName,
            "effectiveDate": {
                "update": updateStatus.effectiveDate,
                "value": benchmarkMasterState.effectiveDate,
            },
            "entryDate": currentData,
            "isActive": {
                "update": updateStatus.isActive,
                "value": benchmarkMasterState.isActive,
            },
            "role": userRole,
            // "sourceUser": "Local",
            "sourceUser": sourceUser,
            "updateFlag": updateExistingData,
            // "userId": userRole === "M" ? "1001" : userRole === "C" ? "2001" : userRole === "A" ? "3001" : null,
            "userId": userId,
        };

        const axiosConfig = {
            "data": data,
            "url": "/benchmarkmaster",
        };

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return postBenchmarkMaster;
}

export default usePostBenchmarkMaster;
