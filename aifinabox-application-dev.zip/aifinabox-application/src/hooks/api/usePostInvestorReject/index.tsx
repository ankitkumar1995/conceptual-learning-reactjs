import { MasterName } from "../interfaces/MasterName.types";
import { PlanMasterDetails } from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import dayjs from "dayjs";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import timezone from "dayjs/plugin/timezone";
import { useDispatch } from "react-redux";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

function usePostInvestorReject() {
    const dispatch = useDispatch();

    const rejectPostInvestor = async (
        clientId: string,
        processCode: string,
        stageCode: string,
        role: "C" | "M" | "A",
        userId: string,
        rejectRemarkText: string,
        transactionNo: string,
        folio: string,
        sourceUser: string,
        clientName: string,
    ) => {
        dispatch(setOpenBackdrop(true));

        const data = {
            "clientId": clientId ?  clientId  : "",
            "clientName": clientName,
            "folio": folio,
            "processCode": processCode ? processCode :  "",
            "rejectRemarks": rejectRemarkText,
            "role": role,
            "sourceUser": sourceUser,
            "stageCode": stageCode ? stageCode :  "",
            "transactionNo": transactionNo,
            "userId": userId,
        };
        
        const axiosConfig = {
            "data": data,
            "url": "/investorreject",
        };

        console.log({data});

        await databasePostAxiosInstance(axiosConfig)
            .then(() => { })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return rejectPostInvestor;
}

export default usePostInvestorReject;
