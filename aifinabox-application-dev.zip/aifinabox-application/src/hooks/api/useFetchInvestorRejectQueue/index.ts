import { MasterName } from "../interfaces/MasterName.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

// clientId=101 processCode=IOP stageCode=IOPIEN userId=v-shobheet.pandey@kfintech.com role=M pageIndex=0 queueLength=5

interface MakerApiResultDataItem {
    clientId: string;
    clientName: string;
    createdBy: string;
    creationDate: string;
    rejectRemarks: string;
    folio: string;
    transactionNo: string;
    _id: string;
}

interface CheckerApiResultDataItem {
    clientId: string;
    clientName: string;
    createdBy: string;
    creationDate: string;
    rejectRemarks: string;
    folio: string;
    transactionNo: string;
    _id: string;
}

export interface RejectQueueItem {
    clientName: string;
    clientId: string;
    rejectRemarks: string;
    transactionNo: string;
    barcode: string;
    createdBy: string;
    creationDate: string;
}

function useFetchInvestorRejectQueue() {
    const dispatch = useDispatch();

    const fetchInvestorRejectQueue = async (
        clientId: string,  
        stageCode: string, 
        userId: string, 
        role: "M" | "C" | "Q" | "A", 
        pageIndex: number, 
        queueLength: number
    ): Promise<{
        ToDoQueue: RejectQueueItem[];
        investorQueueItemCount: number;
    }> => {
        dispatch(setOpenBackdrop(true));

        let makerInvestorQueue: RejectQueueItem[] = [];
        let checkerInvestorQueue: RejectQueueItem[] = [];
        let investorQueueItemCount = 0;

        const axiosConfig = {
            "url": `/investorrejectqueue?clientId=${clientId}&stageCode=${stageCode}&userId=${userId}&pageIndex=${pageIndex}&queueLength=${queueLength}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                investorQueueItemCount = responseData.count;
                makerInvestorQueue = responseData.result.map((queueItem:MakerApiResultDataItem) => {
                    const cardItem = queueItem;
                    const {
                        clientId,
                        clientName,
                        createdBy,
                        creationDate,
                        rejectRemarks,
                        transactionNo,
                        folio,
                    } = cardItem;
                    
                    return ({
                        "barcode": folio,
                        "clientId": clientId,
                        "clientName": clientName,
                        "createdBy": createdBy,
                        "creationDate": creationDate,
                        "rejectRemarks": rejectRemarks,
                        "transactionNo": transactionNo,
                    });
                });

                checkerInvestorQueue = responseData.result.map((queueItem:  CheckerApiResultDataItem) => {
                    const cardItem = queueItem;
                    const {
                        clientId,
                        clientName,
                        createdBy,
                        creationDate,
                        rejectRemarks,
                        transactionNo,
                        folio,
                    } = cardItem;
                    
                    return ({
                        "barcode": folio,
                        "clientId": clientId,
                        "clientName": clientName,
                        "createdBy": createdBy,
                        "creationDate": creationDate,
                        "rejectRemarks": rejectRemarks,
                        "transactionNo": transactionNo,
                    });
                });
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return {
            "ToDoQueue": (role !== "C") ? makerInvestorQueue : checkerInvestorQueue,
            "investorQueueItemCount": investorQueueItemCount,
        };
    };
    
    return fetchInvestorRejectQueue;
}

export default useFetchInvestorRejectQueue;
