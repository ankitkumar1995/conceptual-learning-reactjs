import { 
    PlanMasterDetails, 
    initialPlanMasterDetailsFormState 
} from "../../../redux/AifMaster/PlanMaster/Maker/initialState";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import databaseFetchAxiosInstance from "../../../axios/instances/databaseFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

export interface ValueType {
    value: string;
}

export interface FundPlanData {
    planCategory: ValueType;
    planCode: ValueType;
    planDescription: ValueType;
}

interface FundResponse {
    fundplanCodeData: MenuItem[];
    fundData: FundPlanData[];
}

export function initializeFundPlanData(): FundPlanData {
    return {
        "planCategory": {"value": ""},
        "planCode": {"value": ""},
        "planDescription": {"value": ""},
    };
}

function useFetchFundPlanDetails() {
    const dispatch = useDispatch();

    let fundplanCodeData: MenuItem[] = [];
    let fundData: FundPlanData[]  = [];
    let finalResult: FundResponse = {
        "fundData": [],
        "fundplanCodeData": [],
    };
    const fetchFundPlanDetails = async (
        clientCode: string,
        fundCode: string,
    ): Promise<FundResponse> => {
        dispatch(setOpenBackdrop(true));

        const axiosConfig = {
            "url": `/plans?clientCode=${clientCode}&fundCode=${fundCode}`,
        };

        await databaseFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                fundplanCodeData=responseData.map((data: FundPlanData) => ({"label": data.planCode.value,
                    "value": data.planCode.value,}) as MenuItem);
                fundData=responseData;
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));
        finalResult = {fundData, fundplanCodeData};
        return finalResult; 
    };

    return fetchFundPlanDetails;
}

export default useFetchFundPlanDetails;
