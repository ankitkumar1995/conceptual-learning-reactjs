import initiateTransactionFetchAxiosInstance from "../../../axios/instances/initiateTransactionFetchAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ClassLimitResponse {
    maxAmount: string;
    minAmount: string;
}

function useFetchClassLimit() {
    const dispatch = useDispatch();

    const fetchClassLimit = async (
        clientCode: string,
        fundCode: string,
        classCode: string,
    ): Promise<ClassLimitResponse> => {
        dispatch(setOpenBackdrop(true));

        let classResponse: ClassLimitResponse = {
            "maxAmount": "",
            "minAmount": "",
        };

        const axiosConfig = {
            "url": `/classlimits?clientCode=${clientCode}&fundCode=${fundCode}&classCode=${classCode}`,
        };

        await initiateTransactionFetchAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;

                classResponse = {
                    "maxAmount": responseData.maxAmount,
                    "minAmount": responseData.minAmount,
                };
            })
            .catch((error) => {
                console.error(error);
            });

        dispatch(setOpenBackdrop(false));

        return classResponse;
    };

    return fetchClassLimit;
}

export default useFetchClassLimit;
