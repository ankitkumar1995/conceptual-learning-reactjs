import { AuthDataItem, AuthRole } from "../../../redux/Authorization/initialState";
import {
    setAuthData,
    setAuthRole,
    setAuthToken
} from "../../../redux/Authorization/reducer";
import {
    setClientId,
    setClientName,
    setOpenBackdrop
} from "../../../redux/ApplicationContext/reducer";

import { MenuItem } from "../../../interfaces/MenuItem.types";
import databasePostAxiosInstance from "../../../axios/instances/databasePostAxiosInstance";
import { setAllowedClientMenuItems } from "../../../redux/SelectInputMenuItems/reducer";
import { useDispatch } from "react-redux";

interface ClientDetailsResponse {
    clientCode: string;
    clientName: string; 
    tenantId: string;
}

function getRole (authRoleFromApi: any) {
    let authRole: AuthRole = "";
    switch (authRoleFromApi) {
    case "Auditor":
        authRole = "Auditor";
        break;

    case "Checker":
        authRole = "Checker";
        break;

    case "Maker":
        authRole = "Maker";
        break;

    case "QC":
        authRole = "QC";
        break;
    }
    return authRole;

}

function useFetchClientTenants () {
    const dispatch = useDispatch();

    const fetchClientTenants = async (
        authDataFromApi: any
    ): Promise<string> => {
        dispatch(setOpenBackdrop(true));

        const tenantIds = authDataFromApi.map((authDataItem: any) => (
            authDataItem.code
        ) as String);

        const data = {
            "tenantId": tenantIds
        };

        const axiosConfig = {
            "data": data,
            "url": "/userclients",
        };

        let firstAuthRole: AuthRole = "";

        await databasePostAxiosInstance(axiosConfig)
            .then((response) => { 
                const responseData: ClientDetailsResponse[] = response.data;
                const firstTenantAuthRoleFromApi = authDataFromApi[0].role;
                const firstTenantIdFromApi = authDataFromApi[0].code;

                const allowedClientMenuItems = responseData.map((clientDetails) => (
                    {
                        "label": `${clientDetails.clientCode} - ${clientDetails.clientName}`,
                        "value": clientDetails.clientCode,
                    }
                ) as MenuItem);

                const firstClientDetailFromApi = responseData.find((data) => (
                    data.tenantId === firstTenantIdFromApi
                ));

                const authData: AuthDataItem[] = authDataFromApi.map((authDataItem: any, index: number) => {
                    const clientDetail = responseData.find((data) => (
                        data.tenantId === authDataItem.code
                    ));

                    if (clientDetail)
                        return {
                            "authRole": getRole(authDataItem.role),
                            "clientCode": clientDetail.clientCode,
                            "clientName": clientDetail.clientName,
                        };
                    else {
                        return {
                            "authRole": "",
                            "clientCode": "",
                            "clientName": "",
                        };
                    }
                });

                firstAuthRole = getRole(firstTenantAuthRoleFromApi);
                
                dispatch(setAuthRole(getRole(firstTenantAuthRoleFromApi)));
                dispatch(setClientId(firstClientDetailFromApi?.clientCode ?? ""));
                dispatch(setClientName(firstClientDetailFromApi?.clientName ?? ""));
                dispatch(setAllowedClientMenuItems(allowedClientMenuItems));
                dispatch(setAuthData(authData));

                dispatch(setOpenBackdrop(false));
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        
        dispatch(setOpenBackdrop(false));

        return firstAuthRole;
    };

    return fetchClientTenants;
};

export default useFetchClientTenants;
