import { 
    APPLICATION_ID, 
    APPLICATION_NAME, 
    AUTHENTICATION_FLOW_TYPE 
} from "../../../constants/AppConfig";
import { 
    setCognitoUserPostAuthentication,
    setCognitoUsername,
    setMfaOtpToken,
    setMfaOtpValidateRequestTime,
    setSessionId
} from "../../../redux/Authentication/reducer";

import { Auth } from "aws-amplify";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface LoginRequestData {
    kuid: string;
    password: string;
    userPoolId: string;
    userPoolWebClientId: string;
};

function useLogin() {
    const dispatch = useDispatch();

    const login = async (loginApiRequestData: LoginRequestData): Promise<void> => {
        dispatch(setOpenBackdrop(true));

        const { 
            kuid,
            password, 
            userPoolId,
            userPoolWebClientId,
        } = loginApiRequestData;

        Auth.configure({
            "authenticationFlowType": AUTHENTICATION_FLOW_TYPE,
            "region": import.meta.env.VITE_COGNITO_REGION,
            "userPoolId": userPoolId,
            "userPoolWebClientId": userPoolWebClientId,
        });

        const metadata = {
            "appName": APPLICATION_NAME,
            "applicationId": APPLICATION_ID,
        };

        await Auth.signIn(kuid, password, metadata)
            .then((result) => {                                
                const { challengeParam } = result;
                const { otpToken, sessionId } = challengeParam;

                dispatch(setCognitoUserPostAuthentication(result));
                dispatch(setCognitoUsername(result.username));
                dispatch(setMfaOtpToken(otpToken));
                dispatch(setMfaOtpValidateRequestTime( Date.now().toString() ));
                dispatch(setSessionId(sessionId));
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return login;
}

export default useLogin;
