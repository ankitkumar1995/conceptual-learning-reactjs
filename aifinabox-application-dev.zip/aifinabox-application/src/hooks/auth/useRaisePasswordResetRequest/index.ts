import { APPLICATION_NAME } from "../../../constants/AppConfig";
import { USER_NOT_FOUND_ERROR_CODE } from "../../../constants/ErrorCodes";
import authAxiosInstance from "../../../axios/instances/authAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface Error {
    errorCode: number;
    message: string;
}

function useRaisePasswordResetRequest() {
    const dispatch = useDispatch();

    const raisePasswordResetRequest = async (username: string): Promise<void> => {
        dispatch(setOpenBackdrop(true));

        const data = JSON.stringify({
            "appName": APPLICATION_NAME,
            "code": import.meta.env.VITE_AMC_CODE,
            "userName": username,
        });

        const axiosConfig = {
            "data": data,
            "url": `/auth/forgetPassword`,
        };

        await authAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;

                if (
                    responseData.success !== undefined &&
                    !responseData.success &&
                    responseData.data === "UserNotFound"
                ) {
                    const error: Error = {
                        "errorCode": USER_NOT_FOUND_ERROR_CODE,
                        "message": "User Not Found"
                    };
                    
                    dispatch(setOpenBackdrop(false));
                    throw error;
                }

                const { status } = responseData;

                if (!status) {
                    const error: Error = {
                        "errorCode": 999,
                        "message": `Unexpected Behaviour. API Response: ${JSON.stringify(responseData)}`
                    };

                    dispatch(setOpenBackdrop(false));
                    throw error;
                }
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };

    return raisePasswordResetRequest;
}

export default useRaisePasswordResetRequest;
