import axios from "axios";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ResendOtpOtpDataType {
    userName: string;
};

function useResendOtp() {
    const dispatch = useDispatch();

    const resendOtp = async (resendOtpData: ResendOtpOtpDataType) => {
        dispatch(setOpenBackdrop(true));

        const { userName } = resendOtpData;
        
        var otpData = JSON.stringify({
            "appName": "tenantPortal",
            "code": "101",            
            "loginType": "email",
            "userName": userName,
        });

        var axiosConfig = {
            "data": otpData,
            "headers": {
                "Content-Type": "application/json"
            },
            "method": "post",
            "url": `${import.meta.env.VITE_SAAS_AUTH_API_GATEWAT_ROOT}/auth/resendCode`,
        };

        await axios(axiosConfig)
            .then((response) => { })
            .catch(function (error) {
                dispatch(setOpenBackdrop(false));
                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };
    
    return resendOtp;
}

export default useResendOtp;
