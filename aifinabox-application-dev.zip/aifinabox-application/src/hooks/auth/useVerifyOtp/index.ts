import {
    APPLICATION_CODE,
    APPLICATION_ID,
    APPLICATION_NAME,
    AUTHENTICATION_FLOW_TYPE,
    CHALLENGE_NAME_POST_OTP_MISMATCH,
} from "../../../constants/AppConfig";
import { AuthDataItem, AuthRole } from "../../../redux/Authorization/initialState";
import {
    OTP_MISMATCH_AND_RETRY_LIMIT_REACHED_ERROR_CODE,
    OTP_MISMATCH_ERROR_CODE
} from "../../../constants/ErrorCodes";
import {
    setAuthData,
    setAuthRole,
    setAuthToken
} from "../../../redux/Authorization/reducer";
import { setClientId, setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import {
    setEmail,
    setFirstName,
    setLastName
} from "../../../redux/UserContext/reducer";
import { useDispatch, useSelector } from "react-redux";

import { Auth } from "aws-amplify";
import CryptoJS from "crypto-js";
import { MenuItem } from "../../../interfaces/MenuItem.types";
import { OtpAttemptNumber } from "../../../redux/Authentication/initialState";
import { RootState } from "../../../redux/store";
import authAxiosInstance from "../../../axios/instances/authAxiosInstance";
import { setAllowedClientMenuItems } from "../../../redux/SelectInputMenuItems/reducer";
import { setMfaOtpAttemptNumber } from "../../../redux/Authentication/reducer";

interface VerifyOtpDataType {
    cognitoUser: any;
    otp: string;
    otpAttemptNumber: OtpAttemptNumber;
    otpToken: string;
    sessionId: string;
    userId: string;
    userPoolId: string;
    userPoolWebClientId: string;
};

interface AuthDataFromApi {
    code: string;
    role: string;
}

interface ErrorPostOtpMismatch {
    cognitoObjectPostOtpVerification: any;
    errorCode: number;
    message: string;
}

function useVerifyOtp() {
    const dispatch = useDispatch();
    const authenticationState = useSelector(
        (state: RootState) => 
            state
                .authenticationState
    );

    const {
        cognitoUsername,
        mfaOtpValidateRequestTime,
    } = authenticationState;

    const appName = APPLICATION_NAME;
    const logSessionId = mfaOtpValidateRequestTime + cognitoUsername + appName;
    const hash = CryptoJS.AES.encrypt(logSessionId, "saasloginkey").toString();

    const verifyOtp = async (verifyOtpData: VerifyOtpDataType): Promise<AuthDataFromApi> => {
        dispatch(setOpenBackdrop(true));

        let authToken = "";

        const {
            cognitoUser,
            otp,
            otpAttemptNumber,
            otpToken, 
            sessionId,
            userId,
            userPoolId,
            userPoolWebClientId,
        } = verifyOtpData;

        Auth.configure({
            "authenticationFlowType": AUTHENTICATION_FLOW_TYPE,
            "region": import.meta.env.VITE_COGNITO_REGION,
            "userPoolId": userPoolId,
            "userPoolWebClientId": userPoolWebClientId,
        });

        const clientMetadata = {
            "appName": APPLICATION_NAME,
            "applicationId": APPLICATION_ID,
            "attempts": otpAttemptNumber,
            "code": APPLICATION_CODE,
            "logSessionId": hash,
            "request_timestamp": mfaOtpValidateRequestTime,
            "sessionId": sessionId,
            "token": otpToken
        };

        await Auth.sendCustomChallengeAnswer(cognitoUser, otp, clientMetadata)
            .then((cognitoUserPostOtpVerification) => {
                const { challengeName } = cognitoUserPostOtpVerification;

                if (challengeName === CHALLENGE_NAME_POST_OTP_MISMATCH) {
                    let currentOtpAttempNumber = parseInt(otpAttemptNumber);
                    let error: ErrorPostOtpMismatch = {
                        "cognitoObjectPostOtpVerification": null,
                        "errorCode": 0,
                        "message": ""
                    };

                    const updatedOtpAttempNumber = currentOtpAttempNumber + 1;
                    error = {
                        "cognitoObjectPostOtpVerification": cognitoUserPostOtpVerification,
                        "errorCode": OTP_MISMATCH_ERROR_CODE,
                        "message": "OTP Mismatch",
                    };

                    dispatch(setMfaOtpAttemptNumber(updatedOtpAttempNumber.toString() as OtpAttemptNumber));

                    throw error;
                }
                
                authToken =
                    cognitoUserPostOtpVerification
                        .signInUserSession
                        .accessToken
                        .jwtToken;

                const userInformationPayload =
                    cognitoUserPostOtpVerification
                        .signInUserSession
                        .idToken
                        .payload;

                const userEmail = userInformationPayload["email"];
                // const userFirstName = userInformationPayload["custom:firstName"];
                // const userLastName = userInformationPayload["custom:lastName"];
                
                dispatch(setEmail(userEmail));
                // dispatch(setFirstName(userFirstName));
                // dispatch(setLastName(userLastName));

                dispatch(setAuthToken(authToken));
            })
            .catch((error) => {
                if (otpAttemptNumber === "3") {
                    error = {
                        "cognitoObjectPostOtpVerification": null,
                        "errorCode": OTP_MISMATCH_AND_RETRY_LIMIT_REACHED_ERROR_CODE,
                        "message": "OTP Mismatch and OTP Retry Count Reached",
                    };

                    dispatch(setOpenBackdrop(false));

                    throw error;
                }

                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        const axiosData = JSON.stringify({
            "data": {
                "appName": APPLICATION_NAME,
                "code": import.meta.env.VITE_AMC_CODE,
                "email": userId,
            },
        });

        const axiosConfig = {
            "data": axiosData,
            "headers": {
                "Authorization": authToken,
            },
            "url": "/auth/getAuthData",
        };

        let authDataFromApi : AuthDataFromApi = {
            "code": "",
            "role": "",
        };

        await authAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const { success } = responseData;

                if (!success) {
                    dispatch(setOpenBackdrop(false));

                    throw "Failed to fetch user auth data";
                }

                const authResponseData = responseData.data;
                const userFirstName = authResponseData.firstName ?? "";
                const userLastName = authResponseData.lastName ?? "";
                authDataFromApi = authResponseData.permissions;

                dispatch(setOpenBackdrop(false));
                dispatch(setFirstName(userFirstName));
                dispatch(setLastName(userLastName));
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
        
        return authDataFromApi;
    };
    
    return verifyOtp;
}

export default useVerifyOtp;
