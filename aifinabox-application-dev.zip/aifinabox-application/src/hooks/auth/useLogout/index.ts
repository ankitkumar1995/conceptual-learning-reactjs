import authAxiosInstance from "../../../axios/instances/authAxiosInstance";
import { clearState as clearAuthenticationState } from "../../../redux/Authentication/reducer";
import { clearState as clearAuthorizationState } from "../../../redux/Authorization/reducer";
import { clearState as clearUserContextState } from "../../../redux/UserContext/reducer";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

function useLogout() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const logout = async (authToken: string) => {
        dispatch(setOpenBackdrop(true));

        const axiosData = JSON.stringify({
            "accessToken": authToken,
        });

        const axiosConfig = {
            "data": axiosData,
            "url": "/auth/expireToken",
        };

        await authAxiosInstance(axiosConfig)
            .then(() => {
                dispatch(clearAuthenticationState());
                dispatch(clearAuthorizationState());
                dispatch(clearUserContextState());

                navigate("/login");
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };

    return logout;
}

export default useLogout;
