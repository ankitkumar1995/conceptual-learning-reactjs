import { 
    setAppClientId, 
    setKuid, 
    setUserPoolId 
} from "../../../redux/Authentication/reducer";

import { APPLICATION_NAME } from "../../../constants/AppConfig";
import authAxiosInstance from "../../../axios/instances/authAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface KuidApiResponse {
    data: {
        appClientId: string;
        kuid: string;
        userpoolId: string;
    };
    success: boolean;
}

function useFetchKuidData() {
    const dispatch = useDispatch();

    const fetchKuidData = async (username: string): Promise<void> => {
        dispatch(setOpenBackdrop(true));

        const data = JSON.stringify({
            "appName": APPLICATION_NAME,
            "code": import.meta.env.VITE_AMC_CODE,
            "userName": username,
        });

        const axiosConfig = {
            "data": data,
            "url": `/auth/getKuid`,
        };

        await authAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data;
                const { success } = responseData;

                if (!success) {
                    dispatch(setOpenBackdrop(false));
                    console.error("Failure while fetching kuid data");

                    throw "Failure while fetching kuid data";
                }

                const { data } = responseData as KuidApiResponse;
                const {
                    appClientId,
                    kuid,
                    userpoolId,
                } = data;

                dispatch(setAppClientId(appClientId));
                dispatch(setKuid(kuid));
                dispatch(setUserPoolId(userpoolId));
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };

    return fetchKuidData;
}

export default useFetchKuidData;
