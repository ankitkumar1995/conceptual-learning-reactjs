import generateError, { ErrorMessageCode } from "./helpers/generateError";

import { APPLICATION_NAME } from "../../../constants/AppConfig";
import authAxiosInstance from "../../../axios/instances/authAxiosInstance";
import { setOpenBackdrop } from "../../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

interface ResetPasswordApiResponse {
    message: string;
    success: boolean;
}

function useResetPassword() {
    const dispatch = useDispatch();

    const raisePasswordResetRequest = async (
        username: string,
        newPassword: string,
        resetPasswordOtp: string,
    ): Promise<void> => {
        dispatch(setOpenBackdrop(true));

        const data = JSON.stringify({
            "appName": APPLICATION_NAME,
            "code": import.meta.env.VITE_AMC_CODE,
            "otp": resetPasswordOtp,
            "password": newPassword,
            "userName": username,
        });

        const axiosConfig = {
            "data": data,
            "url": `/auth/resetPassword`,
        };

        await authAxiosInstance(axiosConfig)
            .then((response) => {
                const responseData = response.data as ResetPasswordApiResponse;
                const {
                    message,
                    success,
                } = responseData;
                
                if (!success) {
                    const error = generateError(message as ErrorMessageCode);
                    dispatch(setOpenBackdrop(false));

                    throw error;
                }
            })
            .catch((error) => {
                console.error(error);
                dispatch(setOpenBackdrop(false));

                throw error;
            });

        dispatch(setOpenBackdrop(false));
    };

    return raisePasswordResetRequest;
}

export default useResetPassword;
