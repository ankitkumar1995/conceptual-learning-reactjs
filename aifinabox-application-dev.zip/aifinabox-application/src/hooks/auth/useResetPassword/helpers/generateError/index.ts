import { OTP_MISMATCH_ERROR_CODE } from "../../../../../constants/ErrorCodes";

export type ErrorMessageCode =
    "CodeMismatchException";

interface Error {
    errorCode: number;
    message: string;
}

function generateError(errorMessageCode: ErrorMessageCode): Error {
    switch (errorMessageCode) {
    case "CodeMismatchException":
        return {
            "errorCode": OTP_MISMATCH_ERROR_CODE,
            "message": "OTP Mismatch",
        };
    }
}

export default generateError;
