import { Button, styled } from "@mui/material";
import { FXButtonProps } from "./FXButtonProps.types";
import { fontFamily } from "../../themes/typography/fontFamily";

export const DashedButton = () => {
    const backgroundColor = "#FFFFFF";
    const textColor = "#9497A3";
    
    return {
        "&:focus:not(:hover)": {
            "backgroundColor": backgroundColor
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "backgroundColor": backgroundColor,
        "border": "1px dashed #9497A3",
        "borderRadius": "7px",
        "color": textColor,
        "height": "60px",
        "paddingLeft": "20px",
        "paddingRight": "20px",
    };
};

export const AddNewButton = () => {
    const backgroundColor = "transparent";
    const textColor = "#201C43";
    
    return {
        "&:focus:not(:hover)": {
            "backgroundColor": backgroundColor
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "backgroundColor": backgroundColor,
        "border": "1px dashed rgba(32, 28, 67, 0.70)",
        "borderRadius": "7px",
        "color": textColor,
        "fontFamily": fontFamily,
        "fontSize": "14px",
        "height": "40px",
        "paddingLeft": "20px",
        "paddingRight": "20px",
    };
};

export const DeleteButton = () => {
    const backgroundColor = "#E5435C";
    const textColor = "#FFFFFF";

    return {
        "&:focus:not(:hover)": {
            "backgroundColor": backgroundColor
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "backgroundColor": backgroundColor,
        "borderRadius": "7px",
        "color": textColor, 
        "height": "40px",
        "paddingLeft": "20px",
        "paddingRight": "20px",
    };
};

export const FlowActionButton = () => {
    const backgroundColor = "#A8CCFF";
    const textColor = "#201C43";

    return {
        "&:focus:not(:hover)": {
            "backgroundColor": backgroundColor
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "backgroundColor": backgroundColor,
        "borderRadius": "5px",
        "color": textColor, 
        "height": "40px",
        "paddingLeft": "20px",
        "paddingRight": "20px",
    };
};

export const NormalButton = () => {
    const backgroundColor = "#E8ECFF";
    const textColor = "#201C43";

    return {
        "&:focus:not(:hover)": {
            "backgroundColor": backgroundColor
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "backgroundColor": backgroundColor,
        "borderRadius": "5px",
        "color": textColor,
        "fontFamily": fontFamily,
        "fontSize": "16px",
        "fontStyle": "normal",
        "fontWeight": 500,
        "height": "60px",
        "lineHeight": "24px",
        "paddingLeft": "20px",
        "paddingRight": "20px",
    };
};

export const SubmitButton = () => {
    const backgroundColor = "#2057A6";
    const textColor = "#FFFFFF";

    return {
        "& .MuiButton-endIcon": {
            "position": "absolute",
            "right": "20px"
        },
        "&:disabled": {
            "color": textColor,
            "opacity": "60%"
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "background": backgroundColor,
        "borderRadius": "5px",
        "color": textColor,
        "fontFamily": fontFamily,
        "fontSize": "16px",
        "fontStyle": "normal",
        "fontWeight": 500,
        "height": "60px",
        "lineHeight": "24px",
        "paddingLeft": "20px",
        "paddingRight": "20px"
    };
};

export const SuccessButton = () => {
    const backgroundColor = "#4BAE4F";
    const textColor = "#FFFFFF";

    return {
        "& .MuiButton-endIcon": {
            "position": "absolute",
            "right": "20px"
        },
        "&:disabled": {
            "color": textColor,
            "opacity": "60%"
        },
        "&:hover": {
            "backgroundColor": backgroundColor
        },
        "background": backgroundColor,
        "borderRadius": "5px",
        "color": textColor,
        "fontFamily": fontFamily,
        "fontSize": "16px",
        "fontStyle": "normal",
        "fontWeight": 500,
        "height": "60px",
        "lineHeight": "24px",
        "paddingLeft": "20px",
        "paddingRight": "20px"
    };
};

const StyledButton = styled(Button, {
    "shouldForwardProp": (prop) => prop !== "buttonVariant",
})<FXButtonProps>( ({ buttonVariant }) => {    

    return {
        "textTransform": "none",
        ...(buttonVariant === "dashed" && DashedButton()),
        ...(buttonVariant === "delete" && DeleteButton()),
        ...(buttonVariant === "flowaction" && FlowActionButton()),
        ...(buttonVariant === "normal" && NormalButton()),
        ...(buttonVariant === "submit" && SubmitButton()),
        ...(buttonVariant === "addNew" && AddNewButton()),
        ...(buttonVariant === "success" && SuccessButton()),
    };
}
);

export default StyledButton;
