import { ReactNode } from "react";
import { SxProps } from "@mui/material";

export interface FXButtonProps {
    buttonVariant?: "contained" | "dashed" | "delete" | "flowaction" | "normal" | "submit" | "addNew" | "success";
    disabled?: boolean;
    disableElevation?: boolean;
    disableRipple?: boolean;
    endIcon?: ReactNode;
    fullWidth?: boolean;
    label?: string;
    onClick?: () => void;
    onMouseDown?: () => void;
    onMouseUp?: () => void;
    size?: "small" | "medium" | "large";
    startIcon?: ReactNode;
    sx?: SxProps;
}
