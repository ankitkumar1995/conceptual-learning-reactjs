import { FXButtonProps } from "./FXButtonProps.types";
import React from "react";
import StyledButton from "./StyledFXButton";

const FXButton: React.FC<FXButtonProps> = ({
    buttonVariant, 
    disabled,
    disableElevation,
    disableRipple,
    endIcon,
    fullWidth,
    label, 
    onClick,
    onMouseDown,
    onMouseUp,
    size,
    startIcon,
    sx,
}) => {
    return (
        <StyledButton 
            buttonVariant={buttonVariant}
            disabled={disabled}
            disableRipple={disableRipple}
            disableElevation={disableElevation}
            endIcon={endIcon}
            fullWidth={fullWidth}
            onClick={onClick}
            onMouseDown={onMouseDown}
            onMouseUp={onMouseUp}
            size={size}
            startIcon={startIcon}
            sx={sx}
        >
            {label}     
        </StyledButton>
    );
};

export default FXButton;
