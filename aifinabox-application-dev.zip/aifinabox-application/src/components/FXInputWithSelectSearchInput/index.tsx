import {
    Box,
    FormControl, 
    FormHelperText, 
    FormLabel,
    Stack,
    Typography 
} from "@mui/material";

import CancelIcon from "@mui/icons-material/Cancel";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import FXAutoCompleteInput from "../FXAutoCompleteInput";
import { FXInputWithSelectInput } from "./FXInputWithSelectInput.types";
import FXSelectInput from "../FXSelectInput";
import React from "react";
import StyledTextField from "../FXInput/StyledTextField";
import { initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import inputForbidder from "../FXInput/helpers/inputForbidder";

const FXInputWithSelectSearchPrefix : React.FC<FXInputWithSelectInput> = ({
    autoCapitalize,
    capitalizeFirstLetter,
    crossCheckValue,
    disabled,
    endAdornment,
    error,
    forbidTo,
    formLabelSx,
    helperText,
    label,
    masterName,
    selectLabel,
    maxLength,
    onBlurValidator,
    onChangeValidator,
    onFieldErrorChange,
    onFocus,
    onSelectFieldValueChange,
    onTextFieldBlur,
    onTextFieldValueChange,
    onValidationFailure,
    onValidationSuccess,
    readOnly,
    required,
    selectInputPosition,
    selectFieldMenuItems,
    selectFieldValue,
    size,
    textInputRef,
    textFieldDefaultValue,
    textFieldValue,
    type,
    validatorOptions,
    verified,
    warning,
    disableBGColor
}) => {

    const endAdornmentIcon = (
        (error) 
            ? <CancelIcon color="error"/>
            : (
                (verified)
                    ? <CheckCircleIcon color="success"/>
                    : <></>
            )
    );

    const handleTextFieldOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        let result = event.target.value;

        if (autoCapitalize) result = result.toUpperCase();

        if (capitalizeFirstLetter) result =  result.charAt(0).toUpperCase() + result.slice(1);
        
        if (typeof forbidTo === "string") result = inputForbidder(forbidTo, result);
        
        if (typeof onTextFieldValueChange !== "undefined") onTextFieldValueChange(result);

        if (
            textInputRef !== undefined && 
            textInputRef.current !== null && 
            textInputRef.current !== undefined
        ) {
            textInputRef.current.value = result;
        }
        
        let validation = initializeFieldValidation();
        
        if (onChangeValidator && validatorOptions)
            validation = onChangeValidator(result, validatorOptions);

        if (onFieldErrorChange)
            onFieldErrorChange(validation);

        if (validation.isError && onValidationFailure) 
            onValidationFailure();
    };

    const handleTextFieldOnBlur = async () => { 
        const testerInputValue = 
            textInputRef?.current?.value ?? 
            textFieldValue ?? 
            "";
            
        const testerSelectValue = selectFieldValue ?? "";
        
        let isFieldEmpty = false;

        if (
            required && 
            (testerInputValue === "" && 
            testerSelectValue === "") &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            
            onFieldErrorChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }
        if (
            required && 
            testerInputValue === "" &&
            onFieldErrorChange && !isFieldEmpty
        ) {
            isFieldEmpty = true;
            
            onFieldErrorChange({
                "helperText": `${label} is Empty`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            required && 
            testerSelectValue === "" &&
            onFieldErrorChange && !isFieldEmpty
        ) {
            isFieldEmpty = true; 
            onFieldErrorChange({
                "helperText": selectLabel 
                    ? `${selectLabel} is Empty` 
                    : `${label} Prefix is Empty`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            crossCheckValue !== undefined &&
            (testerInputValue + " " + testerSelectValue) !== crossCheckValue &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }

        if (
            !(required && isFieldEmpty) &&
            !error &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldErrorChange !== "undefined"
        ) {

            await onBlurValidator(testerInputValue, validatorOptions)
                .then(async (result) => {
                    onFieldErrorChange(result);

                    if (
                        !result.isError && 
                        testerInputValue.length &&
                        onValidationSuccess
                    )                     
                        await onValidationSuccess();
                    
                    else if (
                        result.isError && 
                        onValidationFailure
                    ) 
                        onValidationFailure();
                });
        }

        if (typeof onTextFieldBlur !== "undefined") 
            onTextFieldBlur();
    };

    return (
        <FormControl
            className={warning ? "warning" : ""}
            error={error}
            fullWidth
            sx={{ 
                ... formLabelSx, 
                "&.warning": {
                    "& .MuiFilledInput-root": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >
            <FormLabel sx={{"marginTop": "-4px", "paddingBottom": "10px" }}> 
                <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                    {(required ? `${label} *`: label)} 
                </Typography>
            </FormLabel>

            <StyledTextField 
                autoComplete="off"
                defaultValue={textFieldDefaultValue}
                disabled={disabled}
                error={error}
                hiddenLabel
                inputRef={textInputRef}
                onBlur={handleTextFieldOnBlur}
                onChange={handleTextFieldOnChange}
                placeholder="Enter"
                required={required}
                size={size ?? "medium"}
                type={type}
                value={textFieldValue}
                variant="filled"
                // sx={{ "zIndex": 10}}
                FormHelperTextProps={{
                    "sx": {
                        "fontSize": "10px",
                        "fontWeight": 500,
                    }
                }}
                inputProps={{ 
                    "maxLength": maxLength ?? 256,
                    "readOnly": readOnly,
                    "sx": {
                        "&::placeholder": {
                            "color": "#9497A3",
                            "opacity": "1",
                        }
                    }
                }}

                InputProps={{
                    "disableUnderline": true,
                    "endAdornment": 
                        (selectInputPosition === "end")
                            ? 
                            <FXSelectInput
                                disabled={disabled}
                                menuItems={selectFieldMenuItems}
                                value={selectFieldValue}
                                onValueChange={(value) => {
                                    if (onSelectFieldValueChange !== undefined) 
                                        onSelectFieldValueChange(value);
                                }}
                                sx={{ 
                                    "& .MuiSelect-filled": { 
                                        "background": "#FFFFFF",
                                        "border": 0,
                                    },
                                    "& .MuiSelect-select.MuiSelect-filled": {
                                        "paddingLeft": 0,
                                        "paddingRight": "25px",
                                        "paddingTop": "16px",
                                    },
                                    "&.MuiFilledInput-root": {
                                        "border": 0,
                                        "borderRadius": 0,
                                    },
                                }}
                                formLabelSx={{ 
                                    "& .MuiFormLabel-root": {
                                        "display": "none",
                                    },
                                    "width": 180,
                                }}
                            />
                            : (endAdornment !== undefined)
                                ? endAdornment 
                                : endAdornmentIcon,

                    "startAdornment":
                    (selectInputPosition === "start") &&
                    <FXAutoCompleteInput 
                        disabled={disabled}
                        menuItems={selectFieldMenuItems}
                        value={selectFieldValue}
                        onValueChange={(value) => {
                            let validation = initializeFieldValidation();
                            if (onSelectFieldValueChange !== undefined) 
                                onSelectFieldValueChange(value);
                            if (onFieldErrorChange)
                                onFieldErrorChange(validation);
                        }}
                        disablePortal={disabled}
                        
                        sx={{ 
                            "& .MuiSelect-filled": { 
                                
                                "background": "#FFFFFF",
                                "border": 0,
                            },
                            "& .MuiSelect-select.MuiSelect-filled": {
                                "&:hover": {
                                    "background": "#FFFFFF",
                                },
                                "backgroundColor": disabled ? disableBGColor || "#e0e0e0" : "#FFFFFF",
                                "borderRadius": 0,
                                "marginBottom": "-3px",
                                "marginLeft": "-10px",
                                "paddingLeft": "14px",
                                "paddingRight": "20px",
                                "paddingTop": "16px",
                            },
                            "&.MuiFilledInput-root": {
                                "border": 0,
                                "borderRadius": 0,
                                // "marginLeft": "-20px",
                            },
                        }}
                        formLabelSx={{ 
                            "& .MuiFormLabel-root": {
                                "display": "none",
                            },
                            "width": masterName ==="contact_master"?250:260,
                        }}
                        masterName={masterName}
                        disableBGColor={disableBGColor}
                    />
                
                }}
                onFocus={() => {
                    if (typeof onFocus !== "undefined")
                        onFocus();
                }}
            />

            <FormHelperText
                sx={{
                    "fontSize": "10px",
                    "fontWeight": 500,
                }}
            >
                {
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                } 
            </FormHelperText>
        </FormControl>
    );
};

export default FXInputWithSelectSearchPrefix;
