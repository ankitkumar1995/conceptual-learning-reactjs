import React from "react";

export interface FXAlertSnackbarProps {
    alertDescription?: React.ReactNode;
    alertTitle?: React.ReactNode;
    autoHideDuration?: number;
    onClose?: () => void;
    open: boolean;
    severity?: "error" | "info" | "success" | "warning";
}
