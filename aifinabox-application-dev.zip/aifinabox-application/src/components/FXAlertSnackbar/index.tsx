import { Slide, SlideProps } from "@mui/material";
import Alert from "@mui/material/Alert";
import AlertTitle from "@mui/material/AlertTitle";
import { Box } from "@mui/system";
import { FXAlertSnackbarProps } from "./FXAlertSnackbarProps.types";
import Snackbar from "@mui/material/Snackbar";

const FXAlertSnackbar: React.FC<FXAlertSnackbarProps> = ({
    alertDescription,
    alertTitle,
    autoHideDuration,
    open,
    onClose,
    severity,
}) => {
    const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === "clickaway") return;

        if (typeof onClose !== "undefined") onClose();
    };

    type TransitionProps = Omit<SlideProps, 'direction'>;

    function TransitionLeft(props: TransitionProps) {
        return <Slide {...props} direction="left"/>;
    }

    return (
        <Snackbar
            open={open}
            autoHideDuration={autoHideDuration ?? 10000}
            onClose={handleClose}
            anchorOrigin={{
                "horizontal": "right",
                "vertical": "bottom"
            }}
            TransitionComponent={TransitionLeft}
        >
            <Alert
                variant="standard"
                severity={severity ?? "info"}
                onClose={handleClose}
                sx={{ "width": "100%" }}
            >
                <AlertTitle>
                    {alertTitle}
                </AlertTitle>

                <Box>
                    {alertDescription}
                </Box>
            </Alert>
        </Snackbar>
    );
};

export default FXAlertSnackbar;
