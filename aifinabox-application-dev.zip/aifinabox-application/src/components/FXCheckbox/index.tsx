import Checkbox from "@mui/material/Checkbox";
import { FXCheckboxProps } from "./FXCheckboxProps.types";
import FormControl from "@mui/material/FormControl";
import FormControlLabel from "@mui/material/FormControlLabel";
import { useState } from "react";

const FXCheckbox: React.FC<FXCheckboxProps> = ({
    checked,
    checkedIcon,
    defaultChecked,
    disabled,
    indeterminate,
    indeterminateIcon,
    label,
    labelPlacement,
    onValueChange,
    sx,
}) => {
    const [fieldValue, setFieldValue] = useState(false);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const isChecked = event.target.checked;

        if (typeof onValueChange !== "undefined") onValueChange(isChecked);
        else setFieldValue(isChecked);
    };

    return (
        <FormControl>
            <FormControlLabel
                label={label}
                labelPlacement={labelPlacement}
                control={
                    <Checkbox 
                        sx={{ ...sx }}
                        onChange={handleChange}
                        indeterminateIcon={indeterminateIcon}
                        indeterminate={indeterminate}
                        disabled={disabled}
                        defaultChecked={defaultChecked}
                        checkedIcon={checkedIcon}
                        checked={checked ?? fieldValue}
                    />
                }
            />
        </FormControl>
    );
};

export default FXCheckbox;
