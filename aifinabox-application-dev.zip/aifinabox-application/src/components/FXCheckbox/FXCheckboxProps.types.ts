import React from "react";

export interface FXCheckboxProps {
    checked?: boolean;
    checkedIcon?: React.ReactNode;
    defaultChecked?: boolean;
    disabled?: boolean;
    indeterminate?: boolean;
    indeterminateIcon?: React.ReactNode;
    label: string;
    labelPlacement?: "bottom" | "start" | "top" | "end";
    onValueChange?: (isChecked: boolean) => void;
    sx?: React.CSSProperties;
}
