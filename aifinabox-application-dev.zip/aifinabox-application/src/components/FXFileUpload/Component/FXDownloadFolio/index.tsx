import {
    AcceptedFormat,
    FXTransactionTypePopUpProps
} from "../../../FXTransactionTypePopUp/FXTransactionTypePopUpProps.types";
import {
    Box,
    IconButton,
    Modal,
    Paper,
    Radio,
    Typography
} from "@mui/material";
import React, {
    RefObject,
    createRef,
    useEffect,
    useState
} from "react";
import CloseImageIcon from "../../../../icons/CloseImageIcon";
import FXButton from "../../../FXButton";
import { FXDownloadPopUpProps } from "./FXDownloadPopUpProps.types";
import FXRadioGroup from "../../../FXRadioGroup";
import FXSelectInput from "../../../FXSelectInput";
import { FieldValidation } from "../../../../interfaces/FieldValidation.types";
import MFGainDownloadsFormDispatchActionsProvider from "../../../../redux/InitiateTransaction/MFGains/Maker/DownloadFolios/dispatchActionProvider";
import { RootState } from "../../../../redux/store";
import { downloadPopUpStyles } from "./downloadPopUpStyles";
import useFetchUnEndorsedTransaction from "../../../../hooks/api/useFetchUnEndorsedTransaction";
import { useSelector } from "react-redux";
// import { TransactionPopUpStyles } from "../../../FXTransactionTypePopUp/TransactionPopUpStyles";

const FXDownloadFolio: React.FC<FXDownloadPopUpProps> = ({
    accept,
    onClose,
    open,
    clientDetails
}) => {
    const [fundCode, setFundCode] = useState<string>("");
    const [fundName, setFundName] = useState<string>("");

    const appState = useSelector(
        (state: RootState) => state.applicationContextState
    );

    const { clientId } = appState;

    const mfGainFormState = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .mfGainState
                .makerDownloadFolios
    );
 
    const { isActive } = mfGainFormState;

    const { setIsActive } = MFGainDownloadsFormDispatchActionsProvider();

    const downloadTemplate = useFetchUnEndorsedTransaction();

    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };
    const handleAddFundName = () => {
        clientDetails.map((fundDetail: any) => {
            setFundName(fundDetail.fundName.value);
        });
    };

    const handleDownloadTemplate = async () => {
        const data = await downloadTemplate(clientId, isActive, fundCode);
        // const data = await downloadTemplate("TMS900", "MFG", "1234");
        // console.log(data);

        if (data) {            
            window.open(data);
            handleOnClose();            
        }
    };

    useEffect(() => { 
        console.log(clientDetails, "client details");
    }, [clientDetails]);

    return (
        <> 
            <Modal open={open}>
                <Paper sx={downloadPopUpStyles}>
                    
                    <Box
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Typography variant="popupSubDescription" fontSize="18px" sx={{ "padding": "20px 80px 0px 20px" }}>
                            Download Folios
                        </Typography>
                        
                        <IconButton disableRipple onClick={handleOnClose} sx={{ "padding": "10px 25px 0px 20px" }}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box>
                    
                    <Box
                        display="flex"
                        justifyContent="space-around"
                        sx={{ "fontSize": "18px", "padding": "30px 0px 10px 0px" }}
                    >
                        <FXRadioGroup
                            label="" 
                            row 
                            required
                            radioButtonValues={[{"label": "MF Gain","value": "MFG"},{"label": "MF Payout","value": "MFP"}]}
                            value={isActive}   
                            onValueChange={(value) => {
                                setIsActive(value);                                
                            }}
                        />
                        
                    </Box>

                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "30px 30px 20px 25px"  }}
                    >
                        <FXSelectInput
                            label="Fund"
                            required
                            value={fundCode}
                            onValueChange={(value) => {
                                setFundCode(value);
                                handleAddFundName();
                            }}   
                            menuItems={clientDetails?.map((code: any) => (
                                {
                                    "label": code.fundCode.label,
                                    "value": code.fundCode.value
                                }
                            ))}                         
                            // menuItems={clientDetails.fundCode?.map((code: any) => (
                            //     {
                            //         "label": code.label,
                            //         "value": code.value,
                            //     }
                            // ))}                         
                        />
                        
                    </Box>

                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "30px 30px 20px 25px" }}
                    >
                        
                        <FXButton
                            buttonVariant="submit"
                            disabled={fundCode.length === 0}
                            fullWidth
                            label="Continue"
                            onClick={() => handleDownloadTemplate()}                            
                        />
                    
                    </Box>

                
                </Paper>
            </Modal>
        </>
    );
};

export default FXDownloadFolio;

