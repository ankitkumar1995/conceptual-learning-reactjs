
import {  ReactNode } from "react";
import { SxProps } from "@mui/material";

export type AcceptedFormat = 
        ".csv" |
        ".xml" |
        ".xlsx" |
        ".txt" 

export interface FXDownloadPopUpProps {
        onClose?: () => void;
        open: boolean;
        accept?: AcceptedFormat[];
        assetType?: string;
        buttonName?: string;
        disabled?: boolean;
        documentType?: string;
        error?: boolean;
        helperText?: ReactNode;
        label?: string;
        identifier?: string;
        maxLength?: number;
        onBlur?: () => void;
        onFocus?: () => void;
        onRemoveFile?: () => void;
        onS3PresignedUrlFetch?: (format: string, s3PresignedUrl: string, s3Key: string) => void;
        onValueChange?: (result: string) => void;
        placeholder?: string;
        required?: boolean;
        s3CustomFileName?: string;
        sx?: SxProps;
        sxButton?: SxProps;
        sxCrossIcon?: SxProps;
        type?: string;
        value?: string;
        verified?: boolean;
        clientDetails: any;
}
