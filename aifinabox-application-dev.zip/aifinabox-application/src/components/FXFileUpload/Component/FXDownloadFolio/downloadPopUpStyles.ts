export const downloadPopUpStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "375px",
    "left": "0",
    "margin": "auto",
    "position": "absolute",
    "right": "0",
    "top": "15%",
    "width": "350px"
};
