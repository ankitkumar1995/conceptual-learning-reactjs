import {
    Box,
    Grid,
    Typography
} from "@mui/material";
import {
    RefObject,
    createRef,
    useState
} from "react";
import { AcceptedFormat } from "./FXFileUploadProps.types";
import FXButton from "../FXButton";
import FXDownloadFolio from "./Component/FXDownloadFolio";
import FXTransactionTypePopUp from "../FXTransactionTypePopUp";
import { FileDetails } from "./FileDetails.types";
import FileUploadIcon from "../../icons/FileUploadIcon";
import StyledFileUploadButton from "./StyledFileUploadButton";


export default function FXFileUpload({handleUpload} : any) {


    const acceptedFileFormat: AcceptedFormat[] = [".xml", ".csv", ".xlsx", ".txt"];
    const acceptStringFileFormat = acceptedFileFormat.join(",");
    const inputRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>();
    
    const [tabActive, setTabActive] = useState({
        "activeToDo": true,
        "rejectedByAuditor": false,
        "rejectedByChecker": false,
    });

    const handleTabChange = (tab: string) => {
        setTabActive({
            "activeToDo": false,
            "rejectedByAuditor": false,
            "rejectedByChecker": false,
            [tab]: true,
        });
    };

    const [ show, setShow ] = useState({
        "download": false,
        "transactionType": false
    });

    const onCloseShow = (fromClick: any) => {
        
        if (fromClick == "download"){
            setShow({
                "download": false,
                "transactionType": false
            });
        }
        else {
            setShow({
                "download": false,
                "transactionType": false
            });
        }
    };

    const onChangeShow = (fromClick: any) => {
        if (fromClick == "download"){
            setShow({
                "download": !show.download,
                "transactionType": false
            });
        }
        else {
            setShow({
                "download": false,
                "transactionType": !show.transactionType
            });
        }
    };

    
    return (
        <>
            <Box sx={{
                "alignItems": "center",
                "background": "white",
                "borderRadius": "15px",
                "fontFamily": "Poppins",
                "paddingBottom": "200px",
                "paddingTop": "20px",
            }}>
                
                <Grid paddingLeft="30px" paddingRight="30px" paddingBottom="200px">
                    <Box
                        sx={{
                            "alignItems": "center",
                            "background": "#F6F9FD",
                            "border": "lightBlue dashed 2px",
                            "borderRadius": "15px",
                            "display": "flex",
                            "fontFamily": "Poppins",
                            "height": "450px",
                            "justifyContent": "center",
                            "width": "100%",
                        }}
                    >
                        <input
                            type="file"
                            accept={acceptStringFileFormat}
                            data-testid="input-testid"
                            ref={inputRef}
                            onClick={() => {
                                if (inputRef.current !== null) inputRef.current.value = "";
                            }}                            
                            hidden
                        />

                        <Box
                            sx={{
                                "alignItems": "center",
                                "display": "flex",
                                "flexDirection": "column",
                                "justifyContent": "center",
                                "width": "50%",
                            }}

                        >
                            <FileUploadIcon />

                            <FXButton
                                buttonVariant="submit"
                                sx={{ "marginTop": "10px" }}
                                size="small"
                                label="Upload File"
                                onClick={() => handleUpload()
                                }                                
                            />
                            
                            <Typography fontSize="11px" paddingTop="20px" fontFamily="Poppins">
                            Supported Formats: XLSX, XLS, CSV
                            </Typography>
                        </Box>
                    </Box>
                </Grid>   
            </Box>

        </>
    );
}
