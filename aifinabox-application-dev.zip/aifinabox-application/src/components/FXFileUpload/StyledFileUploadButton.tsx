import {
    Button,
    SxProps,
    styled
} from "@mui/material";

interface FXFileUploadProps{
    disabled?: boolean;
    size?: "small" | "medium";
    sx?: SxProps;
    variant?: string;
}

const StyledFileUploadButton = styled(Button, {})<FXFileUploadProps>(() => {
    return {
        "&.MuiButton-text": {
            "color": "#000000",
            "fontFamily": "Poppins",
            "fontSize": "12px",
            "fontStyle": "normal",
            "fontWeight": 500,  
            "lineHeight": "18px",
        },
        "&:hover": { "backgroundColor": "#E7F1FF" },
        ":disabled": {
            "opacity": 0.4,
        },
        "backgroundColor": "#E7F1FF",
        "borderRadius": "5px",      
        "display": "flex",
        "height": "33px",
    };
});

export default StyledFileUploadButton;

