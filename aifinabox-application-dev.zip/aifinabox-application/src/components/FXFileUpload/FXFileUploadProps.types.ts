import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { FileDetails } from "../FXFileUpload/FileDetails.types";
import {  ReactNode } from "react";
import { SxProps } from "@mui/material";

export type AcceptedFormat = 
        ".csv" |
        ".xml" |
        ".xlsx" |
        ".txt" 

export interface FXFileUploadProps {
        accept?: AcceptedFormat[];
        assetType?: string;
        buttonName?: string;
        disabled?: boolean;
        documentType?: string;
        error?: boolean;
        helperText?: ReactNode;
        label?: string;
        identifier?: string;
        maxLength?: number;
        onBlur?: () => void;
        onFieldErrorChange?: (fieldError: FieldValidation) => void;
        onFileUpload: (fileDetails: FileDetails) => void;
        onFocus?: () => void;
        onRemoveFile?: () => void;
        onS3PresignedUrlFetch?: (format: string, s3PresignedUrl: string, s3Key: string) => void;
        onValueChange?: (result: string) => void;
        placeholder?: string;
        required?: boolean;
        s3CustomFileName?: string;
        sx?: SxProps;
        sxButton?: SxProps;
        sxCrossIcon?: SxProps;
        type?: string;
        value?: string;
        verified?: boolean;
}
