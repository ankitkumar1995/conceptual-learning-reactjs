export interface FileDetails {
    "file": File | null;
    // "dimensions": string;
}
