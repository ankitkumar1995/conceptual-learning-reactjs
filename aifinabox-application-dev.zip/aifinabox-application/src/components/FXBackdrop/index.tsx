import Backdrop from "@mui/material/Backdrop";
import CircularProgress from "@mui/material/CircularProgress";
import { FXBackdropProps } from "./FXBackdropProps.types";
import React from "react";

const FXBackdrop: React.FC<FXBackdropProps> = ({
    open,
    invisible,
}) => {
    return (
        <Backdrop
            sx={{ 
                "color": "#ffffff", 
                "zIndex": (theme) => theme.zIndex.modal + theme.zIndex.drawer + 1 
            }}
            open={open}
            invisible={invisible}
        >
            <CircularProgress color="inherit" />
        </Backdrop>
    );
};

export default FXBackdrop;
