export interface FXBackdropProps {
    open: boolean;
    invisible?: boolean;
}
