export const TransactionPopUpStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "250px",
    "left": "40%",
    "position": "absolute",
    "top": "25%",
    "width": "350px"
};
