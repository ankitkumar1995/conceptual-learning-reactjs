import {
    Box,
    IconButton,
    Modal,
    Paper,
    Radio,
    Typography
} from "@mui/material";

import { FieldValidation, initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import React, {
    RefObject,
    createRef,
    useEffect,
    useState
} from "react";
import {
    setFileFormat,
    setS3Key,
    setS3Url
} from "../../redux/InitiateTransaction/MFGains/Maker/UploadFile/reducer";
import { useDispatch, useSelector } from "react-redux";
import { AcceptedFormat } from "../FXFileUpload/FXFileUploadProps.types";
import CloseImageIcon from "../../icons/CloseImageIcon";
import FXButton from "../FXButton";
import FXRadioGroup from "../FXRadioGroup";
import { FXTransactionTypePopUpProps } from "./FXTransactionTypePopUpProps.types";
import MFGainsPageContextDispatchActionsProvider from "../../redux/InitiateTransaction/MFGains/PageContext/diapatchActionProvider";
import { RootState } from "../../redux/store";
import { TransactionPopUpStyles } from "./TransactionPopUpStyles";
import TransactionTypeDetailsFormDispatchActionsProvider from "../../redux/InitiateTransaction/MFGains/Maker/UploadFile/dispatchActionsProvider";
import axios from "axios";
import { setBatchNo } from "../../redux/InitiateTransaction/MFGains/PageContext/reducer";
import { setOpenBackdrop } from "../../redux/ApplicationContext/reducer";
import useFetchBatchNumber from "../../hooks/api/useFetchBatchNumber";
import usePostMFGainsUpload from "../../hooks/api/usePostMFGainsUpload";
// import MakerMutualFundGainsPage from "../../pages/InitiateTransaction/MutualFundGains/Maker";

const FXTransactionTypePopUp: React.FC<FXTransactionTypePopUpProps> = ({
    accept,
    disabled,    
    onClose,
    open,
    successPopUpShow,
    failedPopUpShow,
    onFileUpload,
    uploadedData,
}) => {
    const inputRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>();
    const acceptedFileFormat: AcceptedFormat[] = [".xml", ".csv", ".xlsx", ".txt"];
    const acceptStringFileFormat = accept?.join(",") || acceptedFileFormat.join(",");

    const [event, setEvent] = useState<React.ChangeEvent<HTMLInputElement>>();


    const {
        setBatchNo,
    } = MFGainsPageContextDispatchActionsProvider();

    const mfGainFormState = useSelector(
        (state: RootState) =>
            state
                .initiateTransactionState
                .mfGainState
                .makerUploadFile
    );

    const { isActive } = mfGainFormState;

    const appState = useSelector(
        (state: RootState) => state.applicationContextState
    );

    const { clientId } = appState;

    const authState = useSelector(
        (state: RootState) => state.authenticationState
    );

    const {userId} = authState;

    const { setIsActive, setFileName, setIdentifier, setFileFormat, setS3Key, setS3Url } = TransactionTypeDetailsFormDispatchActionsProvider();

    useEffect(() => {
        if (disabled) setFileName("");
    }, [disabled]);

    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };
    
    const userContextState = useSelector(
        (state: RootState) =>
            state.userContextState
    );

    const {firstName, lastName} = userContextState;

    const mergeUserName = (first: string, last: string) => {
        return first + " " + last;
    };
    const dispatch = useDispatch();
    const useFetchBatchNo = useFetchBatchNumber();
    const postMFGainsUpload = usePostMFGainsUpload();

    const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => { 

        if (event.target.files == null) return;
        const data = event.target.files[0];
        const fileType = `.${data.name.split(".")[1]}` as AcceptedFormat;

        if (event.target.files && acceptedFileFormat.includes(fileType)){
            const data = {
                "file": event.target.files !== null ? event.target.files[0] : null,
            };
            onFileUpload(data);
            successPopUpShow();
        }
        else {
            console.log("file upload fail");            
            failedPopUpShow();
        }
    };


    const getS3SignedURL = async (e: React.ChangeEvent<HTMLInputElement>, batchNo: string) => {
        dispatch(setOpenBackdrop(true));
        
        let s3SignedUrl = "", s3Key = "";
        
        const file = (e.target.files !== null) ? e.target.files[0] : null;
        const name = (file !== null) ? file.name : "";
        const size = (file !== null) ? file.size : 0;
        const extension = (name !== undefined) ? name.split('.').pop() : "";

        let data = {
            "assetType": "MF Gains File",
            "documentType": "AIFMFGF",
            "fileExtension": extension,
            "fileName": name,
            "fileSize": size/(1024**2),
            "identifier": `BATCH_NUMBER_${batchNo}`
        };

        const config = {
            "data": JSON.stringify(data),
            "method": "post",
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT}/s3presignedurl`,
        };
        
        await axios(config)
            .then(async(result) => {
                s3Key = result.data.key;
                s3SignedUrl = result.data.preSignedUrl;

                const putS3ObjectAxiosConfig = {
                    "data": file,
                    "headers": { 
                        "Content-Type": "application/octet-stream",
                    },
                    "method": "put",
                    "url": s3SignedUrl,
                };         
        
                await axios(putS3ObjectAxiosConfig)
                    .then(() => {
                        console.log("is active", isActive);
                        postMFGainsUpload( s3Key, userId, clientId, mergeUserName(firstName, lastName), batchNo, isActive)
                            .then((result) => {                                
                                setBatchNo(result.batchNo);
                                uploadedData(result);
                            });
                    })
                    .catch(() => {
                        dispatch(setOpenBackdrop(false));                        
                    });

                const { bucketName, format } = result.data;

                setFileFormat(format);
                setS3Key(s3Key);
                setS3Url(s3SignedUrl);
                dispatch(setOpenBackdrop(false));
            })
            .catch(function (error) {
                const statusCode = error.response.status;

                if (statusCode === 475) {
                    dispatch(setOpenBackdrop(false));
                }
            });
    };

    const handleFileUploadToBucket = async (event: any) => {
        let result = await useFetchBatchNo("AIFBATCH");

        if (result !== undefined) {
            setBatchNo(result);
            // setFileName(result);
            setIdentifier(`BATCH_NUMBER_${result}`);
            getS3SignedURL(event, result);
            successPopUpShow();
        }
    };

    return (
        <> 
            <Modal open={open}>
                <Paper sx={TransactionPopUpStyles}>
                    
                    <Box
                        display="flex"
                        justifyContent="center"
                    >
                        <Typography variant="popupSubDescription" fontSize="18px" sx={{ "padding": "20px 80px 0px 20px" }}>
                            Transaction Types
                        </Typography>
                        
                        <IconButton disableRipple onClick={handleOnClose} sx={{ "padding": "10px 25px 0px 20px" }}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box>
                    
                    <input
                        type="file"
                        accept={acceptStringFileFormat}
                        data-testid="input-testid"
                        ref={inputRef}
                        onClick={() => {
                            if (inputRef.current !== null) 
                                inputRef.current.value = "";
                        }}
                        onChange={(event) => {
                            handleFileUpload(event);
                            handleFileUploadToBucket(event);
                        }}
                        hidden
                    />

                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "30px 0px 10px 0px" }}
                    >
                        <FXRadioGroup
                            label="" 
                            row 
                            required
                            radioButtonValues={[{"label": "MF Gain","value": "MFG"},{"label": "MF Payout","value": "MFP"}]}
                            value={isActive}   
                            onValueChange={(value) => {
                                setIsActive(value);
                            }}
                        />
                        
                    </Box>

                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "30px 30px 20px 25px" }}
                    >
                        
                        <FXButton
                            buttonVariant="submit"
                            fullWidth
                            label="Continue"    
                            onClick={() => {
                                console.log("continue button");                                
                                inputRef.current?.click(); 
                                                             
                            }}     
                                                  
                        />
                    
                    </Box>               
                    
                </Paper>
            </Modal>
        </>
    );
};

export default FXTransactionTypePopUp;
