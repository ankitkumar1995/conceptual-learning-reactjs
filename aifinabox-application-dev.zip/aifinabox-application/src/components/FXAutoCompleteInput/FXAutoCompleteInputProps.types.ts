import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import { ReactNode } from "react";
import { SxProps } from "@mui/material";

export interface FXAutoCompleteInputProps {
    crossCheckValue?: string;
    defaultOpen?: boolean;
    defaultValue?: string;
    disabled?: boolean;
    disableBGColor?: string;
    disablePortal?: boolean;
    error?: boolean;
    forbidTo?: 
        "aplhanumeric" |
        "name" |
        "namespacecountrycity" |
        "numbers";
    formLabelSx?: SxProps;
    freeSolo?: boolean;
    helperText?: ReactNode;
    hideLabel?: boolean;
    inputLabel?: string;
    label?: string;
    masterName?: string;
    menuItems: MenuItem[];
    onBlur?: () => void;
    onBlurValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onClose?: (event: object) => void;
    onChangeValidator?: (value: string, options: Object) => FieldValidation;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onOpen?: (event: object) => void;
    onValidationFailure?: () => void;
    onValidationSuccess?: () => Promise<void>;
    onValueChange?: (value: string) => void;
    othersOption?: boolean;
    required?: boolean;
    size?: "small" | "medium";
    startAdornment?: string;
    sx?: SxProps;
    validatorOptions?: Object;
    value?: string;
    varient?: "filled" | "standard";
    verified?: boolean;
    warning?: boolean;
}
