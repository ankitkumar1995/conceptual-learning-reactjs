import {
    Autocomplete,
    Box,
    FormControl,
    FormHelperText,
    FormLabel,
    InputAdornment,
    InputLabel,
    Stack,
    Typography,
    createFilterOptions
} from "@mui/material";
import { SyntheticEvent, useState } from "react";

import ErrorIcon from "@mui/icons-material/Error";
import { FXAutoCompleteInputProps } from "./FXAutoCompleteInputProps.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import StyledTextField from "../FXInput/StyledTextField";

const filter = createFilterOptions<MenuItem>();

const FXAutoCompleteInput: React.FC<FXAutoCompleteInputProps> = ({
    crossCheckValue,
    defaultOpen,
    defaultValue,
    disabled,
    disableBGColor,
    disablePortal,
    error,
    forbidTo,
    freeSolo,
    helperText,
    hideLabel,
    inputLabel,
    label,
    masterName,
    menuItems,
    onBlur,
    onBlurValidator,
    onFieldErrorChange,
    onChangeValidator,
    onClose,
    onOpen,
    onValidationFailure,
    onValidationSuccess,
    onValueChange,
    othersOption,
    required,
    size,
    startAdornment,
    sx,
    validatorOptions,
    value,
    varient,
    formLabelSx,
    verified,
    warning,
}) => {
    const [fieldValue, setFieldValue] = useState(defaultValue ?? "");
    let val: RegExp;

    const handleOnChange = async (event: SyntheticEvent<Element, Event>, value: string | MenuItem | null) => {
        let result;
        const testerValue = value as string;
        if (value != null && (typeof value !== "string")) {
            if (value.label === "Others") {
                result = value.value;
                setFieldValue(value.value);
                if (typeof onValueChange !== "undefined") onValueChange(value.value);
            } else {
                const selectedItem = menuItems.find(item => item.label === value.label);

                if (typeof selectedItem !== "undefined") {
                    result = selectedItem.value;
                    setFieldValue(result);
                    if (typeof onValueChange !== "undefined") onValueChange(result);
                }
            }
        } else {
            result = "";
            setFieldValue("");
            if (typeof onValueChange !== "undefined") onValueChange("");
        }

        if (
            required && 
            result === "" &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }
        else if (
            required && 
            result !== "" &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": "",
                "isError": false,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            !(required && result === "") &&
            !error &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldErrorChange !== "undefined"
        ) {
    
            await onBlurValidator(testerValue, validatorOptions)
                .then(async (result) => {
                    onFieldErrorChange(result);
                });
        }

    };

    const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
        const keyCode = event.keyCode || event.which;
        const keyValue = String.fromCharCode(keyCode);

        switch (forbidTo) {
        case "aplhanumeric":
            val = /^[a-zA-Z0-9]+$/;
            break;
        
        case "name": 
            val = /^[a-zA-Z][a-zA-Z\s]*$/;
            break;
        
        case "numbers":
            val = /^[0-9]+$/;
            break;
        
        default:
            break;
        }
    
        if (!val.test(keyValue)) {
            event.preventDefault();
        }
    };

    const handleOnBlur = async () => {
        let isFieldEmpty = false;

        if (
            required && 
            fieldValue === "" &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            onFieldErrorChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            crossCheckValue !== undefined &&
            fieldValue !== crossCheckValue &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }

        if (
            !(required && isFieldEmpty) &&
            !error &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldErrorChange !== "undefined"
        ) {
            await onBlurValidator(fieldValue, validatorOptions)
                .then(async (result) => {
                    onFieldErrorChange(result);

                    if (
                        !result.isError && 
                        fieldValue.length &&
                        onValidationSuccess
                    )                     
                        await onValidationSuccess();
                    
                    else if (
                        result.isError && 
                        onValidationFailure
                    ) 
                        onValidationFailure();
                });
        }
        
        if (typeof onBlur !== "undefined") onBlur();
    };

    return (
        <FormControl
            className={warning ? "warning" : ""}
            disabled={disabled}
            error={error}
            fullWidth
            hiddenLabel
            variant={varient ?? "filled"}
            sx={{ 
                ... formLabelSx, 
                "&.warning": {
                    "& .MuiSelect-select": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >

            <InputLabel sx={{ "color": "#00000099" }}>
                {inputLabel}
            </InputLabel>

            {
                (hideLabel === undefined || !hideLabel) && 
                <FormLabel sx={{ "marginTop": "-5px", "paddingBottom": "10px" }}> 
                    <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                        {(required ? `${label} *`: label)} 
                    </Typography>
                </FormLabel>
            }

            <Autocomplete
                fullWidth
                disabled={disabled}
                disableClearable={!(value ?? fieldValue)}
                freeSolo={freeSolo}
                disablePortal={disablePortal}
                filterOptions={(options, params) => {
                    const filtered = filter(options, params);
            
                    const { inputValue } = params;
                    const isExisting = options.some(
                        (option) => inputValue === option.label
                    );

                    if (inputValue !== "" && !isExisting && othersOption) {
                        filtered.push({
                            "label": "Others",
                            "value": "Others",
                        });
                    }
            
                    return filtered;
                }}
                value={value ?? fieldValue}
                options={menuItems}
                getOptionLabel={(option) => {
                    if (typeof option === "string") 
                        return option;
                    
                    return option.label;
                }}
                readOnly={disabled}
                renderOption={(props, option) => <li {...props}>{option.label}</li>}
                onChange={handleOnChange}
                onClose={onClose}
                onOpen={onOpen}
                sx={{
                    "& .MuiSvgIcon-root": {
                        "color": "#337fc9",
                    },
                }}
                renderInput={(params) =>
                    <StyledTextField
                        {...params}
                        placeholder={`${label}`}
                        disabled={disabled}
                        required={required}
                        helperText={
                            (helperText && helperText.toString().length > 0)
                                ? <Stack direction="row" mt="5px" ml="-10px"> 
                                    {
                                        error && 
                                        <ErrorIcon
                                            style={{ 
                                                "color": "#D03240",
                                                "fontSize": "15px",
                                                "marginRight": "5px" 
                                            }}
                                        />
                                    } 
                                    
                                    <Box>{helperText}</Box> 
                                </Stack>
                                : ""
                        }
                        onKeyPress={handleKeyPress}
                        value={value ?? fieldValue}
                        onBlur={handleOnBlur}
                        InputProps={{
                            ...params.InputProps,
                            "disableUnderline": true,
                            "startAdornment": (
                                (startAdornment !== undefined)
                                    ?
                                    <InputAdornment position="start">
                                        {startAdornment}
                                    </InputAdornment>
                                    :
                                    undefined
                            )
                        }}
                        sx={{
                            "& .MuiFilledInput-root ": {
                                "backgroundColor": disabled ? disableBGColor || "#e0e0e0" : "#FFFFFF",
                                "border": masterName ==="contact_master" || masterName ==="fund_master"?"none": helperText ? "1px solid #d32f2f" : "1px solid #DDEAF3",
                                "marginLeft": masterName ==="contact_master" || masterName ==="fund_master"?"-12px":"0px",
                                "minHeight": "58px",
                                "paddingTop": "0px",
                            },
                            "& input::placeholder": {
                                "color": "#9497fA3",
                                "fontSize": "14px",
                                "fontStyle": "italic",
                                "opacity": "0.7",
                                "textTransform": "capitalize",
                            },
                            ...sx
                        }}
                        FormHelperTextProps={{
                            "sx": {
                                "color": "#d32f2f",
                                "fontSize": "10px",
                                "fontWeight": 500,     
                            }
                        }}

                        variant="filled"
                        size={size ?? "medium"}
                    /> 
                }
            />
        </FormControl>
    );
};

export default FXAutoCompleteInput;
