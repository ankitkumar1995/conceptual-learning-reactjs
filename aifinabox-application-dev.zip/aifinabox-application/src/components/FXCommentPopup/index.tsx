import {
    Box,
    IconButton,
    Modal,
    Paper,
    Typography
} from "@mui/material";

import CloseImageIcon from "../../icons/CloseImageIcon";
import { CommentPopupStyles } from "./CommentPopupStyles";
import { FXCommentPopupProps } from "./FXCommentPopupProps.types";
import React from "react";
import SubmitImageIcon from "../../icons/SubmitImageIcon";

const FXCommentPopup: React.FC<FXCommentPopupProps> = ({
    description,
    ihnoDescription,
    onClose,
    open,
    title
}) => {
    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };

    return (
        <> 
            <Modal open={open}>
                <Paper sx={CommentPopupStyles}>
                    <Box sx={{ "display": "flex","justifyContent": "space-between", "padding": "25px 25px 0px 25px" ,}}>
                        <Typography sx={{"color": "#000", "fontSize": "30px", "fontWeight": "400" }}>
                            {`${title}`}
                        </Typography>
                        <IconButton onClick={handleOnClose} sx={{"fontSize": "30px", "padding": "0px" ,}}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box>
                    
                    <Box
                        display="flex"
                        justifyContent="start"
                        sx={{ "fontWeight": "200", "padding": "50px 0px 0px 25px" }}
                    >
                        <Typography sx={{"color": "#000"}}>
                            {`${description}`}
                        </Typography>
                    </Box>

                    {/* {
                            (ihnoDescription !== undefined) 
                            &&
                            <Box
                                display="flex" 
                                justifyContent="center"
                            >
                                <Typography variant="popupSubDescription">
                                    {`${ihnoDescription}`}
                                </Typography>
                            </Box>
                        } */}
                </Paper>
            </Modal>
        </>
    );
};

export default FXCommentPopup;
