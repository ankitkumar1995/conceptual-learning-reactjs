export interface FXCommentPopupProps {
    description?: string;
    ihnoDescription?: string;
    onClose?: () => void;
    open: boolean;
    title: string;
}
