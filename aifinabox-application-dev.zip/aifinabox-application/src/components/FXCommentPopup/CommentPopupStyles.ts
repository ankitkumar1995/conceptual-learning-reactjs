export const CommentPopupStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "180px",
    "left": "35%",
    "position": "absolute",
    "top": "30%",
    "width": "450px",
};
