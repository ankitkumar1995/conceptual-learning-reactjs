import { AcceptedFormat, FXFileInputProps } from "./FXFileInputProps.types";
import {
    Box,
    FormControl,
    FormLabel,
    IconButton,
    Stack,
    Typography
} from "@mui/material";
import { FieldValidation, initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import React, {
    RefObject,
    createRef,
    useEffect,
    useState,
} from "react";

import { BackendValidationError } from "../../interfaces/BackendValidationError.types";
import ClearRoundedIcon from "@mui/icons-material/ClearRounded";
import ErrorIcon from "@mui/icons-material/Error";
import { FileDetails } from "./helpers/FileDetails.types";
import InputAdornment from "@mui/material/InputAdornment";
import StyledFileInputButton from "./StyledFileInputButton";
import StyledFileInputField from "./StyledFileInputField";
import axios from "axios";
import getImageDimensions from "./helpers/getImageDimensions";
import { setOpenBackdrop } from "../../redux/ApplicationContext/reducer";
import { useDispatch } from "react-redux";

const FXFileInput: React.FC<FXFileInputProps> = ({
    accept,
    assetType,
    buttonName,
    disabled,
    documentType,
    error,
    helperText,
    identifier,
    label,
    onFieldErrorChange,
    onFileUpload,
    onRemoveFile,
    onS3PresignedUrlFetch,
    placeholder,
    required,
    s3CustomFileName,
    sx,
    sxButton,
    sxCrossIcon,
    type,
    value,
    defaultValue,
    hideLabel,
}) => {
    const inputRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>();

    const acceptedFileFormat: AcceptedFormat[] = [".eml", ".jpeg", ".jpg", ".pdf", ".png", ".svg"];
    const acceptStringFileFormat = accept?.join(",") || acceptedFileFormat.join(",");

    const [fileName, setFileName] = useState("");
    const [event, setEvent] = useState<React.ChangeEvent<HTMLInputElement>>();

    const dispatch = useDispatch();

    useEffect(() => {
        if (disabled) setFileName("");
    }, [disabled]);

    useEffect(() => {
        if (event !== undefined && onS3PresignedUrlFetch !== undefined) {
            (identifier === undefined || identifier.length > 0)
                ? getS3SignedURL(event)
                : onS3PresignedUrlFetch("", "", ""); 
        }
    }, [identifier]);

    const handleOnFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        let validation = initializeFieldValidation();

        if (event.target.files) {
            let imageDimensions = "";
            getImageDimensions(event.target.files[0])
                .then((dimensions: string) => {
                    imageDimensions = dimensions;
                })
                .catch((error) => {
                    console.error(error);
                });
            const fileDetails = {
                "dimensions": imageDimensions, 
                "file": event.target.files !== null ? event.target.files[0] : null,   
            };
            onFileUpload(fileDetails);
            
        }
        setEvent(event);
        changeTextFieldContentToFilename(event);

        if (onFieldErrorChange) onFieldErrorChange(validation);

        if (onS3PresignedUrlFetch !== undefined)
        {
            (identifier === undefined || identifier.length > 0)
                ? getS3SignedURL(event)
                : onS3PresignedUrlFetch("","",""); 
        }
    };

    const handleRemoveFile = () => {
        let validation = initializeFieldValidation();
        setFileName("");
        setEvent(undefined);

        if (onFieldErrorChange) onFieldErrorChange(validation);
        if (inputRef.current !== null) inputRef.current.value = '';
        if (onRemoveFile !== undefined) onRemoveFile();
    };

    const changeTextFieldContentToFilename = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = (e.target.files !== null) ? e.target.files[0] : null;
        const name = (file !== null) ? file.name : "";
        setFileName(name);
    };
    
    const getS3SignedURL = async (e: React.ChangeEvent<HTMLInputElement>) => {
        dispatch(setOpenBackdrop(true));
        
        let s3SignedUrl = "", s3Key = "";
        
        const file = (e.target.files !== null) ? e.target.files[0] : null;
        const name = (file !== null) ? file.name : "";
        const size = (file !== null) ? file.size : 0;
        const extension = (name !== undefined) ? name.split('.').pop() : "";

        let data = {
            "assetType": assetType,
            "documentType": documentType,
            "fileExtension": extension,
            "fileName": label,
            "fileSize": size/(1024**2),
            "identifier": identifier
        };

        const config = {
            "data": JSON.stringify(data),
            "method": "post",
            "url": `${import.meta.env.VITE_AIF_IN_A_BOX_API_GATEWAY_ROOT}/s3presignedurl`,
        };
        
        await axios(config)
            .then((result) => {
                s3Key = result.data.key;
                s3SignedUrl = result.data.preSignedUrl;
                const { bucketName, format } = result.data;

                const s3KeyWithBucket = `${bucketName}: ${s3Key}`;

                if (onS3PresignedUrlFetch !== undefined) 
                    onS3PresignedUrlFetch(format, s3KeyWithBucket, s3SignedUrl);
                dispatch(setOpenBackdrop(false));
            })
            .catch(function (error) {
                const statusCode = error.response.status;

                if (onS3PresignedUrlFetch !== undefined) onS3PresignedUrlFetch("", "", "");

                if (statusCode === 475) {
                    const validationErrors = JSON.parse(
                        error
                            .response
                            .data
                            .message
                    );
                    
                    validationErrors.map((validationError: BackendValidationError) => {
                        const error: FieldValidation = {
                            "helperText": validationError.error,
                            "isError": true,
                            "isVerified": false,
                            "isWarning": false
                        };
                        
                        if (onFieldErrorChange) 
                            onFieldErrorChange(error);
                    });
                    dispatch(setOpenBackdrop(false));
                }
            });
    };

    return (
        <FormControl fullWidth disabled={disabled} error={error}>
            {
                (hideLabel === undefined || !hideLabel) && 
                <FormLabel sx={{ "marginTop": "-4px", "paddingBottom": "9px" }}> 
                    <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                        {(required ? `${label} *`: label)} 
                    </Typography>
                </FormLabel>
            }
            
            <input
                type="file"
                accept={acceptStringFileFormat}
                data-testid="input-testid"
                ref={inputRef}
                defaultValue={value}
                onClick={() => {
                    if (inputRef.current !== null) 
                        inputRef.current.value = '';
                }}
                onChange={(event) => {
                    handleOnFileChange(event);
                }}
                hidden
            />

            <StyledFileInputField
                placeholder={placeholder}
                disabled={disabled}
                required={required}
                type={type}
                error={error}
                value={value ?? fileName}
                helperText={
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            }
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }
                inputProps={{
                    "readOnly": true, 
                    "sx": { 
                        "paddingBottom": "20px", 
                        "paddingLeft": (placeholder !== undefined) ? "10px" : "25px", 
                        "paddingTop": "20px",
                    },                    
                }}
                InputProps={{
                    "disableUnderline": true,
                    "endAdornment": (
                        <Box width="40%">
                            <InputAdornment position="end">
                                {((value ?? fileName) !== "") && 
                                        <IconButton 
                                            disableRipple
                                            disabled={disabled}
                                            sx={{"color": "#000000"}}
                                            onClick={handleRemoveFile}
                                        >
                                            <ClearRoundedIcon sx={{...sxCrossIcon }} />
                                        </IconButton>
                                }
                                <StyledFileInputButton 
                                    disabled={disabled}
                                    fullWidth
                                    onClick={() => inputRef.current?.click()}
                                    sx={{...sxButton}}
                                >
                                    { buttonName !== undefined ? buttonName : "Choose" }
                                </StyledFileInputButton>
                            </InputAdornment>
                        </Box>
                    ),
                }}
                FormHelperTextProps={{
                    "sx": {
                        "fontSize": "10px",
                        "fontWeight": 500,                    
                    },
                }}
                sx={{...sx}}
                autoComplete="off"
                variant="filled"
                size="medium"
            />
        </FormControl>
    );
};
export default FXFileInput;
