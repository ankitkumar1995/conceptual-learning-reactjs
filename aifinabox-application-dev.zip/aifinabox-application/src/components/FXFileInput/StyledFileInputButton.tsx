import {
    Button,
    SxProps,
    styled
} from "@mui/material";

interface FXFileInputButtonProps{
    disabled?: boolean;
    size?: "small" | "medium";
    sx?: SxProps;
    variant?: string;
}

const StyledFileInputButton = styled(Button, {})<FXFileInputButtonProps>(() => {
    return {
        "&.MuiButton-text": {
            "color": "#000000",
            "fontFamily": "Poppins",
            "fontSize": "12px",
            "fontStyle": "normal",
            "fontWeight": 400,  
        },
        "&:hover": { "backgroundColor": "#E7F1FF" },
        ":disabled": {
            "opacity": 0.4,
        },
        "backgroundColor": "#E7F1FF",
        "borderRadius": "3px",      
        "display": "flex",
        "height": "33px",
    };
});

export default StyledFileInputButton;
