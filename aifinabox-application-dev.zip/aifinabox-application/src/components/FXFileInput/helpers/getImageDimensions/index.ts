function getImageDimensions(file: File): Promise<string> {
    return new Promise((resolve) => {
        const image = new Image();
        image.src = URL.createObjectURL(file);

        image.onload = () => {
            const dimensions = `${image.width}x${image.height}`;
            resolve(dimensions);
        };
    });
}

export default getImageDimensions;
