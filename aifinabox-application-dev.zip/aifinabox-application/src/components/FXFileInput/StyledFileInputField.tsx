import { TextField, styled } from "@mui/material";
import { FXInputProps } from "../FXInput/FXInputProps.types";

const StyledFileInputField = styled(TextField, {})<FXInputProps>(() => {
    return {
        "& .MuiFilledInput-root": {
            "background": "#FFFFFF",
            "border": "1px solid #DDEAF3",
            "borderRadius": "6px",
            "color": "#9497A3",
            "display": "flex",
            "fontFamily": "Poppins",
            "fontSize": "14px",
            "fontStyle": "normal",
            "fontWeight": 400,
            "height": "57.89px",
        },
        "& .MuiFilledInput-root.Mui-error": {
            "background": "#FFFFFF",
            "border": "1px solid #D03240",
        },
        "& .MuiFilledInput-root:hover": { 
            "backgroundColor": "#FFFFFF",
            "height": "57.89px",
        },
    };
});

export default StyledFileInputField;
