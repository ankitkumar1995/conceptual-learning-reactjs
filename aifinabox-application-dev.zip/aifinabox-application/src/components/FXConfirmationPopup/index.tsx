import {
    Box,
    Modal,
    Paper,
    Stack,
    Typography
} from "@mui/material";

import ConfirmationPopupStyles from "./ConfirmationPopupStyles";
import FXButton from "../FXButton";
import { FXConfirmationPopupProps } from "./FXConfirmationPopupProps.types";
import React from "react";
import WarningIcon from "../../icons/WarningIcon/index";

const FXConfirmationPopup: React.FC<FXConfirmationPopupProps> = ({
    description,
    onClose,
    onNoClicked,
    onYesClicked,
    open,
    subDescription,
    sx
}) => {
    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };

    const handleYesClicked = () => {
        if (typeof onYesClicked !== "undefined") onYesClicked();
    };

    const handleNoClicked = () => {
        if (typeof onNoClicked !== "undefined") onNoClicked();
    };

    return (
        <Modal open={open}>
            <Paper sx={ConfirmationPopupStyles}>
                <Box 
                    flexDirection="column" 
                    justifyContent="center" 
                    alignItems="center" 
                    display="flex" 
                    paddingTop="10px"
                    sx={{...sx}}
                >
                    <Box paddingTop="40px">
                        <WarningIcon/>
                    </Box>

                    <Box paddingTop="30px">
                        <Typography variant="confirmPopupDescription">
                            {`${description}`}
                        </Typography>
                    </Box>

                    <Box paddingTop="10px">
                        <Typography variant="confirmPopupSubDescription">
                            {`${subDescription}`}
                        </Typography>
                    </Box>
                </Box>

                <Box width="80%" marginLeft="40px" marginTop="30px">
                    <Stack 
                        direction="row" 
                        justifyContent="center"  
                        alignItems="center"
                        spacing={2} 
                        display="flex" 
                    >
                        <FXButton
                            label="Yes" 
                            fullWidth 
                            buttonVariant="contained" 
                            onClick={handleYesClicked} 
                            sx={{"backgroundColor": "#E7F1FF", "height": "60px"}}
                        />

                        <FXButton 
                            label="No" 
                            fullWidth  
                            buttonVariant="contained" 
                            onClick={handleNoClicked}    
                            sx={{ "height": "60px" }}
                        />
                    </Stack>
                </Box>
            </Paper>
        </Modal>
    );
};

export default FXConfirmationPopup;
