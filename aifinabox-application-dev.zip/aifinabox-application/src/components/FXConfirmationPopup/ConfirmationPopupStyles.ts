const ConfirmationPopupStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "300px",
    "left": "35%",
    "position": "absolute",
    "top": "30%",
    "width": "450px",
};

export default ConfirmationPopupStyles;
