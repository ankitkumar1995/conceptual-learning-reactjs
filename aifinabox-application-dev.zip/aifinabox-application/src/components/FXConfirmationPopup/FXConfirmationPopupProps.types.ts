import { SxProps } from "@mui/material";

export interface FXConfirmationPopupProps {
    description?: string;
    onClose?: () => void;
    onNoClicked?: () => void;
    onYesClicked?: () => void;
    open: boolean;
    subDescription?: string;
    sx?: SxProps;
}
