import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import { SxProps } from "@mui/material";

export interface FXSelectCheckboxInputProps {
    crossCheckValue?: string;
    label?: string;
    defaultValue?: string;
    disabled?: boolean;
    error?: boolean;
    helperText?: string;
    inputLabel?:string;
    menuItems?: MenuItem[];
    menuSx?: React.CSSProperties;
    onBlur?: () => void;
    onClose?: (event: object) => void;
    //onFieldErrorChange: (value: string[]) => void;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onOpen?: (event: object) => void;
    onValueChange: (value: string[]) => void;
    required?: boolean;
    size?: "small" | "medium";
    variant?: "filled" | "outlined" | "standard";
    sx?: React.CSSProperties;
    value: string[];
    formLabelSx?: SxProps;
    verified?: boolean;
    warning?: boolean;
}
