import {
    Box,
    Checkbox,
    FormControl,
    FormHelperText,
    FormLabel,
    InputAdornment,
    InputLabel, 
    ListItemText, 
    MenuItem, 
    Stack, 
    Tooltip, 
    Typography, 
    createFilterOptions 
} from "@mui/material";

import ErrorIcon from "@mui/icons-material/Error";
import { FXSelectCheckboxInputProps } from "./FXSelectCheckboxInput.types";
import { SelectChangeEvent } from "@mui/material/Select";
import StyledCheckboxSelect from "./StyledSelectCheckboxInput";
import { useState } from "react";

const FXSelectCheckboxInput: React.FC<FXSelectCheckboxInputProps> = ({
    defaultValue,
    disabled,
    error,
    helperText,
    inputLabel,
    label,
    menuItems,
    menuSx,
    onBlur,
    onFieldErrorChange,
    onValueChange,
    value,
    variant,
    required,
    size,
    sx,
    formLabelSx,
    warning,
}) => {
    const [fieldValue, setFieldValue] = useState(defaultValue ?? "");
    const [tooltipOpen, setTooltipOpen] = useState(false);
    const [toolTipLabel, setToolTipLabel] = useState<string[]>([]);
    const handleChange = (event: SelectChangeEvent<unknown>) => {
        let result = event.target.value as string;
            
        if (typeof onValueChange !== "undefined" && typeof onFieldErrorChange !== "undefined") 
        {onValueChange( typeof result === "string" ? result.split(",") : result);
            setToolTipLabel(typeof result === "string" ? result.split(", "): result);
            onFieldErrorChange({
                "helperText": "",
                "isError": false,
                "isVerified": false,
                "isWarning": false,
            });
        }
    
        else {setFieldValue(result);
            if (onFieldErrorChange) {
                onFieldErrorChange({
                    "helperText": "",
                    "isError": false,
                    "isVerified": false,
                    "isWarning": false,
                });
            }
        }
    };

    const handleOnBlur = () => {
        let isFieldEmpty = false;
        if (
            required && 
            value.length === 0 &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            onFieldErrorChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        } else {
            isFieldEmpty = false;
            if (onFieldErrorChange) {
                onFieldErrorChange({
                    "helperText": ``,
                    "isError": false,
                    "isVerified": false,
                    "isWarning": false,
                });
            }
        }
    };

    const handleTooltip = (bool: boolean) => {
        setTooltipOpen(bool);
    };

    return (
        <FormControl
            className={warning ? "warning" : ""}
            disabled={disabled}
            error={error}
            fullWidth
            hiddenLabel
            variant={variant ?? "filled"}
            sx={{ 
                ... formLabelSx, 
                "&.warning": {
                    "& .MuiSelect-select": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >
            <InputLabel sx={{ "color": "#00000099" }}>
                {inputLabel}
            </InputLabel>

            <FormLabel sx={{ "marginTop": "-5px", "paddingBottom": "10px" }}> 
                <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                    {(required ? `${label} *`: label)} 
                </Typography>
            </FormLabel>

            <Tooltip title={value.toString()} arrow >
                <StyledCheckboxSelect
                    onMouseEnter={() => {handleTooltip(true);}}
                    onMouseLeave={() => {handleTooltip(false);}}

                    displayEmpty
                    variant={variant}
                    labelId="demo-multiple-checkbox-label"
                    id="demo-multiple-checkbox"
                    multiple
                    required={required}
                    error={error}
                    value={value ?? fieldValue}
                    onChange={handleChange}
                    onBlur={handleOnBlur}
                    sx={{ ...sx}}
                    renderValue={(selected: any) =>
                        ( selected.length ) === 0 ? "Select" : (selected.includes("All") ? "All" : selected.join(","))
                    }
                    disableUnderline={(variant === "standard") ? false : true}
                    size={size ?? "medium"}
                    inputProps={{
                        "sx": {
                            "color": (value.length === 0) ? "#9497A3" : "",
                        }
                    }}
                    MenuProps={{ 
                        "PaperProps": { "sx": { "maxHeight": "155px" , "maxWidth": "155px", "overflowX": "auto"} },
                        "sx": { "marginLeft": "0px" },
                    }}>
                    {
                        menuItems?.map((menuItem) => {
                            return (
                                <MenuItem 
                                    key={menuItem.value} 
                                    value={menuItem.value}
                                >
                                    <Checkbox checked={value.indexOf(menuItem.value) > -1} />
                                    <ListItemText primary={menuItem.label} />
                                </MenuItem>
                            );
                        })
                    }
                </StyledCheckboxSelect>
            </Tooltip>

            <FormHelperText
                sx={{
                    "fontSize": "10px",
                    "fontWeight": 500,
                }}
            >
                {
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }
            </FormHelperText>
        </FormControl>
    );
};

export default FXSelectCheckboxInput;
