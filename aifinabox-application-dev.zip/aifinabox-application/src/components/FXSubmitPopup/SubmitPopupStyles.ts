export const SubmitPopupStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "315px",
    "left": "0",
    "margin": "auto",
    "position": "absolute",
    "right": "0",
    "top": "20%",
    "width": "450px",
};
