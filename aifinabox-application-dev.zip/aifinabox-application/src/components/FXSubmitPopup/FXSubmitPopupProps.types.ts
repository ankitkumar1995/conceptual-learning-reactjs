export interface FXSubmitPopupProps {
    description?: string;
    ihnoDescription?: string;
    onClose?: () => void;
    open: boolean;
    batchNumber?: string;
}
