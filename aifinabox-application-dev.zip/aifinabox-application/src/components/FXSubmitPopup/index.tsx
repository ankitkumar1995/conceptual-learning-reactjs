import {
    Box,
    IconButton,
    Modal,
    Paper,
    Typography
} from "@mui/material";

import CloseImageIcon from "../../icons/CloseImageIcon";
import { FXSubmitPopupProps } from "./FXSubmitPopupProps.types";
import React from "react";
import SubmitImageIcon from "../../icons/SubmitImageIcon";
import { SubmitPopupStyles } from "./SubmitPopupStyles";

const FXSubmitPopup: React.FC<FXSubmitPopupProps> = ({
    description,
    ihnoDescription,
    onClose,
    open,
    batchNumber
}) => {
    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };

    return (
        <> 
            <Modal open={open}>
                <Paper sx={SubmitPopupStyles}>
                    <Box sx={{ "padding": "25px 25px 0px 405px" }}>
                        <IconButton disableRipple onClick={handleOnClose} sx={{ "padding": "0px" }}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box>

                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "20px 0px 30px 0px" }}
                    >
                        <SubmitImageIcon />
                    </Box>
                    
                    <Box
                        display="flex"
                        justifyContent="center"
                        sx={{ "padding": "0px 0px 10px 0px" }}
                    >
                        <Typography variant="popupDescription">
                            {`${description}`}
                        </Typography>
                    </Box>

                    {
                        (ihnoDescription !== undefined) 
                        &&
                        <Box
                            display="flex" 
                            justifyContent="center"
                        >
                            <Typography variant="popupSubDescription">
                                {`${ihnoDescription}`}
                            </Typography>
                        </Box>
                    }

                    {
                        batchNumber
                        &&
                        <Box
                            display="flex" 
                            justifyContent="center"
                        >
                            <Typography variant="popupSubDescription">
                                Batch No : {`${batchNumber}`}
                            </Typography>
                        </Box>
                    }
                </Paper>
            </Modal>
        </>
    );
};

export default FXSubmitPopup;
