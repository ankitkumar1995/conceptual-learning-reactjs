export type AcceptedFormat = ".csv" | ".xml" | ".xlsx"; 

export interface FXFileUploadButtonProps {
        accept?: AcceptedFormat[];
        assetType?: string;
        documentType?: string;
        onFileUpload: (event: any) => void;
}
