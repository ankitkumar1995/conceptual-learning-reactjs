import { AcceptedFormat, FXFileUploadButtonProps } from "./FXFileUploadButtonProps.types";
import React, { RefObject, createRef } from "react";

import FXButton from "../FXButton";

const FXFileUploadButton: React.FC<FXFileUploadButtonProps> = ({
    accept,
    onFileUpload,
}) => {
    const inputRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>();
    const acceptedFileFormat: AcceptedFormat[] = [".csv" , ".xml" , ".xlsx" ];
    const acceptStringFileFormat = accept?.join(",") || acceptedFileFormat.join(",");

    const handleOnFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            onFileUpload(event);
        }
    };

    return (
        <>
            <input
                type="file"
                accept={acceptStringFileFormat}
                data-testid="input-testid"
                ref={inputRef}
                onClick={() => {
                    if (inputRef.current !== null) 
                        inputRef.current.value = '';
                }}
                onChange={(event) => {
                    handleOnFileChange(event);
                }}
                hidden
            />

            <FXButton
                buttonVariant="submit"
                sx={{ "marginTop": "10px" }}
                size="small"
                label="Upload File"
                onClick={() => inputRef.current?.click()}
            />
        </>
    );
};
export default FXFileUploadButton;
