import { FieldValidation } from "../../interfaces/FieldValidation.types";
import dayjs from "dayjs";

export interface FXDateInputProps {
    crossCheckValue?: string;
    defaultCalendarMonth?: string | null;
    disableFuture?: boolean;
    disablePast?: boolean;
    disabled?: boolean;
    error?: boolean;
    helperText?: string;
    label?: string;
    minDate?: string | null;
    maxDate?: string | null;
    onBlur?: () => void;
    onBlurValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onChangeValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onFieldValidationChange?: (fieldValidation: FieldValidation) => void;
    onValidationFailure?: () => void;
    onValidationSuccess?: () => Promise<void>;
    onValueChange?: (dateString: string) => void;
    readOnlyTextField?: boolean;
    required?: boolean;
    shouldDisableDate?: (day: dayjs.Dayjs) => boolean;
    shouldDisableMonth?: (day: dayjs.Dayjs) => boolean;
    size?: "small" | "medium";
    sx?: React.CSSProperties;
    validatorOptions?: Object;
    value?: string | null;
    warning?: boolean;
}
