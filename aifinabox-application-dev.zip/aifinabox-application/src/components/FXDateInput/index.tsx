import {
    Box,
    FormControl,
    FormHelperText,
    FormLabel,
    Stack,
    Typography
} from "@mui/material";
import React, { useState } from "react";
import dayjs, { Dayjs } from "dayjs";

import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import { DesktopDatePicker } from "@mui/x-date-pickers/DesktopDatePicker";
import ErrorIcon from "@mui/icons-material/Error";
import { FXDateInputProps } from "./FXDateInputProps.types";
import { LocalizationProvider } from "@mui/x-date-pickers";
import StyledTextField from "../FXInput/StyledTextField";
import { initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import timezone from "dayjs/plugin/timezone";
import utc from "dayjs/plugin/utc";

dayjs.extend(utc);
dayjs.extend(timezone);

const FXDateInput: React.FC<FXDateInputProps> = ({
    crossCheckValue,
    defaultCalendarMonth,
    disabled,
    disableFuture,
    disablePast,
    error,
    helperText,
    label,
    minDate,
    maxDate,
    onBlur,
    onBlurValidator,
    onChangeValidator,
    onFieldValidationChange,
    onValueChange,
    onValidationFailure,
    onValidationSuccess,
    required,
    readOnlyTextField,
    shouldDisableDate,
    shouldDisableMonth,
    size,
    sx,
    validatorOptions,
    value,
    warning,
}) => {
    const [fieldValue, setFieldValue] = useState<Dayjs | null>(null);

    const handleOnBlur = async (event: React.FocusEvent<HTMLInputElement>) => {
        const dateString = event.target.value;
        let isFieldEmpty = false;
        
        if (
            required && 
            dateString === "" &&
            onFieldValidationChange
        ) {
            isFieldEmpty = true;
            onFieldValidationChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }
        if (
            !(required && isFieldEmpty) &&
            !error &&
            onChangeValidator &&
            validatorOptions &&
            onFieldValidationChange
        )
            await onChangeValidator(dateString, validatorOptions)
                .then(async (result) => {
                    onFieldValidationChange(result);
                });
        
        if (
            !(required && isFieldEmpty) &&
            !error &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldValidationChange !== "undefined"
        ) {
            await onBlurValidator(dateString, validatorOptions)
                .then(async (result) => {
                    onFieldValidationChange(result);

                    if (
                        !result.isError && 
                        dateString.length &&
                        onValidationSuccess
                    )                     
                        await onValidationSuccess();
                    
                    else if (
                        result.isError && 
                        onValidationFailure
                    ) 
                        onValidationFailure();
                });
        }

        if (
            crossCheckValue !== undefined &&
            dateString !== crossCheckValue &&
            onFieldValidationChange
        ) {
            onFieldValidationChange({
                "helperText": `${label} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }
        
        if (typeof onBlur !== "undefined") onBlur();
    };

    const handleChange = async (newValue: Dayjs | null) => {
        if (newValue === null) return ;
        
        const dateString = 
            newValue
                .utc()
                .local()
                .format("DD/MM/YYYY");

        if (typeof onValueChange !== "undefined") onValueChange(dateString);
        else setFieldValue(newValue);

        let validation = initializeFieldValidation();

        if (dateString.length === 10 && onChangeValidator && validatorOptions)
            validation = await onChangeValidator(dateString, validatorOptions);

        if (onFieldValidationChange)
            onFieldValidationChange(validation);
    };

    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <FormControl 
                className={warning ? "warning" : ""}
                error={error}
                fullWidth 
                sx={{
                    "&.warning": {
                        "& .MuiFilledInput-root": {
                            "borderColor": "#ff9800",
                        }
                    }
                }}
            >
                
                <FormLabel sx={{ "marginTop": "-5px", "paddingBottom": "10px" }}> 
                    <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                        {(required ? `${label} *`: label)} 
                    </Typography>
                </FormLabel>

                <DesktopDatePicker
                    disableFuture={disableFuture}
                    disablePast={disablePast}
                    disabled={disabled}
                    components={{ "OpenPickerIcon": CalendarTodayOutlinedIcon }}
                    value={
                        (typeof value !== "undefined") 
                            ? (value ? dayjs(value, "DD/MM/YYYY") : null) 
                            : fieldValue
                    }
                    onChange={handleChange}
                    minDate={minDate ? dayjs(minDate, "DD/MM/YYYY") : undefined}
                    maxDate={maxDate ? dayjs(maxDate, "DD/MM/YYYY") : undefined}
                    defaultCalendarMonth={dayjs(defaultCalendarMonth)}
                    
                    InputAdornmentProps={{ 
                        "position": "start", 
                        "sx": { 
                            "& .MuiIconButton-root": { 
                                "color": "#2057A6",
                                "marginLeft": 0,
                            }
                        }
                    }}
                    renderInput={
                        (params: any) => 
                            <StyledTextField
                                hiddenLabel
                                onKeyDown={
                                    readOnlyTextField
                                        ? (e) => e.preventDefault()
                                        : undefined
                                }
                                sx={{
                                    "& .MuiFilledInput-root": {
                                        "height": "57.89px",
                                    },
                                    "& .MuiInputBase-input": { 
                                        "borderLeft": "1px solid #F0F6FA", 
                                        "paddingBottom": "15px", 
                                        "paddingLeft": "15px" 
                                    },
                                    "& ::placeholder": {
                                        "fontStyle": "italic"
                                    },
                                    ...sx,
                                }} 
                                {...params}
                                error={error}
                                required={required}
                                onBlur={handleOnBlur}
                                InputProps={{ "disableUnderline": true, ...(params.InputProps) }}
                                autoComplete="off"
                                size={size ?? "medium"}
                                variant="filled"
                            />
                    }
                    shouldDisableDate={shouldDisableDate}
                    shouldDisableMonth={shouldDisableMonth}
                    inputFormat="DD/MM/YYYY"
                    views={[ "year", "month", "day" ]}
                    showDaysOutsideCurrentMonth
                />  

                <FormHelperText
                    sx={{
                        "fontSize": "10px",
                        "fontWeight": 500,
                    }}
                >
                    {
                        (helperText && helperText.toString().length > 0)
                            ? <Stack direction="row" mt="5px" ml="-10px"> 
                                {
                                    error && 
                                    <ErrorIcon
                                        style={{ 
                                            "color": "#D03240",
                                            "fontSize": "15px",
                                            "marginRight": "5px" 
                                        }}
                                    />
                                } 
                            
                                <Box>{helperText}</Box> 
                            </Stack>
                            : ""
                    }
                </FormHelperText>
            </FormControl>
        </LocalizationProvider>
    );
};

export default FXDateInput;
