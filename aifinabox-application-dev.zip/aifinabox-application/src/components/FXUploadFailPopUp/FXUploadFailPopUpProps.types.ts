export interface FXUploadFailPopUpProps {
    description?: string;
    ihnoDescription?: string;
    onClose?: () => void;
    open: boolean;
}
