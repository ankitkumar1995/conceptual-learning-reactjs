import {
    Box,
    Grid,
    IconButton,
    Modal,
    Paper,
    Typography
} from "@mui/material";

import CloseImageIcon from "../../icons/CloseImageIcon";
import { FXUploadFailPopUpProps } from "./FXUploadFailPopUpProps.types";
import React from "react";
import UploadFailIcon from "../../icons/UploadFailIcon";
import { UploadFailPopUpStyles } from "./UploadFailPopUpStyles";

const FXUploadFailPopUp: React.FC<FXUploadFailPopUpProps> = ({
    description,
    ihnoDescription,
    onClose,
    open,
}) => {
    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };

    return (
        <> 
            <Modal open={open}>
                <Paper sx={UploadFailPopUpStyles}>
                    <Box sx={{ "position": "absolute", "right": "20px", "top": "20px" }}>
                        <IconButton onClick={handleOnClose}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box> 

                    <Box
                        display="flex"
                        flexDirection="column"
                        justifyContent="center"
                        alignItems="center"
                        height="100%"
                    >
                        <UploadFailIcon />

                        <Typography variant="popupDescription" color="#FD3A69" margin="30px 0 15px 0">
                            Upload Failed
                        </Typography>

                        <Typography fontSize="16px" fontFamily="roboto" color="#293139">
                            File Format Incorrect, please check it and reupload
                        </Typography>
                    </Box>

                    {
                        (ihnoDescription !== undefined) 
                        &&
                        <Box
                            display="flex" 
                            justifyContent="center"
                        >
                            <Typography variant="popupSubDescription">
                                "File Format Incorrect, please check it and reupload"
                            </Typography>
                        </Box>
                    }
                </Paper>
            </Modal>
        </>
    );
};

export default FXUploadFailPopUp;
