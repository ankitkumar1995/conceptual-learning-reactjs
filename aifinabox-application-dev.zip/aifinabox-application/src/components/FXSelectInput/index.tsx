import {
    Box,
    FormControl,
    FormHelperText,
    FormLabel,
    InputLabel,
    MenuItem,
    Stack,
    Typography
} from "@mui/material";

import CustomTooltip from "../../pages/InitiateTransaction/TopUp/Maker/MakerTopUpForm/SubForms/TopUpForm/components/Tooltip";
import ErrorIcon from "@mui/icons-material/Error";
import { FXSelectInputProps } from "./FXSelectInputProps.types";
import InputAdornment from "@mui/material/InputAdornment";
import { SelectChangeEvent } from "@mui/material/Select";
import StyledSelect from "./StyledSelectInput";
import { initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import { useState } from "react";

const FXSelectInput: React.FC<FXSelectInputProps> = ({
    crossCheckValue,
    defaultOpen,
    defaultValue,
    disabled,
    error,
    helperText,
    inputLabel,
    label,
    menuItems,
    onBlur,
    onBlurValidator,
    onFieldErrorChange,
    onChangeValidator,
    onClose,
    onOpen,
    onValueChange,
    required,
    size,
    startAdornment,
    sx,
    value,
    varient,
    formLabelSx,
    menuSx,
    verified,
    isTooltipIcon,
    validatorOptions,
    warning,
}) => {
    const [fieldValue, setFieldValue] = useState(defaultValue ?? value ?? "");
    let updatedMenuItems = [{"label": "Select", "value": ""}, ...menuItems];

    const handleOnChange = async (event: SelectChangeEvent<unknown>) => {
        let result = event.target.value as string;
        let validation = initializeFieldValidation();
        const testerValue = result;

        if (typeof onValueChange !== "undefined") onValueChange(result);
        setFieldValue(result);

        if (typeof onFieldErrorChange !== "undefined")
            onFieldErrorChange(validation);
        if (
            !(required && result === "") &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldErrorChange !== "undefined"
        ) {
            await onBlurValidator(testerValue, validatorOptions)
                .then(async (result) => {
                    onFieldErrorChange(result);
                });
        }
    };

    const handleOnBlur = () => {
        let isFieldEmpty = false;

        if (
            required && 
            fieldValue === "" &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            onFieldErrorChange({
                "helperText": `${label} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            crossCheckValue !== undefined &&
            fieldValue !== crossCheckValue &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }
        if (typeof onBlur !== "undefined") onBlur();
    };

    return (
        <FormControl  
            className={warning ? "warning" : ""}
            disabled={disabled}
            error={error}
            fullWidth
            hiddenLabel
            variant={varient ?? "filled"}
            sx={{ 
                ... formLabelSx, 
                "&.warning": {
                    "& .MuiSelect-select": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >
            <InputLabel sx={{ "color": "#00000099" }}>
                {inputLabel}
            </InputLabel>

            <FormLabel sx={{ "marginTop": "-5px", "paddingBottom": "10px" }}> 
                <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                    {(required ? `${label} *`: label)} 
                </Typography>
                
                {
                    isTooltipIcon && <CustomTooltip />
                }
            </FormLabel>

            <StyledSelect
                defaultOpen={defaultOpen}
                displayEmpty
                error={error}
                value={value ?? fieldValue}
                sx={{
                    "& .MuiSelect-select": {
                        "color": (value === "Select" || value === "" || fieldValue === "Select" || fieldValue === "") ? "rgba(148, 151, 163, 0.7)" : "inherit",
                        "fontSize": (value === "Select" || value === "" || fieldValue === "Select" || fieldValue === "") ? "14px" : "inherit",
                        "fontStyle": (value === "Select" || value === "" || fieldValue === "Select" || fieldValue === "") ? "italic" : "inherit",
                        "textTransform": (value === "Select" || value === "" || fieldValue === "Select" || fieldValue === "") ? "capitalize" : "inherit",
                    },
                    ...sx 
                }}
                onBlur={handleOnBlur}
                onChange={handleOnChange}
                onClose={onClose}
                onOpen={onOpen}
                startAdornment={
                    (startAdornment !== undefined)
                        ?
                        <InputAdornment position="start">
                            {startAdornment}
                        </InputAdornment>
                        :
                        undefined
                }
                autoComplete="off"
                disableUnderline={(varient === "standard") ? false : true}
                size={size ?? "medium"}
                MenuProps={{ 
                    "PaperProps": { 
                        "sx": {
                            // "&::-webkit-scrollbar": {
                            //     "width": "5px",
                            // },
                            
                            // "&::-webkit-scrollbar-thumb": {
                            //     "backgroundColor": "#2A243850",
                            //     "borderRadius": "5px",
                            // },
                            
                            // "&::-webkit-scrollbar-thumb:active": {
                            //     "backgroundColor": "#2A243870",
                            // },
                            
                            // "&::-webkit-scrollbar-thumb:hover": {
                            //     "backgroundColor": "#2A243899",
                            // },
                            
                            // "&::-webkit-scrollbar-track": {
                            //     "backgroundColor": "#FFF",
                            // },
                            
                            "maxHeight": "155px" , 
                            "maxWidth": "155px", 
                            "overflowX": "auto"
                        },
                    },
                    "sx": {
                        "marginLeft": "0px",  
                        ...menuSx
                    },
                }}
                inputProps={{
                    "sx": {
                        "color": ((value ?? fieldValue) === "") ? "#9497A3" : "",
                    }
                }}
            >
                {
                    updatedMenuItems?.map((menuItem) => {
                        return (
                            <MenuItem 
                                value={menuItem.value} 
                                key={menuItem.value}
                                sx={{
                                    "whiteSpace": "unset",
                                    "wordBreak": "break-word",
                                }}
                            >
                                {menuItem.label}
                            </MenuItem>
                        );
                    })
                }
            </StyledSelect>
            
            <FormHelperText
                sx={{
                    "fontSize": "10px",
                    "fontWeight": 500,
                }}
            >
                {
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }
            </FormHelperText>
        </FormControl>
    );
};
export default FXSelectInput;
