import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import { SxProps } from "@mui/material";

export interface FXSelectInputProps {
    crossCheckValue?: string;
    defaultOpen?: boolean;
    defaultValue?: string;
    disabled?: boolean;
    error?: boolean;
    formLabelSx?: SxProps;
    helperText?: string;
    inputLabel?: string;
    label?: string;
    menuItems: MenuItem[];
    onBlur?: () => void;
    onBlurValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onClose?: (event: object) => void;
    onChangeValidator?: (value: string, options: Object) => FieldValidation;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onOpen?: (event: object) => void;
    onValueChange?: (value: string) => void;
    required?: boolean;
    size?: "small" | "medium";
    validatorOptions?: Object;
    startAdornment?: string;
    sx?: SxProps;
    menuSx?: SxProps;
    value?: string;
    varient?: "filled" | "standard";
    verified?: boolean;
    warning?: boolean;
    isTooltipIcon?: boolean;
}
