import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import { ReactNode } from "react";
import { SxProps } from "@mui/material";

type ForbidTo = 
    "alphanumeric" |
    "contact-number" |
    "decimal-number" |
    "letters" | 
    "name" |
    "namespaceapostrophe" |
    "numbers" | 
    "pan"

export interface FXInputWithSelectInput {
    autoCapitalize?: boolean;
    capitalizeFirstLetter?: boolean;
    crossCheckValue?: string;
    disabled?: boolean;
    endAdornment?: ReactNode;
    error?: boolean;
    forbidTo?: ForbidTo;
    formLabelSx?: React.CSSProperties;
    helperText?: string;
    label?: string;
    selectLabel?: string;
    maxLength?: number;
    onBlurValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onBlurSelectValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onChangeValidator?: (value: string, options: Object) => FieldValidation;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onFocus?: () => void; 
    onSelectFieldMenuClose?: (event: object) => void;
    onSelectFieldMenuOpen?: (event: object) => void;
    onSelectFieldValueChange?: (value: string) => void;
    onTextFieldBlur?: () => void;
    onTextFieldValueChange?: (value: string) => void;
    onValidationFailure?: () => void;
    onValidationSuccess?: () => Promise<void>;
    readOnly?: boolean;
    required?: boolean;
    selectInputPosition: "start" | "end";
    selectFieldMenuItems: MenuItem[];
    selectFieldValue?: string;
    size?: "small" | "medium";
    sx?: SxProps;
    textInputRef?: React.RefObject<HTMLInputElement>;
    textFieldDefaultValue?: string;
    textFieldValue?: string;
    type?: string;
    validatorOptions?: Object;
    selectValidatorOptions?: Object;
    variant?: "filled" | "standard";
    verified?: boolean;
    warning?: boolean;
    disableBGColor?: string;
}
