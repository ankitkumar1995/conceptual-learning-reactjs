export type DocumentFileType =
    "application/pdf" |
    "image/tiff";  

export interface FXDocumentViewerProps {
    docIcon?: React.ReactNode;
    document?: File;
    documentFileType?: DocumentFileType;   
    documentUri?: string;
    ref?: React.MutableRefObject<HTMLDivElement>;
    height?: string;
}
