import React, {
    useEffect,
    useRef,
    useState
} from "react";

import Box from "@mui/material/Box";
import FXBackdrop from "../FXBackdrop";
import { FXDocumentViewerProps } from "./FXDocumentViewerProps.types";
import IconButton from "@mui/material/IconButton";
import NavigateBeforeSharpIcon from "@mui/icons-material/NavigateBeforeSharp";
import NavigateNextSharpIcon from "@mui/icons-material/NavigateNextSharp";
import ResetIcon from "@mui/icons-material/RestartAlt";
import Stack from "@mui/material/Stack";
import StyledDocumentContainer from "./StyledDocumentContainer";
import StyledNavigatorContainer from "./StyledNavigatorContainer";
import Typography from "@mui/material/Typography";
import ZoomInIcon from "@mui/icons-material/ZoomIn";
import ZoomOutIcon from "@mui/icons-material/ZoomOut";
import decoderProvider from "./helpers/decoderProvider";

const FXDocumentViewer: React.FC<FXDocumentViewerProps> = ({ 
    docIcon,
    "document": documentFile,
    documentFileType,
    "documentUri": documentFileUri,
    ref,
    height,
}) => {
    const [dragging, setDragging] = useState(false);
    const [mouseX, setMouseX] = useState(0);
    const [mouseY, setMouseY] = useState(0);
    const [offsetX, setOffsetX] = useState(0);
    const [offsetY, setOffsetY] = useState(0);
    const [openBackdrop, setOpenBackdrop] = useState(false);
    const [page, setPage] = useState(0);
    const [pages, setPages] = useState<HTMLCanvasElement[]>([]);
    const [scale, setScale] = useState(1);

    const canvasRef = useRef<any>();
    
    async function loadDocument (
        documentUri: string, 
        documentFileType: FXDocumentViewerProps["documentFileType"]
    ) {
        setOpenBackdrop(true);

        if (typeof documentFileType === "undefined") {
            setOpenBackdrop(false);
            return ;
        }

        const decoder = decoderProvider(documentFileType);

        if (typeof decoder === "undefined") {
            setOpenBackdrop(false);
            return ;
        }

        await decoder(documentUri)
            .then((decodedCanvasPages) => {
                const documentViewerDiv = document.getElementById("document-container");
                documentViewerDiv?.appendChild(decodedCanvasPages[0]);
                setPages(decodedCanvasPages);
            })
            .catch((error) => {
                console.error(error);
            });
        
        setOpenBackdrop(false);
    }
    
    async function displayDocument (
        documentUri: string, 
        documentFileType: FXDocumentViewerProps["documentFileType"]
    ) {
        await loadDocument(documentUri, documentFileType);
    }
    
    const handlePreviousClick = () => {
        if (page > 0) setPage(page - 1);
        handleReset();
    };
    
    const handleNextClick = () => {
        if (page < pages.length - 1) setPage(page + 1);
        handleReset();
    };

    const handleZoomIn = () => {
        setScale(scale + 0.1);
    };
    
    const handleZoomOut = () => {
        if (scale > 0.1) setScale(scale - 0.1);
    };

    const handleMouseDown = (event: MouseEvent) => {
        setDragging(true);
        const initialX = event.clientX - mouseX;
        const initialY = event.clientY - mouseY;
        setOffsetX(initialX);
        setOffsetY(initialY);
    };
    
    const handleMouseUp = (event: MouseEvent) => {
        setDragging(false);
        setOffsetX(event.clientX);
        setOffsetY(event.clientY);
    };
    
    const handleMouseMove = (event: MouseEvent) => {
        if (dragging) {
            const dX = event.clientX - offsetX;
            const dY = event.clientY - offsetY;
            setMouseX(dX);
            setMouseY(dY);
        }
    };

    const handleReset = () => {
        setScale(1);
        setMouseX(0);
        setMouseY(0);
    };

    useEffect(() => {
        setPage(0);
        setPages([]);

        if (documentFile) {
            const uri = URL.createObjectURL(documentFile);
            const fileType = documentFile.type as FXDocumentViewerProps["documentFileType"];
            
            displayDocument(uri, fileType);
            handleReset();
        }

        else if (documentFileType && documentFileUri) {
            const uri = documentFileUri;
            const fileType = documentFileType;

            displayDocument(uri, fileType);
            handleReset();
        }
    }, [documentFile, documentFileUri]);

    useEffect(() => {
        if (pages.length > 0 && canvasRef && canvasRef.current) {
            canvasRef.current.innerHTML = '';  
            let img = pages[page];
            img.style.transform = `scale(${scale}) translate(${mouseX}px, ${mouseY}px)`;
            canvasRef.current.appendChild(img);

            img.addEventListener("mousedown", handleMouseDown);
            img.addEventListener("mousemove", handleMouseMove);
            img.addEventListener("mouseup", handleMouseUp);
            img.addEventListener("mouseover", handleMouseUp);
            img.addEventListener("mouseout", handleMouseUp);

            return () => {
                img.removeEventListener("mousemove", handleMouseMove);
                img.removeEventListener("mouseup", handleMouseUp);
                img.removeEventListener("mouseover", handleMouseUp);
                img.removeEventListener("mouseout", handleMouseUp);
                img.removeEventListener("mousedown", handleMouseDown);
            };
        }
    }, [page, pages, scale, offsetX, offsetY, mouseX, mouseY]);

    return (
        <>
            <Box 
                p="10px"
                display="flex"
                flexDirection="column"
                alignItems="end"
                justifyContent="center"
                sx={{ 
                    "backgroundColor": "white",
                    "borderRadius": "10px",
                    "height": height?.length !== 0 ? height : "720px",
                    "overflow": "hidden",
                    "position": "relative",
                }}
            >
                <Box
                    margin="auto"
                    sx={{
                        "border": "1px solid black",
                        "overflow": "hidden",
                    }}
                >
                    <StyledDocumentContainer
                        style={{ "cursor": dragging ? "grabbing" : "grab" }}
                        id="document-container"
                        ref={canvasRef}
                    >
                    </StyledDocumentContainer>

                    <Stack 
                        direction="column" 
                        spacing={1}
                        sx={{
                            "position": "absolute",
                            "right": "25px",
                            "top": "25px",
                        }}
                    >
                        <Box
                            display="flex"
                            flexDirection="column"
                            sx={{
                                "backgroundColor": "rgba(0, 0, 0, 0.5)",
                                "borderRadius": "10px",
                                "height": "auto",
                                "width": "40px",
                                "zIndex": "1",
                            }}
                        >
                            <IconButton onClick={handleZoomIn} size="large" disableRipple>
                                <ZoomInIcon style={{ "color": "#ededed" }}/>
                            </IconButton>

                            <IconButton onClick={handleZoomOut} size="large" disableRipple>
                                <ZoomOutIcon style={{ "color": "#ededed" }}/>
                            </IconButton>
                        </Box>

                        <Box
                            display="flex"
                            flexDirection="column"
                            alignItems="center"
                            justifyItems="center"
                            sx={{
                                "backgroundColor": "rgba(0, 0, 0, 0.5)",
                                "borderRadius": "10px",
                                "height": "45px",
                                "width": "40px",
                                "zIndex": "1", 
                            }}
                        >
                            <IconButton onClick={handleReset} size="large" disableRipple>
                                <ResetIcon style={{ "color": "#ededed" }}/>
                            </IconButton>
                        </Box>
                    </Stack>
                </Box>
            </Box>

            <StyledNavigatorContainer>
                {
                    (pages.length > 0)
                        ? 
                        <Stack direction="row">
                            <Box>
                                <IconButton onClick={handlePreviousClick} sx={{ "color": "white" }}>
                                    <NavigateBeforeSharpIcon/>
                                </IconButton>
                            </Box>

                            <Box display="flex" alignItems="center" sx={{ "color": "white" }}>
                                <Typography>
                                    {`Page ${page+1}/${pages.length}`}
                                </Typography>
                            </Box>

                            <Box>
                                <IconButton onClick={handleNextClick} sx={{ "color": "white" }}>
                                    <NavigateNextSharpIcon/>
                                </IconButton>
                            </Box>
                        </Stack>
                        : 
                        <Box height="40px">
                            <></>
                        </Box>
                }
            </StyledNavigatorContainer>

            <FXBackdrop open={openBackdrop}/>
        </>
    );
};

export default FXDocumentViewer;
