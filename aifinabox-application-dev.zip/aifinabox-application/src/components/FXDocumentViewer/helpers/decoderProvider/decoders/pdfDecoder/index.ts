import { pdfjs } from "react-pdf";

pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.js',
    import.meta.url,
).toString();

async function pdfDecoder(pdfDocumentUri: string): Promise<HTMLCanvasElement[]> {
    let canvasPages: HTMLCanvasElement[] = [];

    await pdfjs.getDocument(pdfDocumentUri).promise
        .then(async (pdfFile) => {
            for (let i = 1; i <= pdfFile.numPages; i++) {
                await pdfFile.getPage(i)
                    .then((page) => {
                        let viewport = page.getViewport({
                            "scale": 1.0,
                        });

                        const canvas = document.createElement("canvas");
                        const context = canvas.getContext("2d");
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;

                        if (context) {
                            page.render({
                                "canvasContext": context,
                                "viewport": viewport,
                            });
                        } else {
                            console.error(`context is invalid. Type of context is ${typeof context}`);
                        }
                        
                        canvasPages.push(canvas);
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            }
        })
        .catch((error) => {
            console.error(error);
        });

    return canvasPages;
}

export default pdfDecoder;
