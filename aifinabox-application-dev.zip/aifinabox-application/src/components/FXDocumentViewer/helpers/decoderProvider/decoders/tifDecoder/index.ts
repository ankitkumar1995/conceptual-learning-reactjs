/*
    react-tiff was referenced while implementing this decoder
    GitHub: https://github.com/harundogdu/react-tiff/blob/master/src/index.js
    CodeSandbox Demo: https://codesandbox.io/s/react-tiff-95u65f?file=/src/App.js
*/

import UTIF, { IFD } from "utif";
import axios from "axios";

async function tifDecoder(tiffDocumentUri: string): Promise<HTMLCanvasElement[]> {
    let canvasPages: HTMLCanvasElement[] = [];

    const response = await axios.get(tiffDocumentUri, {
        "responseType": "arraybuffer",
    });

    const ifds = UTIF.decode(response.data);
    canvasPages = ifds.map((ifd: IFD, index: number) => {
        UTIF.decodeImage(response.data, ifd);
        const rgba = UTIF.toRGBA8(ifd);
        const canvas = document.createElement("canvas");
        canvas.width = ifd.width;
        canvas.height = ifd.height;

        const context = canvas.getContext("2d");
        const image = context?.createImageData(ifd.width, ifd.height);
        if (image && context) {
            image.data.set(rgba);
            context.putImageData(image, 0, 0);
        } else {
            console.error(
                `One of image or context is invalid.` +
                `Type of image is ${typeof image}.` +
                `Type of context is ${typeof context}`
            );
        }
        
        return canvas;
    });

    return canvasPages;
}

export default tifDecoder;
