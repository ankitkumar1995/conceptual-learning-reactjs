import { DocumentFileType } from "../../FXDocumentViewerProps.types";
import pdfDecoder from "./decoders/pdfDecoder";
import tifDecoder from "./decoders/tifDecoder";

function decoderProvider(documentFileType: DocumentFileType) {
    switch (documentFileType) {
    case "application/pdf":
        return pdfDecoder;
    
    case "image/tiff":
        return tifDecoder;
    }
}

export default decoderProvider;
