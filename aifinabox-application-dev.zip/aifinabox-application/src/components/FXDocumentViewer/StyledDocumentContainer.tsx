import { Box, styled } from "@mui/material";

const StyledDocumentContainer = styled(Box)(() => {    
    return {
        "canvas": {
            "margin": "auto",
            "maxHeight": "720px",
            "objectFit": "contain",
        }
    };
});

export default StyledDocumentContainer;
