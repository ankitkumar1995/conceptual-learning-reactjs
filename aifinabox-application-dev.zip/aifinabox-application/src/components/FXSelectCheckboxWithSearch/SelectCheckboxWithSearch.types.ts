import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { MenuItem } from "../../interfaces/MenuItem.types";
import { SxProps } from "@mui/material";

export interface SelectCheckboxWithSearchProps {
    crossCheckValue?: string[];
    label?: string;
    disabled?: boolean;
    error?: boolean;
    helperText?: string;
    menuItems: MenuItem[];
    onBlur?: () => void;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onApplyClicked?: (value: string[]) => void;
    onValueChange?: (value: string[]) => void;
    required?: boolean;
    size?: "small" | "medium";
    variant?: "filled" | "outlined" | "standard";
    value: string[];
    formLabelSx?: SxProps;
    warning?: boolean;
}
