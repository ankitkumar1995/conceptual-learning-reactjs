import {
    Box,
    Checkbox,
    FormControl,
    FormHelperText,
    FormLabel,
    InputAdornment,
    ListItemIcon,
    ListItemText,
    ListSubheader,
    MenuItem,
    Stack,
    Typography,
} from "@mui/material";
import React, { useMemo, useState } from "react";

import ErrorIcon from "@mui/icons-material/Error";
import FXButton from "../FXButton";
import SearchIcon from "@mui/icons-material/Search";
import { SelectChangeEvent } from "@mui/material/Select";
import { SelectCheckboxWithSearchProps } from "./SelectCheckboxWithSearch.types";
import StyledCheckboxWithSelect from "./StyledCheckboxWithSelect";
import StyledTextField from "../FXInput/StyledTextField";
import { initializeFieldValidation } from "../../interfaces/FieldValidation.types";

const FXSelectCheckboxWithSearch: React.FC<SelectCheckboxWithSearchProps > = ({
    crossCheckValue,
    disabled,
    error,
    helperText,
    label,
    menuItems,
    onApplyClicked,
    onBlur,
    onFieldErrorChange,
    onValueChange,
    value,
    variant,
    required,
    size,
    formLabelSx,
    warning,
}) => {
    const [applyClicked, setApplyClicked] = useState(false);
    const [searchText, setSearchText] = useState("");
    const [selectedData, setSelectedData] = useState<string[]>([]);

    const allOptions = menuItems && menuItems.map(data => data.value);
    const isAllSelected = (allOptions?.length > 0) && selectedData.length === allOptions.length;

    const containsText = (text: string, searchText: string) => {
        return text.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
    };

    const displayedOptions = useMemo(() => {
        return allOptions?.filter((option) => containsText(option, searchText));
    }, [searchText, allOptions]);

    const handleChange = (event: SelectChangeEvent<unknown>) => {
        setApplyClicked(false);
        (typeof onValueChange !== "undefined")  && onValueChange([]);

        const result = (event.target.value as string[]);
        let validation = initializeFieldValidation();

        if (typeof onFieldErrorChange !== "undefined")
            onFieldErrorChange(validation);

        if (result[result.length - 1] === "all") {
            setSelectedData(
                selectedData.length === allOptions.length ? [] : allOptions
            );
            return;
        }
        setSelectedData(result);
    };

    const handleOnBlur = () => {
        let isFieldEmpty = false;
        
        if (
            required && 
            value.length === 0 &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            onFieldErrorChange({
                "helperText": `${label ?? "Field"} is mandatory`,
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            crossCheckValue !== undefined &&
            value !== crossCheckValue &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label ?? "Field"} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }
        if (typeof onBlur !== "undefined") onBlur();
    };

    const handleApply = () => {
        setApplyClicked(true);
        (typeof onApplyClicked !== "undefined")  && onApplyClicked(selectedData);
    };

    return (
        <FormControl 
            className={warning ? "warning" : ""}
            disabled={disabled}
            error={error}
            fullWidth
            hiddenLabel
            variant={variant ?? "filled"}
            sx={{ 
                ... formLabelSx, 
                "&.warning": {
                    "& .MuiSelect-select": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >
            {
                label && 
                <FormLabel sx={{ "marginTop": "-5px", "paddingBottom": "10px" }}> 
                    <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                        {(required ? `${label} *`: label)} 
                    </Typography>
                </FormLabel>
            }

            <StyledCheckboxWithSelect
                value={selectedData}
                onChange={handleChange}
                onBlur={handleOnBlur}
                disabled={disabled}
                multiple
                error={error}
                size={size ?? "medium"}
                label="Options"
                id="search-select"
                labelId="search-select-label"
                inputProps={{
                    "sx": {
                        "color": (value?.length === 0) ? "#9497A3" : "",
                    }
                }}
                MenuProps={{ 
                    "PaperProps": { "sx": { "maxHeight": "280px" , "maxWidth": "155px", "overflowX": "auto"} },
                    "sx": { "marginLeft": "0px" },
                    "variant": "menu"
                }}
                disableUnderline={(variant === "standard") ? false : true}
                renderValue={(selected: any) => {
                    if (applyClicked)
                        return isAllSelected ? "Selected All" : selected.length + " Selected";
                }}
                sx={formLabelSx}
                onClose={() => setSearchText("")}
            >
                <ListSubheader>
                    <StyledTextField
                        placeholder={label ? `Search ${label}`: "Search"}
                        variant={variant ?? "standard"}
                        autoFocus
                        onChange={(event) => setSearchText(event.target.value)}
                        onKeyDown={(event) => {
                            if (event.key !== "Escape") {
                                // Prevents autoselecting item while typing (default Select behaviour)
                                event.stopPropagation();
                            }
                        }}
                        size={size ?? "medium"}
                        InputProps={{
                            "endAdornment": (
                                <InputAdornment position="end" >
                                    <SearchIcon />
                                </InputAdornment>
                            ),
                        }}
                        sx={{
                            "& .MuiInput-root ": {
                                "height": "42px", 
                            },
                            "& input::placeholder": {
                                "color": "#9497fA3",
                                "fontSize": "14px",
                                "fontStyle": "italic",
                                "opacity": "0.7",
                                "textTransform": "capitalize",
                            },
                        }}
                        FormHelperTextProps={{
                            "sx": {
                                "color": "#d32f2f",
                                "fontSize": "10px",
                                "fontWeight": 500,     
                            }
                        }}
                    />
                </ListSubheader>
                
                {
                    (menuItems?.length > 0) 
                    && 
                    <MenuItem
                        value="all"
                    >
                        <ListItemIcon>
                            <Checkbox
                                checked={isAllSelected}
                                indeterminate={
                                    selectedData.length > 0 &&
                                    selectedData.length < allOptions.length
                                }
                            />
                        </ListItemIcon>
                        <ListItemText
                            primary="Select All"
                        />
                    </MenuItem>
                }

                {
                    displayedOptions?.map((option) => (
                        <MenuItem value={option}>
                            <ListItemIcon>
                                <Checkbox checked={selectedData.indexOf(option) > -1} />
                            </ListItemIcon>
                            <ListItemText primary={option} />
                        </MenuItem>
                    ))
                }

                {
                    (menuItems?.length > 0) 
                    && 
                    <Box width="90%" ml={1.7} mt={1}>
                        <FXButton
                            fullWidth
                            sx={{
                                "height": "40px"
                            }}
                            buttonVariant="submit"
                            label="Apply"
                            onClick={handleApply}
                        />
                    </Box>
                }

                {
                    (menuItems === undefined || menuItems.length === 0) 
                    && 
                    <Typography ml={2} mt={1} fontStyle="italic">
                        No Options
                    </Typography>
                }
            </StyledCheckboxWithSelect>

            <FormHelperText
                sx={{
                    "fontSize": "10px",
                    "fontWeight": 500,
                }}
            >
                {
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }
            </FormHelperText>
        </FormControl>
    );
};

export default FXSelectCheckboxWithSearch;
