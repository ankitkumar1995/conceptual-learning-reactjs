import { Select, styled } from "@mui/material";

import { SelectProps } from "@mui/material/Select";

const StyledCheckboxWithSelect = styled(Select, {
    "shouldForwardProp": (prop) => prop !== "error",
})<SelectProps>(({ error }) => {
    const normalStyle = () => {
        return {
            "& .MuiSelect-filled": {
                "& :hover": {
                    "background": "#FFFFFF",
                },
                "&:focus": {
                    "background": "#FFFFFF",
                    "borderRadius": "6px",
                },
                "background": "#FFFFFF",
                "border": "1px solid #DDEAF3",
                "borderRadius": "6px",
            },
            "& .MuiSvgIcon-root": {
                "color": "#337fc9",
            },
            "&.Mui-disabled": {
                "opacity": 0.6,
            },
            "&.Mui-focused": {
                "background": "#fff",
            },
            "&.MuiFilledInput-root:hover": {
                "background": "#fff",
            },
        };
    };

    const errorStyle = () => {
        return {
            "&, &:hover, &.Mui-focused": {
                "background": "#FFFFFF",
                "border": "1px solid #D03240",
                "borderRadius": "6px",
            },
        };
    };

    return {
        ...(normalStyle()),
        ...(error && errorStyle()),
    };
});

export default StyledCheckboxWithSelect;
