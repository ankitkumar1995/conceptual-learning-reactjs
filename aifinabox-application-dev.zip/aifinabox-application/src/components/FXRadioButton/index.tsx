import { Radio } from "@mui/material";
import { RadioProps } from "@mui/material/Radio";

type radioButtonProp = {
    selected: boolean;
}

const FXRadioButton = (props: RadioProps & radioButtonProp ) => {
    return (
        <Radio sx={{
            "&.MuiRadio-root": {
                "& .MuiSvgIcon-root": {
                    "height": "12px",
                    "width": "12px",
                },
                "color": props.selected ? "#00579B" : "#888e97",
            }
        }}
        {...props}
        />
    );
};

export default FXRadioButton;
