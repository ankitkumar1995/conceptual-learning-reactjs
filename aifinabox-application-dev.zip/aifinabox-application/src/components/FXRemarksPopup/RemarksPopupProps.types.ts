import { MenuItem } from "../../interfaces/MenuItem.types";
import { SxProps } from "@mui/material";

export interface RemarksPopupProps {
    isDisabled: boolean;
    onCancelClick?: () => void;
    onSubmitClick?: (remarks: string) => void;
    open: boolean;
    remarkMenuItems?: MenuItem[];
    rejectRemarkText: string;
    setRejectRemarkText: (rejectRemarkText: string) => void;
    sx?: SxProps;
}
