import {
    Box,
    DialogContent,
    DialogTitle,
    Stack,
    TextField,
    Typography,
} from "@mui/material";
import StyledDailog, { dialogButtonStyles } from "./StyledDialogPopup";

import FXButton from "../FXButton";
import { RemarksPopupProps } from "./RemarksPopupProps.types";
import { useState } from "react";

const RemarksPopup: React.FC<RemarksPopupProps> = ({
    isDisabled,
    onCancelClick,
    onSubmitClick,
    open,
    rejectRemarkText,
    setRejectRemarkText,
    sx,
}) => {
    const [remark, setRemark] = useState("");
    const [remarkFieldError, setRemarkFieldError] = useState(false);

    return (
        <StyledDailog
            disableScrollLock
            open={open}
            sx={{ ...sx }}
        >
            <DialogContent> 
                <DialogTitle sx={{ "mb": "5%" }}> 
                    Remarks 
                </DialogTitle>
    
                <TextField
                    variant="filled"
                    multiline
                    minRows={7}
                    maxRows={10}
                    value={rejectRemarkText}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                        let result = event.target.value;
                        setRemark(result);
                        setRejectRemarkText(result);
                        setRemarkFieldError(false);
                    }}
                    error={remarkFieldError}
                    helperText={remarkFieldError ? "Remarks are required": ""}
                    InputProps={{ "disableUnderline": true }}
                    sx={{
                        "height": "270px",
                        "marginLeft": "20px",
                        "width": "460px",
                    }}
                />

                <Stack
                    direction="row"
                    spacing={1}
                    display="flex"
                    justifyContent="center"
                    marginLeft="212px"
                >

                    <FXButton
                        buttonVariant="contained"
                        label="Cancel"
                        onClick={onCancelClick}
                        sx={{
                            ...dialogButtonStyles,
                            "&:hover": {
                                "background": "#E7F1FA",
                            },
                            "background": "#E7F1FF",
                            "color": "#201C43",
                        }}
                    />

                    <FXButton
                        buttonVariant="submit"
                        disabled={isDisabled}
                        label="Submit"
                        onClick={() => {
                            if  (rejectRemarkText === "") 
                                setRemarkFieldError(true);

                            if  (rejectRemarkText !== "" && onSubmitClick !== undefined)
                                onSubmitClick(rejectRemarkText);
                        }}
                        sx={{ ...dialogButtonStyles }}
                    />
                </Stack>
            </DialogContent>
        </StyledDailog>
    );
};

export default RemarksPopup;
