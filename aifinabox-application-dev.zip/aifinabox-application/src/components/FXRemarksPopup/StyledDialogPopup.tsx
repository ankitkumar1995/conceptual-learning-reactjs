import {
    Dialog,
    DialogProps,
    SxProps,
    styled
} from "@mui/material";

export const dialogButtonStyles: SxProps = {
    "borderRadius": "10px",
    "height": "60px",
    "width": "117px",
};

const StyledDailog = styled(Dialog)<DialogProps>({    
    "& .MuiPaper-root": {
        "background": "#FFFFFF",
        "borderRadius": "10px",
        "display": "flex",
        "height": "467px",
        "justifyContent": "center",
        "minWidth": "550px",
    },
    "maxHeight": "80%",
});

export default StyledDailog;
