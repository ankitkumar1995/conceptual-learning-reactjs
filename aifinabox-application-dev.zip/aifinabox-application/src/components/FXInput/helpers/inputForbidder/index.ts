import {
    AMOUNT_REGEX,
    CONTACT_NUMBER_REGEX,
    EMAIL_REGEX,
    INDIVIDUAL_PAN_REGEX,
    INVESTOR_EMAIL_REGEX,
    NSDL_DP_ID_REGEX,
    PAN_REGEX
} from "../../../../constants/Regex";

import { FXInputProps } from "../../FXInputProps.types";
import partialMatchRegex from "../partialMatchRegex";

function inputForbidder(forbidTo: FXInputProps["forbidTo"], input: string): string {
    let result = input;
    
    switch (forbidTo) {

    case "amount":
        const amountPartialMatchRegex = partialMatchRegex(AMOUNT_REGEX);
        result= result.replace(/[|&;!;#*^$%@"<>()+,]/g, "");
        while (result.length && !amountPartialMatchRegex.test(result))
            result = result.substring(0, result.length - 1);
        break;
    
    case "account-name": 
        result = result.replace(/[^a-zA-Z-|&;!;#*^$%@"<>()+, ]+/ig, "").replace(/(\s{2,})/g, ' ');
        break;

    case "alphanumeric":
        result = result.replace(/[^0-9a-zA-Z]+/ig, "");
        break;
    
    case "alphanumeric-hyphen":
        result = result.replace(/[^0-9a-zA-Z-]+/ig, "");
        break;
    
    case "alphanumeric-ws":
        result = result.replace(/^(\s{2,})|[^0-9a-zA-Z]+/g, " ").replace(/^\s*/, '').trimStart();
        break;

    case "contact-number":
        const contactNumberPartialMatchRegex = partialMatchRegex(CONTACT_NUMBER_REGEX);

        while (result.length && !contactNumberPartialMatchRegex.test(result))
            result = result.substring(0, result.length - 1);

        break;

    case "decimal-number":
        result = result.replace(/[^0-9.]|(?<=\..*)\./g, "");
        break;

    case "letters":
        result = result.replace(/[^a-z\s]/gi, "");
        break;

    case "name":
        result = result.replace(/^(?:\d|\s+)|[^a-z\s]/gi, "");
        break;

    case "namespace":
        result = result.replace(/^(?:\d|\s+)|[^0-9a-zA-Z\s.]+/ig, "");
        break;

    case "namespaceanything":
        result = result.replace(/(\s{2,})/g, ' ').replace(/^\s*/, '').trimStart();
        break;

    case "namespaceapostrophe":
        result = result.replace(/(\s{2,})|[^a-zA-Z' ]/g, '').replace(/^\s*/, '').trimStart();
        break;

    case "namespacecountrycity":
        result = result.replace(/(\s{2,})|[^a-zA-Z ]/g, '').replace(/^\s*/, '').trimStart();
        break;

    case "singleSpace":
        result = result.replace(/(\s{2,})/g, ' ').replace(/^\s*/, '').trimStart();
        break;

    case "nsdl-dp-id":
        const nsdlDpIdPartialMatchRegex = partialMatchRegex(NSDL_DP_ID_REGEX);

        while (result.length && !nsdlDpIdPartialMatchRegex.test(result))
            result = result.substring(0, result.length - 1);

        if (result.length >=0 && result.length <= 2) result = "IN";

        break;

    case "numbers":
        result = result.replace(/\D/g, "");
        break;

    case "nls-name":
        result = result.replace(/[^a-zA-Z\s]|^[^a-zA-Z]+/g, "");
        break;

    case "pan":
        const panPartialMatchRegex = partialMatchRegex(PAN_REGEX);

        while (result.length && !panPartialMatchRegex.test(result))
            result = result.substring(0, result.length - 1);

        break;

    case "pan-investor":
        const panIndividualPartialMatchRegex = partialMatchRegex(INDIVIDUAL_PAN_REGEX);

        while (result.length && !panIndividualPartialMatchRegex.test(result))
            result = result.substring(0, result.length - 1);

        break;

    case "email":
        const emailPatrialMatchRegex = partialMatchRegex(EMAIL_REGEX);
    
        while (result.length && !emailPatrialMatchRegex.test(result))
            result = result.substring(0,result.length - 1);  
        
        break;

    case "investor-email":
        const investorEmailPartialMatchRegex = partialMatchRegex(INVESTOR_EMAIL_REGEX);
        
        while (result.length && !investorEmailPartialMatchRegex.test(result))
            result = result.substring(0,result.length - 1);  
            
        break;
    
    
    case "user-id":
        result = result.replace(/[\s]+/g, "");  
        break;
    
    case "aadhar":
        result = result.replace(/[^0-9\-]+/ig, "");
        break;
    
    default:
        break;
    }
    
    return result;
}

export default inputForbidder;
