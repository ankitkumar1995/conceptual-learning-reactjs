import { TextField, styled } from "@mui/material";
import { TextFieldProps } from "@mui/material/TextField";

const StyledTextField = styled(TextField, {})<TextFieldProps>(() => {
    return {
        "& .MuiFilledInput-root": {
            "& .MuiFilledInput-input": {
                "paddingRight": "10px",
            },
            "background": "#FFFFFF",
            "border": "0.5px solid #DDEAF3",
            "borderRadius": "6px",
        },
        "& .MuiFilledInput-root.Mui-error": {
            "background": "#FFFFFF",
            "border": "1px solid #D03240",
        },
        "& .MuiFilledInput-root:hover, & .MuiFilledInput-root.Mui-focused": {
            "background": "#FFFFFF"
        },
    };
});

export default StyledTextField;
