import { InputBaseComponentProps, SxProps } from "@mui/material";

import { FieldValidation } from "../../interfaces/FieldValidation.types";
import { ReactNode } from "react";

type ForbidTo = 
    "aadhar" |
    "amount" |
    "account-name" |
    "alphanumeric" |
    "alphanumeric-ws" |
    "alphanumeric-hyphen" |
    "email" |
    "investor-email" |
    "contact-number" |
    "decimal-number" |
    "letters" | 
    "name" |
    "namespace" |
    "namespaceanything" |
    "namespaceapostrophe" |
    "namespacecountrycity" |
    "nsdl-dp-id" |
    "numbers" | 
    "nls-name" |
    "pan" |
    "pan-investor" |
    "singleSpace" |
    "user-id";

export interface FXInputProps {
    autoCapitalize?: boolean;
    autoFocus?: boolean;
    capitalizeFirstLetter?: boolean;
    crossCheckValue?: string;
    defaultValue?: string;
    disabled?: boolean;
    endAdornment?: ReactNode;
    error?: boolean;
    forbidTo?: ForbidTo;
    inputRef?: React.RefObject<HTMLInputElement> ;
    helperText?: ReactNode;
    label?: string;
    inputProps?: InputBaseComponentProps;
    isCommaAllowed?: boolean;
    isLabelIcon?: boolean;
    labelIcon?: ReactNode;
    maxLength?: number;
    onBlur?: () => void;
    onBlurValidator?: (value: string, options: Object) => Promise<FieldValidation>;
    onChangeValidator?: (value: string, options: Object) => FieldValidation;
    //onComparisionValidation?: (value: string) => FieldValidation;
    onFieldErrorChange?: (fieldError: FieldValidation) => void;
    onValidationFailure?: () => void;
    onValidationSuccess?: () => Promise<void>;
    onValueChange?: (result: string) => void;
    onFocus?: () => void;
    placeholder?: string;
    readOnly?: boolean;
    required?: boolean;
    rightIndent?: boolean;
    size?: "small" | "medium";
    startAdornment?: ReactNode;
    sx?: SxProps;
    type?: string;
    validatorOptions?: Object;
    value?: string;
    variant?: "filled" | "outlined" | "standard";
    verified?: boolean;
    warning?: boolean;
}
