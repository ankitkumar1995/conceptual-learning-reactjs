import {
    Box,
    FormControl,
    FormLabel,
    Stack,
    Typography
} from "@mui/material";

import CancelIcon from "@mui/icons-material/Cancel";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import { FXInputProps } from "./FXInputProps.types";
import React from "react";
import StyledTextField from "./StyledTextField";
import { initializeFieldValidation } from "../../interfaces/FieldValidation.types";
import inputForbidder from "./helpers/inputForbidder";

const FXInput: React.FC<FXInputProps> = ({
    autoCapitalize,
    autoFocus,
    capitalizeFirstLetter,
    crossCheckValue,
    defaultValue,
    disabled,
    endAdornment,
    error,
    forbidTo,
    helperText,
    inputRef,
    label,
    inputProps,
    isCommaAllowed,
    isLabelIcon,
    labelIcon,
    maxLength,
    onBlur,
    onBlurValidator,
    onChangeValidator,
    onFieldErrorChange,
    onFocus,
    onValidationFailure,
    onValidationSuccess,
    onValueChange,
    placeholder,
    readOnly,
    required,
    rightIndent,
    size,
    startAdornment,
    sx,
    type,
    validatorOptions,
    value,
    variant,
    verified,
    warning,
}) => {
    const endAdornmentIcon = (
        (error) 
            ? <CancelIcon color="error"/>
            : (
                (verified)
                    ? <CheckCircleIcon color="success"/>
                    : <></>
            )
    );

    const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        let result = event.target.value;

        if (autoCapitalize) result = result.toUpperCase();

        if (capitalizeFirstLetter) result =  result.charAt(0).toUpperCase() + result.slice(1);
        
        if (typeof forbidTo === "string") result = inputForbidder(forbidTo, result);
        
        if (typeof onValueChange !== "undefined") onValueChange(result);

        if (
            inputRef !== undefined && 
            inputRef.current !== null && 
            inputRef.current !== undefined
        ) {
            inputRef.current.value = result;
        }

        let validation = initializeFieldValidation();
        
        if (onChangeValidator && validatorOptions)
            validation = onChangeValidator(result, validatorOptions);

        if (onFieldErrorChange)
            onFieldErrorChange(validation);

        if (validation.isError && onValidationFailure) 
            onValidationFailure();
    };

    const handleOnBlur = async () => { 
        let testerValue = 
            inputRef?.current?.value ?? 
            value ?? 
            "";
        if (!(isCommaAllowed))    
            testerValue = testerValue.replace(/,/g, "");
        
        let isFieldEmpty = false;

        if (
            required && 
            testerValue === "" &&
            onFieldErrorChange
        ) {
            isFieldEmpty = true;
            onFieldErrorChange({
                "helperText": label ? `${label} is mandatory` : "Field is mandatory",
                "isError": true,
                "isVerified": false,
                "isWarning": false,
            });
        }

        if (
            crossCheckValue !== undefined &&
            testerValue !== crossCheckValue &&
            onFieldErrorChange
        ) {
            onFieldErrorChange({
                "helperText": `${label} does not match with maker entry value. You may proceed if your interpretetion is correct.`,
                "isError": false,
                "isVerified": false,
                "isWarning": true,
            });
        }
        
        if (
            !(required && isFieldEmpty) &&
            !error &&
            typeof onBlurValidator !== "undefined" &&
            typeof validatorOptions !== "undefined" &&
            typeof onFieldErrorChange !== "undefined"
        ) {
            await onBlurValidator(testerValue, validatorOptions)
                .then(async (result) => {
                    onFieldErrorChange(result);

                    if (
                        !result.isError && 
                        testerValue.length &&
                        onValidationSuccess
                    )                     
                        await onValidationSuccess();
                    
                    else if (
                        result.isError && 
                        onValidationFailure
                    ) 
                        onValidationFailure();
                });
        }
        
        if (typeof onBlur !== "undefined") onBlur();
    };

    return (
        <FormControl
            className={warning ? "warning" : ""}
            error={error}
            fullWidth
            sx={{
                "&.warning": {
                    "& .MuiFilledInput-root": {
                        "borderColor": "#ff9800"
                    }
                }
            }}
        >
            <FormLabel sx={{ "paddingBottom": "10px" }}> 
                <Stack display="flex" flexDirection="row" alignItems="center">
                    {
                        label && 
                        <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                            {(required ? `${label} *`: label)} 
                        </Typography>
                    }

                    {
                        isLabelIcon &&
                        <Box height="10px" marginBottom="11px" marginLeft="5px">
                            {labelIcon}
                        </Box>
                    }
                </Stack>
            </FormLabel>

            <StyledTextField 
                autoComplete="off"
                autoFocus={autoFocus}
                defaultValue={defaultValue}
                disabled={disabled}
                error={error}
                hiddenLabel
                inputRef={inputRef}
                onBlur={handleOnBlur}
                onChange={handleOnChange}
                placeholder={placeholder ?? `${label?.toLowerCase()}`}
                required={required}
                size={size ?? "medium"}
                type={type}
                value={value}
                variant={variant ?? "filled"}
                FormHelperTextProps={{
                    "sx": {
                        "fontSize": "10px",
                        "fontWeight": 500,
                    }
                }}
                helperText={
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }
                inputProps={{
                    ...inputProps,
                    "maxLength": maxLength ?? 256,
                    "readOnly": readOnly,
                    "sx": {
                        "&::placeholder": {
                            "color": "#9497A3",
                            "fontSize": "14px",
                            "fontStyle": "italic",
                            "opacity": "0.7",
                            "textTransform": "capitalize",
                        }
                    }
                }}
                InputProps={{
                    "disableUnderline": true,
                    "endAdornment": 
                        (endAdornment !== undefined)
                            ? endAdornment 
                            : endAdornmentIcon,
                    "startAdornment":
                        (startAdornment !== undefined)
                            ? startAdornment
                            : <></>,
                }}
                onFocus={() => {
                    if (typeof onFocus !== "undefined")
                        onFocus();
                }}
                sx={{
                    "input": {
                        "textAlign": rightIndent ? "right" : "left" 
                    }, 
                    ...sx 
                }}
            />
        </FormControl>
    );
};

export default FXInput;
