import { SxProps } from "@mui/material";

export interface RadioButtonValue {
    label: string;
    value: string;
}

export interface FXRadioGroupProps {
    disabled?: boolean;
    label?: string;
    helperText?: string;
    required?: boolean;
    row?: boolean;
    error?: boolean;
    value?: string;
    startValue?: RadioButtonValue["value"];
    radioButtonValues: RadioButtonValue[];
    onValueChange?: (value: RadioButtonValue["value"]) => void;
    sx?: SxProps;
}
