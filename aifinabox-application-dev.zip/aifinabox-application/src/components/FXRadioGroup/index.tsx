import {
    Box,
    FormControlLabel,
    FormLabel,
    RadioGroup,
    Stack,
    Typography
} from "@mui/material";
import { FXRadioGroupProps, RadioButtonValue } from "./FXInputProps.types";
import React, { useState } from "react";

import ErrorIcon from "@mui/icons-material/Error";
import FormControl from "@mui/material/FormControl";
import FormHelperText from "@mui/material/FormHelperText";
import RadioButton from "../FXRadioButton/index";

const FXRadioGroup: React.FC<FXRadioGroupProps> = ({
    disabled,
    label, 
    helperText, 
    required,
    row, 
    error, 
    startValue, 
    radioButtonValues,
    value,
    onValueChange, 
    sx,
}) => {
    const determineStartValue = () => {
        const radioButtonValuesWithStartValue = radioButtonValues.filter((radioButtonValue) => {
            return (radioButtonValue.value === startValue);
        });

        if (radioButtonValuesWithStartValue.length >= 1) return startValue;
        else return radioButtonValues[0].value;
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value;

        if (typeof onValueChange !== "undefined") onValueChange(newValue);
        else setFieldValue(newValue);
    };
    
    const [fieldvalue, setFieldValue] = useState(determineStartValue());

    const actualRadioButtonValues = radioButtonValues.filter((values) => {
        return (values.value !== "");
    });

    return (
        <FormControl error={error} sx={{...sx}}>

            {label && 
                <FormLabel sx={{ "paddingBottom": "21px" }}> 
                    <Typography variant={required ? "inputFieldLabelRequired" : "inputFeildLabelNormal"}>
                        {(required ? `${label} *`: label)} 
                    </Typography>
                </FormLabel>
            }

            <RadioGroup
                row={row}
                value={value ?? fieldvalue}
                onChange={handleChange} 
            >
                
                {actualRadioButtonValues?.map((radioButtonValue:RadioButtonValue, index: number) => {
                    return (
                        <FormControlLabel 
                            disabled={disabled}
                            value={radioButtonValue.value} 
                            control={<RadioButton selected={value === radioButtonValue.value}/>} 
                            label={radioButtonValue.label}
                            key={`${radioButtonValue.value}`}  
                            sx={{
                                "&.MuiFormControlLabel-root": {
                                    ".MuiFormControlLabel-label": {
                                        "color": value === radioButtonValue.value ? "#00579B" : "#888e97",
                                        "fontFamily": "Work Sans",
                                        "fontSize": "14px",
                                        "fontStyle": "normal",
                                        "fontWeight": 500,
                                        "lineHeight": "16px",
                                    },
                                    "marginLeft": "0px",
                                    "marginRight": 
                                        (index === actualRadioButtonValues.length - 1)
                                            ? "0"
                                            : "20px",
                                },
                                "background": "rgba(0, 87, 155, 0.0535)",
                                "border": value === radioButtonValue.value ? "1px solid #00579B" : "1px solid #e9f1f8",
                                "borderRadius": "12px",
                                "height": "39px",
                                "opacity": 0.9,
                                "paddingRight": "10px",
                            }}
                        />
                    );
                })}    
            </RadioGroup>

            <FormHelperText>
                {
                    (helperText && helperText.toString().length > 0)
                        ? <Stack direction="row" mt="5px" ml="-10px"> 
                            {
                                error && 
                                <ErrorIcon
                                    style={{ 
                                        "color": "#D03240",
                                        "fontSize": "15px",
                                        "marginRight": "5px" 
                                    }}
                                />
                            } 
                            
                            <Box>{helperText}</Box> 
                        </Stack>
                        : ""
                }   
            </FormHelperText>

        </FormControl>
    );
};

export default FXRadioGroup;
