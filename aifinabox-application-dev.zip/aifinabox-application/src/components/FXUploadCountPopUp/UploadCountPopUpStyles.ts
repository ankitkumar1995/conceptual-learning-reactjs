export const UploadCountPopUpStyles = {
    "borderRadius": "10px",
    "color": "#ffffff",
    "height": "309px",
    "left": "0",
    "margin": "auto",
    "outline": "none",
    "padding": "20px",
    "position": "absolute",
    "right": "0",
    "top": "20%",
    "width": "450px",
};
