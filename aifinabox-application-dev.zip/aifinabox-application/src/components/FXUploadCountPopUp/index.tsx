import {
    Box,
    Grid,
    IconButton,
    Modal,
    Paper,
    Radio,
    Typography
} from "@mui/material";

import React, { RefObject, createRef } from "react";
import CloseImageIcon from "../../icons/CloseImageIcon";
import { FXUploadCountPopUpProps } from "./FXUploadCountPopUpProps.types";
import { RootState } from "../../redux/store";
import { UploadCountPopUpStyles } from "./UploadCountPopUpStyles";
import { useSelector } from "react-redux";

const FXUploadCountPopUp: React.FC<FXUploadCountPopUpProps> = ({
    onClose,
    data,
    open,
    batchNo,
}) => {

    const handleOnClose = () => {
        if (typeof onClose !== "undefined") onClose();
    };

    return (
        <> 
            <Modal open={open}>
                <Paper sx={UploadCountPopUpStyles}>
                    <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        paddingBottom="35px"
                    >
                        <Typography variant="popupSubDescription" fontWeight="500px" fontSize="22px">
                            Batch Number: {batchNo}
                        </Typography>
                            
                        <IconButton disableRipple onClick={handleOnClose}>
                            <CloseImageIcon />
                        </IconButton>
                    </Box>

                    <Box 
                        display="flex"
                        flexDirection="column"
                        justifyContent="space-between"
                        alignItems="center"
                        paddingBottom="30px"
                    >
                        <Grid display="flex" justifyContent="space-between" sx={{"width": "100%"}}>
                            <Box  sx={{ "background": "#EFF8FF", "borderRadius": "5px","display": "flex", "flexDirection": "column", "padding": "15px 20px", "width": "40%"}}>
                                <Typography variant="popupBannerDescription">Total Records</Typography>
                                <Typography variant="popupNumberDescription" color="#4985B4" sx={{"paddingTop": "20px"}} >{data.totalRecords}</Typography>
                            </Box>
                            <Box sx={{"background": "#EFFFF8", "borderRadius": "5px", "display": "flex", "flexDirection": "column", "marginX": "15px", "padding": "15px 20px", "width": "30%"}}>
                                <Typography variant="popupBannerDescription">Success</Typography>
                                <Typography variant="popupNumberDescription" color="#69BC98" sx={{"paddingTop": "20px"}}>{data.successRecords}</Typography>
                            </Box>
                            <Box sx={{"background": "#FFEFEF", "borderRadius": "5px", "display": "flex", "flexDirection": "column", "padding": "15px 20px", "width": "30%"}}>
                                <Typography variant="popupBannerDescription">Failed</Typography>
                                <Typography variant="popupNumberDescription" color="#C16E6E" sx={{"paddingTop": "20px"}}>{data.failedRecords}</Typography>
                            </Box>
                        </Grid>
                    </Box>

                    <Box
                        display="flex"                                                           
                        sx={{"background": "#EFF3FF", "borderRadius": "5px", "display": "flex", "flexDirection": "column", "padding": "20px"}}
                    >
                        <Box sx={{"display": "flex", "justifyContent": "space-between", "paddingBottom": "20px"}}>
                            <Typography variant="popupBannerDescription">
                                Uploaded By           
                            </Typography>

                            <Typography variant="popupBannerDescription">
                                {data.uploadedDateTime}
                            </Typography>
                        </Box>

                        <Typography variant="popupBannerDescription" sx={{"color": "#293139", "fontSize": "18px", "fontWeight": "bold"}}>
                            {data.uploadedBy}
                        </Typography>
                    </Box>
                </Paper>
            </Modal>
        </>
    );
};

export default FXUploadCountPopUp;
