export interface FXUploadCountPopUpProps {
    onClose?: () => void;
    open: boolean;
    batchNo: string;
    data: {        
        "failedRecords": number;
        "successRecords": number;
        "totalRecords": number;
        "uploadedBy": string;
        "uploadedDateTime": string;
    };
}
