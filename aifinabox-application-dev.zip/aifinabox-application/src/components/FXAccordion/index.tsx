import {
    Grid,
    Stack,
    Typography
} from "@mui/material";
import MuiAccordion, { AccordionProps } from "@mui/material/Accordion";
import MuiAccordionSummary, { AccordionSummaryProps } from "@mui/material/AccordionSummary";
import { useEffect, useState } from "react";
import useFetchFundPlanDetails, {
    initializeFundPlanData
} from "../../hooks/api/useFetchFundPlanDetails";
import ArrowForwardIosSharpIcon from "@mui/icons-material/ArrowForwardIosSharp";
import { FundCodeData } from "../../hooks/api/useFetchFundDetails";
import MuiAccordionDetails from "@mui/material/AccordionDetails";
import Tooltip from "@mui/material/Tooltip";
import { nanoid } from "@reduxjs/toolkit";
import { styled } from "@mui/material/styles";

interface IFundPlanData {
    [key: string]: 
    {        
        _id?: string;
        planCategory?: string;
        planCode?: FundPlanValue;
        planDescription?: FundPlanValue;}[];
}

interface FundProps {
    activeClient: string;
    fundCodeData: FundCodeData[];
    updateExistingFlag : "0" | "1";
    indexOfFirstData: number;
    indexOfLastData: number;
    itemCountPerPage: number;
    page: number;
    pageCount: number;
    setPageCount: (pageCount : number)=> void;
}

interface FundPlanValue{
    value: string;
}
interface FundPlanData {
    _id?: string;
    planCategory?: string;
    planCode?: FundPlanValue;
    planDescription?: FundPlanValue;
}

const Accordion = styled((props: AccordionProps) => (
    <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    '&:before': {
        "display": 'none',
    },
    // '&:not(:last-child)': {
    //     "borderBottom": `1px solid ${theme.palette.divider}`,
    // },
    //"border": `1px solid ${theme.palette.divider}`,
    "backgroundColor": "#EEF2FE",
    "borderRadius": '10px',
    "marginBottom": "10px"
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
    <MuiAccordionSummary
        expandIcon={<ArrowForwardIosSharpIcon sx={{ "fontSize": '0.9rem' }} />}
        {...props}
    />
))(({ theme }) => ({
    '& .MuiAccordionSummary-content': {
        "marginLeft": theme.spacing(2),
    },
    '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
        "transform": 'rotate(90deg)',   
    },

    //"backgroundColor": "#EEF2FE",
    // theme.palette.mode === 'dark'
    //     ? 'rgba(255, 255, 255, .05)'
    //     : 'rgba(0, 0, 0, .03)',
    "flexDirection": 'row-reverse',
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
    //"backgroundColor": "#EEF2FE",
    "borderTop": '1px solid rgba(0, 0, 0, .125)',
    "padding": theme.spacing(2),
}));

export default function FxAccordions(props: FundProps) {

    const {activeClient, fundCodeData, updateExistingFlag,indexOfFirstData, indexOfLastData, itemCountPerPage, page,pageCount, setPageCount}= props;
    const [activeFundCode, setActiveFundCode] = useState('');
    const [fundPlanData, setFundPlanData] = useState<IFundPlanData>({});
    const [expanded, setExpanded] = useState<number|string  |false >('');

    const fetchFundPlanDetails= useFetchFundPlanDetails();

    let prevData = {};

    useEffect(()=>{

        prevData=fundPlanData; 

        const fetchData= async () => await fetchFundPlanDetails(activeClient,activeFundCode)
            .then(result=>{ 
                let obj ={[activeFundCode]: result?.fundData};
                let isNot=!(activeFundCode in prevData);
                isNot ?setFundPlanData({...obj,...prevData}): setFundPlanData({...prevData});
               
            });
        if (activeFundCode)
            fetchData();
    },[activeFundCode]);

    const handleChange =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
        setExpanded(newExpanded ? panel : false);
    };

    return (
        <div>
            {fundCodeData.slice(indexOfFirstData, indexOfLastData).map((dataelement,index)=>{
                const {
                    fundCode,
                    fundName,
                    id,
                } = dataelement;
                return (
                    <Accordion 
                    // expanded={expanded === dataelement.id} onChange={handleChange(dataelement.id)} 
                        onClick={()=>{setActiveFundCode(dataelement?.fundCode);
                        }}
                        key={dataelement.id}
                    >
                        <AccordionSummary  aria-controls={`${dataelement.id}a-content`} id={`${dataelement.id}a-header`} >
                            <Stack direction="row" spacing={10}> 
                                <Typography display="flex" >
                                    <Typography color="#A4A7B2">Fund Code : </Typography>&nbsp; {dataelement.fundCode} 
                                </Typography>
                                <Typography display="flex" >
                                    <Typography color="#A4A7B2">Fund Name : </Typography>&nbsp;    <Tooltip title={fundName} arrow><Typography>{fundName.length>24?fundName.slice(0,24)+"..." :fundName}</Typography></Tooltip>  
                                </Typography>
                            </Stack>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Stack direction="row" spacing={10} mb={1} ml={2} color="#A4A7B2" fontSize="2px" > 
                                <Typography>
                        Fund Plan Code 
                                </Typography>
                                <Typography>
                        Fund Plan Description 
                                </Typography>
                            </Stack> 
                            {Object.keys(fundPlanData).length>0 && dataelement?.fundCode in fundPlanData  && fundPlanData[dataelement.fundCode].map((data:FundPlanData) => (
                            // <Stack justifyContent="space-between" bgcolor="#E4E9FF" mb={1}  p={1} borderRadius="8px" key={nanoid()} fontSize="2px" > 
                                <Grid display="flex"  item  bgcolor="#E4E9FF" mb={1}  p={1} borderRadius="8px" > 
                                    <Grid width="70%" display="flex"  
                                        flexDirection="row"  flexWrap= "wrap"  >
                                        <Grid
                                            display="flex"  
                                            flexDirection= "column"
                                            flexBasis="100%"  flex= "1"
                                            marginLeft="10px"
                                        >
                                            <Typography>
                                                {data?.planCode?.value}
                                            </Typography>
                                        </Grid>
                                        <Grid
                                            display="flex"  
                                            flexDirection= "column"
                                            flexBasis="100%"  flex= "1"
                                        >
                                            <Tooltip title={data?.planDescription?.value} arrow>
                                                <Typography >
                                                    {data?.planDescription?.value && data?.planDescription.value?.length>16?data?.planDescription?.value.slice(0,16)+"..." :data?.planDescription?.value}
                                                </Typography>
                                            </Tooltip>
                                        </Grid>
                                    </Grid>

                                </Grid>   
                            ))}
                        </AccordionDetails>
                    </Accordion>
                );})}
            
        </div>
    );
}
