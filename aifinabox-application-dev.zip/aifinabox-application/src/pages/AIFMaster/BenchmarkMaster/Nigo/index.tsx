import NigoBenchmarkMasterForm from "./NigoBenchmarkMasterForm";

const NigoBenchmarkMasterPage = () => {
    return (
        <>
            <NigoBenchmarkMasterForm/>
        </>
    );
};

export default NigoBenchmarkMasterPage;

