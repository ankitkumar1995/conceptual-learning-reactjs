import {
    BenchmarkMasterDetails as CheckerBenchmarkMasterDetails
} from "../../../../../../redux/AifMaster/BenchmarkMaster/Checker/initialState";
import {
    BenchmarkMasterDetails as MakerBenchmarkMasterDetails
} from "../../../../../../redux/AifMaster/BenchmarkMaster/Maker/initialState";
import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerBenchmarkMasterDetails, checkerFormState: CheckerBenchmarkMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerBenchmarkMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }

    return nigoData;
}
