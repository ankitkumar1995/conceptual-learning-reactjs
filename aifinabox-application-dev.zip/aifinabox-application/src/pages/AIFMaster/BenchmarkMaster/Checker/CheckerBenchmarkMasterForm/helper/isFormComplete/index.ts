import { 
    BenchmarkMasterDetails 
} from "../../../../../../../redux/AifMaster/BenchmarkMaster/Maker/initialState";

function isFormComplete(benchmarkMasterDetails: BenchmarkMasterDetails): boolean {
    const {
        benchmark,
        benchmarkType,
        clientCode,
        companyName,
        effectiveDate,
        isActive
    } = benchmarkMasterDetails;

    const isEffectiveDateFilled = ( 
        effectiveDate !== null && 
        effectiveDate.length !== 0 
    );
    const isBenchmarkFilled = ( benchmark.length !== 0 );
    const isBenchmarkTypeFilled = ( benchmarkType.length !== 0 );
    const isClientCodeFilled = ( clientCode.length !== 0 );
    const isCompanyNameFilled = ( companyName.length !== 0 );
    const isActiveChecked = ( isActive === "Yes" || isActive === "No" );

    return (
        isEffectiveDateFilled &&
        isBenchmarkFilled &&
        isBenchmarkTypeFilled &&
        isClientCodeFilled &&
        isCompanyNameFilled &&
        isActiveChecked
    );
}

export default isFormComplete;
