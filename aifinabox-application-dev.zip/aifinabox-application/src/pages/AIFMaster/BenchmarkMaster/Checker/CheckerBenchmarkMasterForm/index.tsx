import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Button,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { 
    masterSetupClearButtonStyles, 
    masterSetupSubmitButtonStyles 
} from "../../../styles/ButtonStyles";
import { useEffect, useState } from "react";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { RootState } from "../../../../../redux/store";
import benchmarkMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Checker/dispatchActionsProvider";
import benchmarkMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Nigo/dispatchActionsProvider";
import benchmarkMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/PageContext/dispatchActionsProvider";
import { getNigoData } from "../../Nigo/NigoBenchmarkMasterForm/helpers/getNigoData";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import useBenchmarkFormRef from "./hooks/useBenchmarkFormRef";
import { useNavigate } from "react-router-dom";
import usePostBenchmarkMaster from "../../../../../hooks/api/usePostBenchmarkMaster";
import { useSelector } from "react-redux";

const CheckerBenchmarkMasterForm = () => {
    const formRef = useBenchmarkFormRef();
    const navigate = useNavigate();

    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [isDataMatched, setIsDataMatched] = useState(false);
    const postBenchmarkMaster = usePostBenchmarkMaster();

    const benchmarkMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .checkerForm
    );

    const nigoBenchmarkMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .nigoForm
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .updateState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const {
        setNigoRaised,
    } = benchmarkMasterPageContextDispatchActionsProvider();

    const { firstName, lastName } = userContextState;

    const {
        clientCode,
        companyName,
        benchmark,
        benchmarkType,
        effectiveDate,
        isActive,
    } = benchmarkMasterFormState;

    const {
        clearState,
        setBenchmark,
        setBenchmarkType,
        setClientCode,
        setEffectiveDate,
        setIsActive
    } = benchmarkMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerData,
        setNigoMetaData,
    } = benchmarkMasterNigoDetailsFormDispatchActionsProvider();

    const handleClearState = () => {
        setFormErrorState(initializeFormErrorState);
        if (updateState.updateFlag === "1") {
            for (const [key, value] of Object.entries(updateState)) {
                if (key === "effectiveDate" && value) {
                    setEffectiveDate(null);
                }
                else if (key === "benchmark" && value) {
                    (formRef["benchmark"].current as HTMLInputElement).value = "";
                    setBenchmark("");
                }
                else if (key === "benchmarkType" && value) {
                    setBenchmarkType("");
                }
                else if (key === "isActive" && value) {
                    setIsActive("");
                }
            }
        }
        else {
            setBenchmark("");
            setBenchmarkType("");
            (formRef["benchmark"].current as HTMLInputElement).value = "";
            setEffectiveDate(null);
            setIsActive("");
        }
    };
    
    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };


    useEffect(()=>{
        if (JSON.stringify(nigoBenchmarkMasterFormState.makerData) === JSON.stringify(benchmarkMasterFormState)){
            setIsDataMatched(true);
        }
    },[benchmarkMasterFormState]);


    const handleFormSubmit = () => {
        postBenchmarkMaster(benchmarkMasterFormState, `${firstName} ${lastName}`, "0", userId, "C", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${clientCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    useEffect(() => {
        if (updateState.updateFlag === "1") {
            for (const [key, value] of Object.entries(updateState)) {
                if (key === "effectiveDate" && value) {
                    setEffectiveDate(null);
                }
                else if (key === "benchmark" && value) {
                    setBenchmark("");
                }
                else if (key === "benchmarkType" && value) {
                    setBenchmarkType("");
                }
                else if (key === "isActive" && value) {
                    setIsActive("");
                }
            }
        }
        else {
            setBenchmark("");
            setBenchmarkType("");
            setEffectiveDate(null);
            setIsActive("");
        }
    }, []);

    return (
        <Grid container rowSpacing={2} columnSpacing={2}>
            <Grid item xs={12}>
                <Grid 
                    alignItems="center"
                    display="flex"
                    justifyContent="space-between"
                >
                    <Box 
                        alignItems="center"
                        display="flex"
                    >
                        <IconButton 
                            onClick={() => {
                                handleClearState();
                                setClientCode("");
                            }}
                        >
                            <BackArrowIcon/>
                        </IconButton>

                        <Typography variant="formHeading">
                                Benchmark Master
                        </Typography>
                    </Box>
                </Grid>
            </Grid>

            <Grid item xs={3}>
                <FXInput
                    label="Client Code"
                    readOnly
                    disabled
                    value={clientCode}
                />
            </Grid>

            <Grid item xs={6}>
                <FXInput
                    label="Company Name"
                    required
                    readOnly
                    disabled
                    value={companyName}
                />   
            </Grid>

            <Grid item xs={3}>
                <FXDateInput
                    label="Effective Date"
                    required
                    value={effectiveDate}
                    disabled={updateState.updateFlag === "1" && updateState.effectiveDate ? false : updateState.updateFlag === "0" ? false : true}
                    onBlurValidator={onBlurDateValidator}
                    validatorOptions={{
                        "disableFuture": false, 
                        "disablePast": false, 
                        "disablePresent": false 
                    }}
                    onValueChange={(value) => {
                        handleFieldErrorChange(initializeFieldValidation(), "effectiveDate");
                        setEffectiveDate(value);
                    }}
                    onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "effectiveDate")}
                    error={formErrorState.effectiveDate.isError}
                    helperText={formErrorState.effectiveDate.helperText}
                />
            </Grid>

            <Grid item xs={3}>
                <FXSelectInput
                    label="Benchmark Type"
                    required
                    disabled={updateState.updateFlag === "1" && updateState.benchmarkType ? false : updateState.updateFlag === "0" ? false : true}
                    value={benchmarkType}
                    onValueChange={setBenchmarkType}
                    menuItems={[
                        {
                            "label": "Index",
                            "value": "Index"
                        },
                        {
                            "label": "Stock",
                            "value": "Stock"
                        },
                    ]}
                />
            </Grid>

            <Grid item xs={3}>
                {
                    (updateState.updateFlag === "1" && updateState.benchmark) || (updateState.updateFlag === "0" && !updateState.benchmark) ? 
                        <FXInput
                            label="Benchmark"
                            required
                            // disabled
                            forbidTo="alphanumeric-ws"
                            // value={benchmark}
                            maxLength={256}
                            inputRef={formRef.benchmark}
                            onBlur={() => handleInputFieldChange("benchmark", setBenchmark)}
                            onValueChange={(value) => {
                                handleFieldErrorChange(initializeFieldValidation(), "benchmark");
                                setBenchmark(value);
                            }}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "benchmark")}
                            error={formErrorState.benchmark.isError}
                            helperText={formErrorState.benchmark.helperText}
                        /> :
                        <FXInput
                            label="Benchmark"
                            required
                            disabled
                            value={benchmark}
                            maxLength={256}
                            inputRef={formRef.benchmark}
                            forbidTo="alphanumeric-ws"
                            onBlur={() => handleInputFieldChange("benchmark", setBenchmark)}
                            onValueChange={(value) => {
                                handleFieldErrorChange(initializeFieldValidation(), "benchmark");
                                setBenchmark(value);
                            }}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "benchmark")}
                            error={formErrorState.benchmark.isError}
                            helperText={formErrorState.benchmark.helperText}
                        /> 

                }
            </Grid>

            <Grid item xs={6}>
                <FXRadioGroup 
                    label="Is Active" 
                    row 
                    required
                    radioButtonValues={[{"label": "Yes","value": "Yes"},{"label": "No","value": "No"}]}
                    disabled={updateState.updateFlag === "1" && updateState.isActive ? false : updateState.updateFlag === "0" ? false : true}
                    value={isActive}
                    onValueChange={(value) => {
                        handleFieldErrorChange(initializeFieldValidation(), "isActive");
                        setIsActive(value);
                    }}
                />
            </Grid>

            <Grid item xs={6} mt={55}>
                <FXButton
                    buttonVariant="normal"
                    fullWidth
                    label="Clear"
                    onClick={handleClearState}
                    // sx={masterSetupClearButtonStyles}
                />
            </Grid>

            <Grid item xs={6} mt={55}>
                <FXButton
                    buttonVariant="submit"
                    disabled={
                        alertSnackbarContext.open ||
                        !(isFormComplete(benchmarkMasterFormState)) ||
                        !(isFormValid(formErrorState))
                    }
                    fullWidth
                    label="Submit"
                    onClick={() => {
                        const nigoData = getNigoData(nigoBenchmarkMasterFormState.makerData, benchmarkMasterFormState);
    
                        if (nigoData.length !== 0) {
                            setNigoMetaData(nigoData);
                            setCheckerData(benchmarkMasterFormState);
                            setNigoRaised(true);
                        }
                        else {
                            handleFormSubmit();
                        }
                    }}
                    sx={masterSetupSubmitButtonStyles}
                />
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </Grid>
    );
};

export default CheckerBenchmarkMasterForm;
