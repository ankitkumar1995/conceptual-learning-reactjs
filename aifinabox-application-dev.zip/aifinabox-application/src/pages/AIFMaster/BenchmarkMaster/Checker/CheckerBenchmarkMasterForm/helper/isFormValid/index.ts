import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.benchmark.isError ||
        formErrorState.benchmarkType.isError ||
        formErrorState.clientCode.isError ||
        formErrorState.companyName.isError ||
        formErrorState.effectiveDate.isError ||
        formErrorState.isActive.isError
    );
}

export default isFormValid;
