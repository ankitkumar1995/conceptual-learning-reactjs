import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../../../interfaces/FieldValidation.types";

import { Field } from "../../interfaces/field.types";

export type FormErrorState = { 
    [fieldName in Field]:  FieldValidation
};

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "benchmark": initializeFieldValidation(),
            "benchmarkType": initializeFieldValidation(),
            "clientCode": initializeFieldValidation(),
            "companyName": initializeFieldValidation(),
            "effectiveDate": initializeFieldValidation(),
            "isActive": initializeFieldValidation(),
        }
    );
}

export default initializeFormErrorState;
