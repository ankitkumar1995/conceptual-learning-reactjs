export type UpdateState = { 
    "benchmark": boolean;
    "benchmarkType": boolean;
    "clientCode": boolean;
    "companyName": boolean;
    "effectiveDate": boolean;
    "isActive": boolean;
};

function initializeUpdateState(): UpdateState {
    return (
        {
            "benchmark": false,
            "benchmarkType": false,
            "clientCode": false,
            "companyName": false,
            "effectiveDate": false,
            "isActive": false,
        }
    );
}

export default initializeUpdateState;
