import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

interface FormRef {
    [key: string]: RefObject<HTMLInputElement>;
};

function useBenchmarkFormRef(): FormRef {
    const formRef: { 
        [fieldName in Field]:  RefObject<HTMLInputElement>
    } = {
        "benchmark": useRef<HTMLInputElement>(null),
        "benchmarkType": useRef<HTMLInputElement>(null),
        "clientCode": useRef<HTMLInputElement>(null),
        "companyName": useRef<HTMLInputElement>(null),
        "effectiveDate": useRef<HTMLInputElement>(null),
        "isActive": useRef<HTMLInputElement>(null),
    };

    return formRef;
}

export default useBenchmarkFormRef;
