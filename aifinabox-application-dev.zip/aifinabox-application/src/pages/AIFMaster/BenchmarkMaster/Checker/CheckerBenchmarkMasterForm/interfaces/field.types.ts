export type Field = 
    "benchmark" |
    "benchmarkType" |
    "clientCode" |
    "companyName" |
    "effectiveDate" |
    "isActive";
