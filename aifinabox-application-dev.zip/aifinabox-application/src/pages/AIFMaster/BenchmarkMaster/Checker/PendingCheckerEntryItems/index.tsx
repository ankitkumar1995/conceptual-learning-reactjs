import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import FXSelectInput from "../../../../../components/FXSelectInput";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { StyledPagination } from "./PaginationStyles";
import benchmarkMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Checker/dispatchActionsProvider";
import benchmarkMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Nigo/dispatchActionsProvider";
import updateDispatchActionProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Update/dispatchActionProvider";
import useFetchBenchmarkMaster from "../../../../../hooks/api/useFetchBenchmarkMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const { 
        setClientCode,
        setClientType,
        setBenchmarkMasterCheckerStateFromMakerEntry,
    } = benchmarkMasterDetailsFormDispatchActionsProvider();

    const {setIsUpdate} = updateDispatchActionProvider();

    const { setMakerData } = benchmarkMasterNigoDetailsFormDispatchActionsProvider();

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchBenchmarkMaster = useFetchBenchmarkMaster();

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleCardOnClick = (clientCode: string) => {
        fetchBenchmarkMaster(clientCode, "0", userId)
            .then((benchmarkMaster) => {
                const {benchmarkMasterState, benchmarkMasterUpdateState} = benchmarkMaster;
                setBenchmarkMasterCheckerStateFromMakerEntry(benchmarkMasterState);
                setIsUpdate(benchmarkMasterUpdateState);
                setClientCode(clientCode);
                setClientType(benchmarkMasterState.clientType);
                setMakerData(benchmarkMasterState);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "benchmark_master", "C", userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page, , itemCountPerPage, pageCount]);

    return (
        <>
            <Stack
                paddingBottom="20px"
            >
                <Typography variant="toDoLabel">
                    To Do
                </Typography>
            </Stack>

            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            // clientType,
                            createdBy,
                            createdOn,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName,
                                        }
                                    ]}
                                    onClick={() => handleCardOnClick(clientCode)}
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
