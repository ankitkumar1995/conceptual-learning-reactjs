import CheckerBenchmarkMasterForm from "./CheckerBenchmarkMasterForm";
import PendingCheckerEntryItems from "./PendingCheckerEntryItems";
import { RootState } from "../../../../redux/store";
import benchmarkMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/BenchmarkMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerBenchmarkMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .checkerForm
                .clientCode
    );

    const { 
        setClientCode
    } = benchmarkMasterDetailsFormDispatchActionsProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingCheckerEntryItems />
                    : <CheckerBenchmarkMasterForm />
            }
        </>
    );
};

export default CheckerBenchmarkMasterPage;
