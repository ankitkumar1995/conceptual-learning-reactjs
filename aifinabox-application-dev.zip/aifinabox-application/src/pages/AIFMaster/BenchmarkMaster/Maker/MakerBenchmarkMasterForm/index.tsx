import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Button,
    Grid,
    Stack,
    Typography
} from "@mui/material";
import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../interfaces/FieldValidation.types";
import {
    addNewButtonStyles,
    masterSetupClearButtonStyles, 
    masterSetupSubmitButtonStyles,
    updateExistingButtonStyles 
} from "../../../styles/ButtonStyles";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useEffect, useState } from "react";
import useFetchClientDetails, {
    ClientDetails,
    ClientDetailsData 
} from "../../../../../hooks/api/useFetchClientDetails";

import AddIcon from "../../../../../icons/AddIcon";
import ArrowForwardIcon from "../../../../../icons/ArrowForwardIcon";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { RootState } from "../../../../../redux/store";
import benchmarkMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BenchmarkMaster/Maker/dispatchActionsProvider";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import useBenchmarkFormRef from "./hooks/useBenchmarkFormRef";
import useFetchBenchmarkMaster from "../../../../../hooks/api/useFetchBenchmarkMaster";
import useFetchClientCodes from "../../../../../hooks/api/useFetchClientCodes";
import useFetchClientMaster from "../../../../../hooks/api/useFetchClientMaster";
import usePostBenchmarkMaster from "../../../../../hooks/api/usePostBenchmarkMaster";
import { useSelector } from "react-redux";

const MakerBenchmarkMasterForm = () => {
    const formRef = useBenchmarkFormRef();

    const [disabled, setDisabled] = useState(true);
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [clientCodes, setClientCodes] = useState([initializeMenuItem()]);
    const [clientCodesDetails, setClientCodesDetails] = useState<ClientDetails[]>([]);
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [updateExistingFlag, setUpdateExistingFlag] = useState<"0" | "1">("0");
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);

    const [benchmarkState, setBenchmarkState] = useState<string>("");
    const [benchmarkTypeState, setBenchmarkTypeState] = useState<string>("");
    const [effectiveDateState, setEffectiveDateState] = useState<string | null>("");
    const [isActiveState, setIsActiveState] = useState<string>("");
    
    const benchmarkMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .makerForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        benchmark,
        benchmarkType,
        clientCode,
        companyName,
        effectiveDate,
        isActive,
    } = benchmarkMasterFormState;

    const {
        clearState,
        setBenchmark,
        setBenchmarkMasterMakerState,
        setBenchmarkType,
        setClientCode,
        setClientType,
        setCompanyName,
        setEffectiveDate,
        setIsActive
    } = benchmarkMasterDetailsFormDispatchActionsProvider();

    const fetchClientCodes = useFetchClientCodes();
    const postBenchmarkMaster = usePostBenchmarkMaster();
    const fetchClientDetails = useFetchClientDetails();
    const fetchBenchmarkMaster =  useFetchBenchmarkMaster();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
        setFormErrorState(initializeFormErrorState);
    };
    
    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const handleFormSubmit = () => {
        postBenchmarkMaster(benchmarkMasterFormState, `${firstName} ${lastName}`, (updateExistingFlag), userId, "M", isUpdate)
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleClientCodeChange = async (_clientCode: string) => {
        setClientCode(_clientCode);

        if (updateExistingFlag === "0") {
            const companyName = clientCodesDetails.find((clientCodeDetail) => clientCodeDetail.clientCode === _clientCode)?.clientName;
            setCompanyName(companyName || "");
        }
        else {
            await fetchBenchmarkMaster(_clientCode, updateExistingFlag, userId)
                .then((response) => {
                    const {benchmarkMasterState, benchmarkMasterUpdateState} = response;
                    setBenchmarkMasterMakerState(benchmarkMasterState);
                    setFormErrorState(initializeFormErrorState);
                    
                    setBenchmarkState(benchmarkMasterState.benchmark);
                    setBenchmarkTypeState(benchmarkMasterState.benchmarkType);
                    setEffectiveDateState(benchmarkMasterState.effectiveDate);
                    setIsActiveState(benchmarkMasterState.isActive);
                    
                    (formRef["benchmark"].current as HTMLInputElement).value = benchmarkMasterState.benchmark;
                })
                .catch((error) => console.error(error));
        }
    };

    const handleChangeUpdate = (field: Field, value: string) => {
        if (updateExistingFlag === "1") {
            if (benchmarkMasterFormState[field] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }
    };

    useEffect(() => {
        fetchClientDetails("benchmark_master", updateExistingFlag)
            .then((result) => {
                const clientCodesResponse = result.map((codes: ClientDetails) =>  ({
                    "label": `${codes.clientCode} - ${codes.clientName}`,
                    "value": codes.clientCode,
                }));
                setClientCodes(clientCodesResponse);
                setClientCodesDetails(result);
            });
    }, [updateExistingFlag]);

    useEffect(() => {
        handleClearState();
    }, []);

    return (
        <Grid container rowSpacing={2} columnSpacing={2}>
            <Grid item xs={12}>
                <Grid 
                    alignItems="center"
                    display="flex"
                    justifyContent="space-between"
                >
                    <Typography variant="formHeading" display="flex">
                        {updateExistingFlag === "1" ? "Update" : "Add"} Benchmark Master
                    </Typography>
                    <Stack direction="row" spacing={2}>
                        <FXButton
                            buttonVariant="contained"
                            disabled={disabled}
                            fullWidth
                            label="Add New"
                            onClick={() => {
                                handleClearState();
                                setDisabled(true);
                                setUpdateExistingFlag("0");
                            }}
                            startIcon={<AddIcon/>}
                            sx={addNewButtonStyles}
                        />
                        <FXButton
                            buttonVariant="contained"
                            disabled={!disabled}
                            fullWidth
                            label="Update Existing"
                            onClick={() => {
                                handleClearState();
                                setDisabled(false);
                                setUpdateExistingFlag("1");
                            }}
                            startIcon={<EditIcon/>}
                            sx={updateExistingButtonStyles}
                        />
                    </Stack>
                </Grid>
            </Grid>

            <Grid item xs={3}>
                <FXSelectInput
                    label="Client Code"
                    required
                    value={clientCode}
                    onValueChange={(value) => handleClientCodeChange(value)}
                    menuItems={clientCodes}
                    onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "clientCode")}
                    error={formErrorState.clientCode.isError}
                    helperText={formErrorState.clientCode.helperText}
                />
            </Grid>

            <Grid item xs={6}>
                <FXInput
                    label="Company Name"
                    required
                    readOnly
                    disabled
                    value={companyName}
                />   
            </Grid>

            <Grid item xs={3}>
                <FXDateInput
                    label="Effective Date"
                    required
                    value={effectiveDate}
                    onBlurValidator={onBlurDateValidator}
                    validatorOptions={{
                        "disableFuture": false, 
                        "disablePast": false, 
                        "disablePresent": false 
                    }}
                    onValueChange={(value) => {
                        handleFieldErrorChange(initializeFieldValidation(), "effectiveDate");
                        setEffectiveDate(value);
                        handleChangeUpdate("effectiveDate", value);
                    }}
                    onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "effectiveDate")}
                    error={formErrorState.effectiveDate.isError}
                    helperText={formErrorState.effectiveDate.helperText}
                />
            </Grid>

            <Grid item xs={3}>
                <FXSelectInput
                    label="Benchmark Type"
                    required
                    value={benchmarkType}
                    onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "benchmarkType")}
                    error={formErrorState.benchmarkType.isError}
                    helperText={formErrorState.benchmarkType.helperText}
                    onValueChange={(value) => {
                        setBenchmarkType(value);
                        handleChangeUpdate("benchmarkType", value);
                    }}
                    menuItems={[
                        {
                            "label": "Index",
                            "value": "Index"
                        },
                        {
                            "label": "Stock",
                            "value": "Stock"
                        },
                    ]}
                />
            </Grid>

            <Grid item xs={3}>
                <FXInput
                    label="Benchmark"
                    required
                    maxLength={256}
                    forbidTo="alphanumeric-ws"
                    inputRef={formRef.benchmark}
                    value={benchmark}
                    onBlur={() => handleInputFieldChange("benchmark", setBenchmark)}
                    onValueChange={(value) => {
                        handleFieldErrorChange(initializeFieldValidation(), "benchmark");
                        setBenchmark(value);
                        handleChangeUpdate("benchmark", value);
                    }}
                    onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "benchmark")}
                    error={formErrorState.benchmark.isError}
                    helperText={formErrorState.benchmark.helperText}
                />   
            </Grid>

            <Grid item xs={6}>
                <FXRadioGroup 
                    label="Is Active" 
                    row 
                    required
                    radioButtonValues={[{"label": "Yes","value": "Yes"},{"label": "No","value": "No"}]}
                    value={isActive}
                    onValueChange={(value) => {
                        handleFieldErrorChange(initializeFieldValidation(), "isActive");
                        setIsActive(value);
                        handleChangeUpdate("isActive", value);
                    }}
                />
            </Grid>

            <Grid item xs={6} mt={55}>
                <FXButton
                    buttonVariant="normal"
                    fullWidth
                    label="Clear"
                    onClick={handleClearState}
                />
            </Grid>

            <Grid item xs={6} mt={55}>
                <FXButton
                    buttonVariant="submit"
                    disabled={
                        alertSnackbarContext.open ||
                        !(isFormComplete(benchmarkMasterFormState)) ||
                        !(isFormValid(formErrorState)) ||
                        (
                            benchmark === benchmarkState && 
                            isActive === isActiveState && 
                            effectiveDate === effectiveDateState && 
                            benchmarkType === benchmarkTypeState
                        )
                    }
                    fullWidth
                    label="Submit to Checker"
                    onClick={handleFormSubmit}
                    endIcon={<ArrowForwardIcon/>}
                    sx={masterSetupSubmitButtonStyles}
                />
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success"){
                        handleClearState();
                        setUpdateExistingFlag("1");
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </Grid>
    );
};

export default MakerBenchmarkMasterForm;
