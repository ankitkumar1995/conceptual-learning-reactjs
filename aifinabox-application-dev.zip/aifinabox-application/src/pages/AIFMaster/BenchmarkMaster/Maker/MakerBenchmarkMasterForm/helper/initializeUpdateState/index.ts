import { Field } from "../../interfaces/field.types";

export type UpdateState = { 
    [fieldName in Field]: boolean
};

function initializeUpdateState(): UpdateState {
    return (
        {
            "benchmark": false,
            "benchmarkType": false,
            "clientCode": false,
            "companyName": false,
            "effectiveDate": false,
            "isActive": false,
        }
    );
}

export default initializeUpdateState;
