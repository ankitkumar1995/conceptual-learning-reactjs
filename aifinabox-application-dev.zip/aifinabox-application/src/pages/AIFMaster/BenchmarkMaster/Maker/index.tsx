import MakerBenchmarkMasterForm from "./MakerBenchmarkMasterForm";

const MakerBenchmarkMasterPage = () => {

    return (
        <>
            <MakerBenchmarkMasterForm/>
        </>
    );
};

export default MakerBenchmarkMasterPage;
