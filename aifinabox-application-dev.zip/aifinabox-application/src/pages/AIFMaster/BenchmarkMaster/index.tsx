import CheckerBenchmarkMasterPage from "./Checker";
import MakerBenchmarkMasterPage from "./Maker";
import NigoBenchmarkMasterForm from "./Nigo/NigoBenchmarkMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const BenchmarkMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .benchmarkMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerBenchmarkMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerBenchmarkMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoBenchmarkMasterForm/>
            }
        </>
    );
};

export default BenchmarkMasterPage;
