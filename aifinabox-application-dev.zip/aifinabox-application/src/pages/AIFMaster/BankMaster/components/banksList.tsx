import {
    Box,
    Button,
    Grid,
    Icon,
    Typography
} from "@mui/material";
import {
    ChangeEvent,
    useEffect,
    useState
} from "react";
import useFetchBanksList, { BanksListData } from "../../../../hooks/api/useFetchBanksList";

import FXButton from "../../../../components/FXButton";
import HDFCBankIcon from "../../../../icons/HDFCBankIcon";
import { RootState } from "../../../../redux/store";
import SearchInputField from "./searchInputField";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { useSelector } from "react-redux";

const BanksList = (
    { 
        onBankChange 
    } : 
    { 
        onBankChange: (value:string) => void; 
    }
) => {
    const [selectedBankIndex, setSelectedBankIndex] = useState<number>(0);
    const [banksList, setBanksList] = useState<BanksListData[]>([]);
    const [filteredBanksList, setFilteredBanksList] = useState<BanksListData[]>(banksList);
    
    const makerForm = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .makerForm
    );

    const { companyCode, companyName } = makerForm;

    const { 
        clearState,
        setBankIfscRtgsCode,
        setCorporateBankName,
        setCompanyCode,
        setCompanyName,
    } = bankMasterDetailsFormDispatchActionsProvider();

    const fetchBanksList = useFetchBanksList();
    
    useEffect(() => {
        fetchBanksList(companyCode)
            .then((result) => {
                setBanksList(result);
                onBankChange(result[0].ifscOrRtgsCode.value);
                setBankIfscRtgsCode(result[0].ifscOrRtgsCode.value);
                setCorporateBankName(result[0].bankName.value);
            });
    }, []);

    useEffect(() => {
        setFilteredBanksList(banksList);
    }, [banksList]);

    const handleBankSearch = ( ele: ChangeEvent<Element> ) => {
        const searchValue = (ele.target as HTMLInputElement).value;

        const filterBanksList = banksList.filter((bank) => 
            bank.bankName.value.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1
        );
        
        setFilteredBanksList(filterBanksList);
    };

    const { 
        setFlowType, 
        setMakerNavigation,
    } = bankMasterPageContextFormDispatchActionsProvider();

    useEffect(() => {
        setFilteredBanksList(banksList);
    }, []);

    return (
        <Grid 
            sx={{
                "background": "#fff", 
                "borderRadius": "3px",
                "display": "flex",
                "flex": "0 0 auto",
                "flexDirection": "column",
                "height": "750px",
                "width": "300px",
            }}>
            <SearchInputField 
                handleBankSearch={handleBankSearch} 
                placeholder="Search by Bank Name" 
            />
            <Grid 
                sx={{
                    "flexGrow": "1",
                    "overflow": "auto",
                }}
            >
                {filteredBanksList.map (
                    (bank, index) =>
                        <Button
                            disableRipple
                            sx={{
                                "alignItems": "center",
                                "background": selectedBankIndex === index ? 
                                    "rgba(15, 212, 216, 0.15)": 
                                    "transparent",
                                "borderRadius": 0,
                                "borderRight": selectedBankIndex === index ? 
                                    "5px solid #0FD4D8" : 
                                    "5px solid transparent",
                                "display": "flex",
                                "opacity": selectedBankIndex === index ? 1 : 0.5,
                                "padding": "20px",
                                "textTransform": "none",
                                "width": "100%",
                            }}
                            onClick={() => {
                                setSelectedBankIndex(index);
                                onBankChange(bank.ifscOrRtgsCode.value);
                                setBankIfscRtgsCode(bank.ifscOrRtgsCode.value);
                                setCorporateBankName(bank.bankName.value);
                                // setBankCode(result[0].bankCode.value); 
                                // setBranchName(result[0].branchName.value);
                                // setCity(result[0].city.value);
                                // setCorporateId(result[0].corporateId.value);
                                // setBicSwiftCode(result[0].bicOrSwiftCode.value);
                                // setCurrency(result[0].Currency.value);
                            }}
                        >
                            <Icon sx={{"height": "30px","width": "30px"}}>
                                <HDFCBankIcon />
                            </Icon>

                            <Box ml={1} width="100%">
                                <Typography 
                                    variant="navigationSectionSelected"
                                    sx={{
                                        "color": "#201C43",
                                        "display": "block",
                                        "fontWeight": selectedBankIndex === index ? 600 : 400,
                                        "lineHeight": "20px",
                                        "overflow": "hidden",
                                        "textAlign": "left",
                                        "textOverflow": "ellipsis",
                                        "whiteSpace": "nowrap",
                                        "width": "217px",
                                    }}
                                >
                                    {bank.bankName.value}
                                </Typography>

                                <Typography 
                                    variant="pageDescription"
                                    sx={{
                                        "display": "block",
                                        "lineHeight": "18px",
                                        "textAlign": "left",
                                    }}
                                >
                                    IFSC : {bank.ifscOrRtgsCode.value}
                                </Typography>
                            </Box>
                        </Button>
                )
                }

                {filteredBanksList.length === 0 &&
                    <Box
                        sx={{
                            "padding": "20px",
                            "width": "100%",
                        }}>
                        <Typography variant="navigationSectionNormal">
                            No Results Found
                        </Typography>
                    </Box>
                }
            </Grid> 

            <Box sx={{"padding": "20px"}}>
                <FXButton 
                    disableRipple
                    buttonVariant="dashed" 
                    label="+ Add New Bank" 
                    sx={{
                        "width": "100%"
                    }}
                    onClick={() => {
                        setFlowType("NN");
                        setMakerNavigation("form");
                        clearState(makerForm);
                    }}
                />
            </Box>
        </Grid>
    );
};

export default BanksList;
