import { Chip } from "@mui/material";
import { fontFamily } from "../../../../themes/typography/fontFamily";

const StatusChip = ({ status } : { status: string; }) => {
    return (
        <Chip 
            label= {status === "new" ? "NEW" : "UPDATED"}
            sx={{
                "& .MuiChip-label": {
                    "color": "#fff",
                    "fontFamily": fontFamily,
                    "fontSize": "10px",
                    "fontWeight": 600,
                    "padding": "2px 5px",
                },
                "backgroundColor": status === "new" ? "#39CA3F" : "#DD843A",
                "borderRadius": "4px",
                "height": "16px",
                "lineHeight": "12px",
                "marginBottom": "10px",
                "marginLeft": "5px",
            }}
        />
    );
};

export default StatusChip;
