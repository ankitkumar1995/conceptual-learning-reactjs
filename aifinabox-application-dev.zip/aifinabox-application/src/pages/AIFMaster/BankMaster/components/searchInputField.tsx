import { ChangeEvent } from "react";
import SearchIcon from "@mui/icons-material/Search";
import StyledTextField from "../../../../components/FXInput/StyledTextField";
import { fontFamily } from "../../../../themes/typography/fontFamily";

const SearchInputField = (
    {
        handleBankSearch, 
        placeholder,
    } :
    {
        handleBankSearch: (ele: ChangeEvent<Element>) => void;
        placeholder: string;
    }
) => {
    return (
        <StyledTextField 
            autoComplete="off"
            placeholder={placeholder}
            onChange={(ele) => handleBankSearch(ele)}
            InputProps={{
                "disableUnderline": true,
                "endAdornment": <SearchIcon/>
            }}
            sx={{
                "& .MuiInputBase-input": {
                    "&::placeholder": {
                        "fontSize": "12px",
                    },
                    "fontFamily": fontFamily,
                    "py": 1,
                },
                "& .MuiOutlinedInput-notchedOutline": {
                    "border": 0,
                    "borderBottom": "1px solid rgba(0, 0, 0, 0.23)",
                    "borderRadius": 0,
                },
                "& .MuiOutlinedInput-root.Mui-focused": {
                    "& .MuiOutlinedInput-notchedOutline": {
                        "border": 0,
                        "borderBottom": "1px solid rgba(0, 0, 0, 0.23)",
                        "borderRadius": 0,
                    },
                },
                "& .MuiSvgIcon-root": {
                    "height": "18px",
                    "width": "18px",
                },
                "&::parent": {"background": "red"},
                "marginBottom": "20px",
                "padding": "10px 20px 0",
            }}
            inputProps={{ 
                "maxLength": 256,
            }}
        />
    );
};

export default SearchInputField;
