import {
    Grid,
    Tab,
    Tabs,
} from "@mui/material";

import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import { useNavigate } from "react-router";
import { useState } from "react";

const CheckerBankMasterPage = () => {
    const [currentTab, setCurrentTab] = useState(0);

    const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
        setCurrentTab(newValue);
    };
    
    const { setCheckerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    const navigate = useNavigate();

    return (
        <Grid>
            <Grid mb="28px">
                <Tabs 
                    value={currentTab} 
                    onChange={handleTabChange}
                    sx={{
                        "& .MuiTab-root": {
                            "&.Mui-selected": {
                                "color": "#2057A6",
                                "fontWeight": 600,
                            },
                            "color": "rgba(32, 87, 166, 0.5)",
                            "fontFamily": fontFamily,
                            "fontSize": "14px",
                            "fontWeight": 500,
                            "marginRight": "24px",
                            "minWidth": "unset",
                            "padding": "0",
                            "textTransform": "none",
                        },
                        "& .MuiTabs-indicator": {
                            "display": "none"
                        },
                    }}
                >
                    <Tab disableRipple label="To Do" />
                    <Tab disableRipple label="Rejected By Me" />
                </Tabs>
            </Grid>

            <Grid>
                <PendingCheckerEntryItemCard
                    createdBy="Santhosh"
                    creationDate="15/05/2023"
                    data={[
                        {
                            "dataPartOne": "XYZ154",
                            "dataPartTwo": "Trust",
                        },
                    ]}
                    onClick={() => setCheckerNavigation("form")}
                />
            </Grid>
        </Grid>
    );
};

export default CheckerBankMasterPage;
