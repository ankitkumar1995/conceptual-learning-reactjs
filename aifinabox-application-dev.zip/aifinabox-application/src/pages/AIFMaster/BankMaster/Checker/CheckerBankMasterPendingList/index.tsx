import {
    BankMasterDetails,
    initialBankMasterDetailsFormState
} from "../../../../../redux/AifMaster/BankMaster/Maker/initialState";
import {
    FormControl,
    Grid,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Tab,
    Tabs,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";
import FXButton from "../../../../../components/FXButton";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import PendingCheckerLists from "./components/PendingCheckerLists";
import { RootState } from "../../../../../redux/store";
import {
    StyledPagination
} from "../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Checker/dispatchActionsProvider";
import bankMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Nigo/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import updateStateDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Update/dispatchActionsProvider";
import useFetchBankMaster from "../../../../../hooks/api/useFetchBankMaster";
import { useSelector } from "react-redux";

const itemCountPerPage = 5;

const CheckerBankMasterPendingList = () => {
    const [currentTab, setCurrentTab] = useState(0);

    const [tabActive, setTabActive] = useState({
        "activeToDo": true,
        // "rejectedByAuditor": false,
        "rejectedByMe": false,
    });
    // const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    //     setCurrentTab(newValue);
    // };

    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage, setItemCountPerPage] = useState(5);
    
    const { 
        setCheckerBankIfscRtgsCode,
        setCheckerNavigation 
    } = bankMasterPageContextFormDispatchActionsProvider();

    const { setMakerData } = bankMasterNigoDetailsFormDispatchActionsProvider();
    
    const { setUpdateState } = updateStateDispatchActionsProvider();

    const { 
        setCompanyCode, 
        setCompanyName,
        setFundCode,
        setFundName,
        setCorporateBankName,
        setBankAccountName,
        setBankAccountNumber,
        setOwnershipType,
        setIsActive,
        setDormant,
        setDormantDate,
        setRemarks,
        setDefaultAccount,
    } = bankMasterDetailsFormDispatchActionsProvider();

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchBankMaster = useFetchBankMaster();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleCardOnClick = (
        bankAccountNumber: string, 
        companyCode: string,
        fundCode: string, 
        companyName: string,
        fundName: string,
        corporateBankName: string,
        ifscOrRtgsCode: string,
    ) => {
        fetchBankMaster(bankAccountNumber, companyCode, fundCode, "0", userId)
            .then((bankMasterMakerState) => {
                const { 
                    bankMasterFormState, 
                    bankMasterUpdateState 
                } = bankMasterMakerState;
                setMakerData(bankMasterFormState as BankMasterDetails);
                setUpdateState(bankMasterUpdateState);
                if (bankMasterUpdateState.updateFlag === "1") {
                    if (!(bankMasterUpdateState.bankAccountName))
                        setBankAccountName((bankMasterFormState as BankMasterDetails).bankAccountName ?? "");
                    
                    if (!(bankMasterUpdateState.bankAccountNumber))
                        setBankAccountNumber((bankMasterFormState as BankMasterDetails).bankAccountNumber ?? "");
                    
                    if (!(bankMasterUpdateState.ownershipType))
                        setOwnershipType((bankMasterFormState as BankMasterDetails).ownershipType ?? "");
                    
                    if (!(bankMasterUpdateState.isActive))
                        setIsActive((bankMasterFormState as BankMasterDetails).isActive ?? "Yes");
                    
                    if (!(bankMasterUpdateState.dormant))
                        setDormant((bankMasterFormState as BankMasterDetails).dormant ?? "Yes");
                    
                    if (!(bankMasterUpdateState.dormantDate))
                        setDormantDate((bankMasterFormState as BankMasterDetails).dormantDate ?? null);
                    
                    if (!(bankMasterUpdateState.remarks))
                        setRemarks((bankMasterFormState as BankMasterDetails).remarks ?? "");
                    
                    setDefaultAccount((bankMasterFormState as BankMasterDetails).defaultAccount ?? "No");
                };
            });
        setCompanyCode(companyCode);
        setCompanyName(companyName);
        setFundCode(fundCode);
        setFundName(fundName);
        setCorporateBankName(corporateBankName);
        setCheckerBankIfscRtgsCode(ifscOrRtgsCode);
        setCheckerNavigation("form");
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "bank_master", "C",userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page, itemCountPerPage, pageCount]);


    const handleTabChange = (tab: string) => {
        setTabActive({
            "activeToDo": false,
            // "rejectedByAuditor": false,
            "rejectedByMe": false,
            [tab]: true,
        });
    };

    return (
        <>
            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {/* <Grid mb="28px">
                <Tabs 
                    value={currentTab} 
                    onChange={handleTabChange}
                    sx={{
                        "& .MuiTab-root": {
                            "&.Mui-selected": {
                                "color": "#2057A6",
                                "fontWeight": 600,
                            },
                            "color": "rgba(32, 87, 166, 0.5)",
                            "fontFamily": fontFamily,
                            "fontSize": "14px",
                            "fontWeight": 500,
                            "marginRight": "24px",
                            "minWidth": "unset",
                            "padding": "0",
                            "textTransform": "none",
                        },
                        "& .MuiTabs-indicator": {
                            "display": "none"
                        },
                    }}
                >
                    <Tab disableRipple label="To Do" />
                    <Tab disableRipple label="Rejected By Me" />
                </Tabs>
            </Grid> */}

                <Grid item xs={12} mb={3}>
                    <Grid
                        display="flex"
                    >
                        <FXButton
                            label="To Do"
                            onClick={() => handleTabChange("activeToDo")}
                            disabled={tabActive.activeToDo}
                        />

                        <FXButton
                            label="Rejected By Me"
                            onClick={() => handleTabChange("rejectedByMe")}
                            disabled={tabActive.rejectedByMe}
                        />

                        {/* <FXButton
                            label="Rejected By Auditor"
                            onClick={() => handleTabChange("rejectedByAuditor")}
                            disabled={tabActive.rejectedByAuditor}
                        /> */}

                    </Grid>
                </Grid>

                <PendingCheckerLists
                    tabActive={tabActive}
                    handleCardOnClick={handleCardOnClick}
                />
            </Stack>
            {/* <Grid minHeight="400px" mb={3}>
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            fundCode,
                            fundName,
                            bankAccountNumber,
                            ifscOrRtgsCode,
                            bankName,
                            createdBy,
                            createdOn,
                            id,
                        } = pendingCheckerEntryItem;
                        
                        return (
                            <PendingCheckerEntryItemCard 
                                key={id}
                                createdBy={createdBy}
                                creationDate={createdOn}
                                data={[
                                    {
                                        "dataPartOne": clientCode,
                                        "dataPartTwo": clientName
                                    },
                                    {
                                        "dataPartOne": fundCode,
                                        "dataPartTwo": fundName
                                    },
                                    {
                                        "dataPartOne": bankName as string,
                                        "dataPartTwo": `Ac. No: ${bankAccountNumber as string}`
                                    },
                                ]}
                                onClick={() => handleCardOnClick(bankAccountNumber ?? "", clientCode, fundCode, clientName, fundName, bankName ?? "", ifscOrRtgsCode ?? "")}
                            />
                        );
                    })
                }
            </Grid>
            
            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                            <MenuItem value={20}>20</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>

                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Grid> */}
        </>
    );
};

export default CheckerBankMasterPendingList;
