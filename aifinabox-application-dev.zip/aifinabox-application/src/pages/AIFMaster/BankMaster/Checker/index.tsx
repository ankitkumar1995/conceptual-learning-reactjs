import CheckerBankMasterBankAccountList from "./CheckerBankMasterBankAccountList";
import CheckerBankMasterForm from "./CheckerBankMasterForm";
import CheckerBankMasterPendingList from "./CheckerBankMasterPendingList";
import { RootState } from "../../../../redux/store";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/BankMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerBankMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .checkerForm
                .companyCode
    );

    const { 
        setCompanyCode
    } = bankMasterDetailsFormDispatchActionsProvider();
    
    useEffect(()=>{
        setCompanyCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0) ?
                    <CheckerBankMasterPendingList /> :         
                    <CheckerBankMasterForm /> 
            }
        </>
    );
};

export default CheckerBankMasterPage;

