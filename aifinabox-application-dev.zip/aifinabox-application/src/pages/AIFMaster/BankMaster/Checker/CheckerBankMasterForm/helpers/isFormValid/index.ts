import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.accountType.isError ||
        formErrorState.bankAccountName.isError ||
        formErrorState.bankAccountNumber.isError ||
        formErrorState.bankCode.isError ||
        formErrorState.bankIfscRtgsCode.isError ||
        formErrorState.bicSwiftCode.isError ||
        formErrorState.branchName.isError ||
        formErrorState.city.isError ||
        formErrorState.companyCode.isError ||
        formErrorState.companyName.isError ||
        formErrorState.corporateBankName.isError ||
        formErrorState.corporateId.isError ||
        formErrorState.currency.isError ||
        formErrorState.dormant.isError ||
        formErrorState.dormantDate.isError ||
        formErrorState.fundCode.isError ||
        formErrorState.fundName.isError ||
        formErrorState.isActive.isError ||
        formErrorState.ownershipType.isError ||
        formErrorState.remarks.isError
    );
}

export default isFormValid;
