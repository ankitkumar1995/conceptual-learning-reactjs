import {
    BankMasterDetails
} from "../../../../../../../redux/AifMaster/BankMaster/Maker/initialState";

function isFormComplete(bankMasterForm: BankMasterDetails): boolean {
    const {
        accountType,
        bankAccountName,
        bankAccountNumber,
        bankCode,
        bankIfscRtgsCode,
        bicSwiftCode,
        branchName,
        city,
        companyCode,
        companyName,
        corporateBankName,
        corporateId,
        currency,
        dormant,
        dormantDate,
        fundCode,
        fundName,
        isActive,
        ownershipType,
    } = bankMasterForm ;
 
    const isAccountTypeFilled = ( accountType.length !== 0 );
    const isBankAccountNameFilled = ( bankAccountName.length !== 0 );
    const isBankAccountNumberFilled = ( bankAccountNumber.length !== 0 );
    const isBankCodeFilled = ( bankCode.length !== 0 );
    const isBankIfscRtgsCodeFilled = ( bankIfscRtgsCode.length !== 0 );
    const isBicSwiftCodeFilled = ( bicSwiftCode.length !== 0 );
    const isBranchNameFilled = ( branchName.length !== 0 );
    const isCityFilled = ( city.length !== 0 );
    const isCompanyCodeFilled = ( companyCode.length !== 0 );
    const isCompanyNameFilled = ( companyName.length !== 0 );
    const isCorporateBankNameFilled = ( corporateBankName.length !== 0 );
    const isCorporateIdFilled = ( corporateId.length !== 0 );
    const isCurrencyFilled = ( currency.length !== 0 );
    const isDormantFilled = ( dormant.length !== 0 );
    const isDormantDateFilled = ( 
        dormant === "Yes" ?
            (dormantDate !== null && 
            dormantDate.length !== 0) :
            true
    );
    const isFundCodeFilled = ( fundCode.length !== 0 );
    const isFundNameFilled = ( fundName.length !== 0 );
    const isIsActiveFilled = ( isActive.length !== 0 );
    const isOwnershipTypeFilled = ( ownershipType.length !== 0 );

    return (
        isAccountTypeFilled &&
        isBankAccountNameFilled &&
        isBankAccountNumberFilled &&
        isBankCodeFilled &&
        isBankIfscRtgsCodeFilled &&
        isBicSwiftCodeFilled &&
        isBranchNameFilled &&
        isCityFilled &&
        isCompanyCodeFilled &&
        isCompanyNameFilled &&
        isCorporateBankNameFilled &&
        isCorporateIdFilled &&
        isCurrencyFilled &&
        isDormantFilled &&
        isDormantDateFilled &&
        isFundCodeFilled &&
        isFundNameFilled &&
        isIsActiveFilled &&
        isOwnershipTypeFilled
    );
}

export default isFormComplete;
