import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Checkbox,
    FormControlLabel,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import { Field, YES_NO_RADIO_OPTIONS } from "./interfaces/field.types";
import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helpers/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helpers/initializeUpdateState";
import { useEffect, useState } from "react";

import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { BankMasterDetails } from "../../../../../redux/AifMaster/BankMaster/Checker/initialState";
import {
    UpdateState as CheckerUpdateState
} from "../../../../../redux/AifMaster/BankMaster/Update/initialState";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import RemarksPopup from "../../../../../components/FXRemarksPopup";
import { RootState } from "../../../../../redux/store";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Checker/dispatchActionsProvider";
import bankMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Nigo/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { getNigoData } from "../../Nigo/NigoBankMasterForm/helpers/getNigoData";
import isFormComplete from "./helpers/isFormComplete";
import isFormValid from "./helpers/isFormValid";
import onBlurAccountNumberValidator from "../../../../../validators/onBlurValidator/onBlurAccountNumberValidator";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import useBankFormRef from "./hooks/useBankFormRef";
import useFetchBankDetails from "../../../../../hooks/api/useFetchBankDetails";
import { useNavigate } from "react-router";
import usePostBankMaster from "../../../../../hooks/api/usePostBankMaster";
import usePostRejectDetails from "../../../../../hooks/api/usePostRejectDetails";
import { useSelector } from "react-redux";

const CheckerBankMasterForm = () => {
    const formRef = useBankFormRef();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState); 
    const [checkerUpdateState, setCheckerUpdateState] = useState<UpdateState>(initializeUpdateState());
    const [isBankDetailsFetched, setIsBankDetailsFetched] = useState(false);
    const [isDataMatched, setIsDataMatched] = useState(false);
    const [openRemarksPopup, setOpenRemarksPopup] = useState(false);
    const [openSubmitPopup, setOpenSubmitPopup] = useState(false);
    const [rejectRemarkText, setRejectRemarkText] = useState("Please - Check All Details");
    const bankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .checkerForm
    );

    const nigoBankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .nigoForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
    );

    const updateState = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .bankMasterState
                .updateState
    );

    const pageContextIfscNumber = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .bankMasterState
                .pageContext
                .bankIfscRtgsCode
    );

    const userId = useSelector(
        (state: RootState) => 
            state
                .authenticationState
                .userId    
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { currencyMenuItems, ownershipTypeMenuItems } = selectInputMenuItems;

    const { firstName, lastName } = userContextState;

    const {
        accountType,
        bankAccountName,
        bankAccountNumber,
        bankCode,
        bankIfscRtgsCode,
        bicSwiftCode,
        branchName,
        city,
        companyCode,
        companyName,
        corporateBankName,
        corporateId,
        currency,
        fundCode,
        fundName,
        dormant,
        dormantDate,
        defaultAccount,
        isActive,
        ownershipType,
    } = bankMasterFormState;

    const {
        clearBankAccountDetails,
        clearCriticalFieldsCheckerEntry,
        clearState,
        setAccountType,
        setBankAccountName,
        setBankAccountNumber,
        setBankCode,
        setBankDetails,
        setBankIfscRtgsCode,
        setBicSwiftCode,
        setBranchName,
        setCity,
        setCompanyCode,
        setCompanyName,
        setCorporateBankName,
        setCorporateId,
        setCurrency,
        setDormant,
        setDormantDate,
        setDefaultAccount,
        setFundCode,
        setFundName,
        setIsActive,
        setOwnershipType,
        setRemarks,
    } = bankMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerData,
        setMakerData,
        setNigoMetaData,
    } = bankMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised
    } = bankMasterPageContextFormDispatchActionsProvider();

    const postBankMaster = usePostBankMaster();
    const fetchBankDetails = useFetchBankDetails();
    const postRejectBankMaster = usePostRejectDetails();
    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
    };

    const handleClearCriticalFields = (updateState: CheckerUpdateState) => {        
        if (updateState.updateFlag === "0" || (updateState.bankAccountName && updateState.updateFlag === "1")) {
            if (formRef.bankAccountName.current)
                formRef.bankAccountName.current.value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.bankAccountNumber && updateState.updateFlag === "1")) {
            if (formRef.bankAccountNumber.current)
                formRef.bankAccountNumber.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.bankCode && updateState.updateFlag === "1")) {
            if (formRef.bankCode.current)
                formRef.bankCode.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.bankIfscRtgsCode && updateState.updateFlag === "1")) {
            if (formRef.bankIfscRtgsCode.current)
                formRef.bankIfscRtgsCode.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.bicSwiftCode && updateState.updateFlag === "1")) {
            if (formRef.bicSwiftCode.current)
                formRef.bicSwiftCode.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.branchName && updateState.updateFlag === "1")) {
            if (formRef.branchName.current)
                formRef.branchName.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.city && updateState.updateFlag === "1")) {
            if (formRef.city.current)
                formRef.city.current.value = "";
        }

        if ((updateState.updateFlag === "0" && !isBankDetailsFetched) || (updateState.corporateId && updateState.updateFlag === "1")) {
            if (formRef.corporateId.current)
                formRef.corporateId.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.dormant && updateState.updateFlag === "1")) {
            if (formRef.dormant.current)
                formRef.dormant.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.dormantDate && updateState.updateFlag === "1")) {
            if (formRef.dormantDate.current)
                formRef.dormantDate.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.isActive && updateState.updateFlag === "1")) {
            if (formRef.isActive.current)
                formRef.isActive.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.remarks && updateState.updateFlag === "1")) {
            if (formRef.remarks.current)
                formRef.remarks.current.value = "";
        }

        isBankDetailsFetched ? clearBankAccountDetails(updateState) : clearCriticalFieldsCheckerEntry(updateState);
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const navigate = useNavigate();

    const { setCheckerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    useEffect(()=>{
        if (JSON.stringify(nigoBankMasterFormState.makerData) === JSON.stringify(bankMasterFormState)){
            setIsDataMatched(true);
        }
    },[bankMasterFormState]);

    const handleFormSubmit = () => {
        postBankMaster(bankMasterFormState, `${firstName} ${lastName}`, "0", userId, "C", checkerUpdateState)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Company Code ${companyCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Company Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error ) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    const handleRejectSubmit = () => {
        setOpenRemarksPopup(false);
        //setAlertSnackbarContext(initialAlertSnackbarContext());
        postRejectBankMaster(nigoBankMasterFormState.makerData.bankAccountNumber, nigoBankMasterFormState.makerData.corporateBankName, "", companyCode, fundCode, "bank_master", "", "C", rejectRemarkText, userId, `${firstName} ${lastName}`)
            .then(() => setAlertSnackbarContext({
                "description": `Checker Entry Rejected against Company Code ${companyCode}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Rejected Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Reject Failure against
                                    Company Code ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error ) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Reject Failed",
                });
            });
    };
    
    useEffect(() => {
        setAccountType("Current");
        
        (formRef["bankCode"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bankCode;
        (formRef["bankIfscRtgsCode"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bankIfscRtgsCode;
        (formRef["bicSwiftCode"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bicSwiftCode;
        (formRef["city"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).city;
        (formRef["corporateId"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).corporateId;
        (formRef["branchName"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).branchName;
        (formRef["bankAccountName"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bankAccountName;
        (formRef["bankAccountNumber"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bankAccountNumber;
        (formRef["remarks"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).remarks;
    }, [bankCode]);
    
    useEffect(() => {
        if (updateState.updateFlag === "1") {
            (formRef["bankCode"].current as HTMLInputElement).value = bankMasterFormState.bankCode;
            (formRef["bankIfscRtgsCode"].current as HTMLInputElement).value = bankMasterFormState.bankIfscRtgsCode;
            (formRef["bicSwiftCode"].current as HTMLInputElement).value = bankMasterFormState.bicSwiftCode;
            (formRef["city"].current as HTMLInputElement).value = bankMasterFormState.city;
            (formRef["corporateId"].current as HTMLInputElement).value = bankMasterFormState.corporateId;
            (formRef["corporateBankName"].current as HTMLInputElement).value = bankMasterFormState.corporateBankName;
            (formRef["branchName"].current as HTMLInputElement).value = bankMasterFormState.branchName;
            (formRef["bankAccountNumber"].current as HTMLInputElement).value = bankMasterFormState.bankAccountNumber;
        } else {
            fetchBankDetails(companyCode, pageContextIfscNumber)
                .then((result) => {
                    result[0].bankCode && setIsBankDetailsFetched(true);
                    let _bankDetails = result[0];
                        
                    setFormErrorState(initializeFormErrorState());
                    setBankCode(result[0].bankCode) ?? ""; 
                    setBranchName(result[0].branchName ?? "");
                    setCity(result[0].city ?? "");
                    setCorporateId(result[0].corporateId ?? "");
                    setBicSwiftCode(result[0].bicOrSwiftCode ?? "");
                    setCurrency(result[0].currency ?? "");
                    setBankIfscRtgsCode(result[0].ifscOrRtgsCode ?? "");
    
                    (formRef["bankCode"].current as HTMLInputElement).value = _bankDetails.bankCode;
                    (formRef["bankIfscRtgsCode"].current as HTMLInputElement).value = _bankDetails.ifscOrRtgsCode;
                    (formRef["bicSwiftCode"].current as HTMLInputElement).value = _bankDetails.bicOrSwiftCode;
                    (formRef["city"].current as HTMLInputElement).value = _bankDetails.city;
                    (formRef["corporateId"].current as HTMLInputElement).value = _bankDetails.corporateId;
                    (formRef["corporateBankName"].current as HTMLInputElement).value = _bankDetails.bankName;
                    (formRef["branchName"].current as HTMLInputElement).value = _bankDetails.branchName;
                });  
        };
    }, [updateState]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid sx={{
                        "alignItems": "center",
                        "display": "flex",
                        "marginBottom": "13px",
                    }}>
                        <IconButton 
                            sx={{"color": "#1C1E2C"}}
                            onClick={() => {
                                handleClearState();
                                setCheckerNavigation("");
                            }}
                        >
                            <ChevronLeftIcon/> 
                        </IconButton>
                        <Typography variant="formHeading" display="flex">
                            Update Bank Details
                        </Typography>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Company Code"
                        disabled
                        readOnly
                        required
                        defaultValue={companyCode}
                        inputRef={formRef.companyCode}
                        onBlur={() => handleInputFieldChange("companyCode", setCompanyCode)}
                        error={formErrorState.companyCode.isError}
                        helperText={formErrorState.companyCode.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Company Name"
                        disabled
                        readOnly
                        required
                        defaultValue={companyName}
                        inputRef={formRef.companyName}
                        onBlur={() => handleInputFieldChange("companyName", setCompanyName)}
                        error={formErrorState.companyName.isError}
                        helperText={formErrorState.companyName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="BankCode"
                        disabled={(updateState.updateFlag === "1" && !(updateState.bankCode)) ||
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        maxLength={8}
                        forbidTo="alphanumeric"
                        defaultValue={bankCode}
                        inputRef={formRef.bankCode}
                        onBlur={() => handleInputFieldChange("bankCode", setBankCode)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankCode")
                        }
                        error={formErrorState.bankCode.isError}
                        helperText={formErrorState.bankCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        autoCapitalize
                        label="Bank IFSC / RTGS Code"
                        disabled={(updateState.updateFlag === "1" && !(updateState.bankIfscRtgsCode)) ||
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        defaultValue={bankIfscRtgsCode}
                        inputRef={formRef.bankIfscRtgsCode}
                        maxLength={15}
                        forbidTo="alphanumeric"
                        onBlur={() => handleInputFieldChange("bankIfscRtgsCode", setBankIfscRtgsCode)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankIfscRtgsCode")
                        }
                        error={formErrorState.bankIfscRtgsCode.isError}
                        helperText={formErrorState.bankIfscRtgsCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Corporate / Bank Name"
                        required
                        disabled
                        readOnly
                        maxLength={50}
                        forbidTo="name"
                        defaultValue={corporateBankName}
                        inputRef={formRef.corporateBankName}
                        onBlur={() => handleInputFieldChange("corporateBankName", setCorporateBankName)}
                        error={formErrorState.corporateBankName.isError}
                        helperText={formErrorState.corporateBankName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Branch Name"
                        disabled={(updateState.updateFlag === "1" && !(updateState.branchName)) || 
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        maxLength={50}
                        forbidTo="namespaceanything"
                        defaultValue={branchName}
                        inputRef={formRef.branchName}
                        onBlur={() => handleInputFieldChange("branchName", setBranchName)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "branchName")
                        }
                        error={formErrorState.branchName.isError}
                        helperText={formErrorState.branchName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="City"
                        disabled={(updateState.updateFlag === "1" && !(updateState.city)) || 
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        forbidTo="name"
                        defaultValue={city}
                        maxLength={50}
                        inputRef={formRef.city}
                        onBlur={() => handleInputFieldChange("city", setCity)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "city")
                        }
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Corporate ID"
                        disabled={(updateState.updateFlag === "1" && !(updateState.corporateId)) || 
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        maxLength={20}
                        forbidTo="alphanumeric"
                        defaultValue={corporateId}
                        inputRef={formRef.corporateId}
                        onBlur={() => handleInputFieldChange("corporateId", setCorporateId)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "corporateId")
                        }
                        error={formErrorState.corporateId.isError}
                        helperText={formErrorState.corporateId.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="BIC / SWIFT Code"
                        disabled={(updateState.updateFlag === "1" && !(updateState.bicSwiftCode)) || 
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        forbidTo="alphanumeric"
                        maxLength={15}
                        defaultValue={bicSwiftCode}
                        inputRef={formRef.bicSwiftCode}
                        onBlur={() => handleInputFieldChange("bicSwiftCode", setBicSwiftCode)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bicSwiftCode")
                        }
                        error={formErrorState.bicSwiftCode.isError}
                        helperText={formErrorState.bicSwiftCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Currency"
                        disabled={(updateState.updateFlag === "1" && !(updateState.currency)) || 
                            (updateState.updateFlag === "0" && isBankDetailsFetched)
                        }
                        required
                        value={currency}
                        onValueChange={setCurrency}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "currency")
                        }
                        menuItems={currencyMenuItems}
                        error={formErrorState.currency.isError}
                        helperText={formErrorState.currency.helperText}
                    />
                </Grid>

                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Typography variant="formSubHeading" display="flex">
                        Add Account Details
                        </Typography>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Fund Code"
                        disabled
                        readOnly
                        defaultValue={fundCode}
                        required
                        inputRef={formRef.fundCode}             
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Fund Name"
                        required
                        disabled
                        readOnly
                        inputRef={formRef.fundName}
                        defaultValue={fundName}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Bank Account Number"
                        required
                        forbidTo="numbers"
                        disabled={updateState.updateFlag === "1" && !(updateState.bankAccountNumber)}
                        maxLength={20}
                        inputRef={formRef.bankAccountNumber}
                        onBlurValidator={onBlurAccountNumberValidator}
                        validatorOptions={{}}
                        onBlur={() => handleInputFieldChange("bankAccountNumber", setBankAccountNumber)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankAccountNumber")
                        }
                        error={formErrorState.bankAccountNumber.isError}
                        helperText={formErrorState.bankAccountNumber.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Bank Account Name"
                        disabled={updateState.updateFlag === "1" && !(updateState.bankAccountName)}
                        required
                        maxLength={50}
                        forbidTo="alphanumeric-ws"
                        defaultValue={bankAccountName}
                        inputRef={formRef.bankAccountName}
                        onBlur={() => handleInputFieldChange("bankAccountName", setBankAccountName)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankAccountName")
                        }
                        error={formErrorState.bankAccountName.isError}
                        helperText={formErrorState.bankAccountName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Account Type"
                        disabled={updateState.updateFlag === "1" && !(updateState.accountType)}
                        required
                        readOnly
                        value={accountType}
                        inputRef={formRef.accountType}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "accountType")
                        }
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Ownership Type"
                        disabled={updateState.updateFlag === "1" && !(updateState.ownershipType)}
                        required
                        value={ownershipType}
                        onValueChange={setOwnershipType}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "ownershipType")
                        }
                        menuItems={ownershipTypeMenuItems}
                        error={formErrorState.ownershipType.isError}
                        helperText={formErrorState.ownershipType.helperText}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXRadioGroup 
                        disabled={updateState.updateFlag === "1" && !(updateState.isActive)}
                        row
                        required
                        label="Is Active"
                        radioButtonValues={YES_NO_RADIO_OPTIONS} 
                        value={isActive}
                        onValueChange={setIsActive}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXRadioGroup 
                        disabled={updateState.updateFlag === "1" && !(updateState.dormant)}
                        row
                        required
                        label="Dormant"
                        radioButtonValues={YES_NO_RADIO_OPTIONS} 
                        value={dormant}
                        onValueChange={(value) => {
                            setDormant(value); 
                            if (value === "No") {
                                setDormantDate(null);
                                handleFieldErrorChange(initializeFieldValidation(), "dormantDate");
                            };
                        }}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXDateInput
                        disabled={updateState.updateFlag === "1" && !(updateState.dormantDate)}
                        required={dormant === "Yes"}
                        label="Dormant Date"
                        value={dormantDate}
                        onValueChange={setDormantDate}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false 
                        }}   
                        onFieldValidationChange={(fieldError) => {
                            handleFieldErrorChange(
                                dormant === "Yes" ? 
                                    fieldError : 
                                    initializeFieldValidation(), 
                                "dormantDate"
                            );
                        }}
                        error={formErrorState.dormantDate.isError}
                        helperText={formErrorState.dormantDate.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        disabled={updateState.updateFlag === "1" && !(updateState.remarks)}
                        label="Remarks"
                        maxLength={256}
                        forbidTo="alphanumeric-ws"
                        inputRef={formRef.remarks}
                        onBlur={() => handleInputFieldChange("remarks", setRemarks)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "remarks")
                        }
                        error={formErrorState.remarks.isError}
                        helperText={formErrorState.remarks.helperText}
                    />
                </Grid>

                <Grid item xs={12}>
                    <FormControlLabel 
                        disabled={updateState.updateFlag === "1" && !(updateState.defaultAccount)}
                        sx={{
                            "& .MuiSvgIcon-root": {
                                "height": "18px",
                                "width": "18px",
                            }
                        }}
                        control={<Checkbox />} 
                        label={
                            <Typography variant="loginDescription">
                                Make as Default Account
                            </Typography>
                        }
                        checked={defaultAccount === "Yes"}
                        onChange={
                            (ele) => {
                                const target = ele.target as HTMLInputElement;
                                setDefaultAccount(target.checked ? "Yes" : "No");
                            }
                        }
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXButton 
                        disableRipple
                        label="Reject" 
                        buttonVariant="submit" 
                        fullWidth
                        disabled={alertSnackbarContext.open}
                        onClick={() => setOpenRemarksPopup(true)}
                    />
                </Grid>
                <Grid item xs={4}>
                    <FXButton 
                        disableRipple
                        label="Clear" 
                        buttonVariant="normal" 
                        fullWidth
                        onClick={() => handleClearCriticalFields(updateState)}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXButton 
                        disableRipple
                        disabled={ 
                            alertSnackbarContext.open ||
                            !(isFormComplete(bankMasterFormState)) ||
                            !(isFormValid(formErrorState))
                        }
                        label="Submit" 
                        buttonVariant="submit" 
                        fullWidth
                        endIcon={<ArrowForwardIosIcon/>}
                        onClick={() => {
                            const nigoData = getNigoData(nigoBankMasterFormState.makerData, bankMasterFormState);
    
                            if (nigoData.length !== 0) {
                                setNigoMetaData(nigoData);
                                setCheckerData(bankMasterFormState);
                                setNigoRaised(true);
                            }
                            else {
                                handleFormSubmit();
                            }
                        }}   
                    />
                </Grid>
            </Grid>

            <RemarksPopup 
                open={openRemarksPopup}
                isDisabled={rejectRemarkText.length===0 || !rejectRemarkText}
                onCancelClick={() => {
                    setOpenRemarksPopup(false);
                    setRejectRemarkText("");
                }}
                onSubmitClick={() => handleRejectSubmit()}
                rejectRemarkText={rejectRemarkText}
                setRejectRemarkText={setRejectRemarkText}    
            />

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        handleClearState();
                        setCheckerNavigation("");
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default CheckerBankMasterForm;
