import { RadioButtonValue } from "../../../../../../components/FXRadioGroup/FXInputProps.types";

export type Field = 
    "accountType" |
    "bankAccountName" |
    "bankAccountNumber" |
    "bankCode" |
    "bankIfscRtgsCode" |
    "bicSwiftCode" |
    "branchName" |
    "city" |
    "companyCode" |
    "companyName" |
    "corporateBankName" |
    "corporateId" |
    "currency" |
    "defaultAccount" |
    "dormant" |
    "dormantDate" |
    "fundCode" |
    "fundName" |
    "isActive" |
    "ownershipType" |
    "remarks"

export const YES_NO_RADIO_OPTIONS: RadioButtonValue[] = [
    {
        "label": "Yes",
        "value": "Yes",
    },
    {
        "label": "No",
        "value": "No",
    }
];
