import {Field} from "../../interfaces/field.types";

export type UpdateState = {
    [field in Field]: boolean;
};

function initializeUpdateState(): UpdateState {
    return {
        "accountType": false,
        "bankAccountName": false,
        "bankAccountNumber": false,
        "bankCode": false,
        "bankIfscRtgsCode": false,
        "bicSwiftCode": false,
        "branchName": false,
        "city": false,
        "companyCode": false,
        "companyName": false,
        "corporateBankName": false,
        "corporateId": false,
        "currency": false,
        "defaultAccount": false,
        "dormant": false,
        "dormantDate": false,
        "fundCode": false,
        "fundName": false,
        "isActive": false,
        "ownershipType": false,
        "remarks": false,
    };
};

export default initializeUpdateState;
