import {
    Box,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import { useEffect, useRef } from "react";

import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import EditIcon from "@mui/icons-material/Edit";
import FXButton from "../../../../../components/FXButton";
import StatusChip from "../../components/statusChip";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import { useNavigate } from "react-router";

const CheckerBankMasterBankAccountList = () => {
    const gridRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        const parentElement = gridRef.current?.parentElement;
        if (parentElement) {
            parentElement.style.cssText = "background: #F6F9FD; padding: 0px; padding-bottom: 30px;";
        }
    }, []);

    const { setCheckerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    return (
        <Grid ref={gridRef}>
            <Grid sx={{
                "alignItems": "center",
                "display": "flex",
                "marginBottom": "13px",
            }}>
                <IconButton 
                    sx={{"color": "#1C1E2C"}}
                    onClick={() => setCheckerNavigation("")}
                >
                    <ChevronLeftIcon/> 
                </IconButton>
                <Typography variant="formHeading" display="flex">
                    Bank Accounts
                </Typography>
            </Grid>

            <Grid>
                <Box
                    sx={{
                        "background": "#FFFFFF",
                        "borderRadius": "10px",
                        "boxShadow": "0px 4px 24px rgba(0, 0, 0, 0.05)",
                        "marginBottom": "10px",
                        "padding": "20px",
                    }}
                >
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                        mb={1}
                    >
                        <Typography variant="nigoTableHeading">
                            Bank Details
                            <StatusChip status="new" />
                        </Typography>

                        <FXButton 
                            disableRipple
                            label="Update" 
                            sx={{
                                "&:hover, &:focus": {
                                    "background": "#95b8e9",
                                },
                                "background": "#A8CCFF",
                                "borderRadius": "5px",
                                "color": "#201C43",
                                "fontFamily": fontFamily,
                                "fontSize": "12px",
                                "fontWeight": 500,
                                "padding": "10px 20px",
                            }}
                            startIcon={<EditIcon/>}
                            onClick={() => setCheckerNavigation("form")}
                        />
                    </Grid>

                    <Grid
                        alignItems="flex-start"
                        display="flex"
                        justifyContent="space-between"
                        columnGap={1}
                        mb={3.75}
                    >
                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Client Code
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --  
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Client Name
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Bank Name
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Bank Code
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                    --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                IFSC/RTGS
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                BIC / SWIFT Code 
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Currency
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Corporate ID
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Branch Name
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                City
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>
                    </Grid>
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                        mb={1}
                    >
                        <Typography variant="nigoTableHeading">Fund Code : F153</Typography>

                        <Typography 
                            variant="pageDescription"
                            sx={{
                                "background": "#c9e7ca",
                                "borderRadius": "15px",
                                "color": "#4BAE4F",
                                "padding": "9px 15px",
                            }}
                        >
                            Default Account
                        </Typography>
                    </Grid>

                    <Typography 
                        variant="buttonContent" 
                        display="block"
                        mb={4} 
                    >
                        Fund Name : Motilal Oswal Alternative Investment Trust
                    </Typography>

                    <Grid
                        alignItems="flex-start"
                        display="flex"
                        justifyContent="space-between"
                        columnGap={1}
                        mb={3.75}
                    >
                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Bank Account Name
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --  
                            </Typography>
                        </Box>
                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Bank Account Number
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --  
                            </Typography>
                        </Box>
                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Account Type
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --  
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Ownership Type
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Is Active 
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Dormant 
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Dormant Date 
                            </Typography>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>

                        <Box>
                            <Typography
                                component="p" 
                                variant="buttonContent"
                                sx={{"color": "#666666"}}
                            >
                                Remarks
                            </Typography>
                                
                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                            >
                                --
                            </Typography>
                        </Box>
                    </Grid>
                </Box>
            </Grid>
        </Grid>
    );
};

export default CheckerBankMasterBankAccountList;
