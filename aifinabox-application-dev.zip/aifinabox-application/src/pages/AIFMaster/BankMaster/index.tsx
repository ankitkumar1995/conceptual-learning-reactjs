import CheckerBankMasterPage from "./Checker";
import MakerBankMasterPage from "./Maker";
import NigoBankMasterForm from "./Nigo/NigoBankMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const BankMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerBankMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerBankMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoBankMasterForm/>
            }
        </>
    );
};

export default BankMasterPage;
