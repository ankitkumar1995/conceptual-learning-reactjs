import {
    Box,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import {
    useEffect,
    useRef,
    useState
} from "react";

import AddIcon from "@mui/icons-material/Add";
import BanksList from "../../components/banksList";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import EditIcon from "@mui/icons-material/Edit";
import FXButton from "../../../../../components/FXButton";
import { RootState } from "../../../../../redux/store";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import useBankFormRef from "../MakerBankMasterForm/hooks/useBankFormRef";
import useFetchBankAccounts from "../../../../../hooks/api/useFetchBankAccounts";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const MakerBankMasterList = () => {
    const formRef = useBankFormRef();
    const gridRef = useRef<HTMLDivElement | null>(null);
    const [bankAccounts, setBankAccounts] = useState<any[]>([]);
    const [selectedBank, setSelectedBank] = useState("");    
    const navigate = useNavigate();
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .makerForm
                .companyCode
    );

    const bankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .makerForm
    );

    const { 
        companyCode, 
        companyName 
    } = bankMasterFormState;

    const { 
        clearState,
    } = bankMasterDetailsFormDispatchActionsProvider();

    const handleBankNameChange = (value:string) => {
        setSelectedBank(value);
    };

    const { 
        setFlowType, 
        setMakerNavigation,
    } = bankMasterPageContextFormDispatchActionsProvider();

    useEffect(() => {
        const parentElement = gridRef.current?.parentElement;
        if (parentElement) {
            parentElement.style.cssText = "background: #F6F9FD; padding: 0px; padding-bottom: 30px;";
        }
    }, []);
    
    const fetchBankAccounts = useFetchBankAccounts();

    useEffect(() => {
        selectedBank !== "" && 
        fetchBankAccounts(clientCode, selectedBank)
            .then((result) => {
                setBankAccounts(result);
            });
    }, [selectedBank]);
    
    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState(bankMasterFormState);
        (formRef["companyCode"].current as HTMLInputElement).value = companyCode;
        (formRef["companyName"].current as HTMLInputElement).value = companyName;
    }; 

    return (
        <Grid container ref={gridRef} flexWrap="nowrap">
            <BanksList onBankChange={handleBankNameChange} />

            <Grid 
                sx={{
                    "flexGrow": "1",
                    "marginLeft": "20px",
                }}
            >
                <Grid 
                    alignItems="center"
                    display="flex"
                    justifyContent="space-between"
                    mb={2.5}
                >
                    <Grid sx={{
                        "alignItems": "center",
                        "display": "flex",
                    }}>
                        <IconButton
                            sx={{"color": "#1C1E2C"}}
                            onClick={() => setMakerNavigation("")}
                        >
                            <ChevronLeftIcon/> 
                        </IconButton>

                        <Typography variant="formHeading" display="flex">
                            Bank Accounts
                        </Typography>
                    </Grid>

                    <Box>
                        <FXButton 
                            disableRipple
                            label="Add New Account" 
                            sx={{
                                "&:hover, &:focus": {
                                    "background": "#95b8e9",
                                },
                                "background": "#A8CCFF",
                                "borderRadius": "5px",
                                "color": "#201C43",
                                "fontFamily": fontFamily,
                                "fontSize": "12px",
                                "fontWeight": 500,
                                "padding": "10px 20px",
                            }}
                            startIcon={<AddIcon/>}
                            onClick={() => {
                                setMakerNavigation("form");
                                setFlowType("EN");
                                // handleClearState();
                            }}
                        />

                        <FXButton 
                            disableRipple
                            label="Update Existing" 
                            sx={{
                                "&:hover, &:focus": {
                                    "background": "#95b8e9",
                                },
                                "background": "#A8CCFF",
                                "borderRadius": "5px",
                                "color": "#201C43",
                                "fontFamily": fontFamily,
                                "fontSize": "12px",
                                "fontWeight": 500,
                                "marginInline": "10px",
                                "padding": "10px 20px",
                            }}
                            startIcon={<EditIcon/>}
                            onClick={() => {
                                setMakerNavigation("form");
                                setFlowType("EE");
                            }}
                        />
                    </Box>
                </Grid>

                {/* <Box textAlign="right" mb={1.5}>
                    <FXButton 
                        disableRipple
                        label="Rejected By Checker" 
                        sx={{
                            "&:hover, &:focus": {
                                "background": "transparent",
                            },
                            "background": "transparent",
                            "color": "#2057A6",
                            "fontFamily": fontFamily,
                            "fontSize": "14px",
                            "fontWeight": 500,
                            "padding": "0",
                        }}
                        onClick={() => setMakerNavigation("rejected")}
                    />
                </Box> */}
                <Grid display="flex" justifyContent="flex-end"  marginBottom="10px"   >

                    <FXButton
                        label="Rejected By Checker"
                        onClick={() => setMakerNavigation("rejected")} 
                    />
                
                </Grid>
                

                <Grid>
                    {bankAccounts.map((account) =>
                        <Box
                            sx={{
                                "background": "#FFFFFF",
                                "borderRadius": "10px",
                                "boxShadow": "0px 4px 24px rgba(0, 0, 0, 0.05)",
                                "marginBottom": "10px",
                                "padding": "20px",
                            }}
                        >
                            <Grid
                                alignItems="center"
                                display="flex"
                                justifyContent="space-between"
                            >
                                <Typography variant="nigoTableHeading">{account.fundCode}</Typography>

                                {account.defaultAccount.value === "Yes" &&
                                    <Typography 
                                        variant="pageDescription"
                                        sx={{
                                            "background": "#c9e7ca",
                                            "borderRadius": "15px",
                                            "color": "#4BAE4F",
                                            "padding": "9px 15px",
                                        }}
                                    >
                                        Default Account
                                    </Typography>
                                }
                            </Grid>

                            <Typography
                                component="p" 
                                variant="nigoTableColumn"
                                mb={1}
                                sx={{
                                    "color": "#666666", 
                                    "fontWeight": 500
                                }}
                            >
                                {account.fundName}
                            </Typography>

                            <Typography 
                                variant="buttonContent" 
                                display="block"
                                mb={4} 
                            >
                                {account.fundName.value}
                            </Typography>

                            <Grid
                                alignItems="flex-start"
                                display="flex"
                                justifyContent="space-between"
                                columnGap={1}
                                mb={3.75}
                            >
                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Account Type
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.accountType.value || "--"}
                                    </Typography>
                                </Box>

                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Ownership Type
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.ownershipType.value || "--"}
                                    </Typography>
                                </Box>

                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Is Active 
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.isActive.value || "--"}
                                    </Typography>
                                </Box>

                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Dormant 
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.dormant.value || "--"}
                                    </Typography>
                                </Box>

                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Dormant Date 
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.dormantDate.value || "--"}
                                    </Typography>
                                </Box>

                                <Box>
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Bank Account Number 
                                    </Typography>
                                    
                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.bankAccountNumber.value || "--"}
                                    </Typography>
                                </Box>
                            </Grid>

                            <Grid
                                alignItems="flex-start"
                                display="flex"
                                justifyContent="space-between"
                                columnGap={2}
                                mb={3.35}
                            >
                                <Box flex="0 0 auto">
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Bank Account Name
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.bankAccountName.value || "--"}
                                    </Typography>
                                </Box>

                                <Box flex="1 1 auto">
                                    <Typography
                                        component="p" 
                                        variant="buttonContent"
                                        sx={{"color": "#666666"}}
                                    >
                                        Remarks
                                    </Typography>

                                    <Typography
                                        component="p" 
                                        variant="nigoTableColumn"
                                    >
                                        {account.remarks.value || "--"}
                                    </Typography>
                                </Box>
                            </Grid>
                        </Box>
                    )}
                </Grid>
            </Grid>
        </Grid>
    );
};

export default MakerBankMasterList;
