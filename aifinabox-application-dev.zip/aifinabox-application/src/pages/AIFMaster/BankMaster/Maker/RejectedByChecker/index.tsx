import { 
    Box, 
    IconButton, 
    Typography 
} from "@mui/material";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import RejectedEntryItems from "./RejectedEntryItems";
import { useNavigate } from "react-router-dom";

const RejectedBankMasterPage = () => {
    const navigate = useNavigate();

    return (
        <>
            <Box 
                alignItems="center"
                display="flex"
                mb={3}
            >
                <IconButton   
                    onClick={() => navigate(-1)}
                >
                    <BackArrowIcon/>
                </IconButton>
                
                <Typography variant="formHeading">
                    Rejected by Checker
                </Typography>
            </Box>
            <RejectedEntryItems/>
        </>
    );
};

export default RejectedBankMasterPage;
