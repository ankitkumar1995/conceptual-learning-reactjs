import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";

import { useEffect, useState } from "react";

import useFetchRejectQueue, {
    PendingRejectedItem 
} from "../../../../../../hooks/api/useFetchRejectQueue";

import useFetchTodoQueue, {
    PendingCheckerItem 
} from "../../../../../../hooks/api/useFetchToDoQueue";
import {
    BankMasterDetails
} from "../../../../../../redux/AifMaster/BankMaster/Checker/initialState";
import PendingCheckerEntryItemCard from "../../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../../redux/store";
import {
    StyledPagination
} from "../../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";

import bankMasterDetailsFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterNigoDetailsFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Nigo/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { nanoid } from "@reduxjs/toolkit";
import { setBankDetails } from "../../../../../../redux/AifMaster/BankMaster/Checker/reducer";
import updateStateDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Update/dispatchActionsProvider";
import useFetchRejectBankMaster from "../../../../../../hooks/api/useFetchRejectBankMaster";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const itemCountPerPage = 5;

const RejectedEntryItems = () => {
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [bankData, setBankData] = useState({
        "accountType": "",
        "bankAccountName": "",
        "bankAccountNumber": "",
        "bankCode": "",
        "bankIfscRtgsCode": "",
        "bicSwiftCode": "",
        "branchName": "",
        "city": "",
        "companyCode": "",
        "companyName": "",
        "corporateBankName": "",
        "corporateId": "",
        "currency": "",
        "defaultAccount": "",
        "dormant": "Yes",
        "dormantDate": null,
        "fundCode": "",
        "fundName": "",
        "isActive": "Yes",
        "ownershipType": "",
        "proof": "",
        "proofFile": null,
        "proofFileFormat": "",
        "proofFileS3Key": "",
        "proofFileS3SignedURL": "",
        "proofFileSize": "",
        "remarks": "",
    });
    const navigate = useNavigate();


    const { setMakerData } = bankMasterNigoDetailsFormDispatchActionsProvider();
    
    const { setUpdateState } = updateStateDispatchActionsProvider();

    const { 
        setAccountType,
        setBankAccountName,
        setBankAccountNumber,
        setBankCode,
        setBankIfscRtgsCode,
        setBankMasterMakerState,
        setBicSwiftCode,
        setBranchName,
        setCity,
        setCompanyCode,
        setCompanyName,
        setCorporateBankName,
        setCorporateId,
        setCurrency,
        setDefaultAccount,
        setDormant,
        setDormantDate,
        setFundCode,
        setFundName,
        setIsActive,
        setOwnershipType,
        setProofFile,
        setProofFileFormat,
        setProofFileS3Key,
        setProofFileS3SignedURL,
        setProofFileSize,
        setRemarks,
    } = bankMasterDetailsFormDispatchActionsProvider();


    // const { setMakerData } = classMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setMakerNavigation, setFlowType
    } = bankMasterPageContextFormDispatchActionsProvider();

    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchBanksMasterRejected = useFetchRejectBankMaster();
    const fetchRejectedQueue = useFetchRejectQueue();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const userId = useSelector(
        (state: RootState) => 
            state
                .authenticationState
                .userId    
    );

    const handleCardOnClick = (
        bankAccountNumber: string,
        bankName: string,
        classCode: string,
        clientCode: string,
        clientName: string,
        fundCode: string,
        fundName:string
    ) => {
        fetchBanksMasterRejected(
            bankAccountNumber,
            bankName, 
            clientCode,
            fundCode,
            "bank_master", 
            "",
            "M"
        )
            .then((bankMasterMakerState) => {
                // console.log("res",bankMasterMakerState);     
                // const {clientCode, clientName} = bankMasterMakerState;
                const { 
                    bankMasterFormState, 
                    bankMasterUpdateState 
                } = bankMasterMakerState;
                console.log("bankMasterFormState",bankMasterMakerState.bankMasterFormState.accountType);
                setMakerData(bankMasterFormState as BankMasterDetails);
                setUpdateState(bankMasterUpdateState);
                bankMasterUpdateState.updateFlag === "1" && setBankDetails(bankMasterFormState as BankMasterDetails);
                // setBankData(bankMasterFormState);
             
            });
        setCurrency(bankData.currency);
        setAccountType(bankData.accountType);
        setBankAccountName(bankData.bankAccountName);
        setCompanyCode(clientCode);
        setCompanyName(clientName);
        setFundCode(fundCode),
        setFundName(fundName),
        setCorporateBankName(bankName),
        setBankAccountNumber(bankAccountNumber),
        setMakerNavigation("form"); 
        setFlowType("EE");
        // navigate("/master-setup/bank-master/maker");
    };

    useEffect(() => {
        fetchRejectedQueue(itemCountPerPage,"",page-1, "bank_master", "C", "M", userId)
            .then((result) => {
                const {
                    rejectQueue,
                    pendingRejectItemCount,
                } = result;

                console.log("respon", result);
                setPendingRejectEntryItems(rejectQueue);
                setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
            });
    }, [page, pageCount, itemCountPerPage]);

    return (  
        <>
            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingRejectEntryItems.map((pendingRejectEntryItem) => {
                        const {
                            bankAccountNumber,
                            bankName,
                            clientCode,
                            clientName,
                            fundCode,
                            fundName,
                            planCode,
                            planName,
                            classCode,
                            className,
                            createdBy,
                            createdOn,
                            // id,
                            rejectRemarks,
                        } = pendingRejectEntryItem;

                        console.log("pendingRejectEntryItem", pendingRejectEntryItem);

                        return (
                            <Box key={nanoid()}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName
                                        },
                                        {
                                            "dataPartOne": bankName,
                                            "dataPartTwo": bankAccountNumber
                                        },
                                    ]}
                                    onClick={() => handleCardOnClick( bankAccountNumber, bankName, classCode, clientCode, clientName, fundCode, fundName)} 
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between"> 
                {/* <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={2}>
                        <Select
                            value={rowsPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setRowsPerPage(parseInt(event.target.value));
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={3}>3</MenuItem>
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={7}>7</MenuItem>
                        </Select>
                        
                        <Typography>Rows per page</Typography>
                    </Stack>
                </FormControl> */}

                <Box></Box>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default RejectedEntryItems;
