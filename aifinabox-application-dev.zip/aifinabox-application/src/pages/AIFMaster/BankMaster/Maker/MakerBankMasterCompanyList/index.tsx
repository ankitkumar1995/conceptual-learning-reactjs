import {
    ChangeEvent,
    useEffect,
    useState
} from "react";
import {
    FormControl,
    Grid,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography
} from "@mui/material";
import useFetchClientDetails, {
    ClientDetails
} from "../../../../../hooks/api/useFetchClientDetails";

import CompanyCard from "../../../components/CompanyCard";
import SearchInputField from "../../components/searchInputField";
import {
    StyledPagination
} from "../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";

const MakerBankMasterCompanyList = () => {
    const [filteredCompanyList, setFilteredCompanyList] = useState<ClientDetails[]>([]);
    const { setMakerNavigation } = bankMasterPageContextFormDispatchActionsProvider();
    const [clientDetails, setClientDetails] = useState<ClientDetails[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(2);
    
    const { 
        setCompanyCode, 
        setCompanyName 
    } = bankMasterDetailsFormDispatchActionsProvider();


    const handleBankSearch = ( ele: ChangeEvent<Element> ) => {
        const searchValue = (ele.target as HTMLInputElement).value;

        const filterCompanyList = clientDetails.filter((client) => 
            client.clientName.toLowerCase().indexOf(searchValue.toLowerCase()) !== -1
        );
        
        setFilteredCompanyList(filterCompanyList);
        
    };
    
    const fetchClientDetails = useFetchClientDetails();

    useEffect(() => {
        fetchClientDetails("bank_master", "0")
            .then((result) => {
                setClientDetails(result);
                setFilteredCompanyList(result);
                setPageCount(Math.ceil(result.length / (Number(itemCountPerPage) * 4)));
            });
    }, []);

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const startIndex = (page - 1) * itemCountPerPage * 4;
    const endIndex = startIndex + itemCountPerPage * 4;

    const slicedCompanyList = filteredCompanyList.slice(startIndex, endIndex);

    return (
        <>
            <Grid container spacing={2}>
                <SearchInputField
                    handleBankSearch={handleBankSearch} 
                    placeholder="Search by Client Name"
                />
                <Grid container spacing={2}>
                    {slicedCompanyList.map((data, index) => 
                        <Grid item xs={3}>
                            <CompanyCard 
                                companyCode={data.clientCode}
                                companyName={data.clientName}
                                companyLogo=""
                                onClick={() => {
                                    setMakerNavigation("bankList");
                                    setCompanyCode(data.clientCode);
                                    setCompanyName(data.clientName);
                                }}
                            />
                        </Grid>
                    )}
                    {filteredCompanyList.length === 0 &&
                    <Grid
                        sx={{
                            "padding": "20px 50px",
                            "width": "100%",
                        }}>
                        <Typography variant="navigationSectionNormal">
                            No Results Found
                        </Typography>
                    </Grid>
                    }
                </Grid>
            </Grid>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                                setPageCount(Math.ceil(clientDetails.length / (Number(event.target.value) * 4)));
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            {[1,2,3,4,5].map((item) =>
                                <MenuItem value={item}>{item}</MenuItem>
                            )}
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>

                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default MakerBankMasterCompanyList;
