import MakerBankMasterCompanyList from "./MakerBankMasterCompanyList";
import MakerBankMasterForm from "./MakerBankMasterForm";
import MakerBankMasterList from "./MakerBankMasterList";
import MakerBankMasterRejected from "./MakerBankMasterRejected";
import RejectedEntryItems from "./RejectedByChecker/RejectedEntryItems";
import { RootState } from "../../../../redux/store";
import { useSelector } from "react-redux";

const MakerBankMasterPage = () => {
    const makerNavigation = useSelector (
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .pageContext
                .makerNavigation
    );
    
    let componentToRender;

    switch (makerNavigation) {
    case "":
        componentToRender = <MakerBankMasterCompanyList />;
        break;
    case "bankList":
        componentToRender = <MakerBankMasterList />;
        break;
    case "form":
        componentToRender = <MakerBankMasterForm />;
        break;
    case "rejected":
        componentToRender = <MakerBankMasterRejected />;
        break;
    default:
        componentToRender = <MakerBankMasterCompanyList />;
        break;
    }
  
    return <>{componentToRender}</>;
};

export default MakerBankMasterPage;

