import { 
    Box,
    FormControl,
    Grid, 
    IconButton, 
    MenuItem, 
    Select, 
    SelectChangeEvent, 
    Stack,
    Typography, 
} from "@mui/material";

import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem
} from "../../../../../hooks/api/useFetchRejectQueue";

import { BankMasterDetails } from "../../../../../redux/AifMaster/BankMaster/Maker/initialState";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import {
    StyledPagination
} from "../../../PlanMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { nanoid } from "@reduxjs/toolkit";
import { setBankDetails } from "../../../../../redux/AifMaster/BankMaster/Checker/reducer";
import useFetchRejectBankMaster from "../../../../../hooks/api/useFetchRejectBankMaster";
import useFetchTodoQueue from "../../../../../hooks/api/useFetchToDoQueue";
import { useSelector } from "react-redux";

const MakerBankMasterRejected = () => {
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const [bankData, setBankData] = useState({
        "accountType": "",
        "bankAccountName": "",
        "bankAccountNumber": "",
        "bankCode": "",
        "bankIfscRtgsCode": "",
        "bicSwiftCode": "",
        "branchName": "",
        "city": "",
        "companyCode": "",
        "companyName": "",
        "corporateBankName": "",
        "corporateId": "",
        "currency": "",
        "defaultAccount": "",
        "dormant": "Yes",
        "dormantDate": null,
        "fundCode": "",
        "fundName": "",
        "isActive": "Yes",
        "ownershipType": "",
        "proof": "",
        "proofFile": null,
        "proofFileFormat": "",
        "proofFileS3Key": "",
        "proofFileS3SignedURL": "",
        "proofFileSize": "",
        "remarks": "",
    });

    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .makerForm
                .companyCode
    );

    const { 
        setAccountType,
        setBankAccountName,
        setBankAccountNumber,
        setBankCode,
        setBankIfscRtgsCode,
        setBankMasterMakerState,
        setBicSwiftCode,
        setBranchName,
        setCity,
        setCompanyCode,
        setCompanyName,
        setCorporateBankName,
        setCorporateId,
        setCurrency,
        setDefaultAccount,
        setDormant,
        setDormantDate,
        setFundCode,
        setFundName,
        setIsActive,
        setOwnershipType,
        setProofFile,
        setProofFileFormat,
        setProofFileS3Key,
        setProofFileS3SignedURL,
        setProofFileSize,
        setRemarks,
    } = bankMasterDetailsFormDispatchActionsProvider();
    
    const {
        setMakerNavigation, setFlowType
    } = bankMasterPageContextFormDispatchActionsProvider();

    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchBanksMasterRejected = useFetchRejectBankMaster();
    const fetchRejectedQueue = useFetchRejectQueue();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const userId = useSelector(
        (state: RootState) => 
            state
                .authenticationState
                .userId    
    );

    const handleCardOnClick = (
        bankAccountNumber: string,
        bankName: string,
        clientCode: string,
        clientName: string,
        fundCode: string,
        fundName: string,
        ifscOrRtgsCode: string
    ) => {

        // setCurrency(bankData.currency);
        // setAccountType(bankData.accountType);
        // setCompanyCode(clientCode);
        setBankAccountName(bankName);
        setBankAccountNumber(bankAccountNumber);
        setCompanyName(clientName);
        setBankIfscRtgsCode(ifscOrRtgsCode);
        setFundCode(fundCode);
        setFundName(fundName);
        setMakerNavigation("form"); 
        setFlowType("RR");
        // navigate("/master-setup/bank-master/maker");
    };


    useEffect(() => {
        fetchRejectedQueue(itemCountPerPage,clientCode, page-1, "bank_master", "C", "M", userId)
            .then((result) => {
                const {
                    rejectQueue,
                    pendingRejectItemCount,
                } = result;
                setPendingRejectEntryItems(rejectQueue);
                setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
            });
    }, [page, pageCount, itemCountPerPage]);


    return (
        <>
            <Grid sx={{
                "alignItems": "center",
                "display": "flex",
                "marginBottom": "13px",
            }}>
                <IconButton
                    sx={{"color": "#1C1E2C"}}
                    onClick={() => setMakerNavigation("")}
                >
                    <ChevronLeftIcon/> 
                </IconButton>

                <Typography variant="formHeading" display="flex">
                    Rejected By Checker
                </Typography>
            </Grid>

            <Grid item xs={12}>
                {
                    pendingRejectEntryItems.map((pendingRejectEntryItem) => {
                        const {
                            bankAccountNumber,
                            bankName,
                            clientCode,
                            clientName,
                            fundCode,
                            fundName,
                            planCode,
                            planName,
                            classCode,
                            className,
                            createdBy,
                            createdOn,
                            // id,
                            ifscOrRtgsCode,
                            rejectRemarks,
                        } = pendingRejectEntryItem;

                        return (
                            <Box key={nanoid()}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName
                                        },
                                        {
                                            "dataPartOne": bankName,
                                            "dataPartTwo": bankAccountNumber
                                        },
                                    ]}
                                    remarksData={
                                        [
                                            {
                                                "dataPartOne": `Remarks: ${rejectRemarks}`
                                            },
                                        ]}
                                    onClick={() =>  handleCardOnClick( bankAccountNumber, bankName, clientCode, clientName, fundCode, fundName, ifscOrRtgsCode)}
                                />
                            </Box>
                        );
                    })
                }

            </Grid>

            {pendingRejectEntryItems.length>0 && <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>                    
                    </Stack>
                </FormControl>
  
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>}
        </>
    );
};

export default MakerBankMasterRejected;
