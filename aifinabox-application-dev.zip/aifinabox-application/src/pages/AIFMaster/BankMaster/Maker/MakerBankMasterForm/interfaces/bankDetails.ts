export interface BankDetailsType {
    bankCode: string;
    bankName: string;
    bicOrSwiftCode: string;
    branchName: string;
    city: string;
    clientCode: string;
    clientName: string;
    corporateId: string;
    currency: string;
    ifscOrRtgsCode: string;
}

export const initializeBankDetails: BankDetailsType = {
    "bankCode": "",
    "bankName": "",
    "bicOrSwiftCode": "",
    "branchName": "",
    "city": "",
    "clientCode": "",
    "clientName": "",
    "corporateId": "",
    "currency": "",
    "ifscOrRtgsCode": "",
};   
