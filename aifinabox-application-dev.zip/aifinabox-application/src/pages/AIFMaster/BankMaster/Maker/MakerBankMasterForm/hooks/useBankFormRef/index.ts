import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

interface FormRef {
    [key: string]: RefObject<HTMLInputElement>;
};

function useBankFormRef(): FormRef {
    const formRef: { 
        [fieldName in Field]:  RefObject<HTMLInputElement>
    } = {
        "accountType": useRef<HTMLInputElement>(null),
        "bankAccountName": useRef<HTMLInputElement>(null),
        "bankAccountNumber": useRef<HTMLInputElement>(null),
        "bankCode": useRef<HTMLInputElement>(null),
        "bankIfscRtgsCode": useRef<HTMLInputElement>(null),
        "bicSwiftCode": useRef<HTMLInputElement>(null),
        "branchName": useRef<HTMLInputElement>(null),
        "city": useRef<HTMLInputElement>(null),
        "companyCode": useRef<HTMLInputElement>(null),
        "companyName": useRef<HTMLInputElement>(null),
        "corporateBankName": useRef<HTMLInputElement>(null),
        "corporateId": useRef<HTMLInputElement>(null),
        "currency": useRef<HTMLInputElement>(null),
        "defaultAccount": useRef<HTMLInputElement>(null),
        "dormant": useRef<HTMLInputElement>(null),
        "dormantDate": useRef<HTMLInputElement>(null),
        "fundCode": useRef<HTMLInputElement>(null),
        "fundName": useRef<HTMLInputElement>(null),
        "isActive": useRef<HTMLInputElement>(null),
        "ownershipType": useRef<HTMLInputElement>(null),
        "proof": useRef<HTMLInputElement>(null),
        "remarks": useRef<HTMLInputElement>(null),
    };

    return formRef;
}

export default useBankFormRef;
