export interface BankAccountDetailsType {
    accountType: {
        value: string;
    };
    bankAccountName: {
        value: string;
    };
    chequeUpload: {
        path: string;
    };
    defaultAccount: {
        value: string;
    };
    dormant: {
        value: string;
    };
    dormantDate: {
        value: string;
    };
    isActive: {
        value: string;
    };
    ownershipType: {
        value: string;
    };
    remarks: {
        value: string;
    };
}

export const initializeBankAccountDetails: BankAccountDetailsType = {
    "accountType": {
        "value": "",
    },
    "bankAccountName": {
        "value": "",
    },
    "chequeUpload": {
        "path": "",
    },
    "defaultAccount": {
        "value": "",
    },
    "dormant": {
        "value": "",
    },
    "dormantDate": {
        "value": "",
    },
    "isActive": {
        "value": "",
    },
    "ownershipType": {
        "value": "",
    },
    "remarks": {
        "value": "",
    },
};   
