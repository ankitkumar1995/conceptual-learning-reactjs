import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    BankMasterDetails,
    initialBankMasterDetailsFormState
} from "../../../../../redux/AifMaster/BankMaster/Maker/initialState";
import {
    Checkbox,
    FormControlLabel,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import { Field, YES_NO_RADIO_OPTIONS } from "./interfaces/field.types";
import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helpers/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helpers/initializeUpdateState";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import useFetchBankAccounts, {
    FetchBankAccountsType
} from "../../../../../hooks/api/useFetchBankAccounts";
import useFetchFundCodeDetails, {
    FundDetails
} from "../../../../../hooks/api/useFetchFundCodeDetails";

import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { BankDetailsType } from "./interfaces/bankDetails";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXFileInput from "../../../../../components/FXFileInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import {
    UpdateState as MakerUpdateState
} from "../../../../../redux/AifMaster/BankMaster/Update/initialState";
import { RootState } from "../../../../../redux/store";
import axios from "axios";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Maker/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import isFormComplete from "./helpers/isFormComplete";
import isFormUpdated from "./helpers/isFormUpdated";
import isFormValid from "./helpers/isFormValid";
import onBlurAccountNumberValidator from "../../../../../validators/onBlurValidator/onBlurAccountNumberValidator";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import { setOpenBackdrop } from "../../../../../redux/ApplicationContext/reducer";
import useBankFormRef from "./hooks/useBankFormRef";
import useFetchBankAccountNumbers from "../../../../../hooks/api/useFetchBankAccountNumbers";
import useFetchBankDetails from "../../../../../hooks/api/useFetchBankDetails";
import useFetchBankMaster from "../../../../../hooks/api/useFetchBankMaster";
import useFetchBankName from "../../../../../hooks/api/useFetchBankName";
import useFetchRejectBankMaster from "../../../../../hooks/api/useFetchRejectBankMaster";
import { useLocation } from "react-router-dom";
import usePostBankMaster from "../../../../../hooks/api/usePostBankMaster";

const MakerBankMasterForm = () => {
    const formRef = useBankFormRef();
    const dispatch = useDispatch();
    const location = useLocation();

    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState); 
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    
    const [fundDetails, setFundDetails] = useState<FundDetails[]>([]);
    const [bankAccountNumbers, setBankAccountNumbers] = useState([initializeMenuItem()]);
    const [bankDetails, setBankDetails] = useState<BankDetailsType>();
    const [isBankNameFetched, setIsBankNameFetched] = useState("");
    const [updateState, setUpdateState] = useState<UpdateState>(initializeUpdateState());
    const [bankMaster, setBankMaster] = useState<BankMasterDetails>(initialBankMasterDetailsFormState);
    const [data, setData] = useState<BankMasterDetails>(initialBankMasterDetailsFormState);
    const bankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .makerForm
    );

    const updateFormState = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .bankMasterState
                .updateState
    );

    const flowType = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .pageContext
                .flowType
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
    );

    const { currencyMenuItems, ownershipTypeMenuItems } = selectInputMenuItems;

    const { firstName, lastName } = userContextState;

    const {
        accountType,
        bankAccountName,
        bankAccountNumber,
        bankCode,
        bankIfscRtgsCode,
        bicSwiftCode,
        branchName,
        city,
        companyCode,
        companyName,
        corporateBankName,
        corporateId,
        currency,
        defaultAccount,
        fundCode,
        fundName,
        dormant,
        dormantDate,
        isActive,
        ownershipType,
        proofFile,
        proofFileS3SignedURL,
        remarks
    } = bankMasterFormState;

    const {
        clearCriticalFieldsMakerEntry,
        clearState,
        setAccountType,
        setBankAccountName,
        setBankAccountNumber,
        setBankCode,
        setBankIfscRtgsCode,
        setBankMasterMakerState,
        setBicSwiftCode,
        setBranchName,
        setCity,
        setCompanyCode,
        setCompanyName,
        setCorporateBankName,
        setCorporateId,
        setCurrency,
        setDefaultAccount,
        setDormant,
        setDormantDate,
        setFundCode,
        setFundName,
        setIsActive,
        setOwnershipType,
        setProofFile,
        setProofFileFormat,
        setProofFileS3Key,
        setProofFileS3SignedURL,
        setProofFileSize,
        setRemarks,
    } = bankMasterDetailsFormDispatchActionsProvider();
    
    const { setMakerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState(bankMasterFormState);
        (formRef["companyCode"].current as HTMLInputElement).value = bankMasterFormState.companyCode;
        (formRef["companyName"].current as HTMLInputElement).value = bankMasterFormState.companyName;
    };  

    const handleClearCriticalFields = (updateState: MakerUpdateState) => {        
        if (updateState.updateFlag === "0" || (updateState.bankAccountName && updateState.updateFlag === "1")) {
            if (formRef.bankAccountName.current)
                formRef.bankAccountName.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.bankAccountNumber && updateState.updateFlag === "1")) {
            if (formRef.bankAccountNumber.current)
                formRef.bankAccountNumber.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.dormant && updateState.updateFlag === "1")) {
            if (formRef.dormant.current)
                formRef.dormant.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.dormantDate && updateState.updateFlag === "1")) {
            if (formRef.dormantDate.current)
                formRef.dormantDate.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundCode && updateState.updateFlag === "1")) {
            if (formRef.fundCode.current)
                formRef.fundCode.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundName && updateState.updateFlag === "1")) {
            if (formRef.fundName.current)
                formRef.fundName.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.isActive && updateState.updateFlag === "1")) {
            if (formRef.isActive.current)
                formRef.isActive.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.remarks && updateState.updateFlag === "1")) {
            if (formRef.remarks.current)
                formRef.remarks.current.value = "";
        }

        clearCriticalFieldsMakerEntry(updateState);
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);

            handleUpdateChange(fieldValue, field);
        }
        
    };

    const handleUpdateChange = (
        value: string,
        field: Field,
    ) => {
        if (flowType === "EE") {
            if (bankMaster[field as Field] === value) {
                setUpdateState({
                    ...updateState,
                    [field]: false
                });
            } else {
                setUpdateState({
                    ...updateState,
                    [field]: true
                });
            }
        }
        if (flowType === "RR") {
            if (data[field as Field] === value) {
                setUpdateState({
                    ...updateState,
                    [field]: false
                });
            } else {
                setUpdateState({
                    ...updateState,
                    [field]: true
                });
            }
        }
    };

    const handleonChange = (
        field: Field,
        value: string,
        dispatchFunction: any,
    ) => {
        dispatchFunction(value);

        if (flowType === "EE" ) {
            if (bankMaster[field as Field] === value) {
                setUpdateState({
                    ...updateState,
                    [field]: false
                });
            }
            else {
                setUpdateState({
                    ...updateState,
                    [field]: true,
                    // eslint-disable-next-line sort-keys
                    "bankAccountNumber": false,
                });
            }
        }

        if (flowType === "RR") {
            if (data?.[field] === value) {
                setUpdateState({
                    ...updateState,
                    [field]: false
                });
            }
            else {
                setUpdateState({
                    ...updateState,
                    [field]: true
                });
            }
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const postBankMaster = usePostBankMaster();
    const fetchBanksMasterRejected = useFetchRejectBankMaster();
    const handleFormSubmit = () => {
        postBankMaster(bankMasterFormState, `${firstName} ${lastName}`, flowType === "EE" ? "1" : "0", userId, "M", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Company Code ${companyCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Company Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleUploadFileAndSubmitForm = async () => {
        dispatch(setOpenBackdrop(true));
        const putS3ObjectAxiosConfig = {
            "data": proofFile,
            "headers": { 
                "Content-Type": "application/octet-stream",
            },
            "method": "put",
            "url": proofFileS3SignedURL,
        };

        await axios(putS3ObjectAxiosConfig)
            .then(() => {
                handleFormSubmit();
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                setAlertSnackbarContext({
                    "description": `Maker Entry Failed Company Code ${companyCode}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleBankIfscCodeChange = (value: string) => {
        flowType === "NN" && fetchBankName(value)
            .then((result) => {
                if ( result.address_line_01 ) {
                    setIsBankNameFetched("fetched");
                    setBranchName(result.address_line_01);
                    setCorporateBankName(result.bank_name);
                    setCity(result.city_name);
                    
                    (formRef["city"].current as HTMLInputElement).value = result.city_name;
                    (formRef["corporateBankName"].current as HTMLInputElement).value = result.bank_name;
                    (formRef["branchName"].current as HTMLInputElement).value = result.address_line_01;
                } else {
                    setIsBankNameFetched("failed");
                }
            });
    };

    const fetchBankMaster = useFetchBankMaster();
    const fetchBankDetails = useFetchBankDetails();
    const fetchFundCodeDetails = useFetchFundCodeDetails();
    const fetchBankAccountNumbers = useFetchBankAccountNumbers();
    const fetchBankName = useFetchBankName();

    const onFundCodeChange = (value: string) => {
        setFundCode(value);
        const matchingFund = fundDetails.find((code) => code.fundCode.label === value);
        matchingFund && setFundName(matchingFund.fundName.value);

        if (flowType === "EE") {
            fetchBankAccountNumbers(companyCode, bankIfscRtgsCode, value)
                .then((result) => {
                    setBankAccountNumbers(result);
                });
        }
    }; 

    const onBankNumberChange = (value: string) => {
        setBankAccountNumber(value);
        
        if (flowType === "EE") {
            fetchBankMaster(value, companyCode, fundCode, "1", userId)
                .then((bankMasterData) => {
                    const { bankMasterFormState } = bankMasterData;
                    setBankMasterMakerState(bankMasterFormState as BankMasterDetails);
                    setFormErrorState(initializeFormErrorState);
                    setBankMaster(bankMasterFormState as BankMasterDetails);

                    (formRef["bankAccountName"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).bankAccountName;
                    (formRef["remarks"].current as HTMLInputElement).value = (bankMasterFormState as BankMasterDetails).remarks;
                });
        }
    };
    
    const handleFetchBankDetails = ( _companyCode: string, _ifscCode: string ) => {
        fetchBankDetails(_companyCode, _ifscCode)
            .then((result) => {
                let _bankDetails = result[0];
                setBankDetails(_bankDetails);
                setFormErrorState(initializeFormErrorState());
                setBankCode(result[0].bankCode ?? ""); 
                setBranchName(result[0].branchName ?? "");
                setCity(result[0].city ?? "");
                setCorporateId(result[0].corporateId ?? "");
                setBankIfscRtgsCode(result[0].ifscOrRtgsCode ?? "");
                setCorporateBankName(result[0].bankName ?? "");
                setBicSwiftCode(result[0].bicOrSwiftCode ?? "");
                setCurrency(result[0].currency ?? "");

                (formRef["bankCode"].current as HTMLInputElement).value = _bankDetails.bankCode;
                (formRef["bankIfscRtgsCode"].current as HTMLInputElement).value = _bankDetails.ifscOrRtgsCode;
                (formRef["bicSwiftCode"].current as HTMLInputElement).value = _bankDetails.bicOrSwiftCode;
                (formRef["city"].current as HTMLInputElement).value = _bankDetails.city;
                (formRef["corporateId"].current as HTMLInputElement).value = _bankDetails.corporateId;
                (formRef["corporateBankName"].current as HTMLInputElement).value = _bankDetails.bankName;
                (formRef["branchName"].current as HTMLInputElement).value = _bankDetails.branchName;
            });
    };

    useEffect(() => {
        handleClearState();
        setFormErrorState(initializeFormErrorState);

        setAccountType("Current");

        fetchFundCodeDetails(companyCode, "M")
            .then((result) => setFundDetails(result));
        
        flowType !== "NN" &&
            handleFetchBankDetails(companyCode, bankIfscRtgsCode);
    }, []);

    useEffect (() => {
        if (bankIfscRtgsCode.length)
            handleBankIfscCodeChange(bankIfscRtgsCode);
    }, [bankIfscRtgsCode]);

    useEffect(()=>{
        if (flowType==="RR"){
            fetchBanksMasterRejected(
                bankAccountNumber,
                bankAccountName, 
                companyCode,
                fundCode,
                "bank_master", 
                "",
                "M"
            )
                .then((bankMasterMakerState) => {
                    const { 
                        bankMasterFormState, 
                        bankMasterUpdateState 
                    } = bankMasterMakerState;
                    setData(bankMasterFormState);
                    setBankMasterMakerState(bankMasterFormState);
                    setFundCode(bankMasterFormState.fundCode);
                    setBankCode(bankMasterFormState.bankCode);
                    setBankIfscRtgsCode(bankMasterFormState.bankIfscRtgsCode);
                    setBankAccountName(bankMasterFormState.bankAccountName);
                    setBankAccountNumber(bankMasterFormState.bankAccountNumber);
                    // setBankMasterMakerState(bankMasterFormState.bankMasterFormState);
                    setBicSwiftCode(bankMasterFormState.bicSwiftCode);
                    setBranchName(bankMasterFormState.branchName);
                    setCity(bankMasterFormState.city);
                    setCorporateBankName(bankMasterFormState.corporateBankName);
                    setCorporateId(bankMasterFormState.corporateId);
                    setCurrency(bankMasterFormState.currency);
                    setDefaultAccount(bankMasterFormState.defaultAccount);
                    setDormant(bankMasterFormState.dormant);
                    setDormantDate(bankMasterFormState.dormantDate);
                    setFundName(bankMasterFormState.fundName);
                    setOwnershipType(bankMasterFormState.ownershipType);
                    setProofFile(bankMasterFormState.proofFile);
                    setProofFileFormat(bankMasterFormState.proofFileFormat);
                    setProofFileS3Key(bankMasterFormState.proofFileS3Key);
                    setProofFileS3SignedURL(bankMasterFormState.proofFileS3SignedURL);
                    setProofFileSize(bankMasterFormState.proofFileSize);
                    setRemarks(bankMasterFormState.remarks);
                    setIsActive(bankMasterFormState.isActive);
                 
                });
        }
    },[]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid
                    item 
                    xs={12} 
                    display="flex" 
                    justifyContent="space-between"
                    mb={1.5}
                >
                    <Grid sx={{
                        "alignItems": "center",
                        "display": "flex",
                    }}>
                        <IconButton
                            sx={{"color": "#1C1E2C"}}
                            onClick={() => {
                                clearState(bankMasterFormState);
                                setCompanyCode(companyCode);
                                setCompanyName(companyName);
                                setMakerNavigation("bankList");
                            }}
                        >
                            <ChevronLeftIcon/> 
                        </IconButton>

                        <Typography variant="formHeading" display="flex">
                            {
                                flowType === "NN" ? "Add Bank" :
                                    flowType === "EN" ? "Add Bank Account" :
                                        flowType === "EE" ? "Update Bank Details" :
                                            flowType === "RR" ? "Rejected By Checker" :
                                                ""
                            }
                        </Typography>
                    </Grid>
                
                    {/* <Grid sx={{
                    "alignItems": "center",
                    "display": "flex",
                }}>
                    <IconButton sx={{"color": "#1C1E2C", "marginRight": "12px"}}>
                        <SaveLaterIcon/> 
                    </IconButton>

                    <IconButton sx={{"color": "#1C1E2C"}}>
                        <FetchSavedIcon/> 
                    </IconButton>
                </Grid> */}
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Company Code"
                        disabled
                        readOnly
                        required
                        defaultValue={companyCode}
                        inputRef={formRef.companyCode}
                        onBlur={() => handleInputFieldChange("companyCode", setCompanyCode)}
                        error={formErrorState.companyCode.isError}
                        helperText={formErrorState.companyCode.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Company Name"
                        disabled
                        readOnly
                        required
                        defaultValue={companyName}
                        inputRef={formRef.companyName}
                        onBlur={() => handleInputFieldChange("companyName", setCompanyName)}
                        error={formErrorState.companyName.isError}
                        helperText={formErrorState.companyName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="BankCode"
                        forbidTo="alphanumeric"
                        disabled={flowType !== "NN"}
                        readOnly={flowType !== "NN"}
                        required
                        maxLength={8}
                        defaultValue={bankCode}
                        inputRef={formRef.bankCode}
                        onBlur={() => handleInputFieldChange("bankCode", setBankCode)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankCode")
                        }
                        error={formErrorState.bankCode.isError}
                        helperText={formErrorState.bankCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        autoCapitalize
                        label="Bank IFSC / RTGS Code"
                        disabled={flowType !== "NN"}
                        readOnly={flowType !== "NN"}
                        maxLength={15}
                        forbidTo="alphanumeric"
                        required
                        defaultValue={bankIfscRtgsCode}
                        inputRef={formRef.bankIfscRtgsCode}
                        onBlur={() => handleInputFieldChange("bankIfscRtgsCode", setBankIfscRtgsCode)}
                        onFieldErrorChange={(fieldError) => 
                            setFormErrorState({
                                ...formErrorState,
                                "bankIfscRtgsCode": fieldError,
                                "branchName": initializeFieldValidation(),
                                "city": initializeFieldValidation(),
                                "corporateBankName": initializeFieldValidation(),
                            })
                        }
                        error={formErrorState.bankIfscRtgsCode.isError}
                        helperText={formErrorState.bankIfscRtgsCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Corporate / Bank Name"
                        disabled={isBankNameFetched !== "failed"}
                        readOnly={isBankNameFetched !== "failed"}
                        required
                        maxLength={50}
                        forbidTo="name"
                        defaultValue={corporateBankName}
                        inputRef={formRef.corporateBankName}
                        onBlur={() => handleInputFieldChange("corporateBankName", setCorporateBankName)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "corporateBankName")
                        }
                        error={formErrorState.corporateBankName.isError}
                        helperText={formErrorState.corporateBankName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Branch Name"
                        disabled={isBankNameFetched !== "failed"}
                        readOnly={isBankNameFetched !== "failed"}
                        required
                        maxLength={50}
                        forbidTo="namespaceanything"
                        defaultValue={branchName}
                        inputRef={formRef.branchName}
                        onBlur={() => handleInputFieldChange("branchName", setBranchName)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "branchName")
                        }
                        error={formErrorState.branchName.isError}
                        helperText={formErrorState.branchName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="City"
                        disabled={isBankNameFetched !== "failed"}
                        readOnly={isBankNameFetched !== "failed"}
                        required
                        forbidTo="name"
                        maxLength={50}
                        defaultValue={city}
                        inputRef={formRef.city}
                        onBlur={() => handleInputFieldChange("city", setCity)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "city")
                        }
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Corporate ID"
                        disabled={flowType !== "NN"}
                        readOnly={flowType !== "NN"}
                        required
                        maxLength={20}
                        forbidTo="alphanumeric"
                        defaultValue={corporateId}
                        inputRef={formRef.corporateId}
                        onBlur={() => handleInputFieldChange("corporateId", setCorporateId)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "corporateId")
                        }
                        error={formErrorState.corporateId.isError}
                        helperText={formErrorState.corporateId.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="BIC / SWIFT Code"
                        disabled={flowType !== "NN"}
                        readOnly={flowType !== "NN"}
                        required
                        forbidTo="alphanumeric"
                        maxLength={15}
                        defaultValue={bicSwiftCode}
                        inputRef={formRef.bicSwiftCode}
                        onBlur={() => handleInputFieldChange("bicSwiftCode", setBicSwiftCode)}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bicSwiftCode")
                        }
                        error={formErrorState.bicSwiftCode.isError}
                        helperText={formErrorState.bicSwiftCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Currency"
                        disabled={flowType !== "NN"}
                        required
                        value={currency}
                        onValueChange={(value) => {
                            setCurrency(value);
                            handleUpdateChange(value, "currency");
                        }}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "currency")
                        }
                        menuItems={currencyMenuItems}
                        error={formErrorState.currency.isError}
                        helperText={formErrorState.currency.helperText}
                    />
                </Grid>

                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Typography variant="formSubHeading" display="flex">
                        Add Account Details
                        </Typography>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Fund Code"
                        value={fundCode}
                        required
                        onValueChange={(value) => {
                            setFundCode(value);
                            onFundCodeChange(value);
                            handleonChange("fundCode", value, setFundCode);
                        }}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "fundCode")
                        }
                        menuItems={fundDetails.map((fund) => fund.fundCode)}                    
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Fund Name"
                        required
                        disabled
                        readOnly
                        inputRef={formRef.fundName}
                        value={fundName}
                    />
                </Grid>

                <Grid item xs={3}>
                    {flowType !== "EE" ?
                        <FXInput
                            label="Bank Account Number"
                            required
                            forbidTo="numbers"
                            maxLength={20}
                            inputRef={formRef.bankAccountNumber}
                            // onBlur={() => handleInputFieldChange("bankAccountNumber", setBankAccountNumber)}
                            value={bankAccountNumber}
                            onValueChange={(value)=> handleInputFieldChange("bankAccountNumber", setBankAccountNumber)}
                            onBlurValidator={onBlurAccountNumberValidator}
                            validatorOptions={{}}
                            onFieldErrorChange={(fieldError) => 
                                handleFieldErrorChange(fieldError, "bankAccountNumber")
                            }
                            error={formErrorState.bankAccountNumber.isError}
                            helperText={formErrorState.bankAccountNumber.helperText}
                        />
                        :
                        <FXSelectInput
                            label="Bank Account Number"
                            required
                            value={bankAccountNumber}
                            onValueChange={(value) => {
                                onBankNumberChange(value);
                                handleonChange("bankAccountNumber", value, setBankAccountNumber);
                            }}
                            onFieldErrorChange={(fieldError) => 
                                handleFieldErrorChange(fieldError, "bankAccountNumber")
                            }
                            menuItems={bankAccountNumbers}
                            error={formErrorState.bankAccountNumber.isError}
                            helperText={formErrorState.bankAccountNumber.helperText}
                        />
                    }
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Bank Account Name"
                        required
                        maxLength={50}
                        forbidTo="alphanumeric-ws"
                        defaultValue={bankAccountName}
                        inputRef={formRef.bankAccountName}
                        // onBlur={() => handleInputFieldChange("bankAccountName", setBankAccountName)}
                        value={bankAccountName}
                        onValueChange={(value)=> {
                            setBankAccountName(value);
                            handleInputFieldChange("bankAccountName", setBankAccountName);}}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "bankAccountName")
                        }
                        error={formErrorState.bankAccountName.isError}
                        helperText={formErrorState.bankAccountName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Account Type"
                        required
                        readOnly
                        value={accountType}
                        inputRef={formRef.accountType}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "accountType")
                        }
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Ownership Type"
                        required
                        value={ownershipType}
                        onValueChange={(value) => {
                            setOwnershipType(value);
                            handleUpdateChange(value, "ownershipType");
                        }}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "ownershipType")
                        }
                        menuItems={ownershipTypeMenuItems}
                        error={formErrorState.ownershipType.isError}
                        helperText={formErrorState.ownershipType.helperText}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXRadioGroup 
                        row
                        required
                        label="Is Active"
                        radioButtonValues={YES_NO_RADIO_OPTIONS} 
                        value={isActive}
                        onValueChange={(value) => {
                            setIsActive(value);
                            handleUpdateChange(value, "isActive");
                        }}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXRadioGroup 
                        row
                        required
                        label="Dormant"
                        radioButtonValues={YES_NO_RADIO_OPTIONS} 
                        value={dormant}
                        onValueChange={(value) => {
                            setDormant(value); 
                            if (value === "No") {
                                setDormantDate(null);
                                handleFieldErrorChange(initializeFieldValidation(), "dormantDate");
                            };
                            handleUpdateChange(value, "dormant");
                        }}
                    />
                </Grid>

                <Grid item xs={3}> 
                    <FXDateInput
                        required={dormant === "Yes"}
                        label="Dormant Date"
                        value={dormantDate}
                        onValueChange={(value) => {
                            setDormantDate(value);
                            handleUpdateChange(value, "dormantDate");
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false 
                        }}   
                        onFieldValidationChange={(fieldError) => {
                            handleFieldErrorChange(
                                dormant === "Yes" ? 
                                    fieldError : 
                                    initializeFieldValidation(), 
                                "dormantDate"
                            );
                        }}
                        error={formErrorState.dormantDate.isError}
                        helperText={formErrorState.dormantDate.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Remarks"
                        maxLength={256}
                        forbidTo="alphanumeric-ws"
                        inputRef={formRef.remarks}
                        // onBlur={() => handleInputFieldChange("remarks", setRemarks)}
                        value={remarks}
                        onValueChange={(value)=> {
                            // setRemarks(value);
                            handleInputFieldChange("remarks", setRemarks);}}
                        onFieldErrorChange={(fieldError) => 
                            handleFieldErrorChange(fieldError, "remarks")
                        }
                        error={formErrorState.remarks.isError}
                        helperText={formErrorState.remarks.helperText}
                    />
                </Grid>

                <Grid item container xs={12} alignItems="flex-end">
                    <Grid item xs={6}>
                        <FXFileInput
                            required
                            label="Cheque Upload"
                            accept={[".jpeg", ".jpg", ".png"]}
                            value={(proofFile === null) ? "" : undefined}
                            documentType="CHQPRF"
                            assetType="Client Assets"
                            identifier={
                                (companyCode !== "" && fundCode !== "" && bankAccountNumber !== "") 
                                    ? `CLIENT_CODE_${companyCode}/FUND_CODE_${fundCode}/BANK_ACCOUNT_NUMBER_${bankAccountNumber}`
                                    : ""
                            }
                            onFileUpload={(fileDetails) => {
                                setProofFile(fileDetails.file);
                                setProofFileSize(fileDetails.dimensions);
                            }}
                            onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
                                setProofFileS3Key(s3Key);
                                setProofFileS3SignedURL(s3Url);
                                setProofFileFormat(format);
                            }}
                            onRemoveFile={() => {
                                setFormErrorState({
                                    ...formErrorState,
                                    "proof": initializeFieldValidation(),
                                });
                                setProofFile(null);
                                setProofFileS3Key("");
                                setProofFileS3SignedURL("");
                                setProofFileFormat("");
                                setProofFileSize("");
                            }}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "proof")}
                            error={formErrorState.proof.isError}
                            helperText={formErrorState.proof.helperText}
                        />
                    </Grid>
                    <Grid item xs={6}>
                        <Typography 
                            sx={{
                                "alignItems": "center",
                                "color": "#D03240",
                                "display": "flex",
                                "marginBottom": "20px",
                                "marginLeft": "12px", 
                            }} 
                            variant="pageDescription"
                        >
                            <InfoOutlinedIcon sx={{"color": "#D03240", "marginRight": "12px"}} /> 
                            Penny drop failed upload proof
                        </Typography>
                    </Grid>
                </Grid>

                <Grid item xs={12}>
                    <FormControlLabel 
                        sx={{
                            "& .MuiSvgIcon-root": {
                                "height": "18px",
                                "width": "18px",
                            }
                        }}
                        control={<Checkbox />} 
                        label={
                            <Typography variant="loginDescription">
                                Make as Default Account 
                            </Typography>
                        }
                        checked={defaultAccount === "Yes"}
                        onChange={
                            (ele) => {
                                const target = ele.target as HTMLInputElement;
                                setDefaultAccount(target.checked ? "Yes" : "No");
                                handleUpdateChange(target.checked ? "Yes" : "No", "defaultAccount");
                            }
                        }
                    />
                </Grid>

                <Grid item xs={12} mb={3}>
                    <Grid 
                        sx={{
                            "alignItems": "center",
                            "background": "rgba(252, 227, 231, 0.3)", 
                            "borderRadius": "8px",
                            "display": "flex",
                            "padding": "16px 21px",
                        }}
                    >
                        <FXButton
                            disableRipple
                            disabled
                            label="Verify Bank Details" 
                            buttonVariant="delete" 
                        />
                        <Typography 
                            sx={{
                                "alignItems": "center",
                                "display": "flex",
                                "marginLeft": "16px", 
                            }} 
                            variant="pageDescription"
                        >
                            <InfoOutlinedIcon sx={{"color": "#57B6BA", "marginRight": "12px"}} /> 
                            The Primary Contributor’s bank account will be verified using a penny drop validation
                        </Typography>
                    </Grid>
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        disableRipple
                        label="Clear" 
                        buttonVariant="normal" 
                        fullWidth
                        onClick={() => {
                            flowType === "NN" ?
                                handleClearState() :
                                handleClearCriticalFields(updateFormState);
                        }}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        disableRipple
                        disabled={ 
                            alertSnackbarContext.open ||
                            !(isFormComplete(bankMasterFormState)) ||
                            !(isFormValid(formErrorState))
                            || isFormUpdated(updateState, flowType)
                        }
                        label="Submit to Checker" 
                        buttonVariant="submit" 
                        fullWidth
                        endIcon={<ArrowForwardIosIcon/>}
                        onClick={() => {
                            proofFileS3SignedURL === ""
                                ? handleFormSubmit()
                                : handleUploadFileAndSubmitForm();
                        }} 
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        handleClearState();
                        setCompanyCode("");
                        setCompanyName("");
                        setMakerNavigation("");
                    }
        
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default MakerBankMasterForm;
