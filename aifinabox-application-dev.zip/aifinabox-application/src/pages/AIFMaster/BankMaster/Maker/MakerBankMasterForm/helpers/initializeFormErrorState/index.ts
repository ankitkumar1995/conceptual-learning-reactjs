import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../../../interfaces/FieldValidation.types";

export interface FormErrorState {
    "accountType": FieldValidation;
    "bankAccountName": FieldValidation;
    "bankAccountNumber": FieldValidation;
    "bankCode": FieldValidation;
    "bankIfscRtgsCode": FieldValidation;
    "bicSwiftCode": FieldValidation;
    "branchName": FieldValidation;
    "city": FieldValidation;
    "companyCode": FieldValidation;
    "companyName": FieldValidation;
    "corporateBankName": FieldValidation;
    "corporateId": FieldValidation;
    "currency": FieldValidation;
    "dormant": FieldValidation;
    "dormantDate": FieldValidation;
    "fundCode": FieldValidation;
    "fundName": FieldValidation;
    "isActive": FieldValidation;
    "ownershipType": FieldValidation;
    "proof": FieldValidation;
    "remarks": FieldValidation;
}

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "accountType": initializeFieldValidation(),
            "bankAccountName": initializeFieldValidation(),
            "bankAccountNumber": initializeFieldValidation(),
            "bankCode": initializeFieldValidation(),
            "bankIfscRtgsCode": initializeFieldValidation(),
            "bicSwiftCode": initializeFieldValidation(),
            "branchName": initializeFieldValidation(),
            "city": initializeFieldValidation(),
            "companyCode": initializeFieldValidation(),
            "companyName": initializeFieldValidation(),
            "corporateBankName": initializeFieldValidation(),
            "corporateId": initializeFieldValidation(),
            "currency": initializeFieldValidation(),
            "dormant": initializeFieldValidation(),
            "dormantDate": initializeFieldValidation(),
            "fundCode": initializeFieldValidation(),
            "fundName": initializeFieldValidation(),
            "isActive": initializeFieldValidation(),
            "ownershipType": initializeFieldValidation(),
            "proof": initializeFieldValidation(),
            "remarks": initializeFieldValidation(),
        }
    );
}   

export default initializeFormErrorState;
