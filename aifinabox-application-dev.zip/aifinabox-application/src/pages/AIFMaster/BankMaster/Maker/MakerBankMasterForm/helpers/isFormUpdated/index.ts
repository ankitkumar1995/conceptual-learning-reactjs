import { UpdateState } from "../initializeUpdateState";

function isFormUpdated (
    updateState: UpdateState,
    flowType: "EE" | "EN" | "NN" | "RR"
) {
    if (flowType === "EN" || flowType === "NN")
        return false;

    return !(
        updateState.accountType ||
        updateState.bankAccountName ||
        updateState.bankAccountNumber ||
        updateState.bankCode ||
        updateState.bankIfscRtgsCode ||
        updateState.bicSwiftCode ||
        updateState.branchName ||
        updateState.city ||
        updateState.companyCode ||
        updateState.companyName ||
        updateState.corporateBankName ||
        updateState.corporateId ||
        updateState.currency ||
        updateState.dormant ||
        updateState.dormantDate ||
        updateState.fundCode ||
        updateState.fundName ||
        updateState.isActive ||
        updateState.ownershipType ||
        updateState.remarks
    );
};

export default isFormUpdated;
