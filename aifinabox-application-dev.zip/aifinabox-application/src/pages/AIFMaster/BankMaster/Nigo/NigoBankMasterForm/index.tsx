import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import initializeUpdateState, {
    UpdateState
} from "../../../../../redux/AifMaster/BankMaster/Update/initialState";

import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import NigoTable from "../../../components/NigoTable";
import { RootState } from "../../../../../redux/store";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Checker/dispatchActionsProvider";
import bankMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/Nigo/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import usePostBankMaster from "../../../../../hooks/api/usePostBankMaster";
import { useSelector } from "react-redux";
import { useState } from "react";

const NigoBankMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const navigate = useNavigate();
    const [checkerUpdateState, setCheckerUpdateState] = useState<UpdateState>(initializeUpdateState());

    const checkerBankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .checkerForm
    );
    
    const nigoBankMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .bankMasterState
                .nigoForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { bankCode } = checkerBankMasterFormState;

    const { firstName, lastName } = userContextState;

    const { 
        checkerData, 
        makerData, 
        nigoMetaData
    } = nigoBankMasterFormState;

    const { 
        "clearState": clearNigoState,
        setCheckerData, 
        setMakerData, 
        setNigoMetaData 
    } = bankMasterNigoDetailsFormDispatchActionsProvider();

    const { "clearState": clearCheckerState }  = bankMasterDetailsFormDispatchActionsProvider();

    const { setCheckerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    const {
        setNigoRaised,
    } = bankMasterPageContextFormDispatchActionsProvider(); 

    const postBankMaster = usePostBankMaster();

    const handleFormSubmit = () => {
        let modifiedCheckerData = checkerData;
        let modifiedMakerData = makerData;

        nigoMetaData.forEach((data) => {
            const fieldName = data.field;
            const checkerValue = data.checkerEntry;
            const makerValue = data.makerEntry;

            modifiedCheckerData = {
                ...modifiedCheckerData,
                [fieldName]: checkerValue,
                "proofFileFormat": makerData.proofFileFormat,
                "proofFileS3Key": makerData.proofFileS3Key,
                "proofFileSize": makerData.proofFileSize,
            };
            modifiedMakerData = {
                ...modifiedMakerData,
                [fieldName]: makerValue,
            };
        });

        setCheckerData(modifiedCheckerData);
        setMakerData(modifiedMakerData);

        postBankMaster(modifiedCheckerData, `${firstName} ${lastName}`, "0", userId, "C", checkerUpdateState)
            .then(() => setAlertSnackbarContext({
                "description": `NIGO Entry Done against Bank Code ${bankCode}`,
                "open": true,
                "severity": "success",
                "title": "NIGO Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `NIGO Entry Failure against
                                    Client Code: ${bankCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "NIGO Entry Failed",
                });
            });
    };

    return (
        <>
            <NigoTable 
                nigoData={nigoMetaData}
                onDataChange={(nigoData) => {
                    setNigoMetaData(nigoData);
                }}
                onSubmitClicked={handleFormSubmit}
            />
            
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        clearCheckerState();
                        clearNigoState();
                        setCheckerNavigation("");
                        setNigoRaised(false);
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default NigoBankMasterForm;
