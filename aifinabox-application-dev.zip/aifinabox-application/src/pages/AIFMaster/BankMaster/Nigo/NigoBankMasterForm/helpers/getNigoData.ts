import {
    BankMasterDetails as CheckerBankMasterDetails
} from "../../../../../../redux/AifMaster/BankMaster/Checker/initialState";
import {
    BankMasterDetails as MakerBankMasterDetails
} from "../../../../../../redux/AifMaster/BankMaster/Maker/initialState";
import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerBankMasterDetails, checkerFormState: CheckerBankMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (key === "proofFile" || key === "proofFileS3Key" || key === "proofFileS3SignedURL" || key === "proofFileFormat" || key === "proofFileSize" || key === "proof") 
            continue;

        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerBankMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }

    return nigoData;
}
