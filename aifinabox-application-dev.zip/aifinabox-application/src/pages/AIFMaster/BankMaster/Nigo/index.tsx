import NigoBankMasterForm from "./NigoBankMasterForm";

const NigoBankMasterPage = () => {
    return (
        <>
            <NigoBankMasterForm/>
        </>
    );
};

export default NigoBankMasterPage;

