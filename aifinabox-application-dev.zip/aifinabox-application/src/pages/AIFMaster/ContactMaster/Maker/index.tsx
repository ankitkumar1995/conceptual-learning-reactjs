import MakerContactMasterForm from "./MakerContactMasterForm";

const MakerContactMasterPage = () => {
    return (
        <>
            <MakerContactMasterForm/>
        </>
    );
};

export default MakerContactMasterPage;
