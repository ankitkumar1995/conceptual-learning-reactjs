import { Field } from "../../interfaces/field.types";

export type UpdateState = { 
    [fieldName in Field]: boolean
};

function initializeUpdateState(): UpdateState {
    return (
        {
           
            "aifCompanyName": false,
            "aifContactNumber": false,
            "aifContactNumberPrefix": false,
            "aifEmailId": false,
            "clientCode": false,
            "clientType": false,
            "complianceOfficeContact": false,
            "complianceOfficeContactPrefix": false,
            "complianceOfficeDesignation": false,
            "complianceOfficeEmailId": false,
            "complianceOfficeName": false,
            "complianceOfficeNamePrefix": false,
            "contactPersonName": false,
            "contactPersonNamePrefix": false,
            "spoc1ContactNumber": false,
            "spoc1ContactNumberPrefix": false,
            "spoc1EmailId": false,
            "spoc1Name": false,
            "spoc1NamePrefix": false,
            "spoc1Role": false,
            "spoc2ContactNumber": false,
            "spoc2ContactNumberPrefix": false,
            "spoc2EmailId": false,
            "spoc2Name": false,
            "spoc2NamePrefix": false,
            "spoc2Role": false,
            "spoc3ContactNumber": false,
            "spoc3ContactNumberPrefix": false,
            "spoc3EmailId": false,
            "spoc3Name": false,
            "spoc3NamePrefix": false,
            "spoc3Role": false,
        }
    );
}

export default initializeUpdateState;
