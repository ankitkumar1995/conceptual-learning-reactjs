import { SxProps } from "@mui/material";

export const spocStyle: SxProps = {
    "background": "rgba(15, 212, 216, 0.08)",
    "boxSizing": "unset !important",
    "display": "flex",
    "gap": "15px",
    "margin": "20px -30px 0px -14px",
    "paddingBottom": "40px",
    "paddingLeft": "30px !important",
    "paddingRight": "20px"
};
