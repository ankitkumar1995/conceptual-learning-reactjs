import { MenuItem } from "../../../../../../interfaces/MenuItem.types";

export const companyCodes: MenuItem[] = [
    {
        "label": "10001",
        "value": "10001",
    },
];

export const countryCodeMenuItems: MenuItem[] = [
    {
        "label": "+91",
        "value": "91"
    },
    {
        "label": "+86",
        "value": "86"
    },
];
