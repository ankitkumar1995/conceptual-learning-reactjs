import { UpdateState } from "../initializeUpdateState";

function isFormUpdated(
    updateState: UpdateState, 
    updateExistingFlag: "0" | "1"
) {
    if (updateExistingFlag === "0")
        return false;

    return !(
        updateState.aifCompanyName ||
        updateState.aifContactNumber ||
        updateState.aifContactNumberPrefix ||
        updateState.aifEmailId ||
        updateState.clientCode ||
        updateState.clientType ||
        updateState.complianceOfficeContact ||
        updateState.complianceOfficeContactPrefix ||
        updateState.complianceOfficeDesignation ||
        updateState.complianceOfficeEmailId ||
        updateState.complianceOfficeName ||
        updateState.complianceOfficeNamePrefix ||
        updateState.contactPersonName ||
        updateState.contactPersonNamePrefix ||
        updateState.spoc1ContactNumber ||
        updateState.spoc1ContactNumberPrefix ||
        updateState.spoc1EmailId ||
        updateState.spoc1Name ||
        updateState.spoc1NamePrefix ||
        updateState.spoc1Role ||
        updateState.spoc2ContactNumber ||
        updateState.spoc2ContactNumberPrefix ||
        updateState.spoc2EmailId ||
        updateState.spoc2Name ||
        updateState.spoc2NamePrefix ||
        updateState.spoc2Role ||
        updateState.spoc3ContactNumber ||
        updateState.spoc3ContactNumberPrefix ||
        updateState.spoc3EmailId ||
        updateState.spoc3Name ||
        updateState.spoc3NamePrefix ||
        updateState.spoc3Role 
    );
} 

export default isFormUpdated;
