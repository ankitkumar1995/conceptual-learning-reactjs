export type Field = 
    "aifCompanyName" |
    "aifContactNumber" |
    "aifContactNumberPrefix"|
    "clientType"|
    "aifEmailId" |
    "clientCode" |
    "complianceOfficeContact" |
    "complianceOfficeContactPrefix" |
    "complianceOfficeDesignation" |
    "complianceOfficeEmailId" |
    "complianceOfficeName" |
    "complianceOfficeNamePrefix" |
    "contactPersonName" |
    "contactPersonNamePrefix" |
    "spoc1ContactNumber" |
    "spoc1ContactNumberPrefix" |
    "spoc1EmailId" |
    "spoc1Name" |
    "spoc1Role" |
    "spoc1NamePrefix" |
    "spoc2ContactNumber" |
    "spoc2ContactNumberPrefix" |
    "spoc2EmailId" |
    "spoc2Name" |
    "spoc2NamePrefix" |
    "spoc2Role" |
    "spoc3ContactNumber" |
    "spoc3ContactNumberPrefix" |
    "spoc3EmailId" |
    "spoc3NamePrefix" |
    "spoc3Name" |
    "spoc3Role"
