import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Button,
    Grid,
    Stack,
    Typography,
} from "@mui/material";
import {
    addNewButtonStyles,
    masterSetupClearButtonStyles,
    masterSetupSubmitButtonStyles,
    updateExistingButtonStyles
} from "../../../styles/ButtonStyles";
import initializeFormErrorState, { FormErrorState } from "./helpers/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helpers/initializeUpdateState";
import {
    useEffect,
    useRef,
    useState
} from "react";
import useFetchClientDetails, {
    ClientDetails
} from "../../../../../hooks/api/useFetchClientDetails";

import AddIcon from "../../../../../icons/AddIcon";
import ArrowForwardIcon from "../../../../../icons/ArrowForwardIcon";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXInput from "../../../../../components/FXInput";
import FXInputWithSelectInput from "../../../../../components/FXInputWithSelectInput";
import FXInputWithSelectSearchInput from "../../../../../components/FXInputWithSelectSearchInput";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { FieldValidation } from "../../../../../interfaces/FieldValidation.types";
import { MenuItem } from "../../../../../interfaces/MenuItem.types";
import { RootState } from "../../../../../redux/store";
import contactMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Maker/dispatchActionsProvider";
import isFormComplete from "./helpers/isFormComplete";
import isFormUpdated from "./helpers/isFormUpdated";
import isFormValid from "./helpers/isFormValid";
import onBlurEmailValidator from "../../../../../validators/onBlurValidator/onBlurEmailValidator";
import { spocStyle } from "./ContactMasterStyles";
import useContactFormRef from "./hooks/useContactFormRef";
import useFetchClientCodes from "../../../../../hooks/api/useFetchClientCodes";
import useFetchClientMaster from "../../../../../hooks/api/useFetchClientMaster";
import useFetchContactMaster from "../../../../../hooks/api/useFetchContactMaster";
import usePostContactMaster from "../../../../../hooks/api/usePostContactMaster";
import { useSelector } from "react-redux";

const MakerContactMasterForm = () => {
    const formRef = useContactFormRef();
    let formRefState = useContactFormRef();

    const updateFlag = useRef<"0" | "1">("0");
    const [disabled, setDisabled] = useState(true);
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [clientCodeMenuItems, setClientCodeMenuItems] = useState<MenuItem[]>([]);
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);
    const [clientCodesDetails, setClientCodesDetails] = useState<ClientDetails[]>([]);

    const contactMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .makerForm
    );

    const selectInputMenuItemsState = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        clientCode, 
        aifCompanyName,
        aifContactNumberPrefix, 
        contactPersonNamePrefix,
        spoc1NamePrefix,
        spoc1ContactNumberPrefix,
        spoc2NamePrefix,
        spoc2ContactNumberPrefix,
        spoc3NamePrefix,
        spoc3ContactNumberPrefix,
        complianceOfficeContactPrefix,
        complianceOfficeNamePrefix
    } = contactMasterFormState;

    const {
        countryPhoneCodeMenuItems,
        honorificsMenuItems,
    } = selectInputMenuItemsState;

    const {
        clearState,
        setClientCode,
        setAifCompanyName,
        setClientContactMakerState,
        setContactPersonName,
        setContactPersonNamePrefix,
        setAifContactNumber,
        setAifContactNumberPrefix,
        setAifEmailId,
        setClientType,
        setComplianceOfficeContact,
        setComplianceOfficeContactPrefix,
        setComplianceOfficeEmailId,
        setComplianceOfficeDesignation,
        setComplianceOfficeName,
        setComplianceOfficeNamePrefix,
        setSpoc1ContactNumber,
        setSpoc1ContactNumberPrefix,
        setSpoc1EmailId,
        setSpoc1Name,
        setSpoc1NamePrefix,
        setSpoc2ContactNumber,
        setSpoc2ContactNumberPrefix,
        setSpoc2EmailId,
        setSpoc2Name,
        setSpoc2NamePrefix,
        setSpoc3ContactNumber,
        setSpoc3ContactNumberPrefix,
        setSpoc3EmailId,
        setSpoc3Name,
        setSpoc3NamePrefix
    } = contactMasterDetailsFormDispatchActionsProvider();

    const postContactMaster = usePostContactMaster();
    const fetchClientCodes = useFetchClientCodes();
    const fetchClientMaster = useFetchClientMaster();
    const fetchClientDetails = useFetchClientDetails();
    const fetchContactMaster = useFetchContactMaster();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef) as Field[];

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });
        setFormErrorState(initializeFormErrorState);
        clearState();
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorStateChange = (
        field: Field,
        error: FieldValidation,
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: error,
        });
    };

    const handleChangeUpdate = (field: Field, value: string) => {
        if (updateFlag.current === "1") {
            if (contactMasterFormState[field] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }
    };

    const handleFetchClientCodes = () => {
        fetchClientDetails("contact_master", updateFlag.current)
            .then((result) => {
                const clientCodesResponse = result.map((codes: ClientDetails) =>  ({
                    "label": `${codes.clientCode} - ${codes.clientName}`,
                    "value": codes.clientCode,
                }));
                setClientCodeMenuItems(clientCodesResponse);
            })
            .catch((error) => console.error(error));
    };

    const handleSubmitForm = async () => {
        await postContactMaster(contactMasterFormState, `${firstName} ${lastName}`, updateFlag.current, userId, "M", isUpdate)
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });		
    };

    const handleClientCodeChange = async (_clientCode: string) => {
        setClientCode(_clientCode);

        if (updateFlag.current === "0") {
            const aifCompanyName = clientCodesDetails.find((clientCodeDetail) => clientCodeDetail.clientCode === _clientCode)?.clientName;
            setAifCompanyName(aifCompanyName || "");

            return ;
        }

        await fetchContactMaster(_clientCode, updateFlag.current,userId)
            .then((response) => {
                const { contactMasterMakerEntry } = response;
                setClientContactMakerState(contactMasterMakerEntry);
                setFormErrorState(initializeFormErrorState);

                (formRef["aifContactNumber"].current as HTMLInputElement).value = contactMasterMakerEntry.aifContactNumber;
                (formRef["aifCompanyName"].current as HTMLInputElement).value = contactMasterMakerEntry.aifCompanyName;
                (formRef["aifEmailId"].current as HTMLInputElement).value = contactMasterMakerEntry.aifEmailId;
                (formRef["complianceOfficeContact"].current as HTMLInputElement).value = contactMasterMakerEntry.complianceOfficeContact;
                (formRef["complianceOfficeDesignation"].current as HTMLInputElement).value = contactMasterMakerEntry.complianceOfficeDesignation;
                (formRef["complianceOfficeEmailId"].current as HTMLInputElement).value = contactMasterMakerEntry.complianceOfficeEmailId;
                (formRef["complianceOfficeName"].current as HTMLInputElement).value = contactMasterMakerEntry.complianceOfficeName;
                (formRef["contactPersonName"].current as HTMLInputElement).value = contactMasterMakerEntry.contactPersonName;
                (formRef["spoc1ContactNumber"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc1ContactNumber;
                (formRef["spoc1EmailId"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc1EmailId;
                (formRef["spoc1Name"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc1Name;
                (formRef["spoc2ContactNumber"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc2ContactNumber;
                (formRef["spoc2EmailId"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc2EmailId;
                (formRef["spoc2Name"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc2Name;
                (formRef["spoc3ContactNumber"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc3ContactNumber;
                (formRef["spoc3EmailId"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc3EmailId;
                (formRef["spoc3Name"].current as HTMLInputElement).value = contactMasterMakerEntry.spoc3Name;
            })
            .catch((error) => console.error(error));
    };

    useEffect(() => {
        fetchClientDetails("contact_master", updateFlag.current)
            .then((result) => {
                const clientCodesResponse = result.map((codes: ClientDetails) => ({
                    "label": `${codes.clientCode} - ${codes.clientName}`,
                    "value": codes.clientCode,
                }));
                setClientCodeMenuItems(clientCodesResponse);
                setClientCodesDetails(result);
            });
    }, [updateFlag]);

    useEffect(() => {
        handleClearState();
    }, []);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Typography variant="formHeading">
                            {
                                updateFlag.current === "0" 
                                    ? "Add Contact Master" 
                                    : "Update Contact Master" 
                            } 
                        </Typography>

                        <Stack direction="row" spacing={2}>
                            <FXButton
                                buttonVariant="contained"
                                disabled={disabled}
                                fullWidth
                                label="Add New"
                                onClick={() => {
                                    handleClearState();
                                    updateFlag.current = "0";
                                    setDisabled(true);
                                    handleFetchClientCodes();
                                }}

                                startIcon={<AddIcon/>}
                                sx={addNewButtonStyles}
                            />
                            <FXButton
                                buttonVariant="contained"
                                disabled={!disabled}
                                fullWidth
                                label="Update Existing"
                                onClick={() => {
                                    handleClearState();
                                    setDisabled(false);
                                    updateFlag.current = "1";
                                    handleFetchClientCodes();
                                }}
                                startIcon={<EditIcon/>}
                                sx={updateExistingButtonStyles}
                            />
                        </Stack>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Client Code"
                        required
                        menuItems={clientCodeMenuItems} 
                        value={clientCode}
                        onValueChange={handleClientCodeChange}
                        error={formErrorState.clientCode.isError}
                        helperText={formErrorState.clientCode.helperText} 
                    />
                </Grid>

                <Grid item xs={9}>
                    <FXInput
                        label="AIF Company Name"
                        forbidTo="singleSpace"
                        required
                        readOnly
                        disabled
                        value={aifCompanyName}
                        inputRef={formRef.aifCompanyName}
                        onBlur={() => handleInputFieldChange("aifCompanyName", setAifCompanyName)}
                        error={formErrorState.aifCompanyName.isError}
                        helperText={formErrorState.aifCompanyName.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("aifCompanyName", error)} 
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInputWithSelectInput
                        label="Contact Person Name"
                        forbidTo="namespaceapostrophe"
                        maxLength={256}
                        required
                        selectInputPosition="start"
                        textInputRef={formRef.contactPersonName}
                        onTextFieldBlur={() => handleInputFieldChange("contactPersonName", setContactPersonName)}
                        onTextFieldValueChange={(value) => {
                            handleChangeUpdate("contactPersonName", value);
                        }}
                        error={formErrorState.contactPersonName.isError}
                        helperText={formErrorState.contactPersonName.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("contactPersonName", error)}
                        selectFieldValue={contactPersonNamePrefix}
                        selectFieldMenuItems={honorificsMenuItems}
                        onSelectFieldValueChange={(value) => {
                            setContactPersonNamePrefix(value);
                            handleChangeUpdate("contactPersonNamePrefix", value);
                        }} 
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInputWithSelectSearchInput
                        label="Contact Number Of AIF"
                        required
                        maxLength={20}
                        forbidTo="contact-number"
                        selectLabel="CountryCode"
                        selectInputPosition="start"
                        textInputRef={formRef.aifContactNumber}
                        onTextFieldBlur={() => handleInputFieldChange("aifContactNumber", setAifContactNumber)}
                        error={formErrorState.aifContactNumber.isError}
                        helperText={formErrorState.aifContactNumber.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("aifContactNumber", error)}
                        onTextFieldValueChange={(value) => {
                            handleChangeUpdate("aifContactNumber", value);
                        }}
                        selectFieldValue={aifContactNumberPrefix}
                        selectFieldMenuItems={countryPhoneCodeMenuItems}
                        onSelectFieldValueChange={(value) => {
                            setAifContactNumberPrefix(value);
                            handleChangeUpdate("aifContactNumberPrefix", value);
                        }} 
                        masterName="contact_master"
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInput
                        label="Email ID of AIF"
                        maxLength={256}
                        required
                        inputRef={formRef.aifEmailId}
                        onBlur={() => handleInputFieldChange("aifEmailId", setAifEmailId)}
                        onBlurValidator={onBlurEmailValidator}
                        validatorOptions={{}}
                        error={formErrorState.aifEmailId.isError}
                        helperText={formErrorState.aifEmailId.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("aifEmailId", error)} 
                        onValueChange={(value) => {
                            handleChangeUpdate("aifEmailId", value);
                        }}
                    />
                </Grid>

                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC1 Name"
                            forbidTo="namespaceapostrophe"
                            required
                            maxLength={256}
                            textInputRef={formRef.spoc1Name}
                            onTextFieldBlur={() => handleInputFieldChange("spoc1Name", setSpoc1Name)}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc1Name", value);
                            }}
                            error={formErrorState.spoc1Name.isError}
                            helperText={formErrorState.spoc1Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1Name", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc1NamePrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc1NamePrefix(value);
                                handleChangeUpdate("spoc1NamePrefix", value);
                            }}
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            label="SPOC1 Contact Number"
                            selectLabel="CountryCode"
                            forbidTo="contact-number"
                            required
                            maxLength={20}
                            textInputRef={formRef.spoc1ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc1ContactNumber", setSpoc1ContactNumber)}
                            error={formErrorState.spoc1ContactNumber.isError}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc1ContactNumber", value);
                            }}
                            helperText={formErrorState.spoc1ContactNumber.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc1ContactNumberPrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc1ContactNumberPrefix(value);
                                handleChangeUpdate("spoc1ContactNumberPrefix", value);
                            }}
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC1 Email ID"
                            maxLength={256}
                            required
                            inputRef={formRef.spoc1EmailId}
                            onBlur={() => handleInputFieldChange("spoc1EmailId", setSpoc1EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc1EmailId.isError}
                            helperText={formErrorState.spoc1EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1EmailId", error)}
                            onValueChange={(value) => {
                                handleChangeUpdate("spoc2EmailId", value);
                            }}
                        />
                    </Grid>
                </Grid>
                
                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC2 Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={256}
                            textInputRef={formRef.spoc2Name}
                            onTextFieldBlur={() => handleInputFieldChange("spoc2Name", setSpoc2Name)}
                            error={formErrorState.spoc2Name.isError}
                            helperText={formErrorState.spoc2Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2Name", error)}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc2Name", value);
                            }}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc2NamePrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc2NamePrefix(value);
                                handleChangeUpdate("spoc2NamePrefix", value);
                            }} 
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            label="SPOC2 Contact Number"
                            forbidTo="contact-number"
                            selectLabel="CountryCode"
                            maxLength={20}
                            textInputRef={formRef.spoc2ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc2ContactNumber", setSpoc2ContactNumber)}
                            error={formErrorState.spoc2ContactNumber.isError}
                            helperText={formErrorState.spoc2ContactNumber.helperText}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc2ContactNumber", value);
                            }}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc2ContactNumberPrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc2ContactNumberPrefix(value);
                                handleChangeUpdate("spoc2ContactNumberPrefix",value);
                            }} 
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC2 Email ID"
                            maxLength={256}
                            inputRef={formRef.spoc2EmailId}
                            onBlur={() => handleInputFieldChange("spoc2EmailId", setSpoc2EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc2EmailId.isError}
                            helperText={formErrorState.spoc2EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2EmailId", error)} 
                            onValueChange={(value) => {
                                handleChangeUpdate("spoc2EmailId", value);
                            }}
                        />
                    </Grid>
                </Grid>

                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC3 Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={256}
                            textInputRef={formRef.spoc3Name}
                            onTextFieldBlur={() => handleInputFieldChange("spoc3Name", setSpoc3Name)}
                            error={formErrorState.spoc3Name.isError}
                            helperText={formErrorState.spoc3Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3Name", error)}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc3Name", value);
                            }}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc3NamePrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc3NamePrefix(value);
                                handleChangeUpdate("spoc3NamePrefix", value);
                            }}
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            label="SPOC3 Contact Number"
                            selectLabel="CountryCode"
                            forbidTo="contact-number"
                            maxLength={20}
                            textInputRef={formRef.spoc3ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc3ContactNumber", setSpoc3ContactNumber)}
                            error={formErrorState.spoc3ContactNumber.isError}
                            helperText={formErrorState.spoc3ContactNumber.helperText}
                            onTextFieldValueChange={(value) => {
                                handleChangeUpdate("spoc3ContactNumber", value);
                            }}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc3ContactNumberPrefix}
                            onSelectFieldValueChange={(value) => {
                                setSpoc3ContactNumberPrefix(value);
                                handleChangeUpdate("spoc3ContactNumberPrefix", value);
                            }} 
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC3 Email ID"
                            forbidTo="email"
                            maxLength={256}
                            inputRef={formRef.spoc3EmailId}
                            onBlur={() => handleInputFieldChange("spoc3EmailId", setSpoc3EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc3EmailId.isError}
                            helperText={formErrorState.spoc3EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3EmailId", error)}
                            onValueChange={(value) => {
                                handleChangeUpdate("spoc3EmailId", value);
                            }}
                        />
                    </Grid>
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInputWithSelectInput
                        label="Compliance Office Name"
                        forbidTo="namespaceapostrophe"
                        maxLength={256}
                        selectInputPosition="start"
                        textInputRef={formRef.complianceOfficeName}
                        onTextFieldBlur={() => handleInputFieldChange("complianceOfficeName", setComplianceOfficeName)}
                        required
                        error={formErrorState.complianceOfficeName.isError}
                        helperText={formErrorState.complianceOfficeName.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeName", error)}
                        onTextFieldValueChange={(value) => {
                            handleChangeUpdate("complianceOfficeName", value);
                        }}
                        selectFieldMenuItems={honorificsMenuItems}
                        selectFieldValue={complianceOfficeNamePrefix}
                        onSelectFieldValueChange={(value) => {
                            setComplianceOfficeNamePrefix(value);
                            handleChangeUpdate("complianceOfficeNamePrefix", value);
                        }} 
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInputWithSelectSearchInput
                        label="Compliance Office Contact"
                        forbidTo="contact-number"
                        selectLabel="CountryCode"
                        maxLength={20}
                        selectInputPosition="start"
                        textInputRef={formRef.complianceOfficeContact}
                        onTextFieldBlur={() => handleInputFieldChange("complianceOfficeContact", setComplianceOfficeContact)}
                        required
                        error={formErrorState.complianceOfficeContact.isError}
                        onTextFieldValueChange={(value) => {
                            handleChangeUpdate("complianceOfficeContact", value);
                        }}
                        helperText={formErrorState.complianceOfficeContact.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeContact", error)}
                        selectFieldMenuItems={countryPhoneCodeMenuItems}
                        selectFieldValue={complianceOfficeContactPrefix}
                        onSelectFieldValueChange={(value) => {
                            setComplianceOfficeContactPrefix(value);
                            handleChangeUpdate("complianceOfficeContactPrefix", value);
                        }} 
                        masterName="contact_master"
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInput
                        label="Compliance Office Email ID"
                        maxLength={256}
                        inputRef={formRef.complianceOfficeEmailId}
                        onBlur={() => handleInputFieldChange("complianceOfficeEmailId", setComplianceOfficeEmailId)}
                        required
                        onBlurValidator={onBlurEmailValidator}
                        validatorOptions={{}}
                        error={formErrorState.complianceOfficeEmailId.isError}
                        helperText={formErrorState.complianceOfficeEmailId.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeEmailId", error)} 
                        onValueChange={(value) => {
                            handleChangeUpdate("complianceOfficeEmailId", value);
                        }}
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInput
                        label="Compliance Office Designation"
                        required
                        forbidTo="alphanumeric-ws"
                        maxLength={256}
                        inputRef={formRef.complianceOfficeDesignation}
                        onBlur={() => handleInputFieldChange("complianceOfficeDesignation", setComplianceOfficeDesignation)}
                        error={formErrorState.complianceOfficeDesignation.isError}
                        helperText={formErrorState.complianceOfficeDesignation.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeDesignation", error)} 
                        onValueChange={(value) => {
                            handleChangeUpdate("complianceOfficeDesignation", value);
                        }}
                    />
                </Grid>
                <Grid container rowSpacing={2} columnSpacing={2} mt={3}>
                    <Grid item xs={6} >
                        <FXButton
                            buttonVariant="normal"
                            fullWidth
                            label="Clear"
                            onClick={handleClearState}
                        // sx={masterSetupClearButtonStyles}
                        />
                    </Grid>

                    <Grid item xs={6}   >
                        <FXButton
                            buttonVariant="submit"
                            disabled={
                                alertSnackbarContext.open ||
                            !(isFormValid(formErrorState)) ||
                            !(isFormComplete(contactMasterFormState)) ||
                            isFormUpdated(isUpdate, updateFlag.current)
                            }
                            fullWidth
                            label="Submit to Checker"
                            onClick={handleSubmitForm}
                            endIcon={<ArrowForwardIcon/>}
                            sx={masterSetupSubmitButtonStyles}
                        />
                    </Grid>
                </Grid>
            </Grid>
        
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        handleClearState();
                        updateFlag.current = "0";
                    }

                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }} 
            />
        </>
    );
};

export default MakerContactMasterForm;
