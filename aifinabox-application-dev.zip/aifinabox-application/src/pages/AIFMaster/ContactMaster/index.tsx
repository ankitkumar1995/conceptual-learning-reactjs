import CheckerContactMasterPage from "./Checker";
import MakerContactMasterPage from "./Maker";
import NigoContactMasterForm from "./Nigo/NigoContactMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const ContactMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerContactMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerContactMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoContactMasterForm/>
            }
        </>
    );
};

export default ContactMasterPage;
