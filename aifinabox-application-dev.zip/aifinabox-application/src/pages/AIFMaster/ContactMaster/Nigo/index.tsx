import NigoContactMasterForm from "./NigoContactMasterForm";

const NigoContactMasterPage = () => {
    return (
        <>
            <NigoContactMasterForm/>
        </>
    );
};

export default NigoContactMasterPage;
