import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";

import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import NigoTable from "../../../components/NigoTable";
import { RootState } from "../../../../../redux/store";
import contactMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Checker/dispatchActionsProvider";
import contactMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Nigo/dispatchActionsProvider";
import contactMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/PageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import usePostContactMaster from "../../../../../hooks/api/usePostContactMaster";
import { useSelector } from "react-redux";
import { useState } from "react";

const NigoContactMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const navigate = useNavigate();

    const checkerContactMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .checkerForm
    );
    
    const nigoContactMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .nigoForm
    );

    const {
        setNigoRaised,
    } = contactMasterPageContextDispatchActionsProvider();

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .updateState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const { clientCode } = checkerContactMasterFormState;

    const { 
        checkerData,
        makerData,
        nigoMetaData
    } = nigoContactMasterFormState;

    const { 
        "clearState": clearNigoState,
        setCheckerData, 
        setMakerData, 
        setNigoMetaData 
    } = contactMasterNigoDetailsFormDispatchActionsProvider();

    const { "clearState": clearCheckerState }  = contactMasterDetailsFormDispatchActionsProvider();

    const postContactMaster = usePostContactMaster();

    const handleFormSubmit = () => {    
        let modifiedCheckerData = checkerData;
        let modifiedMakerData = makerData;

        nigoMetaData.forEach((data) => {
            const fieldName = data.field;
            const checkerValue = data.checkerEntry;
            const makerValue = data.makerEntry;

            modifiedCheckerData = {
                ...modifiedCheckerData,
                [fieldName]: checkerValue,
            };
            modifiedMakerData = {
                ...modifiedMakerData,
                [fieldName]: makerValue,
            };
        });

        setCheckerData(modifiedCheckerData);
        setMakerData(modifiedMakerData);

        postContactMaster(modifiedCheckerData, `${firstName} ${lastName}`, "0", userId, "C", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `NIGO Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "NIGO Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `NIGO Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "NIGO Entry Failed",
                });
            });
    };

    return (
        <>
            <NigoTable
                disableSubmit={alertSnackbarContext.open}
                nigoData={nigoMetaData}
                onDataChange={(nigoData) => {
                    setNigoMetaData(nigoData);
                }}
                onSubmitClicked={handleFormSubmit}
            />
        
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        clearCheckerState();
                        clearNigoState();
                        setNigoRaised(false);
                    }

                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default NigoContactMasterForm;
