import {
    ContactMasterDetails as CheckerContactMasterDetails
} from "../../../../../../redux/AifMaster/ContactMaster/Checker/initialState";
import {
    ContactMasterDetails as MakerContactMasterDetails
} from "../../../../../../redux/AifMaster/ContactMaster/Maker/initialState";

import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerContactMasterDetails, checkerFormState: CheckerContactMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerContactMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }

    return nigoData;
}
