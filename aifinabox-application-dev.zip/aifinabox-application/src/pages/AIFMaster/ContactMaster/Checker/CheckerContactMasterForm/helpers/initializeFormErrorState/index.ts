import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../../../interfaces/FieldValidation.types";

export interface FormErrorState {
    "aifCompanyName": FieldValidation;
    "aifContactNumber": FieldValidation;
    "aifContactNumberPrefix": FieldValidation;
    "aifEmailId": FieldValidation;
    "complianceOfficeContact": FieldValidation;
    "complianceOfficeDesignation": FieldValidation;
    "complianceOfficeEmailId": FieldValidation;
    "complianceOfficeName": FieldValidation;
    "clientCode": FieldValidation;
    "contactPersonName": FieldValidation;
    "spoc1ContactNumber": FieldValidation;
    "spoc1EmailId": FieldValidation;
    "spoc1Name": FieldValidation;
    "spoc2ContactNumber": FieldValidation;
    "spoc2EmailId": FieldValidation;
    "spoc2Name": FieldValidation;
    "spoc3ContactNumber": FieldValidation;
    "spoc3EmailId": FieldValidation;
    "spoc3Name": FieldValidation;
}

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "aifCompanyName": initializeFieldValidation(),
            "aifContactNumber": initializeFieldValidation(),
            "aifContactNumberPrefix": initializeFieldValidation(),
            "aifEmailId": initializeFieldValidation(),
            "clientCode": initializeFieldValidation(),
            "complianceOfficeContact": initializeFieldValidation(),
            "complianceOfficeDesignation": initializeFieldValidation(),
            "complianceOfficeEmailId": initializeFieldValidation(),
            "complianceOfficeName": initializeFieldValidation(),
            "contactPersonName": initializeFieldValidation(),
            "spoc1ContactNumber": initializeFieldValidation(),
            "spoc1EmailId": initializeFieldValidation(),
            "spoc1Name": initializeFieldValidation(),
            "spoc2ContactNumber": initializeFieldValidation(),
            "spoc2EmailId": initializeFieldValidation(),
            "spoc2Name": initializeFieldValidation(),
            "spoc3ContactNumber": initializeFieldValidation(),
            "spoc3EmailId": initializeFieldValidation(),
            "spoc3Name": initializeFieldValidation(),
        }
    );
}   

export default initializeFormErrorState;
