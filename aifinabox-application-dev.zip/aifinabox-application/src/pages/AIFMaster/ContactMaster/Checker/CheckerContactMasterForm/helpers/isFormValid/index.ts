import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.aifCompanyName.isError ||
        formErrorState.aifContactNumber.isError ||
        formErrorState.aifEmailId.isError ||
        formErrorState.complianceOfficeContact.isError ||
        formErrorState.complianceOfficeDesignation.isError ||
        formErrorState.complianceOfficeEmailId.isError ||
        formErrorState.complianceOfficeName.isError ||
        formErrorState.clientCode.isError ||
        formErrorState.contactPersonName.isError ||
        formErrorState.spoc1ContactNumber.isError ||
        formErrorState.spoc1EmailId.isError ||
        formErrorState.spoc1Name.isError ||
        formErrorState.spoc2ContactNumber.isError ||
        formErrorState.spoc2EmailId.isError ||
        formErrorState.spoc2Name.isError ||
        formErrorState.spoc3ContactNumber.isError ||
        formErrorState.spoc3EmailId.isError ||
        formErrorState.spoc3Name.isError 
    );
}

export default isFormValid;
