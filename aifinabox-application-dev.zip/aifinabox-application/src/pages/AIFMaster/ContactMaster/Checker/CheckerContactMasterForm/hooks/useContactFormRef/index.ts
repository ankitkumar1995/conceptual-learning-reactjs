import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

interface FormRef {
    [key: string]: RefObject<HTMLInputElement>;
};

function useContactFormRef(): FormRef {
    const formRef: { 
        [fieldName in Field]:  RefObject<HTMLInputElement>
    } = {
        "aifCompanyName": useRef<HTMLInputElement>(null),
        "aifContactNumber": useRef<HTMLInputElement>(null),
        "aifEmailId": useRef<HTMLInputElement>(null),
        "clientCode": useRef<HTMLInputElement>(null),
        "complianceOfficeContact": useRef<HTMLInputElement>(null),
        "complianceOfficeDesignation": useRef<HTMLInputElement>(null),
        "complianceOfficeEmailId": useRef<HTMLInputElement>(null),
        "complianceOfficeName": useRef<HTMLInputElement>(null),
        "contactPersonName": useRef<HTMLInputElement>(null),
        "spoc1ContactNumber": useRef<HTMLInputElement>(null),
        "spoc1EmailId": useRef<HTMLInputElement>(null),
        "spoc1Name": useRef<HTMLInputElement>(null),
        "spoc2ContactNumber": useRef<HTMLInputElement>(null),
        "spoc2EmailId": useRef<HTMLInputElement>(null),
        "spoc2Name": useRef<HTMLInputElement>(null),
        "spoc3ContactNumber": useRef<HTMLInputElement>(null),
        "spoc3EmailId": useRef<HTMLInputElement>(null),
        "spoc3Name": useRef<HTMLInputElement>(null)
    };

    return formRef;
}

export default useContactFormRef;
