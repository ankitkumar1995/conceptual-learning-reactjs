export type Field = 
    "aifCompanyName" |
    "aifContactNumber" |
    "aifEmailId" |
    "clientCode" |
    "complianceOfficeContact" |
    "complianceOfficeDesignation" |
    "complianceOfficeEmailId" |
    "complianceOfficeName" |
    "contactPersonName" |
    "spoc1ContactNumber" |
    "spoc1EmailId" |
    "spoc1Name" |
    "spoc2ContactNumber" |
    "spoc2EmailId" |
    "spoc2Name" |
    "spoc3ContactNumber" |
    "spoc3EmailId" |
    "spoc3Name" 
