import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import { 
    Box, 
    Grid, 
    IconButton, 
    Typography 
} from "@mui/material";
import initializeFormErrorState, { FormErrorState } from "./helpers/initializeFormErrorState";
import {
    masterSetupClearButtonStyles,
    masterSetupSubmitButtonStyles,
} from "../../../styles/ButtonStyles";
import { useEffect, useState } from "react";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXInput from "../../../../../components/FXInput";
import FXInputWithSelectInput from "../../../../../components/FXInputWithSelectInput";
import FXInputWithSelectSearchInput from "../../../../../components/FXInputWithSelectSearchInput";
import { Field } from "./interfaces/field.types";
import { FieldValidation } from "../../../../../interfaces/FieldValidation.types";
import { RootState } from "../../../../../redux/store";
import { UpdateState } from "../../../../../redux/AifMaster/ContactMaster/Update/initialState";
import contactMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Checker/dispatchActionsProvider";
import contactMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Nigo/dispatchActionsProvider";
import contactMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/PageContext/dispatchActionsProvider";
import { getNigoData } from "../../Nigo/NigoContactMasterForm/helpers/getNigoData";
import isFormComplete from "./helpers/isFormComplete";
import isFormValid from "./helpers/isFormValid";
import onBlurEmailValidator from "../../../../../validators/onBlurValidator/onBlurEmailValidator";
import { spocStyle } from "../../Maker/MakerContactMasterForm/ContactMasterStyles";
import useContactFormRef from "./hooks/useContactFormRef";
import { useNavigate } from "react-router-dom";
import usePostContactMaster from "../../../../../hooks/api/usePostContactMaster";
import { useSelector } from "react-redux";

const CheckerContactMasterForm = () => {
    const formRef = useContactFormRef();
    const navigate = useNavigate();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [isDataMatched, setIsDataMatched] = useState(false);
    const contactMasterState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .checkerForm
    );

    const nigoContactMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .nigoForm
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .updateState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const selectInputMenuItemsState = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        setNigoRaised,
    } = contactMasterPageContextDispatchActionsProvider();

    const {
        clientCode,
        contactPersonName,
        aifEmailId,
        spoc1EmailId,
        aifCompanyName,
        aifContactNumber,
        spoc1Name,
        complianceOfficeName,
        spoc1ContactNumber,
        spoc2Name,
        spoc2EmailId,
        spoc2ContactNumber,
        spoc3ContactNumber,
        spoc3EmailId,
        spoc3Name,
        complianceOfficeDesignation,
        aifContactNumberPrefix, 
        contactPersonNamePrefix,
        spoc1NamePrefix,
        spoc1ContactNumberPrefix,
        spoc2NamePrefix,
        spoc2ContactNumberPrefix,
        spoc3NamePrefix,
        spoc3ContactNumberPrefix,
        complianceOfficeContactPrefix,
        complianceOfficeNamePrefix,
        complianceOfficeContact,
        complianceOfficeEmailId
    } = contactMasterState;

    const {
        countryPhoneCodeMenuItems,
        honorificsMenuItems,
    } = selectInputMenuItemsState;

    const {
        clearState,
        setContactPersonName,
        setContactPersonNamePrefix,
        setAifContactNumber,
        setAifContactNumberPrefix,
        setAifEmailId,
        setClientCode,
        setClientType,
        setAifCompanyName,
        setComplianceOfficeContact,
        setComplianceOfficeContactPrefix,
        setComplianceOfficeEmailId,
        setComplianceOfficeDesignation,
        setComplianceOfficeName,
        setComplianceOfficeNamePrefix,
        setSpoc1ContactNumber,
        setSpoc1ContactNumberPrefix,
        setSpoc1EmailId,
        setSpoc1Name,
        setSpoc1NamePrefix,
        setSpoc2ContactNumber,
        setSpoc2ContactNumberPrefix,
        setSpoc2EmailId,
        setSpoc2Name,
        setSpoc2NamePrefix,
        setSpoc3ContactNumber,
        setSpoc3ContactNumberPrefix,
        setSpoc3EmailId,
        setSpoc3Name,
        setSpoc3NamePrefix
    } = contactMasterDetailsFormDispatchActionsProvider();

    type ContactAction = {
        [key in keyof UpdateState]: (value: string) => void;
    };

    const mapDispatchActionToKey:ContactAction = {
        "aifCompanyName": setAifCompanyName,
        "aifContactNumber": setAifContactNumber,
        "aifContactNumberPrefix": setAifContactNumberPrefix,
        "aifEmailId": setAifEmailId,
        "clientCode": setClientCode,
        "clientType": setClientType,
        "complianceOfficeContact": setComplianceOfficeContact,
        "complianceOfficeContactPrefix": setComplianceOfficeContactPrefix,
        "complianceOfficeDesignation": setComplianceOfficeDesignation,
        "complianceOfficeEmailId": setComplianceOfficeEmailId,
        "complianceOfficeName": setComplianceOfficeName,
        "complianceOfficeNamePrefix": setComplianceOfficeNamePrefix,
        "contactPersonName": setContactPersonName,
        "contactPersonNamePrefix": setContactPersonNamePrefix,
        "spoc1ContactNumber": setSpoc1ContactNumber,
        "spoc1ContactNumberPrefix": setSpoc1ContactNumberPrefix,
        "spoc1EmailId": setSpoc1EmailId,
        "spoc1Name": setSpoc1Name,
        "spoc1NamePrefix": setSpoc1NamePrefix,
        "spoc1Role": () => null,
        "spoc2ContactNumber": setSpoc2ContactNumber,
        "spoc2ContactNumberPrefix": setSpoc2ContactNumberPrefix,
        "spoc2EmailId": setSpoc2EmailId,
        "spoc2Name": setSpoc2Name,
        "spoc2NamePrefix": setSpoc2NamePrefix,
        "spoc2Role": () => null,
        "spoc3ContactNumber": setSpoc3ContactNumber,
        "spoc3ContactNumberPrefix": setSpoc3ContactNumberPrefix,
        "spoc3EmailId": setSpoc3EmailId,
        "spoc3Name": setSpoc3Name,
        "spoc3NamePrefix": setSpoc3NamePrefix,
        "spoc3Role": () => null,
        "updateFlag": () => null
    };

    const {
        setCheckerData,
        setNigoMetaData
    } = contactMasterNigoDetailsFormDispatchActionsProvider();

    const postContactMaster = usePostContactMaster();

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorStateChange = (
        field: Field,
        error: FieldValidation,
    ) => {
        setFormErrorState({...formErrorState, [field]: error});
    };

    useEffect(()=>{
        if (JSON.stringify(nigoContactMasterFormState.makerData) === JSON.stringify(contactMasterState)){
            setIsDataMatched(true);
        }
    },[contactMasterState]);

    const handleFormSubmit = () => {
        postContactMaster(contactMasterState, `${firstName} ${lastName}`, "0", userId, "C", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${clientCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    const criticalKeys = [
        "clientCode",
        "clientType",
        "complianceOfficeContact",
        "complianceOfficeContactPrefix",
        "complianceOfficeDesignation",
        "complianceOfficeEmailId",
        "complianceOfficeName",
        "complianceOfficeNamePrefix",
        "contactPersonName",
        "contactPersonNamePrefix",
        "spoc1ContactNumber",
        "spoc1ContactNumberPrefix",
        "spoc1EmailId",
        "spoc1Name",
        "spoc1NamePrefix",
        "spoc1Role",
        "aifCompanyName",
        "aifContactNumber",
        "aifContactNumberPrefix",        
        "aifEmailId",
    ];

    const handleClearState = (type = 1) => {
        if (updateState.updateFlag === '0' && type === 1){
            if (formRef["contactPersonNamePrefix"] && formRef["contactPersonNamePrefix"].current){
                formRef["contactPersonNamePrefix"].current.value = "";
            }
            mapDispatchActionToKey["contactPersonNamePrefix"]("");
            if (formRef["contactPersonName"] && formRef["contactPersonName"].current){
                formRef["contactPersonName"].current.value = "";
            }
            mapDispatchActionToKey["contactPersonName"]("");
            if (formRef["aifContactNumberPrefix"] && formRef["aifContactNumberPrefix"].current){
                formRef["aifContactNumberPrefix"].current.value = "";
            }
            mapDispatchActionToKey["aifContactNumberPrefix"]("");
            if (formRef["aifContactNumber"] && formRef["aifContactNumber"].current){
                formRef["aifContactNumber"].current.value = "";
            }
            mapDispatchActionToKey["aifContactNumber"]("");
            if (formRef["aifEmailId"] && formRef["aifEmailId"].current){
                formRef["aifEmailId"].current.value = "";
            }
            mapDispatchActionToKey["aifEmailId"]("");
            if (formRef["complianceOfficeNamePrefix"] && formRef["complianceOfficeNamePrefix"].current){
                formRef["complianceOfficeNamePrefix"].current.value = "";
            }
            mapDispatchActionToKey["complianceOfficeNamePrefix"]("");
            if (formRef["complianceOfficeName"] && formRef["complianceOfficeName"].current){
                formRef["complianceOfficeName"].current.value = "";
            }
            mapDispatchActionToKey["complianceOfficeName"]("");
            if (formRef["complianceOfficeContactPrefix"] && formRef["complianceOfficeContactPrefix"].current){
                formRef["complianceOfficeContactPrefix"].current.value = "";
            }
            mapDispatchActionToKey["complianceOfficeContactPrefix"]("");
            if (formRef["complianceOfficeContact"] && formRef["complianceOfficeContact"].current){
                formRef["complianceOfficeContact"].current.value = "";
            }
            mapDispatchActionToKey["complianceOfficeContact"]("");
            if (formRef["complianceOfficeEmailId"] && formRef["complianceOfficeEmailId"].current){
                formRef["complianceOfficeEmailId"].current.value = "";
            }
            mapDispatchActionToKey["complianceOfficeEmailId"]("");
            setFormErrorState(initializeFormErrorState);
            
        } else {
            for (const values of Object.entries(updateState)) {
                const key = values[0] as keyof UpdateState ;
                const value = values[1];
                const fieldRef = formRef[key];
                
                if (key in mapDispatchActionToKey && value && criticalKeys.includes(key)) {
                    if (fieldRef && fieldRef.current)
                        fieldRef.current.value = "";
                    mapDispatchActionToKey[key]("");
                }
                setFormErrorState(initializeFormErrorState);
            }
        }
    };

    useEffect(() => {
        setTimeout(() => handleClearState(2), 1000);
    },[]);
    
    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >

                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    handleClearState();
                                    setClientCode("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                Contact Master
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Client Code"
                        required
                        disabled
                        readOnly
                        value={clientCode}
                    />
                </Grid>

                <Grid item xs={9}>
                    <FXInput
                        label="AIF Company Name"
                        disabled
                        readOnly
                        required
                        value={aifCompanyName}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInputWithSelectInput
                        label="Contact Person Name"
                        forbidTo="namespaceapostrophe"
                        maxLength={256}
                        required
                        disabled={ updateState.updateFlag === "1" && 
                                    updateState.contactPersonName 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        textInputRef={formRef.contactPersonName}
                        onTextFieldBlur={() => handleInputFieldChange("contactPersonName", setContactPersonName)}
                        error={formErrorState.contactPersonName.isError}
                        helperText={formErrorState.contactPersonName.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("contactPersonName", error)}
                        selectInputPosition="start"
                        selectFieldValue={contactPersonNamePrefix}
                        selectFieldMenuItems={honorificsMenuItems}
                        textFieldDefaultValue={contactPersonName}
                        onSelectFieldValueChange={setContactPersonNamePrefix} 
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInputWithSelectSearchInput 
                        label="Contact Number Of AIF"
                        required
                        maxLength={20}
                        selectLabel="CountryCode"
                        forbidTo="contact-number"
                        disabled={ updateState.updateFlag === "1" && 
                                    updateState.aifContactNumber 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        textInputRef={formRef.aifContactNumber}
                        onTextFieldBlur={() => handleInputFieldChange("aifContactNumber", setAifContactNumber)}
                        error={formErrorState.aifContactNumber.isError}
                        helperText={formErrorState.aifContactNumber.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("aifContactNumber", error)}
                        selectInputPosition="start"
                        selectFieldValue={aifContactNumberPrefix}
                        selectFieldMenuItems={countryPhoneCodeMenuItems}
                        textFieldDefaultValue={aifContactNumber}
                        onSelectFieldValueChange={setAifContactNumberPrefix} 
                        masterName="contact_master"
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInput
                        label="Email ID of AIF"
                        forbidTo="email"
                        maxLength={256}
                        required
                        defaultValue={aifEmailId}
                        disabled={ updateState.updateFlag === "1" && 
                                    updateState.aifEmailId 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        inputRef={formRef.aifEmailId}
                        onBlur={() => handleInputFieldChange("aifEmailId", setAifEmailId)}
                        onBlurValidator={onBlurEmailValidator}
                        validatorOptions={{}}
                        error={formErrorState.aifEmailId.isError}
                        helperText={formErrorState.aifEmailId.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("aifEmailId", error)} 
                    />
                </Grid>

                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC1 Name"
                            forbidTo="namespaceapostrophe"
                            required
                            maxLength={256}
                            disabled={ updateState.updateFlag === "1" && 
                                    updateState.spoc1Name 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            textInputRef={formRef.spoc1Name}
                            onTextFieldBlur={() => handleInputFieldChange("spoc1Name", setSpoc1Name)}
                            error={formErrorState.spoc1Name.isError}
                            helperText={formErrorState.spoc1Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1Name", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc1NamePrefix}
                            textFieldDefaultValue={spoc1Name}
                            onSelectFieldValueChange={setSpoc1NamePrefix} 
                            disableBGColor="#cfdddd"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            label="SPOC1 Contact Number"
                            forbidTo="contact-number"
                            selectLabel="CountryCode"
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc1ContactNumber
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            required
                            maxLength={20}
                            textInputRef={formRef.spoc1ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc1ContactNumber", setSpoc1ContactNumber)}
                            error={formErrorState.spoc1ContactNumber.isError}
                            helperText={formErrorState.spoc1ContactNumber.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc1ContactNumberPrefix}
                            textFieldDefaultValue={spoc1ContactNumber}
                            onSelectFieldValueChange={setSpoc1ContactNumberPrefix} 
                            disableBGColor="#cfdddd"
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC1 Email ID"
                            forbidTo="email"
                            required
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc1EmailId 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            maxLength={256}
                            defaultValue={spoc1EmailId}
                            inputRef={formRef.spoc1EmailId}
                            onBlur={() => handleInputFieldChange("spoc1EmailId", setSpoc1EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc1EmailId.isError}
                            helperText={formErrorState.spoc1EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc1EmailId", error)} 
                        />
                    </Grid>
                </Grid>

                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC2 Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={256}
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc2Name 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            textInputRef={formRef.spoc2Name}
                            onTextFieldBlur={() => handleInputFieldChange("spoc2Name", setSpoc2Name)}
                            error={formErrorState.spoc2Name.isError}
                            helperText={formErrorState.spoc2Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2Name", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc2NamePrefix}
                            textFieldDefaultValue={spoc2Name}
                            onSelectFieldValueChange={setSpoc2NamePrefix} 
                            disableBGColor="#cfdddd"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            disabled={ updateState.updateFlag === "1" && 
                                    updateState.spoc2ContactNumber 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            label="SPOC2 Contact Number"
                            forbidTo="contact-number"
                            selectLabel="CountryCode"
                            maxLength={20}
                            textInputRef={formRef.spoc2ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc2ContactNumber", setSpoc2ContactNumber)}
                            error={formErrorState.spoc2ContactNumber.isError}
                            helperText={formErrorState.spoc2ContactNumber.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc2ContactNumberPrefix}
                            textFieldDefaultValue={spoc2ContactNumber}
                            onSelectFieldValueChange={setSpoc2ContactNumberPrefix} 
                            disableBGColor="#cfdddd"
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC2 Email ID"
                            forbidTo="email"
                            defaultValue={spoc2EmailId}
                            disabled={updateState.updateFlag === "1" && updateState.spoc2EmailId ? false : updateState.updateFlag === "0" ? false : true}
                            maxLength={256}
                            inputRef={formRef.spoc2EmailId}
                            onBlur={() => handleInputFieldChange("spoc2EmailId", setSpoc2EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc2EmailId.isError}
                            helperText={formErrorState.spoc2EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc2EmailId", error)} 
                            // {...(updateState.updateFlag === "1" && updateState.spoc2EmailId ? {} : {"defaultValue": spoc2EmailId})}
                        />
                    </Grid>
                </Grid>

                <Grid item xs={12} sx={spocStyle}>
                    <Grid item xs={4}>
                        <FXInputWithSelectInput
                            label="SPOC3 Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={256}
                            textInputRef={formRef.spoc3Name}
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc3Name 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            onTextFieldBlur={() => handleInputFieldChange("spoc3Name", setSpoc3Name)}
                            error={formErrorState.spoc3Name.isError}
                            helperText={formErrorState.spoc3Name.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3Name", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={honorificsMenuItems}
                            selectFieldValue={spoc3NamePrefix}
                            textFieldDefaultValue={spoc3Name}
                            onSelectFieldValueChange={setSpoc3NamePrefix} 
                            disableBGColor="#cfdddd"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInputWithSelectSearchInput
                            label="SPOC3 Contact Number"
                            forbidTo="contact-number"
                            selectLabel="CountryCode"
                            maxLength={20}
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc3ContactNumber 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            textInputRef={formRef.spoc3ContactNumber}
                            onTextFieldBlur={() => handleInputFieldChange("spoc3ContactNumber", setSpoc3ContactNumber)}
                            error={formErrorState.spoc3ContactNumber.isError}
                            helperText={formErrorState.spoc3ContactNumber.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3ContactNumber", error)}
                            selectInputPosition="start"
                            selectFieldMenuItems={countryPhoneCodeMenuItems}
                            selectFieldValue={spoc3ContactNumberPrefix}
                            textFieldDefaultValue={spoc3ContactNumber}
                            onSelectFieldValueChange={setSpoc3ContactNumberPrefix} 
                            disableBGColor="#cfdddd"
                            masterName="contact_master"
                        />
                    </Grid>

                    <Grid item xs={4}>
                        <FXInput
                            label="SPOC3 Email ID"
                            forbidTo="email"
                            maxLength={256}
                            defaultValue={spoc3EmailId}
                            disabled={ updateState.updateFlag === "1" && 
                            updateState.spoc3EmailId 
                                ? false : updateState.updateFlag === "0" 
                                    ? false : true}
                            inputRef={formRef.spoc3EmailId}
                            onBlur={() => handleInputFieldChange("spoc3EmailId", setSpoc3EmailId)}
                            onBlurValidator={onBlurEmailValidator}
                            validatorOptions={{}}
                            error={formErrorState.spoc3EmailId.isError}
                            helperText={formErrorState.spoc3EmailId.helperText}
                            onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("spoc3EmailId", error)}
                        />
                    </Grid>
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInputWithSelectInput
                        label="Compliance Office Name"
                        forbidTo="namespaceapostrophe"
                        maxLength={256}
                        disabled={ updateState.updateFlag === "1" && 
                        updateState.complianceOfficeName 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        textInputRef={formRef.complianceOfficeName}
                        onTextFieldBlur={() => handleInputFieldChange("complianceOfficeName", setComplianceOfficeName)}
                        required
                        error={formErrorState.complianceOfficeName.isError}
                        helperText={formErrorState.complianceOfficeName.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeName", error)}
                        selectInputPosition="start"
                        selectFieldMenuItems={honorificsMenuItems}
                        selectFieldValue={complianceOfficeNamePrefix}
                        textFieldDefaultValue={complianceOfficeName}
                        onSelectFieldValueChange={setComplianceOfficeNamePrefix} 
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInputWithSelectSearchInput
                        label="Compliance Office Contact"
                        forbidTo="contact-number"
                        selectLabel="CountryCode"
                        maxLength={20}
                        disabled={ updateState.updateFlag === "1" && 
                        updateState.complianceOfficeContact 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        textInputRef={formRef.complianceOfficeContact}
                        onTextFieldBlur={() => handleInputFieldChange("complianceOfficeContact", setComplianceOfficeContact)}
                        required
                        error={formErrorState.complianceOfficeContact.isError}
                        helperText={formErrorState.complianceOfficeContact.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeContact", error)}
                        selectInputPosition="start"
                        selectFieldMenuItems={countryPhoneCodeMenuItems}
                        textFieldDefaultValue={complianceOfficeContact}
                        selectFieldValue={complianceOfficeContactPrefix}
                        onSelectFieldValueChange={setComplianceOfficeContactPrefix} 
                        masterName="contact_master"
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInput
                        label="Compliance Office Email ID"
                        maxLength={256}
                        forbidTo="email"
                        defaultValue={complianceOfficeEmailId}
                        disabled={ updateState.updateFlag === "1" && 
                        updateState.complianceOfficeEmailId 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        inputRef={formRef.complianceOfficeEmailId}
                        onBlur={() => handleInputFieldChange("complianceOfficeEmailId", setComplianceOfficeEmailId)}
                        required
                        onBlurValidator={onBlurEmailValidator}
                        validatorOptions={{}}
                        error={formErrorState.complianceOfficeEmailId.isError}
                        helperText={formErrorState.complianceOfficeEmailId.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeEmailId", error)} 
                    />
                </Grid>

                <Grid item xs={4} mt={2}>
                    <FXInput
                        label="Compliance Office Designation"
                        required
                        maxLength={256}
                        forbidTo="alphanumeric-ws"
                        defaultValue={complianceOfficeDesignation}
                        disabled={ updateState.updateFlag === "1" && 
                        updateState.complianceOfficeDesignation 
                            ? false : updateState.updateFlag === "0" 
                                ? false : true}
                        inputRef={formRef.complianceOfficeDesignation}
                        onBlur={() => handleInputFieldChange("complianceOfficeDesignation", setComplianceOfficeDesignation)}
                        error={formErrorState.complianceOfficeDesignation.isError}
                        helperText={formErrorState.complianceOfficeDesignation.helperText}
                        onFieldErrorChange={(error: FieldValidation) => handleFieldErrorStateChange("complianceOfficeDesignation", error)} 
                    />
                </Grid>

                <Grid container rowSpacing={2} columnSpacing={2} mt={3}>
                    <Grid item xs={6} mt={3}>
                        <FXButton
                            buttonVariant="normal"
                            fullWidth
                            label="Clear"
                            onClick={() =>handleClearState(1)}
                        // sx={masterSetupClearButtonStyles}
                        />
                    </Grid>

                    <Grid item xs={6} mt={3}>
                        <FXButton
                            buttonVariant="submit"
                            disabled={
                                alertSnackbarContext.open ||
                            !(isFormValid(formErrorState)) ||
                            !(isFormComplete(contactMasterState))
                            }
                            fullWidth
                            label="Submit"
                            sx={masterSetupSubmitButtonStyles}
                            onClick={() => {
                                const nigoData = getNigoData(nigoContactMasterFormState.makerData, contactMasterState);
                            
                                if (nigoData.length !== 0) {
                                    setNigoMetaData(nigoData);
                                    setCheckerData(contactMasterState);
                                    setNigoRaised(true);
                                }
                                else {
                                    handleFormSubmit();
                                }  
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>
            
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />          
        </>
    );
};

export default CheckerContactMasterForm;
