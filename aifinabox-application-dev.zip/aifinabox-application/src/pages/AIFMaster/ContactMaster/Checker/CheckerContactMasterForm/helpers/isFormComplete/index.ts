import {
    ContactMasterDetails
} from "../../../../../../../redux/AifMaster/ContactMaster/Maker/initialState";

function isFormComplete(contactMasterForm: ContactMasterDetails): boolean {
    const {
        aifCompanyName,
        aifContactNumber,
        aifContactNumberPrefix,
        aifEmailId, 
        clientCode, 
        complianceOfficeContact, 
        complianceOfficeContactPrefix,
        complianceOfficeDesignation, 
        complianceOfficeEmailId, 
        complianceOfficeName, 
        complianceOfficeNamePrefix,
        contactPersonName,
        contactPersonNamePrefix,
        spoc1ContactNumber,
        spoc1ContactNumberPrefix,
        spoc1EmailId, 
        spoc1Name, 
        spoc1NamePrefix,
    } = contactMasterForm ;
 
    const isAifCompanyNameFilled = ( aifCompanyName.length !== 0 );
    const isAifContactNumberFilled = ( aifContactNumber.length !== 0 );
    const isAifContactNumberPrefixFilled = ( aifContactNumberPrefix.length !== 0 );
    const isAifEmailIdFilled = ( aifEmailId.length !== 0 );
    const isClientCodeFilled = ( clientCode.length !== 0 );
    const isComplianceOfficeContactFilled = ( complianceOfficeContact.length !== 0 );
    const isComplianceOfficeContactPrefixFilled = ( complianceOfficeContactPrefix.length !== 0 );
    const isComplianceOfficeDesignationFilled = ( complianceOfficeDesignation.length !== 0 );
    const isComplianceOfficeEmailIdFilled = ( complianceOfficeEmailId.length !== 0 );
    const isComplianceOfficeNameFilled = ( complianceOfficeName.length !== 0 );
    const isComplianceOfficeNamePrefixFilled = ( complianceOfficeNamePrefix.length !== 0 );
    const isContactPersonNameFilled = ( contactPersonName.length !== 0 );
    const isContactPersonNamePrefixFilled = ( contactPersonNamePrefix.length !== 0 );
    const isSpoc1ContactNumberFilled = ( spoc1ContactNumber.length !== 0 );
    const isSpoc1ContactNumberPrefixFilled = ( spoc1ContactNumberPrefix.length !== 0 );
    const isSpoc1EmailIdFilled = ( spoc1EmailId.length !== 0 );
    const isSpoc1NameFilled = ( spoc1Name.length !== 0 );
    const isSpoc1NamePrefixFilled = ( spoc1NamePrefix.length !== 0 );
    
    return (
        isAifCompanyNameFilled &&
        isAifContactNumberFilled &&
        isAifContactNumberPrefixFilled &&
        isAifEmailIdFilled &&
        isClientCodeFilled &&
        isComplianceOfficeContactFilled &&
        isComplianceOfficeContactPrefixFilled &&
        isComplianceOfficeDesignationFilled &&
        isComplianceOfficeEmailIdFilled &&
        isComplianceOfficeNameFilled &&
        isComplianceOfficeNamePrefixFilled &&
        isContactPersonNameFilled &&
        isContactPersonNamePrefixFilled &&
        isSpoc1ContactNumberFilled &&
        isSpoc1ContactNumberPrefixFilled &&
        isSpoc1EmailIdFilled &&
        isSpoc1NameFilled &&
        isSpoc1NamePrefixFilled
    );
}

export default isFormComplete;
