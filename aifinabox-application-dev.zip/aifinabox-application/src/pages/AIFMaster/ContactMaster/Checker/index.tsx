import CheckerContactMasterForm from "./CheckerContactMasterForm";
import PendingCheckerEntryItems from "./PendingCheckerEntryItems";
import { RootState } from "../../../../redux/store";
import contactMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/ContactMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerContactMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .contactMasterState
                .checkerForm
                .clientCode
    );

    const { 
        setClientCode
    } = contactMasterDetailsFormDispatchActionsProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingCheckerEntryItems/>
                    : <CheckerContactMasterForm/>
            }
        </>
    );
};

export default CheckerContactMasterPage;
