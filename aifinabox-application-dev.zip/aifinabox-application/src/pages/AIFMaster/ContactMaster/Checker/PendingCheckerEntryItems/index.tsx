import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";
import FXSelectInput from "../../../../../components/FXSelectInput";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import {
    StyledPagination
} from "../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import contactMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Checker/dispatchActionsProvider";
import contactMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ContactMaster/Nigo/dispatchActionsProvider";
import updateDispatchActionProvider from "../../../../../redux/AifMaster/ContactMaster/Update/dispatchActionProvider";
import useFetchContactMaster from "../../../../../hooks/api/useFetchContactMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const { 
        setClientCode,
        setContactMasterCheckerState,
    } = contactMasterDetailsFormDispatchActionsProvider();

    const { setMakerData } = contactMasterNigoDetailsFormDispatchActionsProvider();

    const {setIsUpdate} = updateDispatchActionProvider();

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchContactMaster = useFetchContactMaster();
    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );
    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleOnCardClick = (clientCode: string) => {
        fetchContactMaster(clientCode, "0", userId)
            .then((contactMaster) => {
                const { contactMasterMakerEntry, contactMasterMakerUpdateEntry } = contactMaster;
                setMakerData({...contactMasterMakerEntry});
                if (contactMasterMakerUpdateEntry.updateFlag === "0") {
                    contactMasterMakerEntry.complianceOfficeEmailId = "";
                    contactMasterMakerEntry.complianceOfficeContact = "";
                    contactMasterMakerEntry.complianceOfficeContactPrefix = "";
                    contactMasterMakerEntry.complianceOfficeName = "";
                    contactMasterMakerEntry.complianceOfficeNamePrefix = "";
                    contactMasterMakerEntry.contactPersonName = "";
                    contactMasterMakerEntry.contactPersonNamePrefix = "";
                    contactMasterMakerEntry.aifContactNumber = "";
                    contactMasterMakerEntry.aifContactNumberPrefix = "";
                    contactMasterMakerEntry.aifEmailId = "";
                }
                setContactMasterCheckerState(contactMasterMakerEntry);
                setIsUpdate(contactMasterMakerUpdateEntry);
                setClientCode(clientCode);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "contact_master", "C",userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page, itemCountPerPage, pageCount]);

    return (
        <>
            <Stack
                paddingBottom="20px"
            >
                <Typography variant="toDoLabel">
                    To Do
                </Typography>
            </Stack>

            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            // clientType,
                            createdBy,
                            createdOn,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName,
                                        },
                                    ]}
                                    onClick={() => handleOnCardClick(clientCode)}
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>

                <StyledPagination 
                    count={pageCount}
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
