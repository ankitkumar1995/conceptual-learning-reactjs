import { 
    Box,
    FormControl,
    Grid,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Tab, 
    Tabs, 
    Typography
} from "@mui/material";

import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem
} from "../../../../../hooks/api/useFetchRejectQueue";
import useFetchTodoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import FXButton from "../../../../../components/FXButton";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { StyledPagination } from "../PendingCheckerEntryItems/PaginationStyles";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import fundMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Checker/dispatchActionsProvider";
import fundMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Nigo/dispatchActionsProvider";
import { getNigoDataForAuditorReject } from "../../Nigo/NigoFundMasterForm/helper/getNigoData";
import { nanoid } from "@reduxjs/toolkit";
import pageContextDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/PageContext/dispatchActionsProvider";
import updateStateDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Update/dispatchActionsProvider";
import useFetchFundMaster from "../../../../../hooks/api/useFetchFundMaster";
import useFetchRejectFundMaster from "../../../../../hooks/api/useFetchRejectFundMaster";
import { useSelector } from "react-redux";


const CheckerFundMasterList = () => {
    const checkerNavigateTo = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .pageContext
                .checkerNavigateTo
    );

    const nigoFundMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .nigoForm
    );

    const fundMasterFormState = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .fundMasterState
                .checkerForm
    );



    const { setCheckerNavigateTo ,setNigoRaised} = pageContextDispatchActionsProvider();

    const [currentTab, setCurrentTab] = useState(0);
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const [tabActive, setTabActive] = useState({
        "activeToDo": true,
        "rejectedByAuditor": false,
        "rejectedByMe": false,
    });
    const {
        clearState,
        clearCriticalFieldsCheckerEntry,
        // Fund Additional Information
        setDefaulterPenality,
        setDistributionFrequency,
        setDormant,
        setDormantDate,
        setForexSource,
        setFundAdditionalFee,
        setFundCommitmentApplicability,
        setFundManagementFee,
        setFundStampDutyBorne,
        setFundTrusteeFee,
        setGoodsServiceTax,
        setGpSharingRation,
        setHighWaterMark,
        setHurdleRate,
        setHurdleStartDate,
        setIsActive,
        setNavRadioMethod,
        setOperatingExpenses,
        setPreferredRateOfReturn,
        setSetupFee,
        // Fund Basic Details 
        setCompanyCode,
        setCompanyName,
        setFundBusinessType,
        setFundCategory,
        setFundClientId,
        setFundCode,
        setFundCurrency,
        setFundDepositoryType,
        setFundDomicile,
        setFundDpId,
        setFundFaceValue,
        setFundFrom,
        setFundIsinNumber,
        setFundName,
        setFundNature,
        setFundPeriod,
        setFundPeriodSuffix,
        setFundRegistrationNumber,
        setFundShortName,
        setFundSubCategory,
        setGstin,
        setPanOrTin,
        setServiceModel,
        // Fund Specific Details
        setFundAccountantContactNumber,
        setFundAccountantContactNumberPrefix,
        setFundAccountantEmail,
        setFundAccountantName,
        setFundCustodianCode,
        setFundEndDate,
        setFundInitialContribution,
        setFundInitialContributionAmount,
        setFundInitialContributionCloseDate,
        setFundInitialContributionStartDate,
        setFundInvestmentManager,
        setFundMaturityDate,
        setFundMaxInvestors,
        setFundRtaCode,
        setFundSize,
        setFundSpecificStartDate,
        setFundSponsorName,
        setFundTrusteeName,
        setLegalAdvisorName,
        setTaxAdvisorName,
        setTransferAgentAccountantEmail,
        setTransferAgentContactNumber,
        setTransferAgentContactNumberPrefix,
        setTransferAgentName,
        // Fund Valuation Information
        setFundCurrentDate,
        setFundCurrentYearEnd,
        setFundDDNoticePeriod,
        setFundDDPenaltyCharges,
        setFundDDTreatment,
        setFundNextDate,
        setFundPLCompMethod,
        setFundPreviousDate,
        setFundPreviousYearEnd,
        setFundTopupTreatment,
        setFundValuationStartDate,
        setNavFrequency,
        setNavPubFrequency,
        setNavPublishType,
        setNextNavDate,
        setNextNavPubDate,
        setPrevNavDate,
        setPrevNavPubDate,
        setRoundDecimals,
        setRoundMethod,
        setUnitDecimals,
        setValuationSequence,
        setFundMasterCheckerStateFromMakerEntry
    } = fundMasterDetailsFormDispatchActionsProvider();

    const { setFormStage } = pageContextDispatchActionsProvider();
    const { setMakerData } = fundMasterNigoDetailsFormDispatchActionsProvider();
    const { setUpdateState } = updateStateDispatchActionsProvider();
    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchRejectFundMaster = useFetchRejectFundMaster();
    const fetchRejectedQueue = useFetchRejectQueue();
    const fetchFundMaster = useFetchFundMaster();

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const {
        setCheckerData,
        setNigoMetaData,
    } = fundMasterNigoDetailsFormDispatchActionsProvider();

    const handleTabChange = (tab: string) => {
        setTabActive({
            "activeToDo": false,
            "rejectedByAuditor": false,
            "rejectedByMe": false,
            [tab]: true,
        });
        setItemCountPerPage(5);
    };

    useEffect(()=>{
        if (checkerNavigateTo ==="auditor"){
            setTabActive({
                "activeToDo": false,
                "rejectedByAuditor": true,
                "rejectedByMe": false
            });
        }
    },[checkerNavigateTo]);

    const handleCardOnClick = (clientCode: string, fundCode: string, companyName: string, fundName: string) => {

        if (tabActive.activeToDo) {
            setCheckerNavigateTo("todo");
            fetchFundMaster(clientCode, fundCode, "C", userId)
                .then((fundMaster) => {
                    const {
                        "fundMasterFormState": fundMasterMakerState,
                        "fundMasterUpdateState": fundMasterMakerUpdateState,
                    } = fundMaster;

                    setFundMasterCheckerStateFromMakerEntry(fundMasterMakerUpdateState, fundMasterMakerState);
                    setUpdateState(fundMasterMakerUpdateState);
                    setCompanyCode(clientCode);
                    setCompanyName(companyName);
                    setFundCode(fundCode);
                    setMakerData(fundMasterMakerState);
                });
        } 
        else
        {
            setCheckerNavigateTo("auditor");

            fetchRejectFundMaster("","","",clientCode, fundCode,"fund_master","","C")
                .then((fundMaster) => {
                    const {
                        "fundMasterFormState": fundMasterData,
                        "fundMasterMakerFormState": fundMasterMakerData,
                        "fundMasterUpdateState": fundMasterMakerUpdateState,
                    } = fundMaster;

                    const nigoData =  getNigoDataForAuditorReject(fundMasterMakerData, fundMasterData);

                    if (nigoData.length !== 0) {
                        setNigoMetaData(nigoData);
                        setCheckerData(fundMasterData);
                        setNigoRaised(true);
                    } 
        
                    console.log(nigoData);  

                    setFundMasterCheckerStateFromMakerEntry(fundMasterMakerUpdateState, fundMasterData);
                    setUpdateState(fundMasterMakerUpdateState);
                    setDefaulterPenality(fundMasterData.fundAdditionalInformation.defaulterPenalty);
                    setDistributionFrequency(fundMasterData.fundAdditionalInformation.distributionFrequency);
                    setDormant(fundMasterData.fundAdditionalInformation.dormant);
                    setDormantDate(fundMasterData.fundAdditionalInformation.dormantDate);
                    setForexSource(fundMasterData.fundAdditionalInformation.forexSource);
                    setFundAdditionalFee(fundMasterData.fundAdditionalInformation.fundAdditionalFee);
                    setFundCommitmentApplicability(fundMasterData.fundAdditionalInformation.fundCommitmentApplicability);
                    setFundManagementFee(fundMasterData.fundAdditionalInformation.fundManagementFee);
                    setFundStampDutyBorne(fundMasterData.fundAdditionalInformation.fundStampDutyBorne);
                    setFundTrusteeFee(fundMasterData.fundAdditionalInformation.fundTrusteeFee);
                    setGoodsServiceTax(fundMasterData.fundAdditionalInformation.goodsServiceTax);
                    setGpSharingRation(fundMasterData.fundAdditionalInformation.gpSharingRation);
                    setHighWaterMark(fundMasterData.fundAdditionalInformation.highWaterMark);
                    setHurdleRate(fundMasterData.fundAdditionalInformation.hurdleRate);
                    setHurdleStartDate(fundMasterData.fundAdditionalInformation.hurdleStartDate);
                    setIsActive(fundMasterData.fundAdditionalInformation.isActive);
                    setNavRadioMethod(fundMasterData.fundAdditionalInformation.navRadioMethod);
                    setOperatingExpenses(fundMasterData.fundAdditionalInformation.operatingExpenses);
                    setPreferredRateOfReturn(fundMasterData.fundAdditionalInformation.preferredRateOfReturn);
                    setSetupFee(fundMasterData.fundAdditionalInformation.setupFee);
                    // Fund Basic Details 
                    setCompanyCode(fundMasterData.fundBasicDetails.companyCode);
                    setCompanyName(fundMasterData.fundBasicDetails.companyName);
                    setFundBusinessType(fundMasterData.fundBasicDetails.fundBusinessType);
                    setFundCategory(fundMasterData.fundBasicDetails.fundCategory);
                    setFundClientId(fundMasterData.fundBasicDetails.fundClientId);
                    setFundCode(fundMasterData.fundBasicDetails.fundCode);
                    setFundCurrency(fundMasterData.fundBasicDetails.fundCurrency);
                    setFundDepositoryType(fundMasterData.fundBasicDetails.fundDepositoryType);
                    setFundDomicile(fundMasterData.fundBasicDetails.fundDomicile);
                    setFundDpId(fundMasterData.fundBasicDetails.fundDpId);
                    setFundFaceValue(fundMasterData.fundBasicDetails.fundFaceValue);
                    setFundFrom(fundMasterData.fundBasicDetails.fundFrom);
                    setFundIsinNumber(fundMasterData.fundBasicDetails.fundIsinNumber);
                    setFundName(fundMasterData.fundBasicDetails.fundName);
                    setFundNature(fundMasterData.fundBasicDetails.fundNature);
                    setFundPeriod(fundMasterData.fundBasicDetails.fundPeriod);
                    setFundPeriodSuffix(fundMasterData.fundBasicDetails.fundPeriodSuffix);
                    setFundRegistrationNumber(fundMasterData.fundBasicDetails.fundRegistrationNumber);
                    setFundShortName(fundMasterData.fundBasicDetails.fundShortName);
                    setFundSubCategory(fundMasterData.fundBasicDetails.fundSubCategory);
                    setGstin(fundMasterData.fundBasicDetails.gstin);
                    setPanOrTin(fundMasterData.fundBasicDetails.panOrTin);
                    setServiceModel(fundMasterData.fundBasicDetails.serviceModel);
                    // Fund Specific Details
                    setFundAccountantContactNumber(fundMasterData.fundSpecificDetails.fundAccountantContactNumber);
                    setFundAccountantContactNumberPrefix(fundMasterData.fundSpecificDetails.fundAccountantContactNumberPrefix);
                    setFundAccountantEmail(fundMasterData.fundSpecificDetails.fundAccountantEmail);
                    setFundAccountantName(fundMasterData.fundSpecificDetails.fundAccountantName);
                    setFundCustodianCode(fundMasterData.fundSpecificDetails.fundCustodianCode);
                    setFundEndDate(fundMasterData.fundSpecificDetails.fundEndDate);
                    setFundInitialContribution(fundMasterData.fundSpecificDetails.fundInitialContribution);
                    setFundInitialContributionAmount(fundMasterData.fundSpecificDetails.fundInitialContributionAmount);
                    setFundInitialContributionCloseDate(fundMasterData.fundSpecificDetails.fundInitialContributionCloseDate);
                    setFundInitialContributionStartDate(fundMasterData.fundSpecificDetails.fundInitialContributionStartDate);
                    setFundInvestmentManager(fundMasterData.fundSpecificDetails.fundInvestmentManager);
                    setFundMaturityDate(fundMasterData.fundSpecificDetails.fundMaturityDate);
                    setFundMaxInvestors(fundMasterData.fundSpecificDetails.fundMaxInvestors);
                    setFundRtaCode(fundMasterData.fundSpecificDetails.fundRtaCode);
                    setFundSize(fundMasterData.fundSpecificDetails.fundSize);
                    setFundSpecificStartDate(fundMasterData.fundSpecificDetails.fundStartDate);
                    setFundSponsorName(fundMasterData.fundSpecificDetails.fundSponsorName);
                    setFundTrusteeName(fundMasterData.fundSpecificDetails.fundTrusteeName);
                    setLegalAdvisorName(fundMasterData.fundSpecificDetails.legalAdvisorName);
                    setTaxAdvisorName(fundMasterData.fundSpecificDetails.taxAdvisorName);
                    setTransferAgentAccountantEmail(fundMasterData.fundSpecificDetails.transferAgentAccountantEmail);
                    setTransferAgentContactNumber(fundMasterData.fundSpecificDetails.transferAgentContactNumber);
                    setTransferAgentContactNumberPrefix(fundMasterData.fundSpecificDetails.transferAgentContactNumberPrefix);
                    setTransferAgentName(fundMasterData.fundSpecificDetails.transferAgentName);
                    // Fund Valuation Information
                    setFundCurrentDate(fundMasterData.fundValuationInformation.fundCurrentDate);
                    setFundCurrentYearEnd(fundMasterData.fundValuationInformation.fundCurrentYearEnd);
                    setFundDDNoticePeriod(fundMasterData.fundValuationInformation.fundDDNoticePeriod);
                    setFundDDPenaltyCharges(fundMasterData.fundValuationInformation.fundDDPenaltyCharges);
                    setFundDDTreatment(fundMasterData.fundValuationInformation.fundDDTreatment);
                    setFundNextDate(fundMasterData.fundValuationInformation.fundNextDate);
                    setFundPLCompMethod(fundMasterData.fundValuationInformation.fundPlCompMethod);
                    setFundPreviousDate(fundMasterData.fundValuationInformation.fundPreviousDate);
                    setFundPreviousYearEnd(fundMasterData.fundValuationInformation.fundPreviousYearEnd);
                    setFundTopupTreatment(fundMasterData.fundValuationInformation.fundTopupTreatment);
                    setFundValuationStartDate(fundMasterData.fundValuationInformation.fundStartDate);
                    setNavFrequency(fundMasterData.fundValuationInformation.navFrequency);
                    setNavPubFrequency(fundMasterData.fundValuationInformation.navPubFrequency);
                    setNavPublishType(fundMasterData.fundValuationInformation.navPublishType);
                    setNextNavDate(fundMasterData.fundValuationInformation.nextNavDate);
                    setNextNavPubDate(fundMasterData.fundValuationInformation.nextNavPubDate);
                    setPrevNavDate(fundMasterData.fundValuationInformation.prevNavDate);
                    setPrevNavPubDate(fundMasterData.fundValuationInformation.prevNavPubDate);
                    setRoundDecimals(fundMasterData.fundValuationInformation.roundDecimals);
                    setRoundMethod(fundMasterData.fundValuationInformation.roundMethod);
                    setUnitDecimals(fundMasterData.fundValuationInformation.unitDecimals);
                    setValuationSequence(fundMasterData.fundValuationInformation.valuationSequence);

                    // setFormStage(8);
                });


        }
    };


    useEffect(() => {
        if (tabActive["activeToDo"]) {
            fetchCheckerQueue(itemCountPerPage, page-1, "fund_master", "C", userId)
                .then((result) => {
                    const {
                        checkerQueue,
                        pendingCheckerItemCount,
                    } = result;

                    setPendingCheckerEntryItems(checkerQueue);
                    setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
                });
        }
        else {
            const rejectedBy = tabActive["rejectedByAuditor"] ? "A" : tabActive["rejectedByMe"] ? "C" : "C";

            fetchRejectedQueue(itemCountPerPage,"",page-1, "fund_master", rejectedBy, "C",userId)
                .then((result) => {
                    const {
                        rejectQueue,
                        pendingRejectItemCount,
                    } = result;

                    setPendingRejectEntryItems(rejectQueue);
                    setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
                });
        }
    }, [page, tabActive, itemCountPerPage, pageCount, tabActive]);

    return (
        <Grid container rowSpacing={2} columnSpacing={2}>
            <Grid item xs={12}>
                {/* <Tabs 
                    value={currentTab} 
                    onChange={handleTabChange}
                    sx={{
                        "& .MuiTab-root": {
                            "&.Mui-selected": {
                                "color": "#2057A6",
                                "fontWeight": 600,
                            },
                            "color": "rgba(32, 87, 166, 0.5)",
                            "fontFamily": fontFamily,
                            "fontSize": "14px",
                            "fontWeight": 500,
                            "marginRight": "24px",
                            "minWidth": "unset",
                            "padding": "0",
                            "textTransform": "none",
                        },
                        "& .MuiTabs-indicator": {
                            "display": "none"
                        },
                    }}
                >
                    <Tab disableRipple label="To Do"  />
                    <Tab disableRipple label="Rejected By Me" />
                    <Tab disableRipple label="Rejected By Auditor"/>
                </Tabs> */}
                <Grid item xs={12} mb={3}>
                    <Grid
                        display="flex"
                    >
                        <FXButton
                            label="To Do"
                            onClick={() => handleTabChange("activeToDo")}
                            disabled={tabActive.activeToDo}
                        />

                        <FXButton
                            label="Rejected By Me"
                            onClick={() => handleTabChange("rejectedByMe")}
                            disabled={tabActive.rejectedByMe}
                        />

                        <FXButton
                            label="Rejected By Auditor"
                            onClick={() => handleTabChange("rejectedByAuditor")}
                            disabled={tabActive.rejectedByAuditor}
                        />

                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={12}>
                <>
                    <Stack 
                        direction="column" 
                        width="100%" 
                        marginBottom="20px"
                        minHeight="430px"
                    >
                        {
                            (tabActive.activeToDo? pendingCheckerEntryItems:pendingRejectEntryItems).map((pendingCheckerEntryItem) => {
                                const {
                                    clientCode,
                                    clientName,
                                    // clientType,
                                    createdBy,
                                    createdOn,
                                    fundCode,
                                    fundName,
                                    // id,
                                    rejectRemarks
                                } = pendingCheckerEntryItem;
                                const toDoData = [
                                    {
                                        "dataPartOne": clientCode,
                                        "dataPartTwo": clientName
                                    },
                                    {
                                        "dataPartOne": fundCode,
                                        "dataPartTwo": fundName,
                                    }
                                ];
            
                                const rejectedData = !tabActive["activeToDo"] 
                                    ? [
                                        {
                                            "dataPartOne": `Remarks: ${rejectRemarks}`
                                        }
                                    ] : [];

                                return (
                                    <Box key={nanoid()}>
                                        <PendingCheckerEntryItemCard
                                            createdBy={createdBy}
                                            creationDate={createdOn}
                                            data={[
                                                {
                                                    "dataPartOne": clientCode,
                                                    "dataPartTwo": clientName
                                                },
                                                {
                                                    "dataPartOne": fundCode,
                                                    "dataPartTwo": fundName,
                                                }
                                            ]}
                                            remarksData={rejectedData}
                                            onClick={() =>tabActive["rejectedByMe"]? "": handleCardOnClick(clientCode, fundCode, clientName, fundName)}
                                        />
                                    </Box>
                                );
                            })
                        }
                    </Stack>

                    {(tabActive["activeToDo"] && pendingCheckerEntryItems.length>0 || !tabActive["activeToDo"] && pendingRejectEntryItems.length>0) && <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                        <FormControl sx={{ "minWidth": "50px"}}>
                            <Stack direction="row" spacing={1} alignItems="center">
                                <Select
                                    value={itemCountPerPage.toString()}
                                    style={{ "height": "30px" }}                        
                                    onChange={(event: SelectChangeEvent) => {
                                        setItemCountPerPage(parseInt(event.target.value));
                                    }}
                                    displayEmpty
                                    inputProps={{ "aria-label": "Without label" }}
                                >
                                    <MenuItem value={5}>5</MenuItem>
                                    <MenuItem value={10}>10</MenuItem>
                                    <MenuItem value={15}>15</MenuItem>
                                </Select>
                        
                                <Typography variant="paginationRow">Rows per page</Typography>                    
                            </Stack>
                        </FormControl>

                        <Box></Box>
                
                        <StyledPagination 
                            count={pageCount} 
                            variant="outlined" 
                            shape="rounded" 
                            page={page} 
                            onChange={handleChange}
                        />
                    </Stack>}
                </>
                {/* <PendingCheckerEntryItemCard
                    createdBy="Santhosh"
                    creationDate="15/05/2023"
                    subTitle="Motilal Oswal Alternative Investment Trust"
                    titlePartOne="BCD123"
                    titlePartTwo="Trust"
                    onClick={() => setCheckerNavigateTo("form")}
                /> */}
            </Grid>
        </Grid>
    );
};

export default CheckerFundMasterList;
