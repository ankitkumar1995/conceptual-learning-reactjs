import { FundMasterDetails } from "../../../../../../redux/AifMaster/FundMaster/Maker/initialState";

const fundAdditionalInformationProgress = (fundMasterDetails: FundMasterDetails) => { 
    const fundAdditionalInformationBooleanValues: boolean[] = [];
    let progress = 0;
    let progressPercentage = 0;

    const {
        fundBasicDetails,
        fundAdditionalInformation,
    } = fundMasterDetails;

    const {
        serviceModel,
    } = fundBasicDetails;

    const {
        defaulterPenalty,
        distributionFrequency,
        dormant,
        dormantDate,
        forexSource,
        fundAdditionalFee,
        fundCommitmentApplicability,
        fundManagementFee,
        fundStampDutyBorne,
        fundTrusteeFee,
        goodsServiceTax,
        gpSharingRation,
        highWaterMark,
        hurdleRate,
        hurdleStartDate,
        isActive,
        navRadioMethod,
        operatingExpenses,
        preferredRateOfReturn,
        setupFee,
    } = fundAdditionalInformation;

    const isDormantDateFilled = (
        (dormant === "Yes")
            ? (dormantDate !== null &&
                dormantDate.length !== 0)
            : true
    ); 
    const isFundCommitmentApplicabilityFilled = ( fundCommitmentApplicability.length !== 0 );
    const isFundStampDutyBorneFilled = ( fundStampDutyBorne.length !== 0 );
    const isIsActiveFilled = ( isActive.length !== 0 );
    const isNavRadioMethodFilled = (
        (serviceModel.includes("FA"))
            ? navRadioMethod.length !== 0
            : true 
    );
    const isPreferredRateOfReturnFilled = ( preferredRateOfReturn.length !== 0 );

    if ( dormant === "Yes" )
        fundAdditionalInformationBooleanValues.push(isDormantDateFilled);
    fundAdditionalInformationBooleanValues.push(isFundCommitmentApplicabilityFilled);
    fundAdditionalInformationBooleanValues.push(isFundStampDutyBorneFilled);
    fundAdditionalInformationBooleanValues.push(isIsActiveFilled);
    if ( serviceModel.includes("FA") )
        fundAdditionalInformationBooleanValues.push(isNavRadioMethodFilled);
    fundAdditionalInformationBooleanValues.push(isPreferredRateOfReturnFilled);

    fundAdditionalInformationBooleanValues.map((value) => {
        if (value)
            progress++;
    });

    progressPercentage = (progress/fundAdditionalInformationBooleanValues.length) * 100;

    if ( progressPercentage === 0 )
        return "yetToBeStarted";

    if ( progressPercentage > 0 && progressPercentage < 100 )
        return "inProgress";

    if ( progressPercentage === 100 )
        return "complete";
};

export default fundAdditionalInformationProgress;
