import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import { 
    Box,
    Button,
    Grid,  
    IconButton,  
    Stack, 
    Typography 
} from "@mui/material";
import { 
    ChangeEvent, 
    useEffect, 
    useState 
} from "react";
import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../interfaces/FieldValidation.types";
import { 
    FundAdditionalField, 
    FundBasicField, 
    FundSpecificField, 
    FundValuationField 
} from "./interfaces/field.types";
import { 
    addNewButtonStyles, 
    masterSetupClearButtonStyles, 
    masterSetupSubmitButtonStyles, 
    updateExistingButtonStyles 
} from "../../../styles/ButtonStyles";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import useFetchClientDetails, { 
    ClientDetails 
} from "../../../../../hooks/api/useFetchClientDetails";
import useFormRef, { FormRef } from "./hooks/useFormRef";

import AddIcon from "../../../../../icons/AddIcon";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import { 
    UpdateState as CheckerUpdateState 
} from "../../../../../redux/AifMaster/FundMaster/Update/initialState";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXAutoCompleteInput from "../../../../../components/FXAutoCompleteInput";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXInput from "../../../../../components/FXInput";
import FXInputWithSelectInput from "../../../../../components/FXInputWithSelectInput";
import FXInputWithSelectSearchInput from "../../../../../components/FXInputWithSelectSearchInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectCheckboxInput from "../../../../../components/FXSelectCheckboxInput";
import FXSelectInput from "../../../../../components/FXSelectInput";
import FetchSavedRecordIcon from "../../../../../icons/FetchSavedRecordIcon";
import FundCard from "../../components/FundCard";
import RemarksPopup from "../../../../../components/FXRemarksPopup";
import { RootState } from "../../../../../redux/store";
import SaveForLaterIcon from "../../../../../icons/SaveForLaterIcon";
import { ToWords } from "to-words";
import dayjs from "dayjs";
import fundAdditionalInformationProgress from "./helper/fundAdditionalInformationProgress";
import fundBasicDetailsProgress from "./helper/fundBasicDetailsProgress";
import fundMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Checker/dispatchActionsProvider";
import fundMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Nigo/dispatchActionsProvider";
import fundSpecificDetailsProgress from "./helper/fundSpecificDetailsProgress";
import fundValuationInformationProgress from "./helper/fundValuationInformationProgress";
import { getNigoData } from "../../Nigo/NigoFundMasterForm/helper/getNigoData";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import { inrCurrencyFormatter } from "../../../../../utils/currencyFormatter";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurAmountValidator from "../../../../../validators/onBlurValidator/onBlurAmountValidator";
import onBlurCdslClientIdValidator from "../../../../../validators/onBlurValidator/onBlurCdslClientIdValidator";
import onBlurContactNumberValidator from "../../../../../validators/onBlurValidator/onBlurContactNumberValidator";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import onBlurEmailValidator from "../../../../../validators/onBlurValidator/onBlurEmailValidator";
import onBlurHighWaterMarkValidator from "../../../../../validators/onBlurValidator/onBlurHighWaterMarkValidator";
import onBlurNameValidator from "../../../../../validators/onBlurValidator/onBlurNameValidator";
import onBlurNsdlClientIdValidator from "../../../../../validators/onBlurValidator/onBlurNsdlClientIdValidator";
import onBlurNsdlDpIdValidator from "../../../../../validators/onBlurValidator/onBlurNsdlDpIdValidator";
import onBlurPanValidator from "../../../../../validators/onBlurValidator/onBlurPanValidator";
import onBlurRegistrationNumberValidator from "../../../../../validators/onBlurValidator/onBlurRegistrationNumberValidator";
import onChangePercentageValidator from "../../../../../validators/onChangeValidator/onChangePercentageValidator";
import pageContextDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/PageContext/dispatchActionsProvider";
import setFormRef from "../../utils/setFormRef";
import { useNavigate } from "react-router-dom";
import usePostFundMaster from "../../../../../hooks/api/usePostFundMaster";
import usePostRejectDetails from "../../../../../hooks/api/usePostRejectDetails";
import { useSelector } from "react-redux";

const CheckerFundMasterForm = () => {
    const formRef = useFormRef();
    const toWords = new ToWords(); 
    const navigate = useNavigate();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState());
    const [formHeading, setFormHeading] = useState("To Do - Fund Master");
    const [selectedSection, setSelectedSection] = useState("");
    const [clientDetails, setClientDetails] = useState<ClientDetails[]>();
    const [clientType, setClientType] = useState("");
    const [checkerUpdateState, setCheckerUpdateState] = useState<UpdateState>(initializeUpdateState());
    const [isDataMatched, setIsDataMatched] = useState(false);
    const [openRemarksPopup, setOpenRemarksPopup] = useState(false);
    const [openSubmitPopup, setOpenSubmitPopup] = useState(false);
    const [rejectRemarkText, setRejectRemarkText] = useState("Please - Check All Details");
    const [fundCustodianCodeValue, setFundCustodianCodeValue] = useState("");
    const formStage = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .fundMasterState
                .pageContext
                .formStage
    );
    
    const fundMasterFormState = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .fundMasterState
                .checkerForm
    );

    const nigoFundMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .nigoForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .update
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const checkerNavigateTo = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .fundMasterState
                .pageContext
                .checkerNavigateTo
    );

    const { firstName, lastName } = userContextState;

    const {setNigoRaised, setFundCustodion}  = pageContextDispatchActionsProvider();

    const {
        countryNameMenuItems,
        countryPhoneCodeMenuItems,
        currencyMenuItems,
        distributionFrequencyMenuItems,
        forexSourceMenuItems,
        fundBusinessTypeMenuItems,
        fundCategoryMenuItems,
        fundCustodianCodeMenuItems,
        fundDDTreatmentMenuItems,
        fundDepositoryTypeMenuItems,
        fundNatureMenuItems,
        fundPLCompMethodMenuItems,
        fundPeriodMenuItems,
        fundStampDutyBorneMenuItems,
        fundSubCategory1MenuItems,
        fundSubCategory2MenuItems,
        fundSubCategory3MenuItems,
        fundTopupTreatmentMenuItems,
        navRatioMethodMenuItems,
        roundMethodMenuItems,
        serviceModelMenuItems,
        valuationSequenceMenuItems,
    } = selectInputMenuItems;

    const {
        fundAdditionalInformation,
        fundBasicDetails,
        fundSpecificDetails,
        fundValuationInformation,
    } = fundMasterFormState;

    const {
        companyCode,
        companyName,
        fundBusinessType,
        fundCategory,
        fundClientId,
        fundCode,
        fundCurrency,
        fundDepositoryType,
        fundDomicile,
        fundDpId,
        fundFaceValue,
        fundFrom,
        fundIsinNumber,
        fundName,
        fundNature,
        fundPeriod,
        fundPeriodSuffix,
        fundRegistrationNumber,
        fundShortName,
        fundSubCategory,
        gstin,
        panOrTin,
        serviceModel,
    } = fundBasicDetails;

    const {
        fundAccountantContactNumber,
        fundAccountantContactNumberPrefix,
        fundAccountantEmail,
        fundAccountantName,
        fundCustodianCode,
        fundEndDate,
        fundInitialContribution,
        fundInitialContributionAmount,
        fundInitialContributionCloseDate,
        fundInitialContributionStartDate,
        fundInvestmentManager,
        fundMaturityDate,
        fundMaxInvestors,
        fundRtaCode,
        fundSize,
        fundSponsorName,
        "fundStartDate": fundSpecificStartDate,
        fundTrusteeName,
        legalAdvisorName,
        taxAdvisorName,
        transferAgentAccountantEmail,
        transferAgentContactNumber,
        transferAgentContactNumberPrefix,
        transferAgentName,
    } = fundSpecificDetails;

    const {
        fundCurrentDate,
        fundCurrentYearEnd,
        fundDDNoticePeriod,
        fundDDPenaltyCharges,
        fundDDTreatment,
        fundNextDate,
        fundPlCompMethod,
        fundPreviousDate,
        fundPreviousYearEnd,
        "fundStartDate": fundValuationStartDate,
        fundTopupTreatment,
        navFrequency,
        navPubFrequency,
        navPublishType,
        nextNavDate,
        nextNavPubDate,
        prevNavDate,
        prevNavPubDate,
        roundDecimals,
        roundMethod,
        unitDecimals,
        valuationSequence,
    } = fundValuationInformation;

    const {
        defaulterPenalty,
        distributionFrequency,
        dormant,
        dormantDate,
        forexSource,
        fundAdditionalFee,
        fundCommitmentApplicability,
        fundManagementFee,
        fundStampDutyBorne,
        fundTrusteeFee,
        goodsServiceTax,
        gpSharingRation,
        highWaterMark,
        hurdleRate,
        hurdleStartDate,
        isActive,
        navRadioMethod,
        operatingExpenses,
        preferredRateOfReturn,
        setupFee,
    } = fundAdditionalInformation;

    const {
        clearState,
        clearCriticalFieldsCheckerEntry,
        // Fund Additional Information
        setDefaulterPenality,
        setDistributionFrequency,
        setDormant,
        setDormantDate,
        setForexSource,
        setFundAdditionalFee,
        setFundCommitmentApplicability,
        setFundManagementFee,
        setFundStampDutyBorne,
        setFundTrusteeFee,
        setGoodsServiceTax,
        setGpSharingRation,
        setHighWaterMark,
        setHurdleRate,
        setHurdleStartDate,
        setIsActive,
        setNavRadioMethod,
        setOperatingExpenses,
        setPreferredRateOfReturn,
        setSetupFee,
        // Fund Basic Details 
        setCompanyCode,
        setCompanyName,
        setFundBusinessType,
        setFundCategory,
        setFundClientId,
        setFundCode,
        setFundCurrency,
        setFundDepositoryType,
        setFundDomicile,
        setFundDpId,
        setFundFaceValue,
        setFundFrom,
        setFundIsinNumber,
        setFundName,
        setFundNature,
        setFundPeriod,
        setFundPeriodSuffix,
        setFundRegistrationNumber,
        setFundShortName,
        setFundSubCategory,
        setGstin,
        setPanOrTin,
        setServiceModel,
        // Fund Specific Details
        setFundAccountantContactNumber,
        setFundAccountantContactNumberPrefix,
        setFundAccountantEmail,
        setFundAccountantName,
        setFundCustodianCode,
        setFundEndDate,
        setFundInitialContribution,
        setFundInitialContributionAmount,
        setFundInitialContributionCloseDate,
        setFundInitialContributionStartDate,
        setFundInvestmentManager,
        setFundMaturityDate,
        setFundMaxInvestors,
        setFundRtaCode,
        setFundSize,
        setFundSpecificStartDate,
        setFundSponsorName,
        setFundTrusteeName,
        setLegalAdvisorName,
        setTaxAdvisorName,
        setTransferAgentAccountantEmail,
        setTransferAgentContactNumber,
        setTransferAgentContactNumberPrefix,
        setTransferAgentName,
        // Fund Valuation Information
        setFundCurrentDate,
        setFundCurrentYearEnd,
        setFundDDNoticePeriod,
        setFundDDPenaltyCharges,
        setFundDDTreatment,
        setFundNextDate,
        setFundPLCompMethod,
        setFundPreviousDate,
        setFundPreviousYearEnd,
        setFundTopupTreatment,
        setFundValuationStartDate,
        setNavFrequency,
        setNavPubFrequency,
        setNavPublishType,
        setNextNavDate,
        setNextNavPubDate,
        setPrevNavDate,
        setPrevNavPubDate,
        setRoundDecimals,
        setRoundMethod,
        setUnitDecimals,
        setValuationSequence,
    } = fundMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerData,
        setNigoMetaData,
    } = fundMasterNigoDetailsFormDispatchActionsProvider();

    const fetchClientDetails = useFetchClientDetails();
    const postFundMaster = usePostFundMaster();
    const postRejectFundMaster = usePostRejectDetails();
    const handleClearState = () => {
        const formSectionRefKeys = Object.keys(formRef);

        formSectionRefKeys.map((formSectionRefKey) => {
            const formSectionFieldRefs = formRef[formSectionRefKey as keyof FormRef];
            const formSectionFieldRefsArray = Object.values(formSectionFieldRefs);

            formSectionFieldRefsArray.map((formSectionFieldRef) => {
                if (formSectionFieldRef && formSectionFieldRef.current)
                    formSectionFieldRef.current.value = "";
            });
        });

        clearState();
    };

    const handleClearCriticalFields = (updateState: CheckerUpdateState) => {
        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.fundName && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].fundName && formRef["FundBasicDetails"].fundName.current)
                formRef["FundBasicDetails"].fundName.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.fundFaceValue && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].fundFaceValue && formRef["FundBasicDetails"].fundFaceValue.current)
                formRef["FundBasicDetails"].fundFaceValue.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.fundRegistrationNumber && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].fundRegistrationNumber && formRef["FundBasicDetails"].fundRegistrationNumber.current)
                (formRef["FundBasicDetails"].fundRegistrationNumber.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.panOrTin && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].panOrTin && formRef["FundBasicDetails"].panOrTin.current)
                (formRef["FundBasicDetails"].panOrTin.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.fundIsinNumber && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].fundIsinNumber && formRef["FundBasicDetails"].fundIsinNumber.current)
                (formRef["FundBasicDetails"].fundIsinNumber.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundBasicDetailsUpdateState.fundDpId && updateState.updateFlag === "1")) {
            if (formRef["FundBasicDetails"].fundDpId && formRef["FundBasicDetails"].fundDpId.current)
                (formRef["FundBasicDetails"].fundDpId.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundMaxInvestors && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundMaxInvestors && formRef["FundSpecificDetails"].fundMaxInvestors.current)
                (formRef["FundSpecificDetails"].fundMaxInvestors.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundInitialContribution && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundInitialContribution && formRef["FundSpecificDetails"].fundInitialContribution.current)
                (formRef["FundSpecificDetails"].fundInitialContribution.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundSize && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundSize && formRef["FundSpecificDetails"].fundSize.current)
                (formRef["FundSpecificDetails"].fundSize.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundSponsorName && updateState.updateFlag === "1")) {        
            if (formRef["FundSpecificDetails"].fundSponsorName && formRef["FundSpecificDetails"].fundSponsorName.current)
                (formRef["FundSpecificDetails"].fundSponsorName.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundInvestmentManager && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundInvestmentManager && formRef["FundSpecificDetails"].fundInvestmentManager.current)
                (formRef["FundSpecificDetails"].fundInvestmentManager.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundTrusteeName && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundTrusteeName && formRef["FundSpecificDetails"].fundTrusteeName.current)
                (formRef["FundSpecificDetails"].fundTrusteeName.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundSpecificDetailsUpdateState.fundAccountantName && updateState.updateFlag === "1")) {
            if (formRef["FundSpecificDetails"].fundAccountantName && formRef["FundSpecificDetails"].fundAccountantName.current)
                (formRef["FundSpecificDetails"].fundAccountantName.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundValuationInformationUpdateState.unitDecimals && updateState.updateFlag === "1")) {
            if (formRef["FundValuationInformation"].unitDecimals && formRef["FundValuationInformation"].unitDecimals.current)
                (formRef["FundValuationInformation"].unitDecimals.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundValuationInformationUpdateState.roundDecimals && updateState.updateFlag === "1")) {
            if (formRef["FundValuationInformation"].roundDecimals && formRef["FundValuationInformation"].roundDecimals.current)
                (formRef["FundValuationInformation"].roundDecimals.current as HTMLInputElement).value = "";
        }
        
        if (updateState.updateFlag === "0" || (updateState.fundValuationInformationUpdateState.fundDDNoticePeriod && updateState.updateFlag === "1")) {
            if (formRef["FundValuationInformation"].fundDDNoticePeriod && formRef["FundValuationInformation"].fundDDNoticePeriod.current)
                (formRef["FundValuationInformation"].fundDDNoticePeriod.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundAdditionalInformationUpdateState.fundManagementFee && updateState.updateFlag === "1")) {
            if (formRef["FundAdditionalInformation"].fundManagementFee && formRef["FundAdditionalInformation"].fundManagementFee.current)
                (formRef["FundAdditionalInformation"].fundManagementFee.current as HTMLInputElement).value = "";
        }
         
        if (updateState.updateFlag === "0" || (updateState.fundAdditionalInformationUpdateState.setupFee && updateState.updateFlag === "1")) {
            if (formRef["FundAdditionalInformation"].setupFee && formRef["FundAdditionalInformation"].setupFee.current)
                (formRef["FundAdditionalInformation"].setupFee.current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.fundAdditionalInformationUpdateState.hurdleRate && updateState.updateFlag === "1")) {
            if (formRef["FundAdditionalInformation"].hurdleRate && formRef["FundAdditionalInformation"].hurdleRate.current)
                (formRef["FundAdditionalInformation"].hurdleRate.current as HTMLInputElement).value = "";
        }
         
        if (updateState.updateFlag === "0" || (updateState.fundAdditionalInformationUpdateState.gpSharingRation && updateState.updateFlag === "1")) {
            if (formRef["FundAdditionalInformation"].gpSharingRation && formRef["FundAdditionalInformation"].gpSharingRation.current)
                (formRef["FundAdditionalInformation"].gpSharingRation.current as HTMLInputElement).value = "";
        }

        clearCriticalFieldsCheckerEntry(updateState);
    };

    const handleInputFieldChange = (
        formSectionName: keyof FormRef,
        field: 
            FundAdditionalField |
            FundBasicField |
            FundSpecificField |
            FundValuationField, 
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[formSectionName][field];

        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFetchClientDetails = () => {
        fetchClientDetails("fund_master", "0")
            .then((result) => {
                setClientDetails(result);
            });
    };

    const handleFieldErrorChange = (
        sectionName: keyof FormErrorState,
        field: 
            FundAdditionalField |
            FundBasicField |
            FundSpecificField |
            FundValuationField,
        fieldError: FieldValidation,
    ) => {
        setFormErrorState({
            ...formErrorState,
            [sectionName]: {
                ...formErrorState[sectionName],
                [field]: fieldError,
            },
        });
    };
    
    useEffect(()=>{
        if (JSON.stringify(nigoFundMasterFormState.makerData) === JSON.stringify(fundMasterFormState)){
            setIsDataMatched(true);
        }
    },[fundMasterFormState]);

    const handleFormSubmit = () => {
        postFundMaster(fundMasterFormState, `${firstName} ${lastName}`, userId, "C", "0", clientType, checkerUpdateState)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${companyCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    const handleRejectSubmit = () => {
        setOpenRemarksPopup(false);
        //setAlertSnackbarContext(initialAlertSnackbarContext());
        postRejectFundMaster("", "", "", companyCode, fundCode, "fund_master", "", "C", rejectRemarkText, userId, `${firstName} ${lastName}`)
            .then(() => setAlertSnackbarContext({
                "description": `Checker Entry Rejected against Client Code ${companyCode}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Rejected Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Rejected Failure against
                                    Client Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Reject Failed",
                });
            });
    };

    const handleFundCommitmentApplicabilityChange = (value: string) => {
        if (value === "Open Ended")
            setFundCommitmentApplicability("No");
        else if (value === "Close Ended")
            setFundCommitmentApplicability("Yes");
        else
            setFundCommitmentApplicability(value);
    };

    useEffect(() => {
        setFormRef(formRef, fundMasterFormState);
    }, [selectedSection]);

    useEffect(() => {
        handleFetchClientDetails();
    }, []);

    useEffect(() => {
        clientDetails?.map((client) => {
            if (client.clientCode === companyCode) {
                setClientType(client.clientType);
            }
        });
    }, [companyCode]);


    useEffect(() => {
        if (parseInt(unitDecimals) < 4 || parseInt(unitDecimals) > 9) {
            setFormErrorState({
                ...formErrorState,
                "fundValuationInformationErrorState": {
                    ...formErrorState.fundValuationInformationErrorState,
                    "unitDecimals": {
                        "helperText": "Entered value should be between 4 to 9",
                        "isError": true,
                        "isVerified": false,
                        "isWarning": false,
                    }
                }
            });
        } else {
            setFormErrorState({
                ...formErrorState,
                "fundValuationInformationErrorState": {
                    ...formErrorState.fundValuationInformationErrorState,
                    "unitDecimals": initializeFieldValidation(),
                }
            });
        }
    }, [unitDecimals]);

    useEffect(() => {
        if (parseInt(roundDecimals) < 4 || parseInt(roundDecimals) > 9) {
            setFormErrorState({
                ...formErrorState,
                "fundValuationInformationErrorState": {
                    ...formErrorState.fundValuationInformationErrorState,
                    "roundDecimals": {
                        "helperText": "Entered value should be between 4 to 9",
                        "isError": true,
                        "isVerified": false,
                        "isWarning": false,
                    }
                }
            });
        } else {
            setFormErrorState({
                ...formErrorState,
                "fundValuationInformationErrorState": {
                    ...formErrorState.fundValuationInformationErrorState,
                    "roundDecimals": initializeFieldValidation(),
                }
            });
        }
    }, [roundDecimals]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={1}>
                <Grid item xs={12}>
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    handleClearState();
                                    setCompanyCode("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                {checkerNavigateTo === "todo"?`${formHeading}`:"Rejected By Auditor - Fund Master"}
                            </Typography>
                        </Box>

                        <Stack direction="row" spacing={2}>
                            {/* <Button 
                                variant="contained" 
                                size="medium"
                                startIcon={<EditIcon/>}
                                sx={updateExistingButtonStyles}
                            >
                                <Typography variant="buttonContent" display="flex">
                                    Update
                                </Typography>
                            </Button> */}
                        </Stack>
                    </Grid>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        title="Fund Basic Details"
                        progress={fundBasicDetailsProgress(fundMasterFormState)}
                        setSelectedSection={setSelectedSection}
                    >
                        <Grid item xs={3}>
                            <FXInput
                                required
                                readOnly
                                disabled
                                label="Company Code"
                                value={companyCode}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                required
                                readOnly
                                disabled
                                label="Company Name"
                                value={companyName}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                autoCapitalize
                                required
                                readOnly
                                disabled
                                label="Fund Code"
                                value={fundCode}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundFrom)}
                                label="Fund From"
                                value={fundFrom}
                                onValueChange={setFundFrom}
                                menuItems={[
                                    {
                                        "label": "Existing Fund Master Codes",
                                        "value": "Existing Fund Master Codes",
                                    }
                                ]}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundFrom", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundFrom.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundFrom.helperText}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                required
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundName)}
                                label="Fund Name"
                                maxLength={256}
                                forbidTo="alphanumeric-ws"
                                defaultValue={fundName}
                                inputRef={formRef.FundBasicDetails.fundName}
                                // onBlur={() =>
                                //     handleInputFieldChange("FundBasicDetails", "fundName", setFundName)
                                // }
                                value={fundName}
                                onValueChange={(value) =>setFundName(value)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundName", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundName.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundName.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundShortName)}
                                maxLength={50}
                                forbidTo="alphanumeric"
                                defaultValue={fundShortName}
                                label="Fund Short Name"
                                inputRef={formRef.FundBasicDetails.fundShortName}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "fundShortName", setFundShortName)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundShortName", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundShortName.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundShortName.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundDomicile)}
                                required
                                label="Fund Domicile"
                                value={fundDomicile}
                                onValueChange={setFundDomicile}
                                menuItems={countryNameMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundDomicile", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundDomicile.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundDomicile.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundBusinessType)}
                                required
                                label="Fund Business Type"
                                value={fundBusinessType}
                                onValueChange={setFundBusinessType}
                                menuItems={fundBusinessTypeMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    setFormErrorState({
                                        ...formErrorState,
                                        "fundBasicDetailsErrorState": {
                                            ...formErrorState.fundBasicDetailsErrorState,
                                            "fundBusinessType": fieldError,
                                            "panOrTin": initializeFieldValidation(),
                                        }
                                    })
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundBusinessType.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundBusinessType.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectCheckboxInput
                                required
                                label="Service Model"
                                value={serviceModel}
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.serviceModel)}
                                onValueChange={(value)=>{setServiceModel(value);
                                    
                                }}
                                menuItems={serviceModelMenuItems.slice(1)}
                                onFieldErrorChange={(fieldError) =>
                                    setFormErrorState({
                                        ...formErrorState,
                                        "fundAdditionalInformationErrorState": {
                                            ...formErrorState.fundAdditionalInformationErrorState,
                                            "navRadioMethod": initializeFieldValidation(),
                                        },
                                        "fundBasicDetailsErrorState": {
                                            ...formErrorState.fundBasicDetailsErrorState,
                                            "serviceModel": fieldError,
                                        },
                                        "fundValuationInformationErrorState": {
                                            ...formErrorState.fundValuationInformationErrorState,
                                            "fundCurrentDate": initializeFieldValidation(),
                                            "fundCurrentYearEnd": initializeFieldValidation(),
                                            "fundNextDate": initializeFieldValidation(),
                                            "fundPreviousDate": initializeFieldValidation(),
                                            "fundPreviousYearEnd": initializeFieldValidation(),
                                            "fundStartDate": initializeFieldValidation(),
                                            "navFrequency": initializeFieldValidation(),
                                            "navPubFrequency": initializeFieldValidation(),
                                            "navPublishType": initializeFieldValidation(),
                                            "nextNavDate": initializeFieldValidation(),
                                            "nextNavPubDate": initializeFieldValidation(),
                                            "prevNavDate": initializeFieldValidation(),
                                            "prevNavPubDate": initializeFieldValidation(),
                                        },
                                    })
                                }
                                error={formErrorState.fundBasicDetailsErrorState.serviceModel.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.serviceModel.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                required
                                label="Fund Category"
                                value={fundCategory}
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundCategory)}
                                onValueChange={setFundCategory}
                                menuItems={fundCategoryMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundCategory", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundCategory.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundCategory.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                required
                                label="Fund Sub Category"
                                value={fundSubCategory}
                                onValueChange={setFundSubCategory}
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundSubCategory)}
                                menuItems={
                                    (fundCategory === "Category 1")
                                        ? fundSubCategory1MenuItems
                                        : (fundCategory === "Category 2")
                                            ? fundSubCategory2MenuItems
                                            : fundSubCategory3MenuItems
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundSubCategory", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundSubCategory.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundSubCategory.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundNature)}
                                required
                                label="Fund Nature"
                                value={fundNature}
                                onValueChange={(value) => {
                                    setFundNature(value);
                                    handleFundCommitmentApplicabilityChange(value);
                                }}
                                menuItems={fundNatureMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundNature", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundNature.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundNature.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundFaceValue)}
                                required
                                maxLength={8}
                                forbidTo="numbers"
                                defaultValue={fundFaceValue}
                                label="Fund Face Value"
                                inputRef={formRef.FundBasicDetails.fundFaceValue}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "fundFaceValue", setFundFaceValue)
                                }
                                onBlurValidator={onBlurAmountValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundFaceValue", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundFaceValue.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundFaceValue.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXAutoCompleteInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundCurrency)}
                                required
                                label="Fund Currency"
                                value={fundCurrency}
                                onValueChange={setFundCurrency}
                                menuItems={currencyMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundCurrency", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundCurrency.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundCurrency.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInputWithSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundPeriod || updateState.fundBasicDetailsUpdateState.fundPeriodSuffix)}
                                maxLength={3}
                                forbidTo="numbers"
                                label="Fund Period"
                                textFieldValue={fundPeriod}
                                onTextFieldValueChange={setFundPeriod}
                                selectInputPosition="end"
                                selectFieldValue={fundPeriodSuffix}
                                selectFieldMenuItems={fundPeriodMenuItems}
                                onSelectFieldValueChange={(value) => {
                                    setFundPeriodSuffix(value);
                                    (value === "Months")
                                        ? ((parseInt(fundPeriod) * 12) > 999)
                                            ? (
                                                setFundPeriod(""),
                                                setFundPeriodSuffix("Years")
                                            )
                                            : setFundPeriod(`${parseInt(fundPeriod) * 12}`)
                                        : setFundPeriod(`${Math.floor(parseInt(fundPeriod) / 12)}`);
                                }}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundPeriod", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundPeriod.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundPeriod.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundRegistrationNumber)}
                                maxLength={256}
                                label="Fund Registration Number"
                                defaultValue={fundRegistrationNumber}
                                inputRef={formRef.FundBasicDetails.fundRegistrationNumber}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "fundRegistrationNumber", setFundRegistrationNumber)
                                }
                                onBlurValidator={onBlurRegistrationNumberValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundRegistrationNumber", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundRegistrationNumber.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundRegistrationNumber.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.panOrTin)}
                                autoCapitalize
                                maxLength={20}
                                forbidTo="alphanumeric"
                                label="PAN or TIN"
                                defaultValue={panOrTin}
                                inputRef={formRef.FundBasicDetails.panOrTin}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "panOrTin", setPanOrTin)
                                }
                                onBlurValidator={(fundBusinessType === "Domestic Fund") ? onBlurPanValidator : undefined}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "panOrTin", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.panOrTin.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.panOrTin.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                label="GSTIN"
                                forbidTo="alphanumeric"
                                maxLength={15}
                                defaultValue={gstin}
                                inputRef={formRef.FundBasicDetails.gstin}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "gstin", setGstin)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "gstin", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.gstin.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.gstin.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundIsinNumber)}
                                required
                                maxLength={12}
                                forbidTo="numbers"
                                label="Fund ISIN Number"
                                defaultValue={fundIsinNumber}
                                inputRef={formRef.FundBasicDetails.fundIsinNumber}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "fundIsinNumber", setFundIsinNumber)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundIsinNumber", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundIsinNumber.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundIsinNumber.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundDepositoryType)}
                                required
                                label="Fund Depository Type"
                                value={fundDepositoryType}
                                onValueChange={(value) => {
                                    setFundDepositoryType(value);
                                    if (value==="CDSL"){
                                        setFundDpId("");
                                        setFundClientId("");}
                                    else {
                                        setFundDpId("");
                                        setFundClientId("");
                                    } 
                                }
                                }
                                menuItems={fundDepositoryTypeMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    setFormErrorState({
                                        ...formErrorState,
                                        "fundBasicDetailsErrorState": {
                                            ...formErrorState.fundBasicDetailsErrorState,
                                            "fundClientId": initializeFieldValidation(),
                                            "fundDepositoryType": fieldError,
                                            "fundDpId": initializeFieldValidation(),
                                        },
                                    })
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundDepositoryType.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundDepositoryType.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={(updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundDpId)) || fundDepositoryType !== "NSDL"}
                                required={fundDepositoryType === "NSDL"}
                                maxLength={8}
                                forbidTo="nsdl-dp-id"
                                label="Fund DP ID"
                                defaultValue={fundDpId}
                                inputRef={formRef.FundBasicDetails.fundDpId}
                                onBlur={() =>
                                    handleInputFieldChange("FundBasicDetails", "fundDpId", setFundDpId)
                                }
                                onBlurValidator={onBlurNsdlDpIdValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundDpId", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundDpId.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundDpId.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundBasicDetailsUpdateState.fundClientId)}
                                required
                                maxLength={fundDepositoryType === "NSDL" ? 8 : 16}
                                forbidTo="numbers"
                                label="Fund Client ID"
                                defaultValue={fundClientId}
                                inputRef={formRef.FundBasicDetails.fundClientId}
                                // onBlur={() =>
                                //     handleInputFieldChange("FundBasicDetails", "fundClientId", setFundClientId)
                                // }
                                value={fundClientId}
                                onValueChange={(value)=>setFundClientId(value)}
                                onBlurValidator={fundDepositoryType === "NSDL" ? onBlurNsdlClientIdValidator : onBlurCdslClientIdValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundBasicDetailsErrorState", "fundClientId", fieldError)
                                }
                                error={formErrorState.fundBasicDetailsErrorState.fundClientId.isError}
                                helperText={formErrorState.fundBasicDetailsErrorState.fundClientId.helperText}
                            />
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        title="Fund Specific Details"
                        progress={fundSpecificDetailsProgress(fundMasterFormState)}
                        setSelectedSection={setSelectedSection}
                    >
                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundStartDate)}
                                label="Fund Start Date"
                                value={fundSpecificStartDate}
                                disableFuture
                                onValueChange={setFundSpecificStartDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": true, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundStartDate", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundStartDate.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundStartDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundInitialContributionStartDate)}
                                label="Fund Initial Contribution Start Date"
                                value={fundInitialContributionStartDate}
                                onValueChange={setFundInitialContributionStartDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundInitialContributionStartDate", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundInitialContributionStartDate.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundInitialContributionStartDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundInitialContributionCloseDate)}
                                label="Fund Initial Contribution Close Date"
                                value={fundInitialContributionCloseDate}
                                onValueChange={setFundInitialContributionCloseDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundInitialContributionCloseDate", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundInitialContributionCloseDate.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundInitialContributionCloseDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundEndDate)}
                                label="Fund End Date"
                                value={fundEndDate}
                                onValueChange={setFundEndDate}
                                disablePast
                                shouldDisableDate={(date) => 
                                    date.isSame(dayjs(), "day")
                                }
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": true, 
                                    "disablePresent": true 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundEndDate", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundEndDate.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundEndDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundMaturityDate)}
                                label="Fund Maturity Date"
                                value={fundMaturityDate}
                                onValueChange={setFundMaturityDate}
                                disablePast
                                shouldDisableDate={(date) => 
                                    date.isSame(dayjs(), "day")
                                }
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": true, 
                                    "disablePresent": true 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundMaturityDate", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundMaturityDate.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundMaturityDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundMaxInvestors)}
                                required
                                maxLength={4}
                                forbidTo="numbers"
                                label="Fund Max Investors"
                                defaultValue={fundMaxInvestors}
                                inputRef={formRef.FundSpecificDetails.fundMaxInvestors}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundMaxInvestors", setFundMaxInvestors) 
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundMaxInvestors", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundMaxInvestors.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundMaxInvestors.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundInitialContributionAmount)}
                                maxLength={21}
                                forbidTo="numbers"
                                label="Fund Initial Contribution Amount"
                                defaultValue={inrCurrencyFormatter(fundInitialContributionAmount)}
                                value={inrCurrencyFormatter(fundInitialContributionAmount)}
                                onValueChange={setFundInitialContributionAmount}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundInitialContributionAmount", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundInitialContributionAmount.isError}
                                helperText={
                                    formErrorState.fundSpecificDetailsErrorState.fundInitialContributionAmount.isError
                                        ? formErrorState.fundSpecificDetailsErrorState.fundInitialContributionAmount.helperText
                                        : (
                                            (Number(fundInitialContributionAmount) > 0) &&
                                        `${toWords.convert(Number(fundInitialContributionAmount), {"currency": true})}`
                                        )
                                }
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundInitialContribution)}
                                forbidTo="decimal-number"
                                label="Fund Initial Contribution %"
                                // defaultValue={fundInitialContribution}
                                value={fundInitialContribution}
                                inputRef={formRef.FundSpecificDetails.fundInitialContribution}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundInitialContribution", setFundInitialContribution) 
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setFundInitialContribution("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setFundInitialContribution("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setFundInitialContribution(value.substring(1));
                                    } else {
                                        setFundInitialContribution(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundInitialContribution", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundInitialContribution.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundInitialContribution.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundSize)}
                                required
                                maxLength={21}
                                forbidTo="numbers"
                                label="Fund Size (Corpus)"
                                defaultValue={inrCurrencyFormatter(fundSize)}
                                value={inrCurrencyFormatter(fundSize)}
                                onValueChange={setFundSize}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundSize", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundSize.isError}
                                helperText={
                                    formErrorState.fundSpecificDetailsErrorState.fundSize.isError
                                        ? formErrorState.fundSpecificDetailsErrorState.fundSize.helperText
                                        : (
                                            (Number(fundSize) > 0) &&
                                        `${toWords.convert(Number(fundSize), {"currency": true})}`
                                        )
                                }
                            />
                        </Grid>

                        <Grid item xs={9}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundSponsorName)}
                                maxLength={256}
                                forbidTo="singleSpace"
                                label="Fund Sponsor Name"
                                defaultValue={fundSponsorName}
                                inputRef={formRef.FundSpecificDetails.fundSponsorName}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundSponsorName", setFundSponsorName) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundSponsorName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundSponsorName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundSponsorName.helperText}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundInvestmentManager)}
                                maxLength={256}
                                forbidTo="singleSpace"
                                label="Fund Investment Manager"
                                defaultValue={fundInvestmentManager}
                                inputRef={formRef.FundSpecificDetails.fundInvestmentManager}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundInvestmentManager", setFundInvestmentManager) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundInvestmentManager", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundInvestmentManager.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundInvestmentManager.helperText}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundTrusteeName)}
                                required
                                maxLength={256}
                                forbidTo="namespaceapostrophe"
                                label="Fund Trustee Name"
                                defaultValue={fundTrusteeName}
                                inputRef={formRef.FundSpecificDetails.fundTrusteeName}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundTrusteeName", setFundTrusteeName) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundTrusteeName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundTrusteeName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundTrusteeName.helperText}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.taxAdvisorName)}
                                maxLength={256}
                                forbidTo="namespaceapostrophe"
                                label="Tax Advisor Name"
                                defaultValue={taxAdvisorName}
                                inputRef={formRef.FundSpecificDetails.taxAdvisorName}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "taxAdvisorName", setTaxAdvisorName) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "taxAdvisorName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.taxAdvisorName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.taxAdvisorName.helperText}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.legalAdvisorName)}
                                maxLength={256}
                                forbidTo="namespaceapostrophe"
                                label="Legal Advisor Name"
                                defaultValue={legalAdvisorName}
                                inputRef={formRef.FundSpecificDetails.legalAdvisorName}
                                // onBlur={() =>
                                //     handleInputFieldChange("FundSpecificDetails", "legalAdvisorName", setLegalAdvisorName) 
                                // }
                                value={legalAdvisorName}
                                onValueChange={(value)=>setLegalAdvisorName(value)}
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "legalAdvisorName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.legalAdvisorName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.legalAdvisorName.helperText}
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXAutoCompleteInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundCustodianCode)}
                                required
                                label="Fund Custodian Code"
                                value={updateState.updateFlag === "0"?fundCustodianCodeValue: (fundCustodianCodeMenuItems.includes({"label": fundCustodianCode,"value": fundCustodianCode})?fundCustodianCode:"Others")}
                                // othersOption
                                onValueChange={(value) => {
                                    setFundCustodianCodeValue(value);
                                    if (value !== "Others") {
                                        setFundCustodianCode(value);
                                    }
                                }}
                                menuItems={fundCustodianCodeMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundCustodianCode", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundCustodianCode.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundCustodianCode.helperText}
                            />
                        </Grid>

                        {
                            (fundCustodianCodeValue === "Others" || (updateState.updateFlag ==="1" && !fundCustodianCodeMenuItems.includes({"label": fundCustodianCode,"value": fundCustodianCode})))
                                ?
                                <Grid item xs={6}>
                                    <FXInput
                                        disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundCustodianCode)}
                                        label="Add Details"
                                        required={fundCustodianCodeValue === "Others"}
                                        forbidTo="name"
                                        value={fundCustodianCode}
                                        onValueChange={(value) => setFundCustodianCode(value)}
                                        onFieldErrorChange={(fieldError) =>
                                            handleFieldErrorChange("fundSpecificDetailsErrorState", "fundCustodianCode", fieldError) 
                                        }
                                        error={formErrorState.fundSpecificDetailsErrorState.fundCustodianCode.isError}
                                        helperText={formErrorState.fundSpecificDetailsErrorState.fundCustodianCode.helperText}
                                    />
                                </Grid>
                                :
                                <Grid item xs={6}>
                                    <></>
                                </Grid>
                        }

                        <Grid item xs={4}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundAccountantName)}
                                required
                                maxLength={256}
                                forbidTo="namespaceapostrophe"
                                label="Fund Accountant Name"
                                defaultValue={fundAccountantName}
                                inputRef={formRef.FundSpecificDetails.fundAccountantName}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundAccountantName", setFundAccountantName) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundAccountantName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundAccountantName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundAccountantName.helperText}
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundAccountantEmail)}
                                maxLength={256}
                                forbidTo="email"
                                label="Fund Accountant Email"
                                defaultValue={fundAccountantEmail}
                                inputRef={formRef.FundSpecificDetails.fundAccountantEmail}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundAccountantEmail", setFundAccountantEmail) 
                                }
                                onBlurValidator={onBlurEmailValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundAccountantEmail", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundAccountantEmail.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundAccountantEmail.helperText}
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInputWithSelectSearchInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundAccountantContactNumber || updateState.fundSpecificDetailsUpdateState.fundAccountantContactNumberPrefix)}
                                maxLength={10}
                                forbidTo="numbers"
                                label="Fund Accountant Contact Number"
                                textFieldDefaultValue={fundAccountantContactNumber}
                                textInputRef={formRef.FundSpecificDetails.fundAccountantContactNumber}
                                onTextFieldBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundAccountantContactNumber", setFundAccountantContactNumber)
                                }
                                onBlurValidator={onBlurContactNumberValidator}
                                validatorOptions={{}}
                                selectInputPosition="start"
                                selectFieldValue={fundAccountantContactNumberPrefix}
                                selectFieldMenuItems={countryPhoneCodeMenuItems}
                                onSelectFieldValueChange={setFundAccountantContactNumberPrefix}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundAccountantContactNumber", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundAccountantContactNumber.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundAccountantContactNumber.helperText}
                                masterName="fund_master"
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.transferAgentName)}
                                maxLength={256}
                                forbidTo="namespaceapostrophe"
                                label="Transfer Agent Name"
                                defaultValue={transferAgentName}
                                inputRef={formRef.FundSpecificDetails.transferAgentName}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "transferAgentName", setTransferAgentName) 
                                }
                                onBlurValidator={onBlurNameValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "transferAgentName", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.transferAgentName.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.transferAgentName.helperText}
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.transferAgentAccountantEmail)}
                                maxLength={256}
                                forbidTo="email"
                                label="Transfer Agent Accountant Email"
                                defaultValue={transferAgentAccountantEmail}
                                inputRef={formRef.FundSpecificDetails.transferAgentAccountantEmail}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "transferAgentAccountantEmail", setTransferAgentAccountantEmail) 
                                }
                                onBlurValidator={onBlurEmailValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "transferAgentAccountantEmail", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.transferAgentAccountantEmail.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.transferAgentAccountantEmail.helperText}
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInputWithSelectSearchInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.transferAgentContactNumber || updateState.fundSpecificDetailsUpdateState.fundAccountantContactNumberPrefix)}
                                maxLength={10}
                                forbidTo="numbers"
                                label="Transfer Agent Contact Number"
                                textFieldDefaultValue={transferAgentContactNumber}
                                textInputRef={formRef.FundSpecificDetails.transferAgentContactNumber}
                                onTextFieldBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "transferAgentContactNumber", setTransferAgentContactNumber)
                                }
                                onBlurValidator={onBlurContactNumberValidator}
                                validatorOptions={{}}
                                selectInputPosition="start"
                                selectFieldValue={transferAgentContactNumberPrefix}
                                selectFieldMenuItems={countryPhoneCodeMenuItems}
                                onSelectFieldValueChange={setTransferAgentContactNumberPrefix}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "transferAgentContactNumber", fieldError)
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.transferAgentContactNumber.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.transferAgentContactNumber.helperText}
                                masterName="fund_master"
                            />
                        </Grid>

                        <Grid item xs={4}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundSpecificDetailsUpdateState.fundRtaCode)}
                                maxLength={50} 
                                forbidTo="name"
                                label="Fund RTA Code"
                                defaultValue={fundRtaCode}
                                inputRef={formRef.FundSpecificDetails.fundRtaCode}
                                onBlur={() =>
                                    handleInputFieldChange("FundSpecificDetails", "fundRtaCode", setFundRtaCode) 
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundSpecificDetailsErrorState", "fundRtaCode", fieldError) 
                                }
                                error={formErrorState.fundSpecificDetailsErrorState.fundRtaCode.isError}
                                helperText={formErrorState.fundSpecificDetailsErrorState.fundRtaCode.helperText}
                            />
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        title="Fund Valuation Information"
                        progress={fundValuationInformationProgress(fundMasterFormState)}
                        setSelectedSection={setSelectedSection}
                    >
                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundStartDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Fund Start Date"
                                value={fundValuationStartDate}
                                onValueChange={setFundValuationStartDate}
                                disableFuture
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": true, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundStartDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundStartDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundStartDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundPreviousDate)}
                                required={serviceModel.includes("FA" )|| serviceModel.includes("TA+FA")}
                                label="Fund Previous Date"
                                value={fundPreviousDate}
                                onValueChange={setFundPreviousDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundPreviousDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundPreviousDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundPreviousDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundCurrentDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Fund Current Date"
                                value={fundCurrentDate}
                                onValueChange={setFundCurrentDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundCurrentDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundCurrentDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundCurrentDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundNextDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Fund Next Date"
                                value={fundNextDate}
                                onValueChange={setFundNextDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundNextDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundNextDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundNextDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundPreviousYearEnd)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Fund Previous Year End"
                                value={fundPreviousYearEnd}
                                onValueChange={setFundPreviousYearEnd}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundPreviousYearEnd", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundPreviousYearEnd.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundPreviousYearEnd.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundCurrentYearEnd)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Fund Current Year End"
                                value={fundCurrentYearEnd}
                                onValueChange={setFundCurrentYearEnd}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundCurrentYearEnd", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundCurrentYearEnd.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundCurrentYearEnd.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.prevNavDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Prev NAV Date"
                                value={prevNavDate}
                                onValueChange={setPrevNavDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "prevNavDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.prevNavDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.prevNavDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.navFrequency)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="NAV Frequency"
                                value={navFrequency}
                                onValueChange={setNavFrequency}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "navFrequency", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.navFrequency.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.navFrequency.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.nextNavDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Next NAV Date"
                                value={nextNavDate}
                                onValueChange={setNextNavDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "nextNavDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.nextNavDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.nextNavDate.helperText}
                            />
                        </Grid>

                        {/* <Grid item xs={3}>
                            <FXDateInput
                                required={serviceModel === "FA" || serviceModel === "TA+FA"}
                                label="Nav Publish Type"
                                value={navPublishType}
                                onValueChange={setNavPublishType}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "navPublishType", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.navPublishType.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.navPublishType.helperText}
                            />
                        </Grid> */}

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.prevNavPubDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Prev NAV Pub Date"
                                value={prevNavPubDate}
                                onValueChange={setPrevNavPubDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "prevNavPubDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.prevNavPubDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.prevNavPubDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.navPubFrequency)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="NAV Pub Frequency"
                                value={navPubFrequency}
                                onValueChange={setNavPubFrequency}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "navPubFrequency", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.navPubFrequency.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.navPubFrequency.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.nextNavPubDate)}
                                required={serviceModel.includes("FA") || serviceModel.includes("TA+FA")}
                                label="Next NAV Pub Date"
                                value={nextNavPubDate}
                                onValueChange={setNextNavPubDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "nextNavPubDate", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.nextNavPubDate.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.nextNavPubDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundPlCompMethod)}
                                required
                                label="Fund PL Comp Method"
                                value={fundPlCompMethod}
                                onValueChange={setFundPLCompMethod}
                                menuItems={fundPLCompMethodMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundPlCompMethod", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundPlCompMethod.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundPlCompMethod.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.valuationSequence)}
                                required
                                label="Valuation Sequence"
                                value={valuationSequence}
                                onValueChange={setValuationSequence}
                                menuItems={valuationSequenceMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "valuationSequence", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.valuationSequence.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.valuationSequence.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.unitDecimals)}
                                required
                                maxLength={1}
                                forbidTo="numbers"
                                label="Unit Decimals"
                                defaultValue={unitDecimals}
                                inputRef={formRef.FundValuationInformation.unitDecimals}
                                onBlur={() =>
                                    handleInputFieldChange("FundValuationInformation", "unitDecimals", setUnitDecimals)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundValuationInformationErrorState", "unitDecimals", fieldError)
                                }
                                error={formErrorState.fundValuationInformationErrorState.unitDecimals.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.unitDecimals.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.roundMethod)}
                                required
                                label="Round Method"
                                value={roundMethod}
                                onValueChange={setRoundMethod}
                                menuItems={roundMethodMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "roundMethod", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.roundMethod.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.roundMethod.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.roundDecimals)}
                                required
                                maxLength={1}
                                forbidTo="numbers"
                                label="Round Decimals"
                                defaultValue={roundDecimals}
                                inputRef={formRef.FundValuationInformation.roundDecimals}
                                onBlur={() =>
                                    handleInputFieldChange("FundValuationInformation", "roundDecimals", setRoundDecimals)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundValuationInformationErrorState", "roundDecimals", fieldError)
                                }
                                error={formErrorState.fundValuationInformationErrorState.roundDecimals.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.roundDecimals.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundDDNoticePeriod)}
                                required
                                maxLength={2}
                                forbidTo="contact-number"
                                label="Fund DD Notice Period"
                                defaultValue={fundDDNoticePeriod}
                                endAdornment={<Typography variant="endAdornmentLabel">Days</Typography>}
                                inputRef={formRef.FundValuationInformation.fundDDNoticePeriod}
                                onBlur={() =>
                                    handleInputFieldChange("FundValuationInformation", "fundDDNoticePeriod", setFundDDNoticePeriod)
                                }
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundValuationInformationErrorState", "fundDDNoticePeriod", fieldError)
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundDDNoticePeriod.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundDDNoticePeriod.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundDDPenaltyCharges)}
                                forbidTo="decimal-number"
                                label="Fund DD Penalty Charges"
                                // defaultValue={fundDDPenaltyCharges}
                                value={fundDDPenaltyCharges}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundValuationInformation.fundDDPenaltyCharges}
                                onBlur={() =>
                                    handleInputFieldChange("FundValuationInformation", "fundDDPenaltyCharges", setFundDDPenaltyCharges)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setFundDDPenaltyCharges("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setFundDDPenaltyCharges("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setFundDDPenaltyCharges(value.substring(1));
                                    } else {
                                        setFundDDPenaltyCharges(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundValuationInformationErrorState", "fundDDPenaltyCharges", fieldError)
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundDDPenaltyCharges.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundDDPenaltyCharges.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundTopupTreatment)}
                                required
                                label="Fund Topup Treatment"
                                value={fundTopupTreatment}
                                onValueChange={setFundTopupTreatment}
                                menuItems={fundTopupTreatmentMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundTopupTreatment", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundTopupTreatment.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundTopupTreatment.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundValuationInformationUpdateState.fundDDTreatment)}
                                required
                                label="Fund DD Treatment"
                                value={fundDDTreatment}
                                onValueChange={setFundDDTreatment}
                                menuItems={fundDDTreatmentMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange(
                                        "fundValuationInformationErrorState", 
                                        "fundDDTreatment", 
                                        fieldError
                                    )
                                }
                                error={formErrorState.fundValuationInformationErrorState.fundDDTreatment.isError}
                                helperText={formErrorState.fundValuationInformationErrorState.fundDDTreatment.helperText}
                            />
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        title="Fund Additional Information"
                        progress={fundAdditionalInformationProgress(fundMasterFormState)}
                        setSelectedSection={setSelectedSection}
                    >
                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.fundManagementFee)}
                                forbidTo="decimal-number"
                                label="Fund Management Fee"
                                // defaultValue={fundManagementFee}
                                value={fundManagementFee}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.fundManagementFee}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "fundManagementFee", setFundManagementFee)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setFundManagementFee("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setFundManagementFee("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setFundManagementFee(value.substring(1));
                                    } else {
                                        setFundManagementFee(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "fundManagementFee", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.fundManagementFee.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.fundManagementFee.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.fundAdditionalFee)}
                                forbidTo="decimal-number"
                                label="Fund Additional Fee"
                                defaultValue={fundAdditionalFee}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.fundAdditionalFee}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "fundAdditionalFee", setFundAdditionalFee)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setFundAdditionalFee("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setFundAdditionalFee("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setFundAdditionalFee(value.substring(1));
                                    } else {
                                        setFundAdditionalFee(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "fundAdditionalFee", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.fundAdditionalFee.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.fundAdditionalFee.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.setupFee)}
                                forbidTo="decimal-number"
                                label="Setup Fee"
                                defaultValue={setupFee}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.setupFee}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "setupFee", setSetupFee)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setSetupFee("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setSetupFee("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setSetupFee(value.substring(1));
                                    } else {
                                        setSetupFee(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "setupFee", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.setupFee.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.setupFee.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.fundTrusteeFee)}
                                forbidTo="decimal-number"
                                label="Fund Trustee Fee"
                                // defaultValue={fundTrusteeFee}
                                value={fundTrusteeFee}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.fundTrusteeFee}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "fundTrusteeFee", setFundTrusteeFee)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setFundTrusteeFee("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setFundTrusteeFee("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setFundTrusteeFee(value.substring(1));
                                    } else {
                                        setFundTrusteeFee(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "fundTrusteeFee", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.fundTrusteeFee.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.fundTrusteeFee.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.operatingExpenses)}
                                forbidTo="decimal-number"
                                label="Operating Expenses"
                                // defaultValue={operatingExpenses}
                                value={operatingExpenses}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.operatingExpenses}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "operatingExpenses", setOperatingExpenses)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setOperatingExpenses("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setOperatingExpenses("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setOperatingExpenses(value.substring(1));
                                    } else {
                                        setOperatingExpenses(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "operatingExpenses", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.operatingExpenses.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.operatingExpenses.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.goodsServiceTax)}
                                forbidTo="decimal-number"
                                label="Goods & Service Tax"
                                // defaultValue={goodsServiceTax}
                                value={goodsServiceTax}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.goodsServiceTax}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "goodsServiceTax", setGoodsServiceTax)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setGoodsServiceTax("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setGoodsServiceTax("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setGoodsServiceTax(value.substring(1));
                                    } else {
                                        setGoodsServiceTax(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "goodsServiceTax", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.goodsServiceTax.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.goodsServiceTax.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.defaulterPenalty)}
                                forbidTo="decimal-number"
                                label="Defaulter Penalty"
                                // defaultValue={defaulterPenalty}
                                value={defaulterPenalty}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.defaulterPenalty}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "defaulterPenalty", setDefaulterPenality)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setDefaulterPenality("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setDefaulterPenality("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setDefaulterPenality(value.substring(1));
                                    } else {
                                        setDefaulterPenality(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "defaulterPenalty", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.defaulterPenalty.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.defaulterPenalty.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXRadioGroup
                                disabled={
                                    fundNature === "Open Ended" || 
                                    fundNature === "Close Ended" ||
                                    (updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.fundCommitmentApplicability))
                                }
                                row
                                required
                                label="Fund Commitment Applicability"
                                value={fundCommitmentApplicability}
                                onValueChange={setFundCommitmentApplicability}
                                radioButtonValues={[
                                    {
                                        "label": "Yes",
                                        "value": "Yes",
                                    },
                                    {
                                        "label": "No",
                                        "value": "No",
                                    }    
                                ]}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXRadioGroup
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.preferredRateOfReturn)}
                                row
                                required
                                label="Preferred Rate Of Return"
                                value={preferredRateOfReturn}
                                onValueChange={setPreferredRateOfReturn}
                                radioButtonValues={[
                                    {
                                        "label": "Yes",
                                        "value": "Yes",
                                    },
                                    {
                                        "label": "No",
                                        "value": "No",
                                    }    
                                ]}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.hurdleRate)}
                                forbidTo="decimal-number"
                                label="Hurdle Rate"
                                // defaultValue={hurdleRate}
                                value={hurdleRate}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.hurdleRate}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "hurdleRate", setHurdleRate)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setHurdleRate("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setHurdleRate("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setHurdleRate(value.substring(1));
                                    } else {
                                        setHurdleRate(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "hurdleRate", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.hurdleRate.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.hurdleRate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.highWaterMark)}
                                forbidTo="decimal-number"
                                label="High Water Mark"
                                defaultValue={highWaterMark}
                                inputRef={formRef.FundAdditionalInformation.highWaterMark}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "highWaterMark", setHighWaterMark)
                                }
                                onBlurValidator={onBlurHighWaterMarkValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "highWaterMark", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.highWaterMark.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.highWaterMark.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.hurdleStartDate)}
                                label="Hurdle Start Date"
                                value={hurdleStartDate}
                                onValueChange={setHurdleStartDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "hurdleStartDate", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.hurdleStartDate.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.hurdleStartDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXInput
                                rightIndent
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.gpSharingRation)}
                                forbidTo="decimal-number"
                                label="GP Sharing Ration"
                                // defaultValue={gpSharingRation}
                                value={gpSharingRation}
                                endAdornment={<Typography variant="endAdornmentLabel">%</Typography>}
                                inputRef={formRef.FundAdditionalInformation.gpSharingRation}
                                onBlur={() =>
                                    handleInputFieldChange("FundAdditionalInformation", "gpSharingRation", setGpSharingRation)
                                }
                                onValueChange={(value) => {
                                    if (value === "0.00") {
                                        setGpSharingRation("0");
                                    } else if (/^\.\d+/.test(value)) {
                                        setGpSharingRation("0"+value);
                                    }  else if (/^0\d/.test(value)) {
                                        setGpSharingRation(value.substring(1));
                                    } else {
                                        setGpSharingRation(value); 
                                    }}
                                }
                                onChangeValidator={onChangePercentageValidator}
                                validatorOptions={{}}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "gpSharingRation", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.gpSharingRation.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.gpSharingRation.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.distributionFrequency)}
                                label="Distribution Frequency"
                                value={distributionFrequency}
                                onValueChange={setDistributionFrequency}
                                menuItems={distributionFrequencyMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "distributionFrequency", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.distributionFrequency.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.distributionFrequency.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.forexSource)}
                                label="Forex Source"
                                value={forexSource}
                                onValueChange={setForexSource}
                                menuItems={forexSourceMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "forexSource", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.forexSource.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.forexSource.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.navRadioMethod)}
                                required={serviceModel.includes("FA")}
                                label="NAV Ratio Method"
                                value={navRadioMethod}
                                onValueChange={setNavRadioMethod}
                                menuItems={navRatioMethodMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "navRadioMethod", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.navRadioMethod.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.navRadioMethod.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXRadioGroup
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.isActive)}
                                row
                                required
                                label="Is Active"
                                value={isActive}
                                onValueChange={setIsActive}
                                radioButtonValues={[
                                    {
                                        "label": "Yes",
                                        "value": "Yes",
                                    },
                                    {
                                        "label": "No",
                                        "value": "No",
                                    }    
                                ]}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXRadioGroup
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.dormant)}
                                row
                                label="Dormant"
                                value={dormant}
                                onValueChange={(value) => {
                                    setDormant(value);
                                    setFormErrorState({
                                        ...formErrorState,
                                        "fundAdditionalInformationErrorState": {
                                            ...formErrorState.fundAdditionalInformationErrorState,
                                            "dormantDate": initializeFieldValidation(),
                                        },
                                    });
                                }}
                                radioButtonValues={[
                                    {
                                        "label": "Yes",
                                        "value": "Yes",
                                    },
                                    {
                                        "label": "No",
                                        "value": "No",
                                    }    
                                ]}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXDateInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.dormantDate)}
                                required={dormant === "Yes"}
                                label="Dormant Date"
                                value={dormantDate}
                                onValueChange={setDormantDate}
                                onBlurValidator={onBlurDateValidator}
                                validatorOptions={{
                                    "disableFuture": false, 
                                    "disablePast": false, 
                                    "disablePresent": false 
                                }}
                                onFieldValidationChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "dormantDate", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.dormantDate.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.dormantDate.helperText}
                            />
                        </Grid>

                        <Grid item xs={3}>
                            <FXSelectInput
                                disabled={updateState.updateFlag === "1" && !(updateState.fundAdditionalInformationUpdateState.fundStampDutyBorne)}
                                required
                                label="Fund Stamp Duty Borne"
                                value={fundStampDutyBorne}
                                onValueChange={setFundStampDutyBorne}
                                menuItems={fundStampDutyBorneMenuItems}
                                onFieldErrorChange={(fieldError) =>
                                    handleFieldErrorChange("fundAdditionalInformationErrorState", "fundStampDutyBorne", fieldError)
                                }
                                error={formErrorState.fundAdditionalInformationErrorState.fundStampDutyBorne.isError}
                                helperText={formErrorState.fundAdditionalInformationErrorState.fundStampDutyBorne.helperText}
                            />
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={4}>
                    <FXButton 
                        disableRipple
                        label="Reject" 
                        buttonVariant="submit" 
                        fullWidth
                        onClick={() => setOpenRemarksPopup(true)}
                        disabled={alertSnackbarContext.open}
                    />
                </Grid>
                <Grid item xs={4}>
                    <FXButton
                        disableRipple
                        fullWidth
                        buttonVariant="normal"
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        label="Clear"
                        onClick={() => handleClearCriticalFields(updateState)}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXButton
                        disableRipple
                        fullWidth
                        buttonVariant="submit"
                        label="Submit"
                        endIcon={<ArrowForwardIosIcon />}
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        disabled={
                            alertSnackbarContext.open || 
                            !isFormComplete(fundMasterFormState) ||
                            !isFormValid(formErrorState) 
                        }
                        onClick={() => {
                            const nigoData = 
                                (formStage === 8)
                                    ? []
                                    : getNigoData(nigoFundMasterFormState.makerData, fundMasterFormState);

                            if (nigoData.length !== 0) {
                                setNigoMetaData(nigoData);
                                setCheckerData(fundMasterFormState);
                                setNigoRaised(true);
                            } else {
                                handleFormSubmit();
                            }
                        }}
                    />
                </Grid>
            </Grid>

            <RemarksPopup 
                open={openRemarksPopup}
                isDisabled={rejectRemarkText.length===0 || !rejectRemarkText}
                onCancelClick={() => {
                    setOpenRemarksPopup(false);
                    setRejectRemarkText("");
                }}
                onSubmitClick={() =>
                    handleRejectSubmit()
                }
                rejectRemarkText={rejectRemarkText}
                setRejectRemarkText={setRejectRemarkText}  
            />

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default CheckerFundMasterForm;
