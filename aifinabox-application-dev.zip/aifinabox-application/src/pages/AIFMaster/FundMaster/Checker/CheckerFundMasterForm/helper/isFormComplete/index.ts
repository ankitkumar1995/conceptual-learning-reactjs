import { 
    FundMasterDetails 
} from "../../../../../../../redux/AifMaster/FundMaster/Maker/initialState";
import fundAdditionalInformationProgress from "../fundAdditionalInformationProgress";
import fundBasicDetailsProgress from "../fundBasicDetailsProgress";
import fundSpecificDetailsProgress from "../fundSpecificDetailsProgress";
import fundValuationInformationProgress from "../fundValuationInformationProgress";

function isFormComplete(fundMasterDetails: FundMasterDetails): boolean {
    const isFundAdditionalInformationComplete = fundAdditionalInformationProgress(fundMasterDetails);
    const isFundBasicDetailsComplete = fundBasicDetailsProgress(fundMasterDetails);
    const isFundSpecificDetailsComplete = fundSpecificDetailsProgress(fundMasterDetails);
    const isFundValuationInformationComplete = fundValuationInformationProgress(fundMasterDetails);

    if (
        isFundAdditionalInformationComplete === "complete" &&
        isFundBasicDetailsComplete === "complete" &&
        isFundSpecificDetailsComplete === "complete" &&
        isFundValuationInformationComplete === "complete"
    )
        return true;
    
    return false;
}

export default isFormComplete;
