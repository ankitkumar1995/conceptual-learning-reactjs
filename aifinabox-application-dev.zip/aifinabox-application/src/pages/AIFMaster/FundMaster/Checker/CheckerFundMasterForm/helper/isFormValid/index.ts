import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    const {
        fundAdditionalInformationErrorState,
        fundBasicDetailsErrorState,
        fundSpecificDetailsErrorState,
        fundValuationInformationErrorState,
    } = formErrorState;

    return !(
        fundAdditionalInformationErrorState.defaulterPenalty.isError ||
        fundAdditionalInformationErrorState.distributionFrequency.isError ||
        fundAdditionalInformationErrorState.dormant.isError ||
        fundAdditionalInformationErrorState.dormantDate.isError ||
        fundAdditionalInformationErrorState.forexSource.isError ||
        fundAdditionalInformationErrorState.fundAdditionalFee.isError ||
        fundAdditionalInformationErrorState.fundCommitmentApplicability.isError ||
        fundAdditionalInformationErrorState.fundManagementFee.isError ||
        fundAdditionalInformationErrorState.fundStampDutyBorne.isError ||
        fundAdditionalInformationErrorState.fundTrusteeFee.isError ||
        fundAdditionalInformationErrorState.goodsServiceTax.isError ||
        fundAdditionalInformationErrorState.gpSharingRation.isError ||
        fundAdditionalInformationErrorState.highWaterMark.isError ||
        fundAdditionalInformationErrorState.hurdleRate.isError ||
        fundAdditionalInformationErrorState.hurdleStartDate.isError ||
        fundAdditionalInformationErrorState.isActive.isError ||
        fundAdditionalInformationErrorState.navRadioMethod.isError ||
        fundAdditionalInformationErrorState.operatingExpenses.isError ||
        fundAdditionalInformationErrorState.preferredRateOfReturn.isError ||
        fundAdditionalInformationErrorState.setupFee.isError ||

        fundBasicDetailsErrorState.companyCode.isError ||
        fundBasicDetailsErrorState.companyName.isError ||
        fundBasicDetailsErrorState.fundBusinessType.isError ||
        fundBasicDetailsErrorState.fundCategory.isError ||
        fundBasicDetailsErrorState.fundClientId.isError ||
        fundBasicDetailsErrorState.fundCode.isError ||
        fundBasicDetailsErrorState.fundCurrency.isError ||
        fundBasicDetailsErrorState.fundDepositoryType.isError ||
        fundBasicDetailsErrorState.fundDomicile.isError ||
        fundBasicDetailsErrorState.fundDpId.isError ||
        fundBasicDetailsErrorState.fundFaceValue.isError ||
        fundBasicDetailsErrorState.fundFrom.isError ||
        fundBasicDetailsErrorState.fundIsinNumber.isError ||
        fundBasicDetailsErrorState.fundName.isError ||
        fundBasicDetailsErrorState.fundNature.isError ||
        fundBasicDetailsErrorState.fundPeriod.isError ||
        fundBasicDetailsErrorState.fundPeriodSuffix.isError ||
        fundBasicDetailsErrorState.fundRegistrationNumber.isError ||
        fundBasicDetailsErrorState.fundShortName.isError ||
        fundBasicDetailsErrorState.fundSubCategory.isError ||
        fundBasicDetailsErrorState.gstin.isError ||
        fundBasicDetailsErrorState.panOrTin.isError ||
        fundBasicDetailsErrorState.serviceModel.isError ||

        fundSpecificDetailsErrorState.fundAccountantContactNumber.isError ||
        fundSpecificDetailsErrorState.fundAccountantContactNumberPrefix.isError ||
        fundSpecificDetailsErrorState.fundAccountantEmail.isError ||
        fundSpecificDetailsErrorState.fundAccountantName.isError ||
        fundSpecificDetailsErrorState.fundCustodianCode.isError ||
        fundSpecificDetailsErrorState.fundEndDate.isError ||
        fundSpecificDetailsErrorState.fundInitialContribution.isError ||
        fundSpecificDetailsErrorState.fundInitialContributionAmount.isError ||
        fundSpecificDetailsErrorState.fundInitialContributionCloseDate.isError ||
        fundSpecificDetailsErrorState.fundInitialContributionStartDate.isError ||
        fundSpecificDetailsErrorState.fundInvestmentManager.isError ||
        fundSpecificDetailsErrorState.fundMaturityDate.isError ||
        fundSpecificDetailsErrorState.fundMaxInvestors.isError ||
        fundSpecificDetailsErrorState.fundRtaCode.isError ||
        fundSpecificDetailsErrorState.fundSize.isError ||
        fundSpecificDetailsErrorState.fundSponsorName.isError ||
        fundSpecificDetailsErrorState.fundStartDate.isError ||
        fundSpecificDetailsErrorState.fundTrusteeName.isError ||
        fundSpecificDetailsErrorState.legalAdvisorName.isError ||
        fundSpecificDetailsErrorState.taxAdvisorName.isError ||
        fundSpecificDetailsErrorState.transferAgentAccountantEmail.isError ||
        fundSpecificDetailsErrorState.transferAgentContactNumber.isError ||
        fundSpecificDetailsErrorState.transferAgentContactNumberPrefix.isError ||
        fundSpecificDetailsErrorState.transferAgentName.isError ||

        fundValuationInformationErrorState.fundCurrentDate.isError ||
        fundValuationInformationErrorState.fundCurrentYearEnd.isError ||
        fundValuationInformationErrorState.fundDDNoticePeriod.isError ||
        fundValuationInformationErrorState.fundDDPenaltyCharges.isError ||
        fundValuationInformationErrorState.fundDDTreatment.isError ||
        fundValuationInformationErrorState.fundNextDate.isError ||
        fundValuationInformationErrorState.fundPlCompMethod.isError ||
        fundValuationInformationErrorState.fundPreviousDate.isError ||
        fundValuationInformationErrorState.fundPreviousYearEnd.isError ||
        fundValuationInformationErrorState.fundStartDate.isError ||
        fundValuationInformationErrorState.fundTopupTreatment.isError ||
        fundValuationInformationErrorState.navFrequency.isError ||
        fundValuationInformationErrorState.navPubFrequency.isError ||
        fundValuationInformationErrorState.navPublishType.isError ||
        fundValuationInformationErrorState.nextNavDate.isError ||
        fundValuationInformationErrorState.nextNavPubDate.isError ||
        fundValuationInformationErrorState.prevNavDate.isError ||
        fundValuationInformationErrorState.prevNavPubDate.isError ||
        fundValuationInformationErrorState.roundDecimals.isError ||
        fundValuationInformationErrorState.roundMethod.isError ||
        fundValuationInformationErrorState.unitDecimals.isError ||
        fundValuationInformationErrorState.valuationSequence.isError
    );
}

export default isFormValid;
