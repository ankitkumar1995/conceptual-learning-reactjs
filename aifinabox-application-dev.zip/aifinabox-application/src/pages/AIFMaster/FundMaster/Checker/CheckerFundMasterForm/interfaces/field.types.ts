export type FundAdditionalField =
    "defaulterPenalty" |
    "distributionFrequency" |
    "dormant" |
    "dormantDate" |
    "forexSource" |
    "fundAdditionalFee" |
    "fundCommitmentApplicability" |
    "fundManagementFee" |
    "fundStampDutyBorne" |
    "fundTrusteeFee" |
    "goodsServiceTax" |
    "gpSharingRation" |
    "highWaterMark" |
    "hurdleRate" |
    "hurdleStartDate" |
    "isActive" |
    "navRadioMethod" |
    "operatingExpenses" |
    "preferredRateOfReturn" |
    "setupFee";

export type FundBasicField = 
    "companyCode" |
    "companyName" |
    "fundBusinessType" |
    "fundCategory" |
    "fundClientId" |
    "fundCode" |
    "fundCurrency" |
    "fundDepositoryType" |
    "fundDomicile" |
    "fundDpId" |
    "fundFaceValue" |
    "fundFrom" |
    "fundIsinNumber" |
    "fundName" |
    "fundNature" |
    "fundPeriod" |
    "fundPeriodSuffix" |
    "fundRegistrationNumber" |
    "fundShortName" |
    "fundSubCategory" |
    "gstin" |
    "panOrTin" |
    "serviceModel";

export type FundSpecificField =
    "fundAccountantContactNumber" |
    "fundAccountantContactNumberPrefix" |
    "fundAccountantEmail" |
    "fundAccountantName" |
    "fundCustodianCode" |
    "fundEndDate" |
    "fundInitialContribution" |
    "fundInitialContributionAmount" |
    "fundInitialContributionCloseDate" |
    "fundInitialContributionStartDate" |
    "fundInvestmentManager" |
    "fundMaturityDate" |
    "fundMaxInvestors" |
    "fundRtaCode" |
    "fundSize" |
    "fundSponsorName" |
    "fundStartDate" |
    "fundTrusteeName" |
    "legalAdvisorName" |
    "taxAdvisorName" |
    "transferAgentAccountantEmail" |
    "transferAgentContactNumber" |
    "transferAgentContactNumberPrefix" |
    "transferAgentName";

export type FundValuationField =
    "fundCurrentDate" |
    "fundCurrentYearEnd" |
    "fundDDNoticePeriod" |
    "fundDDPenaltyCharges" |
    "fundDDTreatment" |
    "fundNextDate" |
    "fundPlCompMethod" |
    "fundPreviousDate" |
    "fundPreviousYearEnd" |
    "fundStartDate" |
    "fundTopupTreatment" |
    "navFrequency" |
    "navPubFrequency" |
    "navPublishType" |
    "nextNavDate" |
    "nextNavPubDate" |
    "prevNavDate" |
    "prevNavPubDate" |
    "roundDecimals" |
    "roundMethod" |
    "unitDecimals" |
    "valuationSequence"; 

export type FundBasicUpdateField = 
    "fundBusinessType" |
    "fundCategory" |
    "fundClientId" |
    "fundCurrency" |
    "fundDepositoryType" |
    "fundDomicile" |
    "fundDpId" |
    "fundFaceValue" |
    "fundFrom" |
    "fundIsinNumber" |
    "fundName" |
    "fundNature" |
    "fundPeriod" |
    "fundPeriodSuffix" |
    "fundRegistrationNumber" |
    "fundShortName" |
    "fundSubCategory" |
    "panOrTin" |
    "serviceModel";
