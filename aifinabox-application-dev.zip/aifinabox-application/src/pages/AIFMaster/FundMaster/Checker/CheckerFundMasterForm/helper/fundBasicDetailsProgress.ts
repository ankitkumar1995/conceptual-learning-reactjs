import { FundMasterDetails } from "../../../../../../redux/AifMaster/FundMaster/Maker/initialState";

const fundBasicDetailsProgress = (fundMasterDetails: FundMasterDetails) => {
    const fundBasicDetailsBooleanValues: boolean[] = [];
    let progress = 0;
    let progressPercentage = 0;

    const {
        fundBasicDetails,
    } = fundMasterDetails;

    const {
        companyCode,
        companyName,
        fundBusinessType,
        fundCategory,
        fundClientId,
        fundCode,
        fundCurrency,
        fundDepositoryType,
        fundDomicile,
        fundDpId,
        fundFaceValue,
        fundFrom,
        fundIsinNumber,
        fundName,
        fundNature,
        fundPeriod,
        fundRegistrationNumber,
        fundShortName,
        fundSubCategory,
        gstin,
        panOrTin,
        serviceModel,
    } = fundBasicDetails;

    const isCompanyCodeFilled = ( companyCode.length !== 0 );
    const isCompanyNameFilled = ( companyName.length !== 0 );
    const isFundBusinessTypeFilled = ( fundBusinessType.length !== 0 );
    const isFundCategoryFilled = ( fundCategory.length !== 0 );
    const isFundCodeFilled = ( fundCode.length !== 0 );
    const isFundCurrencyFilled = ( fundCurrency.length !== 0 );
    const isFundDepositoryTypeFilled = ( fundDepositoryType.length !== 0 );
    const isFundDomicileFilled = ( fundDomicile.length !== 0 );
    const isFundDpIdFilled = (
        (fundDepositoryType === "NSDL")
            ? fundDpId.length !== 0
            : true
    );
    const isFundClientIdFilled = ( fundClientId.length !== 0 );
    const isFundFaceValueFilled = ( fundFaceValue.length !== 0 );
    const isFundIsinNumberFilled = ( fundIsinNumber.length !== 0 );
    const isFundNameFilled = ( fundName.length !== 0 );
    const isFundNatureFilled = ( fundNature.length !== 0 );
    const isFundSubCategoryFilled = ( fundSubCategory.length !== 0 );
    const isServiceModelFilled = ( serviceModel.length !== 0 );

    fundBasicDetailsBooleanValues.push(isCompanyCodeFilled);
    fundBasicDetailsBooleanValues.push(isCompanyNameFilled);
    fundBasicDetailsBooleanValues.push(isFundBusinessTypeFilled);
    fundBasicDetailsBooleanValues.push(isFundCategoryFilled);
    fundBasicDetailsBooleanValues.push(isFundCodeFilled);
    fundBasicDetailsBooleanValues.push(isFundCurrencyFilled);
    fundBasicDetailsBooleanValues.push(isFundDepositoryTypeFilled);
    fundBasicDetailsBooleanValues.push(isFundDomicileFilled);
    if ( fundDepositoryType === "NSDL" )
        fundBasicDetailsBooleanValues.push(isFundDpIdFilled);
    fundBasicDetailsBooleanValues.push(isFundClientIdFilled);
    fundBasicDetailsBooleanValues.push(isFundFaceValueFilled);
    fundBasicDetailsBooleanValues.push(isFundIsinNumberFilled);
    fundBasicDetailsBooleanValues.push(isFundNameFilled);
    fundBasicDetailsBooleanValues.push(isFundNatureFilled);
    fundBasicDetailsBooleanValues.push(isFundSubCategoryFilled);
    fundBasicDetailsBooleanValues.push(isServiceModelFilled);

    fundBasicDetailsBooleanValues.map((value) => {
        if (value)
            progress++;
    });

    progressPercentage = (progress/fundBasicDetailsBooleanValues.length) * 100;

    if ( progressPercentage === 0 )
        return "yetToBeStarted";

    if ( progressPercentage > 0 && progressPercentage < 100 )
        return "inProgress";

    if ( progressPercentage === 100 )
        return "complete";
};

export default fundBasicDetailsProgress;
