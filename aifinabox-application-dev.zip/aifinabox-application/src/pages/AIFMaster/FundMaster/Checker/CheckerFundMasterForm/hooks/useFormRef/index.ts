import { 
    FundAdditionalField, 
    FundBasicField, 
    FundSpecificField, 
    FundValuationField 
} from "../../interfaces/field.types";
import { RefObject, useRef } from "react";

export interface FormRef {
    FundAdditionalInformation: {
        [key: string]: RefObject<HTMLInputElement>;
    };
    FundBasicDetails: {
        [key: string]: RefObject<HTMLInputElement>;
    };
    FundSpecificDetails: {
        [key: string]: RefObject<HTMLInputElement>;
    };
    FundValuationInformation: {
        [key: string]: RefObject<HTMLInputElement>;
    };
}

function useFormRef(): FormRef {
    const formRef: {
        FundAdditionalInformation: {
            [fieldName in FundAdditionalField]: RefObject<HTMLInputElement>;  
        };
        FundBasicDetails: {
            [fieldName in FundBasicField]: RefObject<HTMLInputElement>;
        };
        FundSpecificDetails: {
            [fieldName in FundSpecificField]: RefObject<HTMLInputElement>;
        };
        FundValuationInformation: {
            [fieldName in FundValuationField]: RefObject<HTMLInputElement>;
        };
    } = {
        "FundAdditionalInformation": {
            "defaulterPenalty": useRef<HTMLInputElement>(null),
            "distributionFrequency": useRef<HTMLInputElement>(null),
            "dormant": useRef<HTMLInputElement>(null),
            "dormantDate": useRef<HTMLInputElement>(null),
            "forexSource": useRef<HTMLInputElement>(null),
            "fundAdditionalFee": useRef<HTMLInputElement>(null),
            "fundCommitmentApplicability": useRef<HTMLInputElement>(null),
            "fundManagementFee": useRef<HTMLInputElement>(null),
            "fundStampDutyBorne": useRef<HTMLInputElement>(null),
            "fundTrusteeFee": useRef<HTMLInputElement>(null),
            "goodsServiceTax": useRef<HTMLInputElement>(null),
            "gpSharingRation": useRef<HTMLInputElement>(null),
            "highWaterMark": useRef<HTMLInputElement>(null),
            "hurdleRate": useRef<HTMLInputElement>(null),
            "hurdleStartDate": useRef<HTMLInputElement>(null),
            "isActive": useRef<HTMLInputElement>(null),
            "navRadioMethod": useRef<HTMLInputElement>(null),
            "operatingExpenses": useRef<HTMLInputElement>(null),
            "preferredRateOfReturn": useRef<HTMLInputElement>(null),
            "setupFee": useRef<HTMLInputElement>(null),
        },
        "FundBasicDetails": {
            "companyCode": useRef<HTMLInputElement>(null),
            "companyName": useRef<HTMLInputElement>(null),
            "fundBusinessType": useRef<HTMLInputElement>(null),
            "fundCategory": useRef<HTMLInputElement>(null),
            "fundClientId": useRef<HTMLInputElement>(null),
            "fundCode": useRef<HTMLInputElement>(null),
            "fundCurrency": useRef<HTMLInputElement>(null),
            "fundDepositoryType": useRef<HTMLInputElement>(null),
            "fundDomicile": useRef<HTMLInputElement>(null),
            "fundDpId": useRef<HTMLInputElement>(null),
            "fundFaceValue": useRef<HTMLInputElement>(null),
            "fundFrom": useRef<HTMLInputElement>(null),
            "fundIsinNumber": useRef<HTMLInputElement>(null),
            "fundName": useRef<HTMLInputElement>(null),
            "fundNature": useRef<HTMLInputElement>(null),
            "fundPeriod": useRef<HTMLInputElement>(null),
            "fundPeriodSuffix": useRef<HTMLInputElement>(null),
            "fundRegistrationNumber": useRef<HTMLInputElement>(null),
            "fundShortName": useRef<HTMLInputElement>(null),
            "fundSubCategory": useRef<HTMLInputElement>(null),
            "gstin": useRef<HTMLInputElement>(null),
            "panOrTin": useRef<HTMLInputElement>(null),
            "serviceModel": useRef<HTMLInputElement>(null),
        },
        "FundSpecificDetails": {
            "fundAccountantContactNumber": useRef<HTMLInputElement>(null),
            "fundAccountantContactNumberPrefix": useRef<HTMLInputElement>(null),
            "fundAccountantEmail": useRef<HTMLInputElement>(null),
            "fundAccountantName": useRef<HTMLInputElement>(null),
            "fundCustodianCode": useRef<HTMLInputElement>(null),
            "fundEndDate": useRef<HTMLInputElement>(null),
            "fundInitialContribution": useRef<HTMLInputElement>(null),
            "fundInitialContributionAmount": useRef<HTMLInputElement>(null),
            "fundInitialContributionCloseDate": useRef<HTMLInputElement>(null),
            "fundInitialContributionStartDate": useRef<HTMLInputElement>(null),
            "fundInvestmentManager": useRef<HTMLInputElement>(null),
            "fundMaturityDate": useRef<HTMLInputElement>(null),
            "fundMaxInvestors": useRef<HTMLInputElement>(null),
            "fundRtaCode": useRef<HTMLInputElement>(null),
            "fundSize": useRef<HTMLInputElement>(null),
            "fundSponsorName": useRef<HTMLInputElement>(null),
            "fundStartDate": useRef<HTMLInputElement>(null),
            "fundTrusteeName": useRef<HTMLInputElement>(null),
            "legalAdvisorName": useRef<HTMLInputElement>(null),
            "taxAdvisorName": useRef<HTMLInputElement>(null),
            "transferAgentAccountantEmail": useRef<HTMLInputElement>(null),
            "transferAgentContactNumber": useRef<HTMLInputElement>(null),
            "transferAgentContactNumberPrefix": useRef<HTMLInputElement>(null),
            "transferAgentName": useRef<HTMLInputElement>(null),
        },
        "FundValuationInformation": {
            "fundCurrentDate": useRef<HTMLInputElement>(null),
            "fundCurrentYearEnd": useRef<HTMLInputElement>(null),
            "fundDDNoticePeriod": useRef<HTMLInputElement>(null),
            "fundDDPenaltyCharges": useRef<HTMLInputElement>(null),
            "fundDDTreatment": useRef<HTMLInputElement>(null),
            "fundNextDate": useRef<HTMLInputElement>(null),
            "fundPlCompMethod": useRef<HTMLInputElement>(null),
            "fundPreviousDate": useRef<HTMLInputElement>(null),
            "fundPreviousYearEnd": useRef<HTMLInputElement>(null),
            "fundStartDate": useRef<HTMLInputElement>(null),
            "fundTopupTreatment": useRef<HTMLInputElement>(null),
            "navFrequency": useRef<HTMLInputElement>(null),
            "navPubFrequency": useRef<HTMLInputElement>(null),
            "navPublishType": useRef<HTMLInputElement>(null),
            "nextNavDate": useRef<HTMLInputElement>(null),
            "nextNavPubDate": useRef<HTMLInputElement>(null),
            "prevNavDate": useRef<HTMLInputElement>(null),
            "prevNavPubDate": useRef<HTMLInputElement>(null),
            "roundDecimals": useRef<HTMLInputElement>(null),
            "roundMethod": useRef<HTMLInputElement>(null),
            "unitDecimals": useRef<HTMLInputElement>(null),
            "valuationSequence": useRef<HTMLInputElement>(null),
        },
    };

    return formRef;
}

export default useFormRef;
