import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../../../interfaces/FieldValidation.types";
import { 
    FundAdditionalField, 
    FundBasicField, 
    FundSpecificField, 
    FundValuationField 
} from "../../interfaces/field.types";

export interface FormErrorState {
    fundAdditionalInformationErrorState: {
        [fieldError in FundAdditionalField]: FieldValidation;
    };
    fundBasicDetailsErrorState: {
        [fieldError in FundBasicField]: FieldValidation;
    };
    fundSpecificDetailsErrorState: {
        [fieldError in FundSpecificField]: FieldValidation;
    };
    fundValuationInformationErrorState: {
        [fieldError in FundValuationField]: FieldValidation;
    };
}

function initializeFormErrorState(): FormErrorState {
    return {
        "fundAdditionalInformationErrorState": {
            "defaulterPenalty": initializeFieldValidation(),
            "distributionFrequency": initializeFieldValidation(),
            "dormant": initializeFieldValidation(),
            "dormantDate": initializeFieldValidation(),
            "forexSource": initializeFieldValidation(),
            "fundAdditionalFee": initializeFieldValidation(),
            "fundCommitmentApplicability": initializeFieldValidation(),
            "fundManagementFee": initializeFieldValidation(),
            "fundStampDutyBorne": initializeFieldValidation(),
            "fundTrusteeFee": initializeFieldValidation(),
            "goodsServiceTax": initializeFieldValidation(),
            "gpSharingRation": initializeFieldValidation(),
            "highWaterMark": initializeFieldValidation(),
            "hurdleRate": initializeFieldValidation(),
            "hurdleStartDate": initializeFieldValidation(),
            "isActive": initializeFieldValidation(),
            "navRadioMethod": initializeFieldValidation(),
            "operatingExpenses": initializeFieldValidation(),
            "preferredRateOfReturn": initializeFieldValidation(),
            "setupFee": initializeFieldValidation(),
        },
        "fundBasicDetailsErrorState": {
            "companyCode": initializeFieldValidation(),
            "companyName": initializeFieldValidation(),
            "fundBusinessType": initializeFieldValidation(),
            "fundCategory": initializeFieldValidation(),
            "fundClientId": initializeFieldValidation(),
            "fundCode": initializeFieldValidation(),
            "fundCurrency": initializeFieldValidation(),
            "fundDepositoryType": initializeFieldValidation(),
            "fundDomicile": initializeFieldValidation(),
            "fundDpId": initializeFieldValidation(),
            "fundFaceValue": initializeFieldValidation(),
            "fundFrom": initializeFieldValidation(),
            "fundIsinNumber": initializeFieldValidation(),
            "fundName": initializeFieldValidation(),
            "fundNature": initializeFieldValidation(),
            "fundPeriod": initializeFieldValidation(),
            "fundPeriodSuffix": initializeFieldValidation(),
            "fundRegistrationNumber": initializeFieldValidation(),
            "fundShortName": initializeFieldValidation(),
            "fundSubCategory": initializeFieldValidation(),
            "gstin": initializeFieldValidation(),
            "panOrTin": initializeFieldValidation(),
            "serviceModel": initializeFieldValidation(),            
        },
        "fundSpecificDetailsErrorState": {
            "fundAccountantContactNumber": initializeFieldValidation(),
            "fundAccountantContactNumberPrefix": initializeFieldValidation(),
            "fundAccountantEmail": initializeFieldValidation(),
            "fundAccountantName": initializeFieldValidation(),
            "fundCustodianCode": initializeFieldValidation(),
            "fundEndDate": initializeFieldValidation(),
            "fundInitialContribution": initializeFieldValidation(),
            "fundInitialContributionAmount": initializeFieldValidation(),
            "fundInitialContributionCloseDate": initializeFieldValidation(),
            "fundInitialContributionStartDate": initializeFieldValidation(),
            "fundInvestmentManager": initializeFieldValidation(),
            "fundMaturityDate": initializeFieldValidation(),
            "fundMaxInvestors": initializeFieldValidation(),
            "fundRtaCode": initializeFieldValidation(),
            "fundSize": initializeFieldValidation(),
            "fundSponsorName": initializeFieldValidation(),
            "fundStartDate": initializeFieldValidation(),
            "fundTrusteeName": initializeFieldValidation(),
            "legalAdvisorName": initializeFieldValidation(),
            "taxAdvisorName": initializeFieldValidation(),
            "transferAgentAccountantEmail": initializeFieldValidation(),
            "transferAgentContactNumber": initializeFieldValidation(),
            "transferAgentContactNumberPrefix": initializeFieldValidation(),
            "transferAgentName": initializeFieldValidation(),
        },
        "fundValuationInformationErrorState": {
            "fundCurrentDate": initializeFieldValidation(),
            "fundCurrentYearEnd": initializeFieldValidation(),
            "fundDDNoticePeriod": initializeFieldValidation(),
            "fundDDPenaltyCharges": initializeFieldValidation(),
            "fundDDTreatment": initializeFieldValidation(),
            "fundNextDate": initializeFieldValidation(),
            "fundPlCompMethod": initializeFieldValidation(),
            "fundPreviousDate": initializeFieldValidation(),
            "fundPreviousYearEnd": initializeFieldValidation(),
            "fundStartDate": initializeFieldValidation(),
            "fundTopupTreatment": initializeFieldValidation(),
            "navFrequency": initializeFieldValidation(),
            "navPubFrequency": initializeFieldValidation(),
            "navPublishType": initializeFieldValidation(),
            "nextNavDate": initializeFieldValidation(),
            "nextNavPubDate": initializeFieldValidation(),
            "prevNavDate": initializeFieldValidation(),
            "prevNavPubDate": initializeFieldValidation(),
            "roundDecimals": initializeFieldValidation(),
            "roundMethod": initializeFieldValidation(),
            "unitDecimals": initializeFieldValidation(),
            "valuationSequence": initializeFieldValidation(),
        },
    };
}

export default initializeFormErrorState;
