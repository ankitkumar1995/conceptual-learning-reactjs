import { FundMasterDetails } from "../../../../../../redux/AifMaster/FundMaster/Maker/initialState";

const fundValuationInformationProgress = (fundMasterDetails: FundMasterDetails) => {
    const fundValuationInformationBooleanValues: boolean[] = [];
    let progress = 0;
    let progressPercentage = 0;

    const {
        fundBasicDetails,
        fundValuationInformation
    } = fundMasterDetails;

    const {
        serviceModel,
    } = fundBasicDetails;

    const {
        fundCurrentDate,
        fundCurrentYearEnd,
        fundDDNoticePeriod,
        fundDDPenaltyCharges,
        fundDDTreatment,
        fundNextDate,
        fundPlCompMethod,
        fundPreviousDate,
        fundPreviousYearEnd,
        fundStartDate,
        fundTopupTreatment,
        navFrequency,
        navPubFrequency,
        navPublishType,
        nextNavDate,
        nextNavPubDate,
        prevNavDate,
        prevNavPubDate,
        roundDecimals,
        roundMethod,
        unitDecimals,
        valuationSequence,
    } = fundValuationInformation;

    const isFundCurrentDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundCurrentDate !== null &&
                fundCurrentDate.length !== 0)
            : true
    );
    const isFundCurrentYearEndFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundCurrentYearEnd !== null &&
                fundCurrentYearEnd.length !== 0)
            : true
    );
    const isFundDDNoticePeriodFilled = ( fundDDNoticePeriod.length !== 0 );
    const isFundDDTreatmentFilled = ( fundDDTreatment.length !== 0 );
    const isFundNextDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundNextDate !== null &&
                fundNextDate.length !== 0)
            : true
    );
    const isFundPLCompMethodFilled = ( fundPlCompMethod.length !== 0 );
    const isFundPreviousDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundPreviousDate !== null &&
                fundPreviousDate.length !== 0)
            : true
    );
    const isFundPreviousYearEndFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundPreviousYearEnd !== null &&
                fundPreviousYearEnd.length !== 0)
            : true
    );
    const isFundStartDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (fundStartDate !== null &&
                fundStartDate.length !== 0)
            : true
    );
    const isFundTopupTreatmentFilled = ( fundTopupTreatment.length !== 0 );
    const isNavFrequencyFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (navFrequency !== null &&
                navFrequency.length !== 0)
            : true
    );
    const isNavPubFrequencyFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (navPubFrequency !== null &&
                navPubFrequency.length !== 0)
            : true
    );
    // const isNavPublishTypeFilled = (
    //     (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
    //         ? (navPublishType !== null &&
    //             navPublishType.length !== 0)
    //         : true
    // );
    const isNextNavDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (nextNavDate !== null &&
                nextNavDate.length !== 0)
            : true
    );
    const isNextNavPubDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (nextNavPubDate !== null &&
                nextNavPubDate.length !== 0)
            : true
    );
    const isPrevNavDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (prevNavDate !== null &&
                prevNavDate.length !== 0)
            : true
    );
    const isPrevNavPubDateFilled = (
        (serviceModel.includes("FA") || serviceModel.includes("TA+FA"))
            ? (prevNavPubDate !== null &&
                prevNavPubDate.length !== 0)
            : true
    );
    const isRoundDecimalsFilled = ( roundDecimals.length !== 0 );
    const isRoundMethodFilled = ( roundMethod.length !== 0 );
    const isUnitDecimalsFilled = ( unitDecimals.length !== 0 );
    const isValuationSequenceFilled = ( valuationSequence.length !== 0 );

    if ( serviceModel.includes("FA") || serviceModel.includes("TA+FA") ) {
        fundValuationInformationBooleanValues.push(isFundCurrentDateFilled);
        fundValuationInformationBooleanValues.push(isFundCurrentYearEndFilled);
        fundValuationInformationBooleanValues.push(isFundNextDateFilled);
        fundValuationInformationBooleanValues.push(isFundPreviousDateFilled);
        fundValuationInformationBooleanValues.push(isFundPreviousYearEndFilled);
        fundValuationInformationBooleanValues.push(isFundStartDateFilled);
        fundValuationInformationBooleanValues.push(isNavFrequencyFilled);
        fundValuationInformationBooleanValues.push(isNavPubFrequencyFilled);
        // fundValuationInformationBooleanValues.push(isNavPublishTypeFilled);
        fundValuationInformationBooleanValues.push(isNextNavDateFilled);
        fundValuationInformationBooleanValues.push(isNextNavPubDateFilled);
        fundValuationInformationBooleanValues.push(isPrevNavDateFilled);
        fundValuationInformationBooleanValues.push(isPrevNavPubDateFilled);
    }
    fundValuationInformationBooleanValues.push(isFundDDNoticePeriodFilled);
    fundValuationInformationBooleanValues.push(isFundDDTreatmentFilled);
    fundValuationInformationBooleanValues.push(isFundPLCompMethodFilled);
    fundValuationInformationBooleanValues.push(isFundTopupTreatmentFilled);
    fundValuationInformationBooleanValues.push(isRoundDecimalsFilled);
    fundValuationInformationBooleanValues.push(isRoundMethodFilled);
    fundValuationInformationBooleanValues.push(isUnitDecimalsFilled);
    fundValuationInformationBooleanValues.push(isValuationSequenceFilled);

    fundValuationInformationBooleanValues.map((value) => {
        if (value)
            progress++;
    });

    progressPercentage = (progress/fundValuationInformationBooleanValues.length) * 100;

    if ( progressPercentage === 0 )
        return "yetToBeStarted";

    if ( progressPercentage > 0 && progressPercentage < 100 )
        return "inProgress";

    if ( progressPercentage === 100 )
        return "complete";
};

export default fundValuationInformationProgress;
