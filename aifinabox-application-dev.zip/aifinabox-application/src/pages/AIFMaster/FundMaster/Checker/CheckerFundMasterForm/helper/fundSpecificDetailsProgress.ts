import { FundMasterDetails } from "../../../../../../redux/AifMaster/FundMaster/Maker/initialState";
import { RootState } from "../../../../../../redux/store";
import { useSelector } from "react-redux";

const fundSpecificDetailsProgress = (fundMasterDetails: FundMasterDetails) => {
    const fundSpecificDetailsBooleanValues: boolean[] = [];
    let progress = 0;
    let progressPercentage = 0;

    const {
        fundSpecificDetails
    } = fundMasterDetails;

    const {
        fundAccountantContactNumber,
        fundAccountantEmail,
        fundAccountantName,
        fundCustodianCode,
        fundEndDate,
        fundInitialContribution,
        fundInitialContributionAmount,
        fundInitialContributionCloseDate,
        fundInitialContributionStartDate,
        fundInvestmentManager,
        fundMaturityDate,
        fundMaxInvestors,
        fundRtaCode,
        fundSize,
        fundSponsorName,
        fundStartDate,
        fundTrusteeName,
        legalAdvisorName,
        taxAdvisorName,
        transferAgentAccountantEmail,
        transferAgentContactNumber,
        transferAgentName,
    } = fundSpecificDetails;

    const isFundAccountantNameFilled = ( fundAccountantName.length !== 0 );
    const isFundCustodianCodeFilled = ( fundCustodianCode.length !== 0 );
    const isFundMaxInvestorsFilled = ( fundMaxInvestors.length !== 0 );
    const isFundSizeFilled = ( fundSize.length !== 0 );
    const isFundTrusteeNameFilled = ( fundTrusteeName.length !== 0 );

    fundSpecificDetailsBooleanValues.push(isFundAccountantNameFilled);
    fundSpecificDetailsBooleanValues.push(isFundCustodianCodeFilled);
    fundSpecificDetailsBooleanValues.push(isFundMaxInvestorsFilled);
    fundSpecificDetailsBooleanValues.push(isFundSizeFilled);
    fundSpecificDetailsBooleanValues.push(isFundTrusteeNameFilled);

    fundSpecificDetailsBooleanValues.map((value) => {
        if (value)
            progress++;
    });

    progressPercentage = (progress/fundSpecificDetailsBooleanValues.length) * 100;

    if ( progressPercentage === 0 )
        return "yetToBeStarted";

    if ( progressPercentage > 0 && progressPercentage < 100 )
        return "inProgress";

    if ( progressPercentage === 100 )
        return "complete";
};

export default fundSpecificDetailsProgress;
