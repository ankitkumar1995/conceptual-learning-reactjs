import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { StyledPagination } from "./PaginationStyles";
import fundMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Checker/dispatchActionsProvider";
import fundMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Nigo/dispatchActionsProvider";
import updateStateDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Update/dispatchActionsProvider";
import useFetchFundMaster from "../../../../../hooks/api/useFetchFundMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);

    const { 
        setCompanyCode,
        setCompanyName,
        setFundCode,
        setFundName,
        setFundMasterCheckerStateFromMakerEntry,
    } = fundMasterDetailsFormDispatchActionsProvider();

    const { setMakerData } = fundMasterNigoDetailsFormDispatchActionsProvider();
    const { setUpdateState } = updateStateDispatchActionsProvider();

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchFundMaster = useFetchFundMaster();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleCardOnClick = (clientCode: string, fundCode: string, companyName: string, fundName: string) => {
        fetchFundMaster(clientCode, fundCode, "C", userId)
            .then((fundMaster) => {
                const {
                    "fundMasterFormState": fundMasterMakerState,
                    "fundMasterUpdateState": fundMasterMakerUpdateState,
                } = fundMaster;

                setFundMasterCheckerStateFromMakerEntry(fundMasterMakerUpdateState, fundMasterMakerState);
                setUpdateState(fundMasterMakerUpdateState);
                setCompanyCode(clientCode);
                setCompanyName(companyName);
                setFundCode(fundCode);
                setMakerData(fundMasterMakerState);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "fund_master", "C",userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page,itemCountPerPage,pageCount]);

    return (
        <>
            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            // clientType,
                            createdBy,
                            createdOn,
                            fundCode,
                            fundName,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName,
                                        }
                                    ]}
                                    onClick={() => handleCardOnClick(clientCode, fundCode, clientName, fundName)}
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>                    
                    </Stack>
                </FormControl>

                <Box></Box>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
