import { Box, Stack } from "@mui/material";
import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem 
} from "../../../../../../hooks/api/useFetchRejectQueue";
import useFetchTodoQueue, {
    PendingCheckerItem 
} from "../../../../../../hooks/api/useFetchToDoQueue";
import {
    BankMasterDetails
} from "../../../../../../redux/AifMaster/BankMaster/Checker/initialState";

import PendingCheckerEntryItemCard from "../../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../../redux/store";
import {
    StyledPagination 
} from "../../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import bankMasterDetailsFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Checker/dispatchActionsProvider";
import bankMasterNigoDetailsFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Nigo/dispatchActionsProvider";
import bankMasterPageContextFormDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/PageContext/dispatchActionsProvider";
import { nanoid } from "@reduxjs/toolkit";
import updateStateDispatchActionsProvider from "../../../../../../redux/AifMaster/BankMaster/Update/dispatchActionsProvider";
import useFetchBankMaster from "../../../../../../hooks/api/useFetchBankMaster";
import useFetchRejectFundMaster from "../../../../../../hooks/api/useFetchRejectFundMaster";
import { useSelector } from "react-redux";


const itemCountPerPage = 5;

interface ActiveTab {
    activeToDo: boolean;
    rejectedByAuditor: boolean;
    rejectedByMe: boolean;
}

interface PendingCheckerListsProps {
    tabActive: ActiveTab;
    handleCardOnClick: (
        clientCode: string, 
        clientName: string,
        classCode: string, 
        fundCode: string,
        fundName: string,
        planCode: string, 
        planName: string
        ) => void;
}

const PendingCheckerLists = (pendingCheckerListsProps: PendingCheckerListsProps) => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const { setCheckerNavigation } = bankMasterPageContextFormDispatchActionsProvider();

    const { setMakerData } = bankMasterNigoDetailsFormDispatchActionsProvider();
    
    const { setUpdateState } = updateStateDispatchActionsProvider();

    const { 
        setCompanyCode, 
        setCompanyName,
        setFundCode,
        setFundName,
        setCorporateBankName,
        setBankAccountNumber,
        setBankDetails,
    } = bankMasterDetailsFormDispatchActionsProvider();

    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchRejectFundMaster = useFetchRejectFundMaster();
    const fetchRejectedQueue = useFetchRejectQueue();


    const {
        tabActive,
        // handleCardOnClick,
    } = pendingCheckerListsProps;



    const handleCardOnClick = (
        clientCode: string, fundCode: string, companyName: string, fundName: string
    ) => {
        fetchRejectFundMaster("", "", "", clientCode, fundCode,"fund_master", "", "C")
            .then((fundMasterMakerState) => {
                // const { 
                //     bankMasterFormState, 
                //     bankMasterUpdateState 
                // } = bankMasterMakerState;
                // setMakerData(bankMasterFormState as BankMasterDetails);
                // setUpdateState(bankMasterUpdateState);
                // bankMasterUpdateState.updateFlag === "1" && setBankDetails(bankMasterFormState as BankMasterDetails);
            });
        // setCompanyCode(companyCode);
        // setCompanyName(companyName);
        // setFundCode(fundCode),
        // setFundName(fundName),
        // setCorporateBankName(corporateBankName),
        // setBankAccountNumber(bankAccountNumber),
        // setCheckerNavigation("form");
    };


    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    useEffect(() => {
        if (tabActive["activeToDo"]) {
            fetchCheckerQueue(itemCountPerPage, page-1, "fund_master", "C", userId)
                .then((result) => {
                    const {
                        checkerQueue,
                        pendingCheckerItemCount,
                    } = result;

                    setPendingCheckerEntryItems(checkerQueue);
                    setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
                });
        }
        else {
            const rejectedBy = tabActive["rejectedByAuditor"] ? "A" : tabActive["rejectedByMe"] ? "C" : "C";

            fetchRejectedQueue(itemCountPerPage,"",page-1, "fund_master", rejectedBy, "C", userId)
                .then((result) => {
                    const {
                        rejectQueue,
                        pendingRejectItemCount,
                    } = result;

                    setPendingRejectEntryItems(rejectQueue);
                    setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
                });
        }
    }, [page, tabActive, itemCountPerPage, pageCount]);

    const mapData = tabActive["activeToDo"] ? pendingCheckerEntryItems : pendingRejectEntryItems;

    return (
        <>
            {
                mapData.map((pendingCheckerEntryItem : PendingRejectedItem | PendingCheckerItem) => {
                    const {
                        bankAccountNumber,
                        bankName,
                        clientCode,
                        clientName,
                        fundCode,
                        fundName,
                        planCode,
                        planName,
                        classCode,
                        className,
                        createdBy,
                        createdOn,
                        // id,
                        rejectRemarks,
                    } = pendingCheckerEntryItem;

                    const toDoData = [
                        {
                            "dataPartOne": clientCode,
                            "dataPartTwo": clientName
                        },
                        {
                            "dataPartOne": fundCode,
                            "dataPartTwo": fundName,
                        }
                    ];

                    const rejectedData = !tabActive["activeToDo"] ? [...toDoData, {
                        "dataPartOne": "Remarks",
                        "dataPartTwo": rejectRemarks,
                    }] : [...toDoData];

                    return (
                        <Box key={nanoid()}>
                            <PendingCheckerEntryItemCard
                                createdBy={createdBy}
                                creationDate={createdOn}
                                data={rejectedData}
                                onClick={() => tabActive["activeToDo"] && handleCardOnClick(clientCode, fundCode, clientName, fundName)} 
                            />
                        </Box>
                    );
                })
            }

            <Stack direction="row" justifyContent="space-between"> 
                
                <Box></Box>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerLists;
