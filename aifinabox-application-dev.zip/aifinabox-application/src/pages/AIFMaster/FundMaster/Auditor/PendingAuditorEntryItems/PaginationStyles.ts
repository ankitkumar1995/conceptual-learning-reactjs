import { Pagination, styled } from "@mui/material";

export const StyledPagination = styled(Pagination)(() => ({
    "& .Mui-selected": {
        "&:hover": {
            "backgroundColor": "#2057A6 !important",
            "color": "#FFFFFF !important",
        },
        "backgroundColor": "#2057A6 !important",
        "color": "#FFFFFF",
    },

    "& .MuiPaginationItem-root": {
        "&:hover": {
            "backgroundColor": "#FFFFFF",
            "color": "#201C43",
        },
        "border": "none",
    }
})
);
