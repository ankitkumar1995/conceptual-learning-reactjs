import { 
    FundAdditionalField, 
    FundBasicUpdateField, 
    FundSpecificField, 
    FundValuationField 
} from "../../interfaces/field.types";

export interface UpdateState {
    fundAdditionalInformationUpdateState: {
        [field in FundAdditionalField]: boolean;
    };
    fundBasicDetailsUpdateState: {
        [field in FundBasicUpdateField]: boolean;
    };
    fundSpecificDetailsUpdateState: {
        [field in FundSpecificField]: boolean;
    };
    fundValuationInformationUpdateState: {
        [field in FundValuationField]: boolean;
    };
}

function initializeUpdateState(): UpdateState {
    return {
        "fundAdditionalInformationUpdateState": {
            "defaulterPenalty": false,
            "distributionFrequency": false,
            "dormant": false,
            "dormantDate": false,
            "forexSource": false,
            "fundAdditionalFee": false,
            "fundCommitmentApplicability": false,
            "fundManagementFee": false,
            "fundStampDutyBorne": false,
            "fundTrusteeFee": false,
            "goodsServiceTax": false,
            "gpSharingRation": false,
            "highWaterMark": false,
            "hurdleRate": false,
            "hurdleStartDate": false,
            "isActive": false,
            "navRadioMethod": false,
            "operatingExpenses": false,
            "preferredRateOfReturn": false,
            "setupFee": false,
        },
        "fundBasicDetailsUpdateState": {
            "fundBusinessType": false,
            "fundCategory": false,
            "fundClientId": false,
            "fundCurrency": false,
            "fundDepositoryType": false,
            "fundDomicile": false,
            "fundDpId": false,
            "fundFaceValue": false,
            "fundFrom": false,
            "fundIsinNumber": false,
            "fundName": false,
            "fundNature": false,
            "fundPeriod": false,
            "fundPeriodSuffix": false,
            "fundRegistrationNumber": false,
            "fundShortName": false,
            "fundSubCategory": false,
            "panOrTin": false,  
            "serviceModel": false,            
        },
        "fundSpecificDetailsUpdateState": {
            "fundAccountantContactNumber": false,
            "fundAccountantContactNumberPrefix": false,
            "fundAccountantEmail": false,
            "fundAccountantName": false,
            "fundCustodianCode": false,
            "fundEndDate": false,
            "fundInitialContribution": false,
            "fundInitialContributionAmount": false,
            "fundInitialContributionCloseDate": false,
            "fundInitialContributionStartDate": false,
            "fundInvestmentManager": false,
            "fundMaturityDate": false,
            "fundMaxInvestors": false,
            "fundRtaCode": false,
            "fundSize": false,
            "fundSponsorName": false,
            "fundStartDate": false,
            "fundTrusteeName": false,
            "legalAdvisorName": false,
            "taxAdvisorName": false,
            "transferAgentAccountantEmail": false,
            "transferAgentContactNumber": false,
            "transferAgentContactNumberPrefix": false,
            "transferAgentName": false,
        },
        "fundValuationInformationUpdateState": {
            "fundCurrentDate": false,
            "fundCurrentYearEnd": false,
            "fundDDNoticePeriod": false,
            "fundDDPenaltyCharges": false,
            "fundDDTreatment": false,
            "fundNextDate": false,
            "fundPlCompMethod": false,
            "fundPreviousDate": false,
            "fundPreviousYearEnd": false,
            "fundStartDate": false,
            "fundTopupTreatment": false,
            "navFrequency": false,
            "navPubFrequency": false,
            "navPublishType": false,
            "nextNavDate": false,
            "nextNavPubDate": false,
            "prevNavDate": false,
            "prevNavPubDate": false,
            "roundDecimals": false,
            "roundMethod": false,
            "unitDecimals": false,
            "valuationSequence": false,
        },
    };
}

export default initializeUpdateState;
