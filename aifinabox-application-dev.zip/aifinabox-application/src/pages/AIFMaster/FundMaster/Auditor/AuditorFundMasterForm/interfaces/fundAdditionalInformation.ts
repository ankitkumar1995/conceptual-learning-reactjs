export interface FundAdditionalInformation {
    defaulterPenalty: string;
    distributionFrequency: string;
    dormant: string;
    dormantDate: string | null;
    forexSource: string;
    fundAdditionalFee: string;
    fundCommitmentApplicability: string;
    fundManagementFee: string;
    fundStampDutyBorne: string;
    fundTrusteeFee: string;
    goodsServiceTax: string;
    gpSharingRation: string;
    highWaterMark: string;
    hurdleRate: string;
    hurdleStartDate: string | null;
    isActive: string;
    navRadioMethod: string;
    operatingExpenses: string;
    preferredRateOfReturn: string;
    setupFee: string;
}

export const initializeFundAdditionalInformation: FundAdditionalInformation = {
    "defaulterPenalty": "",
    "distributionFrequency": "",
    "dormant": "",
    "dormantDate": null,
    "forexSource": "",
    "fundAdditionalFee": "",
    "fundCommitmentApplicability": "",
    "fundManagementFee": "",
    "fundStampDutyBorne": "",
    "fundTrusteeFee": "",
    "goodsServiceTax": "",
    "gpSharingRation": "",
    "highWaterMark": "",
    "hurdleRate": "",
    "hurdleStartDate": null,
    "isActive": "",
    "navRadioMethod": "",
    "operatingExpenses": "",
    "preferredRateOfReturn": "",
    "setupFee": "",   
};
