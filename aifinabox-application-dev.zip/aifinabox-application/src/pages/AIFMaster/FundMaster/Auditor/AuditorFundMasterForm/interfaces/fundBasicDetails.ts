export interface FundBasicDetails {
    companyCode: string;
    companyName: string;
    fundBusinessType: string;
    fundCategory: string;
    fundClientId: string;
    fundCode: string;
    fundCurrency: string;
    fundDepositoryType: string;
    fundDomicile: string;
    fundDpId: string;
    fundFaceValue: string;
    fundFrom: string;
    fundIsinNumber: string;
    fundName: string;
    fundNature: string;
    fundPeriod: string;
    fundPeriodSuffix: string;
    fundRegistrationNumber: string;
    fundShortName: string;
    fundSubCategory: string;
    gstin: string;
    panOrTin: string;
    serviceModel: string[];
}

export const initializeFundBasicDetails: FundBasicDetails = {  
    "companyCode": "",
    "companyName": "",
    "fundBusinessType": "",
    "fundCategory": "",
    "fundClientId": "",
    "fundCode": "",
    "fundCurrency": "",
    "fundDepositoryType": "",
    "fundDomicile": "",
    "fundDpId": "",
    "fundFaceValue": "",
    "fundFrom": "",
    "fundIsinNumber": "",
    "fundName": "",
    "fundNature": "",
    "fundPeriod": "",
    "fundPeriodSuffix": "Years",
    "fundRegistrationNumber": "",
    "fundShortName": "",
    "fundSubCategory": "",
    "gstin": "",
    "panOrTin": "",
    "serviceModel": [],
};
