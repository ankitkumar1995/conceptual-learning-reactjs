export interface FundValuationInformation {
    fundCurrentDate: string | null;
    fundCurrentYearEnd: string | null;
    fundDDNoticePeriod: string;
    fundDDPenaltyCharges: string;
    fundDDTreatment: string;
    fundNextDate: string | null;
    fundPlCompMethod: string;
    fundPreviousDate: string | null;
    fundPreviousYearEnd: string | null;
    fundStartDate: string | null;
    fundTopupTreatment: string;
    navFrequency: string | null;
    navPubFrequency: string | null;
    navPublishType: string | null;
    nextNavDate: string | null;
    nextNavPubDate: string | null;
    prevNavDate: string | null;
    prevNavPubDate: string | null;
    roundDecimals: string;
    roundMethod: string;
    unitDecimals: string;
    valuationSequence: string;
}

export const initializeFundValuationInformation: FundValuationInformation = {
    "fundCurrentDate": null,
    "fundCurrentYearEnd": null,
    "fundDDNoticePeriod": "",
    "fundDDPenaltyCharges": "",
    "fundDDTreatment": "",
    "fundNextDate": null,
    "fundPlCompMethod": "",
    "fundPreviousDate": null,
    "fundPreviousYearEnd": null,
    "fundStartDate": null,
    "fundTopupTreatment": "",
    "navFrequency": null,
    "navPubFrequency": null,
    "navPublishType": null,
    "nextNavDate": null,
    "nextNavPubDate": null,
    "prevNavDate": null,
    "prevNavPubDate": null,
    "roundDecimals": "",
    "roundMethod": "",
    "unitDecimals": "",
    "valuationSequence": "",
}; 
