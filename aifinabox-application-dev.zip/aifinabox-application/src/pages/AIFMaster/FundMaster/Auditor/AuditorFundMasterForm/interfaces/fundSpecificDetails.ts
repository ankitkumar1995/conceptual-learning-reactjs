export interface FundSpecificDetails {
    fundAccountantContactNumber: string;
    fundAccountantContactNumberPrefix: string;
    fundAccountantEmail: string;
    fundAccountantName: string;
    fundCustodianCode: string;
    fundEndDate: string | null;
    fundInitialContribution: string;
    fundInitialContributionAmount: string;
    fundInitialContributionCloseDate: string | null;
    fundInitialContributionStartDate: string | null;
    fundInvestmentManager: string;
    fundMaturityDate: string | null;
    fundMaxInvestors: string;
    fundRtaCode: string;
    fundSize: string;
    fundSponsorName: string;
    fundStartDate: string | null;
    fundTrusteeName: string;
    legalAdvisorName: string;
    taxAdvisorName: string;
    transferAgentAccountantEmail: string;
    transferAgentContactNumber: string;
    transferAgentContactNumberPrefix: string;
    transferAgentName: string;
}

export const initializeFundSpecificDetails: FundSpecificDetails = {
    "fundAccountantContactNumber": "",
    "fundAccountantContactNumberPrefix": "",
    "fundAccountantEmail": "",
    "fundAccountantName": "",
    "fundCustodianCode": "",
    "fundEndDate": null,
    "fundInitialContribution": "",
    "fundInitialContributionAmount": "",
    "fundInitialContributionCloseDate": null,
    "fundInitialContributionStartDate": null,
    "fundInvestmentManager": "",
    "fundMaturityDate": null,
    "fundMaxInvestors": "",
    "fundRtaCode": "",
    "fundSize": "",
    "fundSponsorName": "",
    "fundStartDate": null,
    "fundTrusteeName": "",
    "legalAdvisorName": "",
    "taxAdvisorName": "",
    "transferAgentAccountantEmail": "",
    "transferAgentContactNumber": "",
    "transferAgentContactNumberPrefix": "",
    "transferAgentName": "",
};
