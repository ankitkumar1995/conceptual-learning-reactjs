import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import { 
    Box,
    Button,
    Grid, 
    IconButton, 
    Stack, 
    Typography 
} from "@mui/material";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { 
    masterSetupClearButtonStyles, 
    masterSetupSubmitButtonStyles 
} from "../../../styles/ButtonStyles";
import { useEffect, useState } from "react";
import useFetchClientDetails, { 
    ClientDetails 
} from "../../../../../hooks/api/useFetchClientDetails";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FundCard from "../../components/FundCard";
import RemarksPopup from "../../../../../components/FXRemarksPopup";
import { RootState } from "../../../../../redux/store";
import fundMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/FundMaster/Auditor/dispatchActionsProvider";
import usePostFundMaster from "../../../../../hooks/api/usePostFundMaster";
import usePostRejectDetails from "../../../../../hooks/api/usePostRejectDetails";
import { useSelector } from "react-redux";

const AuditorFundMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [clientDetails, setClientDetails] = useState<ClientDetails[]>();
    const [clientType, setClientType] = useState("");
    const [updateState, setUpdateState] = useState<UpdateState>(initializeUpdateState());
    const [openRemarksPopup, setOpenRemarksPopup] = useState(false);
    const [openSubmitPopup, setOpenSubmitPopup] = useState(false);
    const [rejectRemarkText, setRejectRemarkText] = useState("Please - Check All Details");

    const fundMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .auditorForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        fundAdditionalInformation,
        fundBasicDetails,
        fundSpecificDetails,
        fundValuationInformation,
    } = fundMasterFormState;

    const {
        companyCode,
        companyName,
        fundBusinessType,
        fundCategory,
        fundClientId,
        fundCode,
        fundCurrency,
        fundDepositoryType,
        fundDomicile,
        fundDpId,
        fundFaceValue,
        fundFrom,
        fundIsinNumber,
        fundName,
        fundNature,
        fundPeriod,
        fundPeriodSuffix,
        fundRegistrationNumber,
        fundShortName,
        fundSubCategory,
        gstin,
        panOrTin,
        serviceModel,
    } = fundBasicDetails;

    const {
        fundAccountantContactNumber,
        fundAccountantContactNumberPrefix,
        fundAccountantEmail,
        fundAccountantName,
        fundCustodianCode,
        fundEndDate,
        fundInitialContribution,
        fundInitialContributionAmount,
        fundInitialContributionCloseDate,
        fundInitialContributionStartDate,
        fundInvestmentManager,
        fundMaturityDate,
        fundMaxInvestors,
        fundRtaCode,
        fundSize,
        fundSponsorName,
        "fundStartDate": fundSpecificStartDate,
        fundTrusteeName,
        legalAdvisorName,
        taxAdvisorName,
        transferAgentAccountantEmail,
        transferAgentContactNumber,
        transferAgentContactNumberPrefix,
        transferAgentName,
    } = fundSpecificDetails;

    const {
        fundCurrentDate,
        fundCurrentYearEnd,
        fundDDNoticePeriod,
        fundDDPenaltyCharges,
        fundDDTreatment,
        fundNextDate,
        fundPlCompMethod,
        fundPreviousDate,
        fundPreviousYearEnd,
        "fundStartDate": fundValuationStartDate,
        fundTopupTreatment,
        navFrequency,
        navPubFrequency,
        navPublishType,
        nextNavDate,
        nextNavPubDate,
        prevNavDate,
        prevNavPubDate,
        roundDecimals,
        roundMethod,
        unitDecimals,
        valuationSequence,
    } = fundValuationInformation;

    const {
        defaulterPenalty,
        distributionFrequency,
        dormant,
        dormantDate,
        forexSource,
        fundAdditionalFee,
        fundCommitmentApplicability,
        fundManagementFee,
        fundStampDutyBorne,
        fundTrusteeFee,
        goodsServiceTax,
        gpSharingRation,
        highWaterMark,
        hurdleRate,
        hurdleStartDate,
        isActive,
        navRadioMethod,
        operatingExpenses,
        preferredRateOfReturn,
        setupFee,
    } = fundAdditionalInformation;

    const {
        clearState,
        setCompanyCode,
    } = fundMasterDetailsFormDispatchActionsProvider();

    const fetchClientDetails = useFetchClientDetails();
    const postFundMaster = usePostFundMaster();
    const postRejectFundMaster = usePostRejectDetails();
    const handleFetchClientDetails = () => {
        fetchClientDetails("fund_master", "0")
            .then((result) => {
                setClientDetails(result);
            });
    };

    const handleFormSubmit = () => {
        postFundMaster(fundMasterFormState, `${firstName} ${lastName}`, userId, "A", "0", clientType, updateState)
            .then(() => setAlertSnackbarContext({
                "description": `Auditor Entry Done against Client Code ${companyCode}`,
                "open": true,
                "severity": "success",
                "title": "Auditor Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Auditor Entry Failure against
                                    Client Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Auditor Entry Failed",
                });
            });
    };

    const handleRejectSubmit = () => {
        setOpenRemarksPopup(false);
        //setAlertSnackbarContext(initialAlertSnackbarContext());
        postRejectFundMaster("", "", "", companyCode, fundCode, "fund_master", "", "A", rejectRemarkText, userId, `${firstName} ${lastName}`)
            .then(() => setAlertSnackbarContext({
                "description": `Auditor Entry Rejected against Client Code ${companyCode}`,
                "open": true,
                "severity": "success",
                "title": "Auditor Entry Rejected Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Auditor Entry Failure against
                                    Client Code: ${companyCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Auditor Entry Reject Failed",
                });
            });
    };

    useEffect(() => {
        handleFetchClientDetails();
    }, []);

    useEffect(() => {
        clientDetails?.map((client) => {
            if (client.clientCode === companyCode) {
                setClientType(client.clientType);
            }
        });
    }, [companyCode]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={1}>
                <Grid item xs={12}>
                    <Box 
                        alignItems="center"
                        display="flex"
                    >
                        <IconButton
                            onClick={() => {
                                setCompanyCode("");
                            }}
                        >
                            <BackArrowIcon/>
                        </IconButton>

                        <Typography variant="formHeading">
                            Fund Master
                        </Typography>
                    </Box>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        auditor
                        title="Fund Basic Details"
                    >
                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Company Code</Typography>
                                <Typography variant="auditorFieldValue">{`${companyCode}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Company Name</Typography>
                                <Typography variant="auditorFieldValue">{`${companyName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Code</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCode}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund From</Typography>
                                <Typography variant="auditorFieldValue">{`${fundFrom}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Name</Typography>
                                <Typography variant="auditorFieldValue">{`${fundName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Short Name</Typography>
                                <Typography variant="auditorFieldValue">{`${fundShortName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Domicile</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDomicile}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Business Type</Typography>
                                <Typography variant="auditorFieldValue">{`${fundBusinessType}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Service Model</Typography>
                                <Typography variant="auditorFieldValue">{`${serviceModel}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Category</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCategory}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Sub Category</Typography>
                                <Typography variant="auditorFieldValue">{`${fundSubCategory}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Nature</Typography>
                                <Typography variant="auditorFieldValue">{`${fundNature}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Face Value</Typography>
                                <Typography variant="auditorFieldValue">{`${fundFaceValue}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Currency</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCurrency}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Period</Typography>
                                <Typography variant="auditorFieldValue">{`${fundPeriod} ${fundPeriodSuffix}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Registration Number</Typography>
                                <Typography variant="auditorFieldValue">{`${fundRegistrationNumber}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">PAN or TIN</Typography>
                                <Typography variant="auditorFieldValue">{`${panOrTin}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">GSTIN</Typography>
                                <Typography variant="auditorFieldValue">{`${gstin}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund ISIN Number</Typography>
                                <Typography variant="auditorFieldValue">{`${fundIsinNumber}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Depository Type</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDepositoryType}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund DP ID</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDpId}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Client ID</Typography>
                                <Typography variant="auditorFieldValue">{`${fundClientId}`}</Typography>
                            </Stack>
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        auditor
                        title="Fund Specific Details"
                    >
                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Start Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundSpecificStartDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Initial Contribution Start Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundInitialContributionStartDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Initial Contribution Close Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundInitialContributionCloseDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund End Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundEndDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Maturity Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundMaturityDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Max Investors</Typography>
                                <Typography variant="auditorFieldValue">{`${fundMaxInvestors}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Initial Contribution Amount</Typography>
                                <Typography variant="auditorFieldValue">{`${fundInitialContributionAmount}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Initial Contribution %</Typography>
                                <Typography variant="auditorFieldValue">{`${fundInitialContribution}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Size (Corpus)</Typography>
                                <Typography variant="auditorFieldValue">{`${fundSize}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Sponsor Name</Typography>
                                <Typography variant="auditorFieldValue">{`${fundSponsorName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Investment Manager</Typography>
                                <Typography variant="auditorFieldValue">{`${fundInvestmentManager}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Trustee Name</Typography>
                                <Typography variant="auditorFieldValue">{`${fundTrusteeName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Tax Advisor Name</Typography>
                                <Typography variant="auditorFieldValue">{`${taxAdvisorName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Legal Advisor Name</Typography>
                                <Typography variant="auditorFieldValue">{`${legalAdvisorName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Custodian Code</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCustodianCode}`}</Typography>
                            </Stack>
                        </Grid>
                        
                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Accountant Name</Typography>
                                <Typography variant="auditorFieldValue">{`${fundAccountantName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Accountant Email</Typography>
                                <Typography variant="auditorFieldValue">{`${fundAccountantEmail}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Accountant Contact Number</Typography>
                                <Typography variant="auditorFieldValue">{`${fundAccountantContactNumberPrefix} ${fundAccountantContactNumber}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Transfer Agent Name</Typography>
                                <Typography variant="auditorFieldValue">{`${transferAgentName}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Transfer Agent Accountant Email</Typography>
                                <Typography variant="auditorFieldValue">{`${transferAgentAccountantEmail}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Transfer Agent Contact Number</Typography>
                                <Typography variant="auditorFieldValue">{`${transferAgentContactNumberPrefix} ${transferAgentContactNumber}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund RTA Code</Typography>
                                <Typography variant="auditorFieldValue">{`${fundRtaCode}`}</Typography>
                            </Stack>
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        auditor
                        title="Fund Valuation Information"
                    >
                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Start Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundValuationStartDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Previous Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundPreviousDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Current Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCurrentDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Next Date</Typography>
                                <Typography variant="auditorFieldValue">{`${fundNextDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Previous Year End</Typography>
                                <Typography variant="auditorFieldValue">{`${fundPreviousYearEnd}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Current Year End</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCurrentYearEnd}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Prev NAV Date</Typography>
                                <Typography variant="auditorFieldValue">{`${prevNavDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">NAV Frequency</Typography>
                                <Typography variant="auditorFieldValue">{`${navFrequency}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Next NAV Date</Typography>
                                <Typography variant="auditorFieldValue">{`${nextNavDate}`}</Typography>
                            </Stack>
                        </Grid>

                        {/* <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Nav Publish Type</Typography>
                                <Typography variant="auditorFieldValue">{`${navPublishType}`}</Typography>
                            </Stack>
                        </Grid> */}

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Prev NAV Pub Date</Typography>
                                <Typography variant="auditorFieldValue">{`${prevNavPubDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">NAV Pub Frequency</Typography>
                                <Typography variant="auditorFieldValue">{`${navPubFrequency}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Next NAV Pub Date</Typography>
                                <Typography variant="auditorFieldValue">{`${nextNavPubDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund PL Comp Method</Typography>
                                <Typography variant="auditorFieldValue">{`${fundPlCompMethod}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Valuation Sequence</Typography>
                                <Typography variant="auditorFieldValue">{`${valuationSequence}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Unit Decimals</Typography>
                                <Typography variant="auditorFieldValue">{`${unitDecimals}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Round Method</Typography>
                                <Typography variant="auditorFieldValue">{`${roundMethod}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Round Decimals</Typography>
                                <Typography variant="auditorFieldValue">{`${roundDecimals}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund DD Notice Period</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDDNoticePeriod}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund DD Penalty Charges</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDDPenaltyCharges}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Topup Treatment</Typography>
                                <Typography variant="auditorFieldValue">{`${fundTopupTreatment}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund DD Treatment</Typography>
                                <Typography variant="auditorFieldValue">{`${fundDDTreatment}`}</Typography>
                            </Stack>
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={12}>
                    <FundCard
                        auditor
                        title="Fund Additional Information"
                    >
                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Management Fee</Typography>
                                <Typography variant="auditorFieldValue">{`${fundManagementFee}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Additional Fee</Typography>
                                <Typography variant="auditorFieldValue">{`${fundAdditionalFee}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Setup Fee</Typography>
                                <Typography variant="auditorFieldValue">{`${setupFee}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Trustee Fee</Typography>
                                <Typography variant="auditorFieldValue">{`${fundTrusteeFee}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Operating Expenses</Typography>
                                <Typography variant="auditorFieldValue">{`${operatingExpenses}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Goods & Services Tax %</Typography>
                                <Typography variant="auditorFieldValue">{`${goodsServiceTax}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Defaulter Penalty</Typography>
                                <Typography variant="auditorFieldValue">{`${defaulterPenalty}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Commitment Applicability</Typography>
                                <Typography variant="auditorFieldValue">{`${fundCommitmentApplicability}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Preferred Rate Of Return</Typography>
                                <Typography variant="auditorFieldValue">{`${preferredRateOfReturn}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Hurdle Rate</Typography>
                                <Typography variant="auditorFieldValue">{`${hurdleRate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">High Water Mark</Typography>
                                <Typography variant="auditorFieldValue">{`${highWaterMark}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Hurdle Start Date</Typography>
                                <Typography variant="auditorFieldValue">{`${hurdleStartDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">GP Sharing Ration</Typography>
                                <Typography variant="auditorFieldValue">{`${gpSharingRation}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Distribution Frequency</Typography>
                                <Typography variant="auditorFieldValue">{`${distributionFrequency}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Forex Source</Typography>
                                <Typography variant="auditorFieldValue">{`${forexSource}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">NAV Ratio Method</Typography>
                                <Typography variant="auditorFieldValue">{`${navRadioMethod}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Is Active</Typography>
                                <Typography variant="auditorFieldValue">{`${isActive}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Dormant</Typography>
                                <Typography variant="auditorFieldValue">{`${dormant}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Dormant Date</Typography>
                                <Typography variant="auditorFieldValue">{`${dormantDate}`}</Typography>
                            </Stack>
                        </Grid>

                        <Grid item xs={2.4}>
                            <Stack direction="column" spacing={1}>
                                <Typography variant="auditorFieldName">Fund Stamp Duty Borne</Typography>
                                <Typography variant="auditorFieldValue">{`${fundStampDutyBorne}`}</Typography>
                            </Stack>
                        </Grid>
                    </FundCard>
                </Grid>

                <Grid item xs={6}>
                    <FXButton
                        disableRipple
                        fullWidth
                        buttonVariant="normal"
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        disabled={alertSnackbarContext.open}
                        label="Reject"
                        onClick={() => setOpenRemarksPopup(true)}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton
                        disableRipple
                        fullWidth
                        disabled={alertSnackbarContext.open}
                        buttonVariant="submit"
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        label="Accept"
                        onClick={handleFormSubmit}
                    />
                </Grid>
            </Grid>

            <RemarksPopup 
                open={openRemarksPopup}
                isDisabled={rejectRemarkText.length===0 || !rejectRemarkText}
                onCancelClick={() => {
                    setOpenRemarksPopup(false);
                    setRejectRemarkText("");
                }}
                onSubmitClick={() => handleRejectSubmit()}
                rejectRemarkText={rejectRemarkText}
                setRejectRemarkText={setRejectRemarkText}            
            />
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        clearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default AuditorFundMasterForm;
