import AuditorFundMasterForm from "./AuditorFundMasterForm";
import PendingAuditorEntryItems from "./PendingAuditorEntryItems";
import { RootState } from "../../../../redux/store";
import fundMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/FundMaster/Auditor/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const AuditorFundMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .auditorForm
                .fundBasicDetails
                .companyCode
    ); 

    const { 
        setCompanyCode
    } = fundMasterDetailsFormDispatchActionsProvider();

    useEffect(()=>{
        setCompanyCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingAuditorEntryItems/>
                    : <AuditorFundMasterForm/>
            }
        </>
    );
};

export default AuditorFundMasterPage;
