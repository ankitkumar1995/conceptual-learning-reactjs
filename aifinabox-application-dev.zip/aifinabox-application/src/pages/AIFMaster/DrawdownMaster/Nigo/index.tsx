import NigoDrawdownMasterForm from "./NigoDrawdownMasterForm";

const NigoDrawdownMasterPage = () => {
    return (
        <>
            <NigoDrawdownMasterForm/>
        </>
    );
};

export default NigoDrawdownMasterPage;
