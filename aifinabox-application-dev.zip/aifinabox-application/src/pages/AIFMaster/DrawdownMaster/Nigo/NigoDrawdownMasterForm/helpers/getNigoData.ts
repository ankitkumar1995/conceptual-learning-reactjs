import {
    DrawdownMasterDetails as CheckerDrawdownMasterDetails
} from "../../../../../../redux/AifMaster/DrawdownMaster/Checker/initialState";
import {
    DrawdownMasterDetails as MakerDrawdownMasterDetails
} from "../../../../../../redux/AifMaster/DrawdownMaster/Maker/initialState";
import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerDrawdownMasterDetails, checkerFormState: CheckerDrawdownMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (key === "ddSourceFile" || key === "ddSourceFileS3Key" || key === "ddSourceFileS3SignedURL" || key === "ddSourceFileFormat") 
            continue;

        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerDrawdownMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }

    return nigoData;
}
