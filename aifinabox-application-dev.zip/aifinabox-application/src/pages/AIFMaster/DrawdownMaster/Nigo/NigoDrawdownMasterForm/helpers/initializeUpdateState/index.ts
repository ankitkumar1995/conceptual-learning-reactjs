import { Field } from "../../../../Maker/MakerDrawdownMasterForm/interfaces/field.types";

export type UpdateState = { 
    [fieldName in Field]: boolean
};

function initializeUpdateState(): UpdateState {
    return (
        {
            "allotmentDate1": false,
            "allotmentDate2": false,
            "allotmentDate3": false,
            "allotmentDate4": false,
            "allotmentMethod": false,
            "clientCode": false,
            "companyName": false,
            "ddExtensionDate": false,
            "ddNo": false,
            "ddSourceFile": false,
            "endDate": false,
            "eventOrBatchId": false,
            "foliosApplicableFromDate": false,
            "foliosApplicableToDate": false,
            "fundClassCategory": false,
            "fundCode": false,
            "fundName": false,
            "isActive": false,
            "percentageOfDD": false,
            "startDate": false,
            "totalCommitment": false,
        }
    );
}

export default initializeUpdateState;
