import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import initializeUpdateState, { 
    UpdateState 
} from "../../Nigo/NigoDrawdownMasterForm/helpers/initializeUpdateState";

import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import NigoTable from "../../../components/NigoTable";
import { RootState } from "../../../../../redux/store";
import drawdownMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Checker/dispatchActionsProvider";
import drawdownMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Nigo/dispatchActionsProvider";
import drawdownMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/PageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import usePostDrawdownMaster from "../../../../../hooks/api/usePostDrawdownMaster";
import { useSelector } from "react-redux";
import { useState } from "react";

const NigoDrawdownMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [updateState, setUpdateState] = useState<UpdateState>(initializeUpdateState);

    const navigate = useNavigate();

    const checkerDrawdownMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .checkerForm
    );
    
    const nigoDrawdownMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .nigoForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { clientCode } = checkerDrawdownMasterFormState;
    const { firstName, lastName } = userContextState;

    const { 
        checkerData, 
        makerData, 
        nigoMetaData
    } = nigoDrawdownMasterFormState;

    const { 
        "clearState": clearNigoState,
        setCheckerData, 
        setMakerData, 
        setNigoMetaData 
    } = drawdownMasterNigoDetailsFormDispatchActionsProvider();

    const { "clearState": clearCheckerState }  = drawdownMasterDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised,
    } = drawdownMasterPageContextDispatchActionsProvider();

    const postDrawdownMaster = usePostDrawdownMaster();

    const handleFormSubmit = () => {
        let modifiedCheckerData = checkerData;
        let modifiedMakerData = makerData;

        nigoMetaData.forEach((data) => {
            const fieldName = data.field;
            const checkerValue = data.checkerEntry;
            const makerValue = data.makerEntry;

            modifiedCheckerData = {
                ...modifiedCheckerData,
                "ddSourceFileFormat": makerData.ddSourceFileFormat,
                "ddSourceFileS3Key": makerData.ddSourceFileS3Key,
                [fieldName]: checkerValue,
            };

            modifiedMakerData = {
                ...modifiedMakerData,
                [fieldName]: makerValue,
            };
        });

        setCheckerData(modifiedCheckerData);
        setMakerData(modifiedMakerData);

        postDrawdownMaster(modifiedCheckerData, `${firstName} ${lastName}`, "0", userId, "C", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `NIGO Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "NIGO Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `NIGO Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "NIGO Entry Failed",
                });
            });
    };

    return (
        <>
            <NigoTable
                disableSubmit={alertSnackbarContext.open} 
                nigoData={nigoMetaData}
                onDataChange={(nigoData) => {
                    setNigoMetaData(nigoData);
                }}
                onSubmitClicked={handleFormSubmit}
            />
            
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        clearCheckerState();
                        clearNigoState();
                        setNigoRaised(false);
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default NigoDrawdownMasterForm;
