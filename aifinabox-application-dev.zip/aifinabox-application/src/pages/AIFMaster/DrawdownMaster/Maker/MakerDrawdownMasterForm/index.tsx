import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import { 
    DrawdownMasterDetails, 
    initialDrawdownMasterDetailsFormState 
} from "../../../../../redux/AifMaster/DrawdownMaster/Maker/initialState";
import {
    FieldValidation,
    initializeFieldValidation,
} from "../../../../../interfaces/FieldValidation.types";
import {
    Grid,
    Stack,
    Typography
} from "@mui/material";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import useFetchClientDetails, { 
    ClientDetails,
} from "../../../../../hooks/api/useFetchClientDetails";
import useFetchFundDetails, { FundDetails } from "../../../../../hooks/api/useFetchFundCodeDetails";

import AddIcon from "../../../../../icons/AddIcon";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXFileInput from "../../../../../components/FXFileInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { RootState } from "../../../../../redux/store";
import { ToWords } from "to-words";
import axios from "axios";
import dayjs from "dayjs";
import drawdownMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Maker/dispatchActionsProvider";
import { fontFamily } from "../../../../../themes/typography/fontFamily";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import isFormComplete from "./helper/isFormComplete";
import isFormUpdated from "./helper/isFormUpdated";
import isFormValid from "./helper/isFormValid";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import onChangePercentageValidator from "../../../../../validators/onChangeValidator/onChangePercentageValidator";
import { setOpenBackdrop } from "../../../../../redux/ApplicationContext/reducer";
import useFetchDrawdownMaster from "../../../../../hooks/api/useFetchDrawdownMaster";
import useFetchEventIds from "../../../../../hooks/api/useFetchEventIds";
import useFetchFundClass from "../../../../../hooks/api/useFetchFundClass";
import useFormRef from "./hooks/useFormRef";
import useGenerateEventId from "../../../../../hooks/api/useGenerateEventId";
import usePostDrawdownMaster from "../../../../../hooks/api/usePostDrawdownMaster";

const MakerDrawdownMasterForm = () => {
    const formRef = useFormRef();
    const dispatch = useDispatch();
    const toWords = new ToWords();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [clientDetails, setClientDetails] = useState<ClientDetails[]>([]);
    const [fundClassMenuItems, setFundClassMenuItems] = useState([initializeMenuItem()]);
    const [eventIds, setEventIds] = useState([initializeMenuItem()]);
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState());
    const [fundDetails, setFundDetails] = useState<FundDetails[]>([]);
    const [updateState, setUpdateState] = useState<UpdateState>(initializeUpdateState);
    const [updateExistingFlag, setUpdateExistingFlag] = useState<"0" | "1">("0");
    const [drawdownMaster, setDrawdownMaster] = useState<DrawdownMasterDetails>(initialDrawdownMasterDetailsFormState);

    const drawdownMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .makerForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        allotmentMethodMenuItems,
    } = selectInputMenuItems;

    const {
        allotmentDate1,
        allotmentDate2,
        allotmentDate3,
        allotmentDate4,
        allotmentMethod,
        clientCode,
        companyName,
        ddExtensionDate,
        ddNo,
        ddSourceFile,
        ddSourceFileS3SignedURL,
        endDate,
        eventOrBatchId,
        foliosApplicableFromDate,
        foliosApplicableToDate,
        fundClassCategory,
        fundCode,
        fundName,
        isActive,
        percentageOfDD,
        startDate,
        totalCommitment,
    } = drawdownMasterFormState;

    const {
        clearState,
        setAllotmantDate1,
        setAllotmentDate2,
        setAllotmentDate3,
        setAllotmentDate4,
        setAllotmentMethod,
        setClientCode,
        setCompanyName,
        setDDExtensionDate,
        setDDNo,
        setDDSourceFile,
        setDDSourceFileFormat,
        setDDSourceFileS3Key,
        setDDSourceFileS3SignedURL,
        setDrawdownMasterMakerState,
        setEndDate,
        setEventOrBatchId,
        setFoliosApplicableFromDate,
        setFoliosApplicableToDate,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setIsActive,
        setPercentageOfDD,
        setStartDate,
        setTotalCommitment,
    } = drawdownMasterDetailsFormDispatchActionsProvider();

    const fetchClientDetails = useFetchClientDetails();
    const fetchDrawdownMaster = useFetchDrawdownMaster();
    const fetchEventIds = useFetchEventIds();
    const fetchFundDetails = useFetchFundDetails();
    const generateEventId = useGenerateEventId();
    const postDrawdownMaster = usePostDrawdownMaster();
    const fetchFundClass = useFetchFundClass();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey as Field];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        setFormErrorState(initializeFormErrorState());
        clearState();
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };      

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const onFundCodeChange = (value: string) => {
        setFundCode(value);
        const matchingFund = fundDetails.find((code) => code.fundCode.label === value);
        matchingFund && setFundName(matchingFund.fundName.value);
        fetchFundClass(clientCode,value)
            .then((response) => {
                setFundClassMenuItems(response);
            })
            .catch((error) => console.error(error));
    };

    const handleFetchFundCodes = (clientCode: string) => {
        fetchFundDetails(clientCode, "M")
            .then((result) => {
                setFundDetails(result);
            });
    };

    const handleFetchEventIds = (value: string) => {
        fetchEventIds(clientCode, fundCode, value)
            .then((result) => setEventIds(result));
    };

    const onClientCodeChange = (value: string) => {
        setClientCode(value);
        const matchingFund = clientDetails.find((code) => code.clientCode === value);
        matchingFund && setCompanyName(matchingFund.clientName);

        handleFetchFundCodes(value);
    };

    const handleFundClassChange = async (_fundClass: string) => {
        setFundClassCategory(_fundClass);
        handleFetchEventIds(_fundClass);
    };

    const handleFetchDDMaster = (_eventOrBatchId: string) => {
        setEventOrBatchId(_eventOrBatchId);
        if (updateExistingFlag === "1") {

            fetchDrawdownMaster(clientCode, updateExistingFlag, fundClassCategory, fundCode, _eventOrBatchId, userId)
                .then((drawdownMaster) => {
                    const {
                        "drawdownMasterFormState": drawdownMasterData,
                    } = drawdownMaster;
                    setDrawdownMasterMakerState(drawdownMasterData);
                    setDrawdownMaster(drawdownMasterData);
                    setFormErrorState(initializeFormErrorState);

                    (formRef["ddNo"].current as HTMLInputElement).value = drawdownMasterData.ddNo;
                    (formRef["percentageOfDD"].current as HTMLInputElement).value = drawdownMasterData.percentageOfDD;
                    (formRef["totalCommitment"].current as HTMLInputElement).value = drawdownMasterData.totalCommitment;
                })
                .catch((error) => console.error(error));
        }
    };

    const handleFormSubmit = async () => {
        await postDrawdownMaster(drawdownMasterFormState, `${firstName} ${lastName}`, (updateExistingFlag), userId, "M", updateState)
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });		
    };

    const handleUploadFileAndSubmitForm = async () => {
        dispatch(setOpenBackdrop(true));
        const putS3ObjectAxiosConfig = {
            "data": ddSourceFile,
            "headers": { 
                "Content-Type": "application/octet-stream",
            },
            "method": "put",
            "url": ddSourceFileS3SignedURL,
        };

        await axios(putS3ObjectAxiosConfig)
            .then(() => {
                handleFormSubmit();
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                setAlertSnackbarContext({
                    "description": `Maker Entry Failed Client Code ${clientCode}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleChangeUpdate = (field: Field, value: string) => {
        if (updateExistingFlag === "1") {
            if (drawdownMaster[field] === value) {
                setUpdateState({
                    ...updateState,
                    [field]: false
                });
            }
            else {
                setUpdateState({
                    ...updateState,
                    [field]: true
                });
            }
        }
    };

    useEffect(() => {
        fetchClientDetails("dd_master", updateExistingFlag)
            .then((result) => {
                setClientDetails(result);
            });
    }, []);

    const handleAddNew = () => {
        clearState();
        setUpdateExistingFlag("0");
        generateEventId()
            .then((result) => {
                setEventOrBatchId(result);
            });
    };

    useEffect(() => {
        handleClearState();
    }, []);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        
                        <Typography variant="formHeading" display="flex">
                            {
                                (updateExistingFlag === "0")
                                    ? "Add DD Master"
                                    : "Update DD Master"
                            }
                        </Typography>
                        
                        <Stack direction="row" spacing={2}>
                            <FXButton
                                label="Add New" 
                                buttonVariant="flowaction"
                                startIcon={<AddIcon/>}
                                disabled={(updateExistingFlag === "0")}
                                onClick={() => {
                                    handleClearState();
                                    setUpdateExistingFlag("0");
                                    handleAddNew();
                                }}
                                sx={{
                                    "fontFamily": fontFamily,
                                    "fontSize": "12px",
                                    "fontWeight": 500,
                                }}
                            />
                
                            <FXButton 
                                label="Update Existing" 
                                buttonVariant="flowaction"
                                startIcon={<EditIcon/>}
                                disabled={(updateExistingFlag === "1")}
                                onClick={() => {
                                    setFormErrorState(initializeFormErrorState());
                                    handleClearState();
                                    setUpdateExistingFlag("1");
                                }}
                                sx={{
                                    "fontFamily": fontFamily,
                                    "fontSize": "12px",
                                    "fontWeight": 500,
                                }}
                            />
                        </Stack>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Client Code"
                        required
                        value={clientCode}
                        onValueChange={(value) => {
                            handleClearState();
                            onClientCodeChange(value);
                            generateEventId()
                                .then((result) => {
                                    setEventOrBatchId(result);
                                });
                        }}
                        menuItems={clientDetails.map((code) => (
                            {
                                "label": code.clientCode,
                                "value": code.clientCode
                            }
                        ))}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "clientCode")}
                        error={formErrorState.clientCode.isError}
                        helperText={formErrorState.clientCode.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Company Name"
                        required
                        readOnly
                        disabled
                        value={companyName}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Fund Code"
                        required
                        value={fundCode}
                        onValueChange={onFundCodeChange}
                        menuItems={fundDetails.map((fund) => fund.fundCode)}
                        onFieldErrorChange={(fieldError) =>
                            setFormErrorState({
                                ...formErrorState,
                                "fundCode": fieldError,
                                "fundName": initializeFieldValidation(),
                            }) 
                        }
                        error={formErrorState.fundCode.isError}
                        helperText={formErrorState.fundCode.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Fund Name"
                        required
                        value={fundName}
                        inputRef={formRef.fundName}
                        onBlur={() => handleInputFieldChange("fundName", setFundName)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "fundName")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "fundName")}
                        error={formErrorState.fundName.isError}
                        helperText={formErrorState.fundName.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Fund Class Category"
                        required
                        value={fundClassCategory}
                        onValueChange={(value) => {
                            handleFundClassChange(value);
                            handleChangeUpdate("fundClassCategory", value);
                        }}
                        menuItems={fundClassMenuItems}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "fundClassCategory")}
                        error={formErrorState.fundClassCategory.isError}
                        helperText={formErrorState.fundClassCategory.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="% of DD"
                        required
                        forbidTo="decimal-number"
                        inputRef={formRef.percentageOfDD}
                        onValueChange={(value) => handleChangeUpdate("percentageOfDD", value)}
                        onBlur={() => handleInputFieldChange("percentageOfDD", setPercentageOfDD)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "percentageOfDD")}
                        error={formErrorState.percentageOfDD.isError}
                        helperText={formErrorState.percentageOfDD.helperText}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Folios Applicable From Date"
                        value={foliosApplicableFromDate}
                        onValueChange={(value) => {
                            handleChangeUpdate("foliosApplicableFromDate", value);
                            setFoliosApplicableFromDate(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "foliosApplicableFromDate")}
                        error={formErrorState.foliosApplicableFromDate.isError}
                        helperText={formErrorState.foliosApplicableFromDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Folios Applicable To Date"
                        value={foliosApplicableToDate}
                        onValueChange={(value) => {
                            handleChangeUpdate("foliosApplicableToDate", value);
                            setFoliosApplicableToDate(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "foliosApplicableToDate")}
                        error={formErrorState.foliosApplicableToDate.isError}
                        helperText={formErrorState.foliosApplicableToDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Start Date"
                        required
                        value={startDate}
                        onValueChange={(value) => {
                            handleChangeUpdate("startDate", value); 
                            setStartDate(value);
                        }}
                        disableFuture
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": true, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "startDate")}
                        error={formErrorState.startDate.isError}
                        helperText={formErrorState.startDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="End Date"
                        required
                        value={endDate}
                        onValueChange={(value) => {
                            handleChangeUpdate("endDate",value);
                            setEndDate(value);
                        }}
                        disablePast
                        shouldDisableDate={(date) => 
                            date.isSame(dayjs(), "day")
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": true, 
                            "disablePresent": true,
                            "disableWeekends": false,
                        }}
                        onFieldValidationChange={(fieldError) => {
                            handleFieldErrorChange(fieldError, "endDate");
                        }}
                        error={formErrorState.endDate.isError}
                        helperText={formErrorState.endDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="DD No"
                        required
                        forbidTo="numbers"
                        maxLength={2}
                        inputRef={formRef.ddNo}
                        onBlur={() => handleInputFieldChange("ddNo", setDDNo)}
                        onValueChange={(value) => handleChangeUpdate("ddNo", value)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ddNo")}
                        error={formErrorState.ddNo.isError}
                        helperText={formErrorState.ddNo.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="DD Extension Date"
                        value={ddExtensionDate}
                        onValueChange={(value) => {
                            handleChangeUpdate("ddExtensionDate", value);
                            setDDExtensionDate(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "ddExtensionDate")}
                        error={formErrorState.ddExtensionDate.isError}
                        helperText={formErrorState.ddExtensionDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 1"
                        value={allotmentDate1}
                        onValueChange={(value) => {
                            handleChangeUpdate("allotmentDate1", value);
                            setAllotmantDate1(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate1")}
                        error={formErrorState.allotmentDate1.isError}
                        helperText={formErrorState.allotmentDate1.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 2"
                        value={allotmentDate2}
                        onValueChange={(value) => {
                            handleChangeUpdate("allotmentDate2", value);
                            setAllotmentDate2(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate2")}
                        error={formErrorState.allotmentDate2.isError}
                        helperText={formErrorState.allotmentDate2.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 3"
                        value={allotmentDate3}
                        onValueChange={(value) => {
                            handleChangeUpdate("allotmentDate3", value);
                            setAllotmentDate3(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate3")}
                        error={formErrorState.allotmentDate3.isError}
                        helperText={formErrorState.allotmentDate3.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 4"
                        value={allotmentDate4}
                        onValueChange={(value) => {
                            handleChangeUpdate("allotmentDate4", value);
                            setAllotmentDate4(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate4")}
                        error={formErrorState.allotmentDate4.isError}
                        helperText={formErrorState.allotmentDate4.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Total Commitment"
                        maxLength={15}
                        forbidTo="numbers"
                        inputRef={formRef.totalCommitment}
                        onBlur={() => handleInputFieldChange("totalCommitment", setTotalCommitment)}
                        onValueChange={(value) => handleChangeUpdate("totalCommitment", value)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "totalCommitment")}
                        error={formErrorState.totalCommitment.isError}
                        helperText={
                            formErrorState.totalCommitment.isError
                                ? formErrorState.totalCommitment.helperText
                                : (
                                    (Number(totalCommitment) > 0) &&
                                `${toWords.convert(Number(totalCommitment), {"currency": true})}`
                                )
                        }
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Allotment Method"
                        required
                        value={allotmentMethod}
                        onValueChange={(value) => {
                            handleChangeUpdate("allotmentMethod", value);
                            setAllotmentMethod(value);
                        }}
                        menuItems={allotmentMethodMenuItems}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentMethod")}
                        error={formErrorState.allotmentMethod.isError}
                        helperText={formErrorState.allotmentMethod.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXFileInput
                        label="DD Source"
                        required
                        accept={[".pdf", ".eml"]}
                        documentType="DDSRC"
                        assetType="Client Assets"
                        identifier={
                            (clientCode !== "" && fundCode !== "") 
                                ? `CLIENT_CODE_${clientCode}/FUND_CODE_${fundCode}`
                                : ""
                        }
                        value={(ddSourceFile === null) ? "" : undefined}
                        onFileUpload={(fileDetails) => {
                            setDDSourceFile(fileDetails.file);
                        }}
                        onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
                            setDDSourceFileS3Key(s3Key);
                            setDDSourceFileS3SignedURL(s3Url);
                            setDDSourceFileFormat(format);
                        }}
                        onRemoveFile={() => {
                            setFormErrorState({
                                ...formErrorState,
                                "ddSourceFile": initializeFieldValidation(),
                            });
                            setDDSourceFile(null);
                            setDDSourceFileS3Key("");
                            setDDSourceFileS3SignedURL("");
                            setDDSourceFileFormat("");
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ddSourceFile")}
                        error={formErrorState.ddSourceFile.isError}
                        helperText={formErrorState.ddSourceFile.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Is Active"
                        required 
                        row 
                        radioButtonValues={[{"label": "Yes","value": "Yes"},{"label": "No","value": "No"}]}
                        value={isActive}
                        onValueChange={(value) => {
                            handleFieldErrorChange(initializeFieldValidation(), "isActive");
                            handleChangeUpdate("isActive", value);
                            setIsActive(value);
                        }}
                    />
                </Grid>

                <Grid item xs={3}>
                    {
                        (updateExistingFlag === "0")
                            ? <FXInput
                                label="Event/BatchId"
                                required
                                readOnly
                                disabled
                                value={eventOrBatchId}
                            />
                            : <FXSelectInput
                                label="Event/BatchId"
                                required
                                value={eventOrBatchId}
                                onValueChange={(value) => handleFetchDDMaster(value)}
                                menuItems={eventIds}
                            />
                    }
                </Grid>
                {/* 
                <Grid item xs={6}>
                    <></>
                </Grid> */}

                <Grid item xs={6}>
                    <FXButton
                        label="Clear"
                        buttonVariant="normal"
                        fullWidth
                        onClick={handleClearState}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        label="Submit to Checker"
                        buttonVariant="submit"
                        endIcon={<ArrowForwardIosIcon/>}
                        fullWidth
                        disabled={
                            alertSnackbarContext.open ||
                            !(isFormComplete(drawdownMasterFormState)) ||
                            !(isFormValid(formErrorState)) ||
                            isFormUpdated(updateState,updateExistingFlag)
                        }
                        onClick={() => {
                            ddSourceFileS3SignedURL === ""
                                ? handleFormSubmit()
                                : handleUploadFileAndSubmitForm();
                        }}
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default MakerDrawdownMasterForm;
