import { UpdateState } from "../initializeUpdateState";

function isFormUpdated (
    UpdateState: UpdateState,
    updateExistingFlag: "0" | "1"
) {
    if (updateExistingFlag === "0")
        return false;

    return !(
        UpdateState.allotmentDate1 ||
        UpdateState.allotmentDate2 ||
        UpdateState.allotmentDate3 ||
        UpdateState.allotmentDate4 ||
        UpdateState.allotmentMethod ||
        UpdateState.clientCode ||
        UpdateState.companyName ||
        UpdateState.ddExtensionDate ||
        UpdateState.ddNo ||
        UpdateState.ddSourceFile ||
        UpdateState.endDate ||
        UpdateState.eventOrBatchId ||
        UpdateState.foliosApplicableFromDate ||
        UpdateState.foliosApplicableToDate ||
        UpdateState.fundClassCategory ||
        UpdateState.fundCode ||
        UpdateState.fundName ||
        UpdateState.isActive ||
        UpdateState.percentageOfDD ||
        UpdateState.startDate ||
        UpdateState.totalCommitment
    );
};

export default isFormUpdated;
