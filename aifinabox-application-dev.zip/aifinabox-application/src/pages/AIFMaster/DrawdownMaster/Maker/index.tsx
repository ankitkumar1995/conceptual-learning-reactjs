import MakerDrawdownMasterForm from "./MakerDrawdownMasterForm";

const MakerDrawdownMasterPage = () => {
    return (
        <>
            <MakerDrawdownMasterForm/>
        </>
    );
};

export default MakerDrawdownMasterPage;
