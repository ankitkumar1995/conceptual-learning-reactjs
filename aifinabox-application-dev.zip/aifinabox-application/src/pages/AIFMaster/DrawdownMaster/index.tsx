import CheckerDrawdownMasterPage from "./Checker";
import MakerDrawdownMasterPage from "./Maker";
import NigoDrawdownMasterForm from "./Nigo/NigoDrawdownMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const DrawdownMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerDrawdownMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerDrawdownMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoDrawdownMasterForm/>
            }
        </>
    );
};

export default DrawdownMasterPage;
