import CheckerDrawdownMasterForm from "./CheckerDrawdownMasterForm";
import PendingCheckerEntryItems from "./PendingCheckerEntryItems";
import { RootState } from "../../../../redux/store";
import drawdownMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/DrawdownMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerDrawdownMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .checkerForm
                .clientCode
    );

    const { 
        setClientCode,
    } = drawdownMasterDetailsFormDispatchActionsProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingCheckerEntryItems/>
                    : <CheckerDrawdownMasterForm/>
            }
        </>
    );
};

export default CheckerDrawdownMasterPage;
