import { 
    DrawdownMasterDetails 
} from "../../../../../../../redux/AifMaster/DrawdownMaster/Maker/initialState";

function isFormComplete(drawdownMasterDetails: DrawdownMasterDetails): boolean {
    const {
        allotmentDate1,
        allotmentDate2,
        allotmentDate3,
        allotmentDate4,
        allotmentMethod,
        clientCode,
        companyName,
        ddExtensionDate,
        ddNo,
        ddSourceFile,
        endDate,
        eventOrBatchId,
        foliosApplicableFromDate,
        foliosApplicableToDate,
        fundClassCategory,
        fundCode,
        fundName,
        isActive,
        percentageOfDD,
        startDate,
        totalCommitment,
    } = drawdownMasterDetails;

    const isActiveFilled = ( isActive.length !== 0 );
    const isAllotmentMethodFilled = ( allotmentMethod.length !== 0 );
    const isClientCodeFilled = ( clientCode.length !== 0 );
    const isCompanyNameFilled = ( companyName.length !== 0 );
    const isDDNoFilled = ( ddNo.length !== 0 );
    const isDDSourceFilled = ( ddSourceFile !== null );
    const isEndDateFilled = ( 
        endDate !== null &&
        endDate.length !== 0
    );
    const isEventOrBatchIdFilled = ( eventOrBatchId.length !== 0 );
    const isFundClassCategoryFilled = ( fundClassCategory.length !== 0 ); 
    const isFundCodeFilled = ( fundCode.length !== 0 );
    const isFundNameFilled = ( fundName.length !== 0 );
    const isPercentageOfDDFilled = ( percentageOfDD.length !== 0 );
    const isStartDateFilled = (
        startDate !== null &&
        startDate.length !== 0
    );

    return (
        isActiveFilled &&
        isAllotmentMethodFilled &&
        isClientCodeFilled &&
        isCompanyNameFilled &&
        isDDNoFilled &&
        isDDSourceFilled &&
        isEndDateFilled &&
        isEventOrBatchIdFilled &&
        isFundClassCategoryFilled &&
        isFundCodeFilled &&
        isFundNameFilled &&
        isPercentageOfDDFilled &&
        isStartDateFilled
    );
}

export default isFormComplete;
