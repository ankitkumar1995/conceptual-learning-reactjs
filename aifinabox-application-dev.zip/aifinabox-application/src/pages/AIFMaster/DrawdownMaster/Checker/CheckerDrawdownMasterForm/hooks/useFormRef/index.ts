import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

type FormRef = {
    [fieldName in Field]: RefObject<HTMLInputElement>;
};

function useFormRef(): FormRef {
    const formRef: FormRef = {
        "allotmentDate1": useRef<HTMLInputElement>(null),
        "allotmentDate2": useRef<HTMLInputElement>(null),
        "allotmentDate3": useRef<HTMLInputElement>(null),
        "allotmentDate4": useRef<HTMLInputElement>(null),
        "allotmentMethod": useRef<HTMLInputElement>(null),
        "clientCode": useRef<HTMLInputElement>(null),
        "companyName": useRef<HTMLInputElement>(null),
        "ddExtensionDate": useRef<HTMLInputElement>(null),
        "ddNo": useRef<HTMLInputElement>(null),
        "ddSourceFile": useRef<HTMLInputElement>(null),
        "endDate": useRef<HTMLInputElement>(null),
        "eventOrBatchId": useRef<HTMLInputElement>(null),
        "foliosApplicableFromDate": useRef<HTMLInputElement>(null),
        "foliosApplicableToDate": useRef<HTMLInputElement>(null),
        "fundClassCategory": useRef<HTMLInputElement>(null),
        "fundCode": useRef<HTMLInputElement>(null),
        "fundName": useRef<HTMLInputElement>(null),
        "isActive": useRef<HTMLInputElement>(null),
        "percentageOfDD": useRef<HTMLInputElement>(null),
        "startDate": useRef<HTMLInputElement>(null),
        "totalCommitment": useRef<HTMLInputElement>(null),
    };

    return formRef;
}

export default useFormRef;
