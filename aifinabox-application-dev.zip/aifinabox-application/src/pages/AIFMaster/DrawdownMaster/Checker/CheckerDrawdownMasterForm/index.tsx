import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Button,
    Grid,
    IconButton,
    Typography
} from "@mui/material";
import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { 
    UpdateState 
} from "../../Checker/CheckerDrawdownMasterForm/helper/initializeUpdateState";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";

import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import {
    UpdateState as CheckerUpdateState
} from "../../../../../redux/AifMaster/DrawdownMaster/Update/initialState";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXFileInput from "../../../../../components/FXFileInput";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { RootState } from "../../../../../redux/store";
import { ToWords } from "to-words";
import axios from "axios";
import dayjs from "dayjs";
import drawdownMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Checker/dispatchActionsProvider";
import drawdownMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Nigo/dispatchActionsProvider";
import drawdownMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/PageContext/dispatchActionsProvider";
import { getNigoData } from "../../Nigo/NigoDrawdownMasterForm/helpers/getNigoData";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import onChangePercentageValidator from "../../../../../validators/onChangeValidator/onChangePercentageValidator";
import { setOpenBackdrop } from "../../../../../redux/ApplicationContext/reducer";
import useFormRef from "./hooks/useFormRef";
import { useNavigate } from "react-router-dom";
import usePostDrawdownMaster from "../../../../../hooks/api/usePostDrawdownMaster";

const CheckerDrawdownMasterForm = () => {
    const formRef = useFormRef();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const toWords = new ToWords();

    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [checkerUpdateState, setCheckerUpdateState] = useState<UpdateState>(initializeUpdateState);
    const [isDataMatched, setIsDataMatched] = useState(false);
    const drawdownMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .checkerForm
    );

    const nigoDrawdownMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .nigoForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .drawdownMasterState
                .updateState            
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        allotmentMethodMenuItems,
    } = selectInputMenuItems;

    const {
        allotmentDate1,
        allotmentDate2,
        allotmentDate3,
        allotmentDate4,
        allotmentMethod,
        clientCode,
        companyName,
        ddExtensionDate,
        ddNo,
        ddSourceFile,
        ddSourceFileS3SignedURL,
        endDate,
        eventOrBatchId,
        foliosApplicableFromDate,
        foliosApplicableToDate,
        fundClassCategory,
        fundCode,
        fundName,
        isActive,
        percentageOfDD,
        startDate,
        totalCommitment,
    } = drawdownMasterFormState;

    const {
        clearState,
        clearCriticalFieldsCheckerEntry,
        setAllotmantDate1,
        setAllotmentDate2,
        setAllotmentDate3,
        setAllotmentDate4,
        setAllotmentMethod,
        setClientCode,
        setDDExtensionDate,
        setDDNo,
        setDDSourceFile,
        setDDSourceFileFormat,
        setDDSourceFileS3Key,
        setDDSourceFileS3SignedURL,
        setEndDate,
        setEventOrBatchId,
        setFoliosApplicableFromDate,
        setFoliosApplicableToDate,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setIsActive,
        setPercentageOfDD,
        setStartDate,
        setTotalCommitment,
    } = drawdownMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerData,
        setNigoMetaData
    } = drawdownMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised,
    } = drawdownMasterPageContextDispatchActionsProvider();

    const postDrawdownMaster = usePostDrawdownMaster();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey as Field];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
    };

    const handleClearCriticalFields = (updateState: CheckerUpdateState) => {
        if (updateState.updateFlag === "0" || (updateState.percentageOfDD && updateState.updateFlag === "1")) {
            if (formRef.percentageOfDD.current)
                formRef.percentageOfDD.current.value = "";
        }   
        
        if (updateState.updateFlag === "0" || (updateState.ddNo && updateState.updateFlag === "1")) {
            if (formRef.ddNo.current)
                formRef.ddNo.current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.totalCommitment && updateState.updateFlag === "1")) {
            if (formRef.totalCommitment.current)
                formRef.totalCommitment.current.value = "";
        }
        clearCriticalFieldsCheckerEntry(updateState);
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    useEffect(()=>{
        if (JSON.stringify(nigoDrawdownMasterFormState.makerData) === JSON.stringify(drawdownMasterFormState)){
            setIsDataMatched(true);
        }
    },[drawdownMasterFormState]);

    const handleFormSubmit = () => {
        postDrawdownMaster(drawdownMasterFormState, `${firstName} ${lastName}`, "0", userId, "C", checkerUpdateState)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${clientCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    const handleUploadFileAndSubmitForm = async () => {
        dispatch(setOpenBackdrop(true));
        const putS3ObjectAxiosConfig = {
            "data": ddSourceFile,
            "headers": { 
                "Content-Type": "application/octet-stream",
            },
            "method": "put",
            "url": ddSourceFileS3SignedURL,
        };

        await axios(putS3ObjectAxiosConfig)
            .then(() => {
                handleFormSubmit();
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                setAlertSnackbarContext({
                    "description": `Maker Entry Failed Client Code ${clientCode}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    useEffect(() => {
        if (startDate !== null && endDate !== null){
            const start = dayjs(startDate, "DD/MM/YYYY");
            const end = dayjs(endDate, "DD/MM/YYYY");

            const endDay = end.date();
            const endMonth = end.month() + 1;
            const endYear = end.year();

            const startDay = start.date();
            const startMonth = start.month() + 1;
            const startYear = start.year();

            if (endYear < startYear) {
                setFormErrorState({
                    ...formErrorState,
                    "endDate": {
                        "helperText": "End Date Must be greater than start Date",
                        "isError": true,
                        "isVerified": false,
                        "isWarning": false,
                    },
                });
            }
            if (endYear > startYear) {
                setFormErrorState({
                    ...formErrorState,
                    "endDate": initializeFieldValidation(),
                });
            }
            if (endYear === startYear) {
                if (endMonth < startMonth) {
                    setFormErrorState({
                        ...formErrorState,
                        "endDate": {
                            "helperText": "End Date Must be greater than start Date",
                            "isError": true,
                            "isVerified": false,
                            "isWarning": false,
                        },
                    });
                }
                if (endMonth > startMonth) {
                    setFormErrorState({
                        ...formErrorState,
                        "endDate": initializeFieldValidation(),
                    });
                }
                if (endMonth === startMonth) {
                    if (endDay <= startDay) {
                        setFormErrorState({
                            ...formErrorState,
                            "endDate": {
                                "helperText": "End Date Must be greater than start Date",
                                "isError": true,
                                "isVerified": false,
                                "isWarning": false,
                            },
                        });
                    }
                    if (endDay > startDay) {
                        setFormErrorState({
                            ...formErrorState,
                            "endDate": initializeFieldValidation(),
                        });
                    }
                }
            }
        }
    },[startDate, endDate]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    handleClearState();
                                    setClientCode("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                DD Master
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Client Code"
                        required 
                        disabled
                        readOnly
                        value={clientCode}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Company Name"
                        required
                        readOnly
                        disabled
                        value={companyName}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Fund Code"
                        required
                        disabled
                        readOnly
                        value={fundCode}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Fund Name"
                        required
                        disabled
                        readOnly
                        value={fundName}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Fund Class Category"
                        required
                        disabled
                        readOnly
                        value={fundClassCategory}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="% of DD"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.percentageOfDD)}
                        forbidTo="decimal-number"
                        defaultValue={percentageOfDD}
                        inputRef={formRef.percentageOfDD}
                        onBlur={() => handleInputFieldChange("percentageOfDD", setPercentageOfDD)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "percentageOfDD")}
                        error={formErrorState.percentageOfDD.isError}
                        helperText={formErrorState.percentageOfDD.helperText}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Folios Applicable From Date"
                        disabled={updateState.updateFlag === "1" && !(updateState.foliosApplicableFromDate)}
                        value={foliosApplicableFromDate}
                        onValueChange={setFoliosApplicableFromDate}
                        // shouldDisableDate={(date) => 
                        //     date.day() === 0 ||
                        //     date.day() === 6
                        // }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "foliosApplicableFromDate")}
                        error={formErrorState.foliosApplicableFromDate.isError}
                        helperText={formErrorState.foliosApplicableFromDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Folios Applicable To Date"
                        disabled={updateState.updateFlag === "1" && !(updateState.foliosApplicableToDate)}
                        value={foliosApplicableToDate}
                        onValueChange={setFoliosApplicableToDate}
                        // shouldDisableDate={(date) => 
                        //     date.day() === 0 ||
                        //     date.day() === 6
                        // }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "foliosApplicableToDate")}
                        error={formErrorState.foliosApplicableToDate.isError}
                        helperText={formErrorState.foliosApplicableToDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Start Date"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.startDate)}
                        value={startDate}
                        onValueChange={setStartDate}
                        disableFuture
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": false, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "startDate")}
                        error={formErrorState.startDate.isError}
                        helperText={formErrorState.startDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="End Date"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.endDate)}
                        value={endDate}
                        onValueChange={setEndDate}
                        disablePast
                        shouldDisableDate={(date) => 
                            date.isSame(dayjs(), "day")
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": true, 
                            "disablePresent": true,
                            "disableWeekends": false,
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "endDate")}
                        error={formErrorState.endDate.isError}
                        helperText={formErrorState.endDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="DD No"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.ddNo)}
                        forbidTo="numbers"
                        maxLength={2}
                        defaultValue={ddNo}
                        inputRef={formRef.ddNo}
                        onBlur={() => handleInputFieldChange("ddNo", setDDNo)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ddNo")}
                        error={formErrorState.ddNo.isError}
                        helperText={formErrorState.ddNo.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="DD Extension Date"
                        disabled={updateState.updateFlag === "1" && !(updateState.ddExtensionDate)}
                        value={ddExtensionDate}
                        onValueChange={setDDExtensionDate}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "ddExtensionDate")}
                        error={formErrorState.ddExtensionDate.isError}
                        helperText={formErrorState.ddExtensionDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 1"
                        disabled={updateState.updateFlag === "1" && !(updateState.allotmentDate1)}
                        value={allotmentDate1}
                        onValueChange={setAllotmantDate1}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate1")}
                        error={formErrorState.allotmentDate1.isError}
                        helperText={formErrorState.allotmentDate1.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 2"
                        disabled={updateState.updateFlag === "1" && !(updateState.allotmentDate2)}
                        value={allotmentDate2}
                        onValueChange={setAllotmentDate2}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate2")}
                        error={formErrorState.allotmentDate2.isError}
                        helperText={formErrorState.allotmentDate2.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 3"
                        disabled={updateState.updateFlag === "1" && !(updateState.allotmentDate3)}
                        value={allotmentDate3}
                        onValueChange={setAllotmentDate3}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate3")}
                        error={formErrorState.allotmentDate3.isError}
                        helperText={formErrorState.allotmentDate3.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Allotment Date 4"
                        disabled={updateState.updateFlag === "1" && !(updateState.allotmentDate4)}
                        value={allotmentDate4}
                        onValueChange={setAllotmentDate4}
                        shouldDisableDate={(date) => 
                            date.day() === 0 ||
                            date.day() === 6
                        }
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": false, 
                            "disablePresent": false,
                            "disableWeekends": true, 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentDate4")}
                        error={formErrorState.allotmentDate4.isError}
                        helperText={formErrorState.allotmentDate4.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Total Commitment"
                        disabled={updateState.updateFlag === "1" && !(updateState.totalCommitment)}
                        maxLength={15}
                        defaultValue={totalCommitment}
                        inputRef={formRef.totalCommitment}
                        onBlur={() => handleInputFieldChange("totalCommitment", setTotalCommitment)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "totalCommitment")}
                        error={formErrorState.totalCommitment.isError}
                        helperText={
                            formErrorState.totalCommitment.isError
                                ? formErrorState.totalCommitment.helperText
                                : (
                                    (Number(totalCommitment) > 0) &&
                                `${toWords.convert(Number(totalCommitment), {"currency": true})}`
                                )
                        }
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Allotment Method"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.allotmentMethod)}
                        value={allotmentMethod}
                        onValueChange={setAllotmentMethod}
                        menuItems={allotmentMethodMenuItems}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "allotmentMethod")}
                        error={formErrorState.allotmentMethod.isError}
                        helperText={formErrorState.allotmentMethod.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXFileInput
                        label="DD Source"
                        required
                        accept={[".eml",".pdf"]}
                        documentType="DDSRC"
                        assetType="Client Assets"
                        identifier={
                            (clientCode !== "" && fundCode !== "") 
                                ? `CLIENT_CODE_${clientCode}/FUND_CODE_${fundCode}`
                                : ""
                        }
                        value={(ddSourceFile === null) ? "" : undefined}
                        onFileUpload={(fileDetails) => {
                            setDDSourceFile(fileDetails.file);
                        }}
                        onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
                            setDDSourceFileS3Key(s3Key);
                            setDDSourceFileS3SignedURL(s3Url);
                            setDDSourceFileFormat(format);
                        }}
                        onRemoveFile={() => {
                            setFormErrorState({
                                ...formErrorState,
                                "ddSourceFile": initializeFieldValidation(),
                            });
                            setDDSourceFile(null);
                            setDDSourceFileS3Key("");
                            setDDSourceFileS3SignedURL("");
                            setDDSourceFileFormat("");
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ddSourceFile")}
                        error={formErrorState.ddSourceFile.isError}
                        helperText={formErrorState.ddSourceFile.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Is Active"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.isActive)} 
                        row 
                        radioButtonValues={[{"label": "Yes","value": "Yes"},{"label": "No","value": "No"}]}
                        value={isActive}
                        onValueChange={(value) => {
                            handleFieldErrorChange(initializeFieldValidation(), "isActive");
                            setIsActive(value);
                        }}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Event/Batch ID"
                        required
                        readOnly
                        disabled
                        value={eventOrBatchId}
                    />
                </Grid>

                {/* <Grid item xs={6}>
                    <></>
                </Grid> */}

                <Grid item xs={6}>
                    <FXButton
                        label="Clear"
                        buttonVariant="normal"
                        fullWidth
                        onClick={() => handleClearCriticalFields(updateState)}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        label="Submit"
                        buttonVariant="submit"
                        endIcon={<ArrowForwardIosIcon/>}
                        fullWidth
                        disabled={
                            alertSnackbarContext.open ||
                            !(isFormComplete(drawdownMasterFormState)) ||
                            !(isFormValid(formErrorState))
                        }
                        onClick={() => {
                            const nigoData = getNigoData(nigoDrawdownMasterFormState.makerData, drawdownMasterFormState);
                        
                            if (nigoData.length !== 0) {
                                setNigoMetaData(nigoData);
                                setCheckerData(drawdownMasterFormState);
                                setNigoRaised(true);
                            }
                            else {
                                ddSourceFileS3SignedURL === ""
                                    ? handleFormSubmit()
                                    : handleUploadFileAndSubmitForm();
                            }  
                        }}
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default CheckerDrawdownMasterForm;
