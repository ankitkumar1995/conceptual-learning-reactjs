export type Field =
    "allotmentDate1" |
    "allotmentDate2" |
    "allotmentDate3" |
    "allotmentDate4" |
    "allotmentMethod" |
    "clientCode" |
    "companyName" |
    "ddExtensionDate" |
    "ddNo" |
    "ddSourceFile" |
    "endDate" |
    "eventOrBatchId" |
    "foliosApplicableFromDate" |
    "foliosApplicableToDate" |
    "fundClassCategory" |
    "fundCode" |
    "fundName" |
    "isActive" |
    "percentageOfDD" |
    "startDate" |
    "totalCommitment"
