import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.allotmentDate1.isError ||
        formErrorState.allotmentDate2.isError ||
        formErrorState.allotmentDate3.isError ||
        formErrorState.allotmentDate4.isError ||
        formErrorState.allotmentMethod.isError ||
        formErrorState.clientCode.isError ||
        formErrorState.companyName.isError ||
        formErrorState.ddExtensionDate.isError ||
        formErrorState.ddNo.isError ||
        formErrorState.ddSourceFile.isError ||
        formErrorState.endDate.isError ||
        formErrorState.eventOrBatchId.isError ||
        formErrorState.foliosApplicableFromDate.isError ||
        formErrorState.foliosApplicableToDate.isError ||
        formErrorState.fundClassCategory.isError ||
        formErrorState.fundCode.isError ||
        formErrorState.fundName.isError ||
        formErrorState.isActive.isError ||
        formErrorState.percentageOfDD.isError ||
        formErrorState.startDate.isError ||
        formErrorState.totalCommitment.isError
    );
}

export default isFormValid;
