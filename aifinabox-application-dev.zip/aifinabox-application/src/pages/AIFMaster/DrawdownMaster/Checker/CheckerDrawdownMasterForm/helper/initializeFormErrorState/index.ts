import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../../../interfaces/FieldValidation.types";

import { Field } from "../../interfaces/field.types";

export type FormErrorState = { 
    [fieldName in Field]:  FieldValidation
};

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "allotmentDate1": initializeFieldValidation(),
            "allotmentDate2": initializeFieldValidation(),
            "allotmentDate3": initializeFieldValidation(),
            "allotmentDate4": initializeFieldValidation(),
            "allotmentMethod": initializeFieldValidation(),
            "clientCode": initializeFieldValidation(),
            "companyName": initializeFieldValidation(),
            "ddExtensionDate": initializeFieldValidation(),
            "ddNo": initializeFieldValidation(),
            "ddSourceFile": initializeFieldValidation(),
            "endDate": initializeFieldValidation(),
            "eventOrBatchId": initializeFieldValidation(),
            "foliosApplicableFromDate": initializeFieldValidation(),
            "foliosApplicableToDate": initializeFieldValidation(),
            "fundClassCategory": initializeFieldValidation(),
            "fundCode": initializeFieldValidation(),
            "fundName": initializeFieldValidation(),
            "isActive": initializeFieldValidation(),
            "percentageOfDD": initializeFieldValidation(),
            "startDate": initializeFieldValidation(),
            "totalCommitment": initializeFieldValidation(),
        }
    );
}

export default initializeFormErrorState;
