import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { StyledPagination } from "./PaginationStyles";
import drawdownMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Checker/dispatchActionsProvider";
import drawdownMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/DrawdownMaster/Nigo/dispatchActionsProvider";
import updateDispatchActionProvider from "../../../../../redux/AifMaster/DrawdownMaster/Update/dispatchActionsProvider";
import useFetchDrawdownMaster from "../../../../../hooks/api/useFetchDrawdownMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);

    const { 
        setClientCode,
        setCompanyName,
        setEventOrBatchId,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setDrawdownMasterCheckerStateFromMakerEntry,
    } = drawdownMasterDetailsFormDispatchActionsProvider();

    const { setMakerData } = drawdownMasterNigoDetailsFormDispatchActionsProvider();
    const { setUpdateState } = updateDispatchActionProvider();

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchDrawdownMaster = useFetchDrawdownMaster();

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleOnCardClick = (clientCode: string, companyName: string, fundCode: string, fundName: string, eventId: string, fundClassCategory: string) => {
        fetchDrawdownMaster(clientCode, "0", fundClassCategory,fundCode, eventId, userId)
            .then((drawdownMaster) => {
                const {
                    "drawdownMasterFormState": drawdownMasterMakerState,
                    "drawdownMasterUpdateState": drawdownMasterUpdateState, 
                } = drawdownMaster;
                setDrawdownMasterCheckerStateFromMakerEntry(drawdownMasterUpdateState, drawdownMasterMakerState);
                setUpdateState(drawdownMasterUpdateState); 
                setClientCode(clientCode);
                setCompanyName(companyName);
                setFundClassCategory(fundClassCategory),
                setFundCode(fundCode);
                setFundName(fundName);
                setEventOrBatchId(eventId);
                setMakerData(drawdownMasterMakerState);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "dd_master", "C",userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page,itemCountPerPage,pageCount]);

    return (
        <>
            <Stack
                paddingBottom="20px"
            >
                <Typography variant="toDoLabel">
                    To Do
                </Typography>
            </Stack>

            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            createdBy,
                            createdOn,
                            fundClassCategory,
                            fundCode,
                            fundName,
                            eventId,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName,
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName,
                                        },
                                        {
                                            "dataPartOne": eventId,
                                            "dataPartTwo": fundClassCategory as string,
                                        }
                                    ]}
                                    onClick={() => handleOnCardClick(clientCode, clientName, fundCode, fundName, eventId, fundClassCategory as string)}
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>
                
                <StyledPagination 
                    count={pageCount}
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
