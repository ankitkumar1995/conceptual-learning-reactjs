import MakerClassCardPage from "./MakerClassCardPage";
import MakerClassListPage from "./MakerClassListPage";
import MakerClassMasterRejected from "./MakerClassMasterRejected";
import MakerClasssMasterForm from "./MakerClassMasterForm";
import { RootState } from "../../../../redux/store";
import { useSelector } from "react-redux";

const MakerClassMasterPage = () => {
    const makerNavigation = useSelector (
        (state: RootState) =>
            state.
                aifMasterState.
                classMasterState.
                pageContext.
                makerNavigation
    );

    let componentToRender;

    switch (makerNavigation) {
    case "":
        componentToRender = <MakerClassCardPage />;
        break;
    // case "bankList":
    //     componentToRender = <MakerBankMasterList />;
    //     break;
    case "form":
        componentToRender = <MakerClasssMasterForm />;
        break;
    case "rejected":
        componentToRender = <MakerClassMasterRejected />;
        break;
    default:
        componentToRender = <MakerClassListPage />;
        break;
    }
  
    return <>{componentToRender}</>;

    // return (
    //     <>
    //         {
    //             makerNavigation === "" ? 
    //                 <MakerClassCardPage/> : 
    //                 makerNavigation === "form" ? 
    //                     <MakerClasssMasterForm/> : 
    //                     <MakerClassListPage/>
    //         }
    //     </>
    // );
};

export default MakerClassMasterPage;
