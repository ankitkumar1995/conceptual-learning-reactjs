import { 
    Box,
    FormControl,
    Grid, 
    IconButton, 
    MenuItem, 
    Select, 
    SelectChangeEvent, 
    Stack,
    Typography, 
} from "@mui/material";

import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem
} from "../../../../../hooks/api/useFetchRejectQueue";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { 
    StyledPagination 
} from "../../../PlanMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Maker/dispatchActionsProvider";
import classMasterPageContextFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { nanoid } from "@reduxjs/toolkit";
import useFetchRejectClassMaster from "../../../../../hooks/api/useFetchRejectClassMaster";
import { useSelector } from "react-redux";

const MakerClassMasterRejected = () => {
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const [classData, setClassData] = useState({
        "additionalFee": "",
        "carryPercentage": "",
        "catchUpPercentage": "",
        "classCode": "",
        "clientCode": "",
        "comapnyName": "",
        "currency": "",
        "description": "",
        "faceValue": "",
        "fundClassCategory": "",
        "fundCode": "",
        "fundName": "",
        "fundPlanCode": "",
        "fundPlanName": "",
        "fundSponserClass": "",
        "gstRate": "",
        "highWaterMark": "",
        "hurdleRate": "",
        "incomeDistFrequency": "",
        "isActive": "",
        "isinCode": "",
        "managementFee": "",
        "maxAmount": "",
        "maxReturn": "",
        "minAmount": "",
        "orgFee": "",
        "perFeePercentage": "",
        "performanceFee": "",
        "preferredReturn": "",
        "setUpFee": "",
        "shareRatio": "",
    });

    const userId = useSelector(
        (state: RootState) => 
            state
                .authenticationState
                .userId    
    );

    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .makerForm
                .clientCode
    );

    const {
        setAdditionalFee,
        setCarryPercentage,
        setCatchupPercentage,
        setClassCode,
        setClassMasterMakerState,
        setClientCode,
        setCompanyName,
        setCurrency,
        setDescription,
        setFaceValue,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setFundSponsorClass,
        setGstRate,
        setHighWaterMark,
        setHurdleRate,
        setIncomeDistFrequency,
        //setInitialClassMakerEntry,
        setIsActive,
        setIsinCode,
        setManagementFee,
        setMaxAmount,
        setMaxReturn,
        setMinAmount,
        setOrgFee,
        setPerFeePercentage,
        setPerformanceFee,
        setPreferredReturn,
        setSetUpFee,
        setShareRatio
    } = classMasterDetailsFormDispatchActionsProvider();

    const {
        setMakerNavigation,
        setFlowType
    } = classMasterPageContextFormDispatchActionsProvider();

    const fetchClassMasterRejected = useFetchRejectClassMaster();
    const fetchRejectedQueue = useFetchRejectQueue();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleCardOnClick = (
        classCode: string,
        clientCode: string,
        fundCode: string,
        planCode: string,
    ) => {

        setClientCode(clientCode);
        setFundPlanCode(planCode);
        setClassCode(classCode);
        setFundCode(fundCode);
        setMakerNavigation("form");
        setFlowType("reject");
    };

    useEffect(() => {
        fetchRejectedQueue(itemCountPerPage,clientCode, page-1, "class_master", "C", "M",userId)
            .then((result) => {
                const {
                    rejectQueue,
                    pendingRejectItemCount,
                } = result;
                setPendingRejectEntryItems(rejectQueue);
                setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
            });
    }, [page, pageCount, itemCountPerPage]);

    return (
        <>
            <Grid sx={{
                "alignItems": "center",
                "display": "flex",
                "marginBottom": "13px",
            }}>
                <IconButton
                    sx={{"color": "#1C1E2C"}}
                    onClick={() => setMakerNavigation("")}
                >
                    <BackArrowIcon/> 
                </IconButton>

                <Typography variant="formHeading" display="flex">
                    Rejected By Checker
                </Typography>
            </Grid>

            <Grid item xs={12}>
                {
                    pendingRejectEntryItems.map((pendingRejectEntryItem) => {
                        const {
                            bankAccountNumber,
                            bankName,
                            clientCode,
                            clientName,
                            fundCode,
                            fundName,
                            planCode,
                            planName,
                            classCode,
                            className,
                            createdBy,
                            createdOn,
                            // id,
                            rejectRemarks,
                        } = pendingRejectEntryItem;

                        return (
                            <Box key={nanoid()}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName
                                        },
                                        {
                                            "dataPartOne": planCode,
                                            "dataPartTwo": planName
                                        },
                                        {
                                            "dataPartOne": classCode,
                                            "dataPartTwo": className,
                                        },
                                    ]}
                                    remarksData={
                                        [
                                            {
                                                "dataPartOne": `Remarks: ${rejectRemarks}`
                                            },
                                        ]}
                                    onClick={() =>  handleCardOnClick( classCode, clientCode, fundCode, planCode)}
                                />
                            </Box>
                        );
                    })
                }
            </Grid>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>                    
                    </Stack>
                </FormControl>
  
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default MakerClassMasterRejected;
