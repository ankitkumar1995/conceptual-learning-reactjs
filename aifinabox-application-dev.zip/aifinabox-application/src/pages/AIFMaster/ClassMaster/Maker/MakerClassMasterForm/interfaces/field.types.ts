import { RadioButtonValue } from "../../../../../../components/FXRadioGroup/FXInputProps.types";

export type Field = 
    "additionalFee" |
    "carryPercentage" |
    "catchupPercentage" |
    "fundClassCategory" |
    "clientCode" |
    "classCode" |
    "companyName" |
    "currency" |
    "description" |
    "faceValue" |
    "fundCode" |
    "fundName" |
    "fundPlanCode" |
    "fundPlanName" |
    "fundSponsorClass" |
    "gstRate" |
    "highWaterMark" |
    "hurdleRate" |
    "incomeDistFrequency" |
    "isActive" |
    "isinCode" |
    "managementFee" |
    "maxAmount" |
    "maxReturn" |
    "minAmount" |
    "orgFee" |
    "perFeePercentage" |
    "performanceFee" |
    "preferredReturn" |
    "setUpFee" |
    "shareRatio";

export type UpdateField =
    "additionalFee" |
    "carryPercentage" |
    "catchupPercentage" |
    "classCode" |
    "currency" |
    "description" |
    "faceValue" |
    "fundClassCategory" |
    "fundSponsorClass" |
    "gstRate" |
    "highWaterMark" |
    "hurdleRate" |
    "incomeDistFrequency" |
    "isActive" |
    "isinCode" |
    "managementFee" |
    "maxAmount" |
    "maxReturn" |
    "minAmount" |
    "orgFee" |
    "perFeePercentage" |
    "performanceFee" |
    "preferredReturn" |
    "setUpFee" |
    "shareRatio"

export const DECISION_RADIO_OPTIONS: RadioButtonValue[] = [
    {
        "label": "Yes",
        "value": "Yes",
    },
    {
        "label": "No",
        "value": "No",   
    }
];
