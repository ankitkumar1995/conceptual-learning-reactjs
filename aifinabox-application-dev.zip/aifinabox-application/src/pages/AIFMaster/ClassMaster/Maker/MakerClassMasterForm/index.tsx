import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Grid,
    IconButton,
    Stack,
    Typography
} from "@mui/material";
import { 
    ClassMasterDetails, 
    initialClassMasterDetailsFormState 
} from "../../../../../redux/AifMaster/ClassMaster/Checker/initialState";
import { DECISION_RADIO_OPTIONS, Field } from "./interfaces/field.types";
import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useEffect, useState } from "react";
import useFetchClassDetails, { ClassData } from "../../../../../hooks/api/useFetchClassDetails";
import useFetchFundCodeDetails, { 
    FundDetails 
} from "../../../../../hooks/api/useFetchFundCodeDetails";
import useFetchFundPlanDetails, {
    FundPlanData
} from "../../../../../hooks/api/useFetchFundPlanDetails";
import { useLocation, useNavigate } from "react-router-dom";

import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { RootState } from "../../../../../redux/store";
import SaveIcon from "../../../../../icons/SaveIcon";
import { ToWords } from "to-words";
import UpdateIcon from "../../../../../icons/UpdateIcon";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Maker/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import { inrCurrencyFormatter } from "../../../../../utils/currencyFormatter";
import isFormComplete from "./helper/isFormComplete";
import isFormUpdated from "./helper/isFormUpdated";
import isFormValid from "./helper/isFormValid";
import onBlurAmountValidator from "../../../../../validators/onBlurValidator/onBlurAmountValidator";
import onBlurDecimalValidator from "../../../../../validators/onBlurValidator/onBlurDecimalValidator";
import onBlurHighWaterMarkValidator from "../../../../../validators/onBlurValidator/onBlurHighWaterMarkValidator";
import onBlurMaxAmountValidator from "../../../../../validators/onBlurValidator/onBlurMaxAmountValidator";
import onBlurMinAmountValidator from "../../../../../validators/onBlurValidator/onBlurMinAmountValidator";
import onChangePercentageValidator from "../../../../../validators/onChangeValidator/onChangePercentageValidator";
import useFetchClassMaster from "../../../../../hooks/api/useFetchClassMaster";
import useFetchRejectClassMaster from "../../../../../hooks/api/useFetchRejectClassMaster";
import useFormRef from "./hooks/useFormRef";
import usePostClassMaster from "../../../../../hooks/api/usePostClassMaster";
import { useSelector } from "react-redux";

const MakerClasssMasterForm = () => {
    const formRef = useFormRef();
    const navigate = useNavigate();
    const toWords = new ToWords();
    const location = useLocation();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [classCodes, setClassCodes] = useState([initializeMenuItem()]);
    const [fundDetails, setFundDetails] = useState<FundDetails[]>([]);
    const [planDetails, setPlanDetails] = useState<FundPlanData[]>([]);
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);
    const [classMasterState, setClassMasterState] = useState<ClassMasterDetails>(initialClassMasterDetailsFormState);
 
    const classMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .makerForm
    );

    const [data, setData] = useState<ClassMasterDetails>();

    const flowType = useSelector (
        (state: RootState) =>
            state.
                aifMasterState
                .classMasterState
                .pageContext
                .flowType
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const { firstName, lastName } = userContextState;
    
    const {
        additionalFee,
        carryPercentage,
        catchupPercentage,
        clientCode,
        classCode,
        companyName,
        currency,
        description,
        faceValue,
        fundClassCategory,
        fundCode,
        fundName,
        fundPlanCode,
        fundPlanName,
        fundSponsorClass,
        gstRate,
        highWaterMark,
        hurdleRate,
        incomeDistFrequency,
        isActive,
        isinCode,
        managementFee,
        maxAmount,
        maxReturn,
        minAmount,
        orgFee,
        perFeePercentage,
        performanceFee,
        preferredReturn,
        setUpFee,
        shareRatio,
    } = classMasterFormState;

    const {
        currencyMenuItems,
        fundClassCategoryMenuItems,
        distributionFrequencyMenuItems,
    } = selectInputMenuItems;

    const {
        clearState,
        setAdditionalFee,
        setCarryPercentage,
        setCatchupPercentage,
        setFundClassCategory,
        setClassMasterMakerState,
        setClientCode,
        setClassCode,
        setCompanyName,
        setCurrency,
        setDescription,
        setFaceValue,
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setFundSponsorClass,
        setGstRate,
        setHighWaterMark,
        setHurdleRate,
        setIncomeDistFrequency,
        setIsActive,
        setIsinCode,
        setManagementFee,
        setMaxAmount,
        setMaxReturn,
        setMinAmount,
        setOrgFee,
        setPerFeePercentage,
        setPerformanceFee,
        setPreferredReturn,
        setSetUpFee,
        setShareRatio,
    } = classMasterDetailsFormDispatchActionsProvider();

    const { setMakerNavigation } = classMasterPageContextDispatchActionProvider();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey as Field];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];


        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const postClassMaster = usePostClassMaster();
    const fetchClassMaster = useFetchClassMaster();
    const fetchPlanDetails = useFetchFundPlanDetails();
    const fetchFundCodeDetails = useFetchFundCodeDetails();
    const fetchClassCodes = useFetchClassDetails();
    const fetchClassMasterRejected = useFetchRejectClassMaster();
    const onFundCodeChange = (value: string) => {
        setFundCode(value);
        const matchingFund = fundDetails.find((code) => code.fundCode.label === value);
        matchingFund && setFundName(matchingFund.fundName.value);
        fetchPlanDetails(clientCode, value)
            .then((result) => setPlanDetails(result.fundData));
    };  

    const onFundPlanChange = (value: string) => {
        setFundPlanCode(value);
        const matchingPlan = planDetails.find((code) => code.planCode.value === value);
        matchingPlan && setFundPlanName(matchingPlan.planDescription.value);
        if (flowType === "update") {
            fetchClassCodes(clientCode, fundCode, value)
                .then((result) => {
                    console.log("fetchClassCodes", result);
                    setClassCodes(result.map((item) => ({
                        "label": item.classCode.value,
                        "value": item.classCode.value,
                    }))); 
                });
        }
    };

    const handleFetchFundCodeDetails = () => {
        fetchFundCodeDetails(clientCode, "M")
            .then((result) => setFundDetails(result));
    };

    const handleonChange = (
        field: Field,
        value: string,
        dispatchFunction: any,
    ) => {
        dispatchFunction(value);

        if (flowType === "update" ) {
            if (classMasterFormState[field] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }

        if (flowType === "reject") {
            if (data?.[field] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }
    };

    const handleInputFieldOnsubmit = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];

        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);

            if (flowType === "update" ) {
                if (classMasterFormState[field] === fieldValue) {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: false
                    });
                }
                else {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: true
                    });
                }
            }

            if (flowType === "reject") {
                if (data?.[field] === fieldValue) {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: false
                    });
                }
                else {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: true
                    });
                }
            }
        };
    };

    useEffect(()=>{
        if (flowType==="reject"){
            fetchClassMasterRejected(
                "",
                "",
                classCode,
                clientCode,
                fundCode,
                "class_master",
                fundPlanCode,
                "M"
            )
                .then((classMasterMakerState) => {
                    const {
                        classMasterState,
                        classMasterUpdateState,
                    } = classMasterMakerState;
                    setData({...classMasterState});
                    setClassMasterMakerState(classMasterState);
                    setAdditionalFee(classMasterState.additionalFee);
                    setCarryPercentage(classMasterState.carryPercentage);
                    setCatchupPercentage(classMasterState.catchupPercentage);
                    setClassCode(classMasterState.classCode);
                    setClientCode(classMasterState.clientCode);
                    setCompanyName(classMasterState.companyName);
                    setCurrency(classMasterState.currency);
                    setDescription(classMasterState.description);
                    setFaceValue(classMasterState.faceValue);
                    setFundClassCategory(classMasterState.fundClassCategory);
                    setFundCode(classMasterState.fundCode);
                    setFundName(classMasterState.fundName);
                    setFundPlanCode(classMasterState.fundPlanCode);
                    setFundPlanName(classMasterState.fundPlanName);
                    setFundSponsorClass(classMasterState.fundSponsorClass);
                    setGstRate(classMasterState.gstRate);
                    setHighWaterMark(classMasterState.highWaterMark);
                    setHurdleRate(classMasterState.hurdleRate);
                    setIncomeDistFrequency(classMasterState.incomeDistFrequency);
                    setIsActive(classMasterState.isActive);
                    setIsinCode(classMasterState.isinCode);
                    setManagementFee(classMasterState.managementFee);
                    setMaxAmount(classMasterState.maxAmount);
                    setMaxReturn(classMasterState.maxReturn);
                    setMinAmount(classMasterState.minAmount);
                    setOrgFee(classMasterState.orgFee);
                    setPerFeePercentage(classMasterState.perFeePercentage);
                    setPerformanceFee(classMasterState.performanceFee);
                    setPreferredReturn(classMasterState.preferredReturn);
                    setSetUpFee(classMasterState.setUpFee);
                    setShareRatio(classMasterState.shareRatio);
                });
        }
    },[]);

    const handleChangeUpdate = (field: Field, value: string) => {
        if (flowType === "reject") {
            if (data?.[field] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                console.log(data?.[field] ,value);
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }
    };

    const handleFormSubmit = () => {
        postClassMaster(classMasterFormState, `${firstName} ${lastName}`, flowType === "update" ? "1" : "0", userId, "M", isUpdate, "")
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleFetchClassMaster = (value: string) => {
        if (flowType === "update") {
            fetchClassMaster(value, clientCode, fundCode, fundPlanCode, "M", userId)
                .then((classMaster) => {
                    const {
                        "classMasterState": classMasterData,
                    } = classMaster;

                    setClassMasterState(classMasterData);
                    setClassMasterMakerState(classMasterData);
                    setFormErrorState(initializeFormErrorState);
                
                    (formRef["additionalFee"].current as HTMLInputElement).value = classMasterData.additionalFee;
                    (formRef["carryPercentage"].current as HTMLInputElement).value = classMasterData.carryPercentage;
                    (formRef["catchupPercentage"].current as HTMLInputElement).value = classMasterData.catchupPercentage;
                    (formRef["description"].current as HTMLInputElement).value = classMasterData.description;
                    (formRef["faceValue"].current as HTMLInputElement).value = classMasterData.faceValue;
                    (formRef["gstRate"].current as HTMLInputElement).value = classMasterData.gstRate;
                    (formRef["highWaterMark"].current as HTMLInputElement).value = classMasterData.highWaterMark;
                    (formRef["hurdleRate"].current as HTMLInputElement).value = classMasterData.hurdleRate;
                    (formRef["isinCode"].current as HTMLInputElement).value = classMasterData.isinCode;
                    (formRef["managementFee"].current as HTMLInputElement).value = classMasterData.managementFee;
                    (formRef["maxAmount"].current as HTMLInputElement).value = classMasterData.maxAmount;
                    (formRef["maxReturn"].current as HTMLInputElement).value = classMasterData.maxReturn;
                    (formRef["minAmount"].current as HTMLInputElement).value = classMasterData.minAmount;
                    (formRef["orgFee"].current as HTMLInputElement).value = classMasterData.orgFee;
                    (formRef["perFeePercentage"].current as HTMLInputElement).value = classMasterData.perFeePercentage;
                    (formRef["performanceFee"].current as HTMLInputElement).value = classMasterData.performanceFee;
                    (formRef["preferredReturn"].current as HTMLInputElement).value = classMasterData.preferredReturn;
                    (formRef["setUpFee"].current as HTMLInputElement).value = classMasterData.setUpFee;
                    (formRef["shareRatio"].current as HTMLInputElement).value = classMasterData.shareRatio;
                });
        }
    };

    // const handleMaxAmountValidator = (fieldError: FieldValidation) => {

    //     if (fieldError.isError) {
    //         setFormErrorState({
    //             ...formErrorState,
    //             "maxAmount": fieldError,
    //         });
    //     } else if (Number(maxAmount) <= Number(minAmount)) {
    //         console.log("max amount", maxAmount);
    //         setFormErrorState ({
    //             ...formErrorState,
    //             "maxAmount": {
    //                 "helperText": "Max Amount cannot be less than or equal to Min Amount",
    //                 "isError": true,
    //                 "isVerified": false,
    //                 "isWarning": false,
    //             },
    //         });
    //     }
    // };

    useEffect(() => {
        if ((Number(minAmount) >= Number(maxAmount)) && minAmount.length && maxAmount.length) {
            setFormErrorState({
                ...formErrorState,
                "minAmount": {
                    "helperText": "Minimum Amount Should Be Less Than Maximum Amount",
                    "isError": true,
                    "isVerified": false,
                    "isWarning": false,
                },
            });
        } else {
            setFormErrorState({
                ...formErrorState,
                "minAmount": initializeFieldValidation(),
            });
        }
    }, [minAmount, maxAmount]);
    
    useEffect (() => {
        handleFetchFundCodeDetails();
    },[]);

    useEffect(() => {
        handleClearState();
        setFormErrorState(initializeFormErrorState);
    }, [location]);

    useEffect(()=>{
        if (flowType ==="reject"){
            fetchPlanDetails(clientCode, fundCode)
                .then((result) => {
                    setPlanDetails(result.fundData);});
        }


    },[flowType,clientCode, fundCode]);
    
    useEffect(()=>{
        if (flowType === "reject") {
            setClassCodes([{"label": classCode,"value": classCode,}]);
        }
    },[flowType, clientCode, fundCode, fundPlanCode]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid
                        alignContent="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    setMakerNavigation("list");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                {flowType === "add" ? "Add Class" : flowType ==="reject" ?" Rejected": "Update Class"}
                            </Typography>
                        </Box>

                        {/* <Stack direction="row" spacing={1}>
                            <IconButton>
                                <SaveIcon/>
                            </IconButton>

                            <IconButton>
                                <UpdateIcon/>
                            </IconButton>
                        </Stack> */}
                    </Grid>
                </Grid>

                <Grid item xs={4}>
                    <FXInput
                        label="Client Code"
                        defaultValue={clientCode}
                        disabled
                        readOnly
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Company Name"
                        forbidTo="singleSpace"
                        defaultValue={companyName}
                        disabled
                        readOnly
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXSelectInput
                        label="Fund Code"
                        value={fundCode}
                        required
                        onValueChange={onFundCodeChange}
                        menuItems={fundDetails.map((fund) => fund.fundCode)}                    
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Fund Name"
                        forbidTo="letters"
                        value={fundName}
                        disabled
                        readOnly
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXSelectInput 
                        label="Fund Plan Code"
                        required
                        value={fundPlanCode}
                        onValueChange={onFundPlanChange}
                        menuItems={planDetails.map((plan) => ({
                            "label": plan.planCode.value,
                            "value": plan.planCode.value,
                        }))}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "fundPlanCode")}
                        error={formErrorState.fundPlanCode.isError}
                        helperText={formErrorState.fundPlanCode.helperText} 
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Fund Plan Name"
                        required
                        value={fundPlanName}
                        disabled
                        readOnly
                        inputRef={formRef.fundPlanName}
                    />
                </Grid>

                <Grid item xs={3}>
                    {
                        (flowType === "add")
                            ? <FXInput
                                label="Class Code"
                                maxLength={5}
                                forbidTo="alphanumeric"
                                required
                                inputRef={formRef.classCode}
                                value={classCode}
                                onValueChange={setClassCode}
                                //onBlur={() => handleInputFieldChange("classCode", setClassCode)}
                                onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "classCode")}
                                error={formErrorState.classCode.isError}
                                helperText={formErrorState.classCode.helperText}
                            />
                            : <FXSelectInput
                                label="Class Code"    
                                required
                                value={classCode}
                                onValueChange={(value) => {
                                    setClassCode(value);
                                    handleFetchClassMaster(value);
                                }}
                                menuItems={classCodes.map((codes) => ({
                                    "label": codes.label,
                                    "value": codes.value,
                                }))}
                                onFieldErrorChange={(fieldError) =>
                                    setFormErrorState({
                                        ...formErrorState,
                                        "classCode": fieldError,
                                        "currency": initializeFieldValidation(),
                                        "description": initializeFieldValidation(),
                                        "faceValue": initializeFieldValidation(),
                                        "fundClassCategory": initializeFieldValidation(),
                                        "incomeDistFrequency": initializeFieldValidation(), 
                                        "maxAmount": initializeFieldValidation(),
                                    }) 
                                }
                                error={formErrorState.classCode.isError}
                                helperText={formErrorState.classCode.helperText}
                            />
                    }
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Description"
                        required
                        maxLength={256}
                        inputRef={formRef.description}
                        // onBlur={() => handleInputFieldOnsubmit("description", setDescription)}
                        value={description}
                        onValueChange={(value) => {
                            setDescription(value);
                            handleInputFieldOnsubmit("description", setDescription);
                            handleFieldErrorChange(initializeFieldValidation(), "description");
                            
                            // handleChangeUpdate("description", value);
                            // if (flowType === "reject") {
                            //     if (data?.["description"] === value) {
                            //         setIsUpdate({
                            //             ...isUpdate,
                            //             ["description"]: false
                            //         });
                            //     }
                            //     else {
                            //         setIsUpdate({
                            //             ...isUpdate,
                            //             ["description"]: true
                            //         });
                            //     }
                            // }
                            
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "description")}
                        error={formErrorState.description.isError}
                        helperText={formErrorState.description.helperText}      
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Fund Class Category" 
                        value={fundClassCategory}
                        onValueChange={(value) => 
                            handleonChange("fundClassCategory", value, setFundClassCategory)
                        } 
                        required
                        menuItems={fundClassCategoryMenuItems}                    
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "fundClassCategory")}
                        error={formErrorState.fundClassCategory.isError}
                        helperText={formErrorState.fundClassCategory.helperText} 
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Min Amount" 
                        maxLength={21}
                        forbidTo="amount"
                        endAdornment= {<Typography color="#9497A3">INR</Typography>}
                        value={minAmount}
                        inputRef={formRef.minAmount}
                        required
                        onValueChange={(value) => 
                            handleonChange("minAmount", value, setMinAmount)
                        }
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        error={formErrorState.minAmount.isError}
                        helperText={
                            formErrorState.minAmount.isError
                                ? formErrorState.minAmount.helperText
                                : (
                                    (Number(minAmount) > 0) &&
                                `${toWords.convert(Number(minAmount), {"currency": true})}`
                                )
                        }
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "minAmount")}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Max Amount" 
                        maxLength={21}
                        forbidTo="amount"
                        endAdornment= {<Typography color="#9497A3">INR</Typography>}
                        value={maxAmount}
                        onValueChange={(value) =>
                            handleonChange("maxAmount", value, setMaxAmount)
                        }
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        inputRef={formRef.maxAmount}
                        required
                        onFieldErrorChange={(fieldError) =>handleFieldErrorChange(fieldError, "maxAmount") }
                        error={formErrorState.maxAmount.isError}
                        helperText={
                            formErrorState.maxAmount.isError
                                ? formErrorState.maxAmount.helperText
                                : (
                                    (Number(maxAmount) > 0) &&
                                `${toWords.convert(Number(maxAmount), {"currency": true})}`
                                )
                        }
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Management Fee"
                        forbidTo="decimal-number"
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        inputRef={formRef.managementFee}
                        value={managementFee}
                        //onBlur={() => handleInputFieldOnsubmit("managementFee", setManagementFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setManagementFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setManagementFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setManagementFee(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("managementFee", setManagementFee);
                                handleFieldErrorChange(initializeFieldValidation(), "managementFee");
                                setManagementFee(value);
                            }
                        }}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "managementFee")}
                        error={formErrorState.managementFee.isError}
                        helperText={formErrorState.managementFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Performance Fee"
                        forbidTo="decimal-number"
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        inputRef={formRef.performanceFee}
                        value={performanceFee}
                        //onBlur={() => handleInputFieldOnsubmit("performanceFee", setPerformanceFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPerformanceFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPerformanceFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPerformanceFee(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("performanceFee", setPerformanceFee);
                                handleFieldErrorChange(initializeFieldValidation(), "performanceFee");
                                setPerformanceFee(value);
                            }
                        }}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "performanceFee")}
                        error={formErrorState.performanceFee.isError}
                        helperText={formErrorState.performanceFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Hurdle Rate"
                        forbidTo="decimal-number"
                        inputRef={formRef.hurdleRate}
                        value={hurdleRate}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        //onBlur={() => handleInputFieldChange("hurdleRate", setHurdleRate)}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setHurdleRate("0");
                            } else if (/^\.\d+/.test(value)) {
                                setHurdleRate("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setHurdleRate(value.substring(1));
                            } else {
                                handleInputFieldChange("hurdleRate", setHurdleRate);
                                handleFieldErrorChange(initializeFieldValidation(), "hurdleRate");
                                setHurdleRate(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "hurdleRate")}
                        error={formErrorState.hurdleRate.isError}
                        helperText={formErrorState.hurdleRate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Per Fee Percentage"
                        forbidTo="decimal-number"
                        inputRef={formRef.perFeePercentage}
                        value={perFeePercentage}
                        endAdornment= {<Typography color="#9497A3">%</Typography>} 
                        //onBlur={() => handleInputFieldOnsubmit("perFeePercentage", setPerFeePercentage)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPerFeePercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPerFeePercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPerFeePercentage(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("perFeePercentage", setPerFeePercentage);
                                handleFieldErrorChange(initializeFieldValidation(), "perFeePercentage");
                                setPerFeePercentage(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "perFeePercentage")}
                        error={formErrorState.perFeePercentage.isError}
                        helperText={formErrorState.perFeePercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Share Ratio"
                        forbidTo="decimal-number"
                        inputRef={formRef.shareRatio}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        value={shareRatio}
                        //onBlur={() => handleInputFieldOnsubmit("shareRatio", setShareRatio)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setShareRatio("0");
                            } else if (/^\.\d+/.test(value)) {
                                setShareRatio("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setShareRatio(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("shareRatio", setShareRatio);
                                handleFieldErrorChange(initializeFieldValidation(), "shareRatio");
                                setShareRatio(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "shareRatio")}
                        error={formErrorState.shareRatio.isError}
                        helperText={formErrorState.shareRatio.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Additional Fee"
                        forbidTo="decimal-number"
                        inputRef={formRef.additionalFee}
                        value={additionalFee}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        //onBlur={() => handleInputFieldOnsubmit("additionalFee", setAdditionalFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setAdditionalFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setAdditionalFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setAdditionalFee(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("additionalFee", setAdditionalFee);
                                handleFieldErrorChange(initializeFieldValidation(), "additionalFee");
                                setAdditionalFee(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "additionalFee")}
                        error={formErrorState.additionalFee.isError}
                        helperText={formErrorState.additionalFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="ORG Fee"
                        forbidTo="decimal-number"
                        inputRef={formRef.orgFee} 
                        value={orgFee}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        //onBlur={() => handleInputFieldOnsubmit("orgFee", setOrgFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setOrgFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setOrgFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setOrgFee(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("orgFee", setOrgFee);
                                handleFieldErrorChange(initializeFieldValidation(), "orgFee");
                                setOrgFee(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "orgFee")}
                        error={formErrorState.orgFee.isError}
                        helperText={formErrorState.orgFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="GST Rate"
                        forbidTo="decimal-number"
                        inputRef={formRef.gstRate}
                        value={gstRate}
                        endAdornment= {<Typography color="#9497A3">%</Typography>} 
                        //onBlur={() => handleInputFieldOnsubmit("gstRate", setGstRate)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setGstRate("0");
                            } else if (/^\.\d+/.test(value)) {
                                setGstRate("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setGstRate(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("gstRate", setGstRate);
                                handleFieldErrorChange(initializeFieldValidation(), "gstRate");
                                setGstRate(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "gstRate")}
                        error={formErrorState.gstRate.isError}
                        helperText={formErrorState.gstRate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Preferred Return"
                        forbidTo="decimal-number"
                        inputRef={formRef.preferredReturn}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        value={preferredReturn} 
                        //onBlur={() => handleInputFieldOnsubmit("preferredReturn", setPreferredReturn)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPreferredReturn("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPreferredReturn("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPreferredReturn(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("preferredReturn", setPreferredReturn);
                                handleFieldErrorChange(initializeFieldValidation(), "preferredReturn");
                                setPreferredReturn(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "preferredReturn")}
                        error={formErrorState.preferredReturn.isError}
                        helperText={formErrorState.preferredReturn.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Max Return"
                        forbidTo="decimal-number"
                        inputRef={formRef.maxReturn}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        value={maxReturn}
                        //onBlur={() => handleInputFieldOnsubmit("maxReturn", setMaxReturn)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setMaxReturn("0");
                            } else if (/^\.\d+/.test(value)) {
                                setMaxReturn("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setMaxReturn(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("maxReturn", setMaxReturn);
                                handleFieldErrorChange(initializeFieldValidation(), "maxReturn");
                                setMaxReturn(value);
                            }
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "maxReturn")}
                        error={formErrorState.maxReturn.isError}
                        helperText={formErrorState.maxReturn.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Carry Percentage"
                        forbidTo="decimal-number"
                        inputRef={formRef.carryPercentage}
                        value={carryPercentage}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        //onBlur={() => handleInputFieldOnsubmit("carryPercentage", setCarryPercentage)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setCarryPercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setCarryPercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setCarryPercentage(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("carryPercentage", setCarryPercentage);
                                handleFieldErrorChange(initializeFieldValidation(), "carryPercentage");
                                setCarryPercentage(value);
                            }
                        }}
                        //onValueChange={setCarryPercentage}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "carryPercentage")}
                        error={formErrorState.carryPercentage.isError}
                        helperText={formErrorState.carryPercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Catchup Percentage"
                        forbidTo="decimal-number"
                        inputRef={formRef.catchupPercentage}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        value={catchupPercentage}
                        //onBlur={() => handleInputFieldOnsubmit("catchupPercentage", setCatchupPercentage)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setCatchupPercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setCatchupPercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setCatchupPercentage(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("catchupPercentage", setCatchupPercentage);
                                handleFieldErrorChange(initializeFieldValidation(), "catchupPercentage");
                                setCatchupPercentage(value);
                            }
                        }}
                        //onValueChange={setCatchupPercentage}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "catchupPercentage")}
                        error={formErrorState.catchupPercentage.isError}
                        helperText={formErrorState.catchupPercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Fund Sponsor Class" 
                        radioButtonValues={DECISION_RADIO_OPTIONS} 
                        required   
                        row
                        onValueChange={(value) => 
                            handleonChange("fundSponsorClass", value, setFundSponsorClass)
                        }
                        value={fundSponsorClass}
                        error={formErrorState.fundSponsorClass.isError}
                        helperText={formErrorState.fundSponsorClass.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Currency" 
                        required  
                        menuItems={currencyMenuItems}  
                        value={currency}
                        onValueChange={(value) => 
                            handleonChange("currency", value, setCurrency)
                        }
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "currency")}
                        error={formErrorState.currency.isError}
                        helperText={formErrorState.currency.helperText} 
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Face Value"
                        maxLength={8}
                        forbidTo="numbers"
                        required
                        inputRef={formRef.faceValue}
                        value={faceValue}
                        //onBlur={() => handleInputFieldOnsubmit("faceValue", setFaceValue)}
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        onValueChange={() => handleInputFieldOnsubmit("faceValue", setFaceValue)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "faceValue")}
                        error={formErrorState.faceValue.isError}
                        helperText={formErrorState.faceValue.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Income Dist Frequency" 
                        menuItems={distributionFrequencyMenuItems}                           
                        required 
                        value={incomeDistFrequency}
                        onValueChange={(value) => 
                            handleonChange("incomeDistFrequency", value, setIncomeDistFrequency)
                        }
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "incomeDistFrequency")}
                        error={formErrorState.incomeDistFrequency.isError}
                        helperText={formErrorState.incomeDistFrequency.helperText}                     
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="ISIN Code"
                        maxLength={12}
                        forbidTo="alphanumeric"
                        inputRef={formRef.isinCode}
                        value={isinCode}
                        //onBlur={() => handleInputFieldOnsubmit("isinCode", setIsinCode)}
                        onValueChange={setIsinCode}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "isinCode")}
                        error={formErrorState.isinCode.isError}
                        helperText={formErrorState.isinCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="High Water Mark"
                        maxLength={10}
                        forbidTo="decimal-number"
                        inputRef={formRef.highWaterMark}
                        value={highWaterMark}
                        onValueChange={setHighWaterMark}
                        //onBlur={() => handleInputFieldOnsubmit("highWaterMark", setHighWaterMark)}
                        validatorOptions={{}}
                        onBlurValidator={onBlurHighWaterMarkValidator}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "highWaterMark")}
                        error={formErrorState.highWaterMark.isError}
                        helperText={formErrorState.highWaterMark.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Is Active" 
                        radioButtonValues={DECISION_RADIO_OPTIONS} 
                        required               
                        row
                        value={isActive}
                        onValueChange={(value) =>
                            handleonChange("isActive", value, setIsActive) 
                        }
                        error={formErrorState.isActive.isError}
                        helperText={formErrorState.isActive.helperText}
                    />  
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Setup Fee %"
                        forbidTo="decimal-number"
                        inputRef={formRef.setUpFee}
                        value={setUpFee}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        //onBlur={() => handleInputFieldOnsubmit("setUpFee", setSetUpFee)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setSetUpFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setSetUpFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setSetUpFee(value.substring(1));
                            } else {
                                handleInputFieldOnsubmit("setUpFee", setSetUpFee);
                                handleFieldErrorChange(initializeFieldValidation(), "setUpFee");
                                setSetUpFee(value);
                            }
                        }}
                        //onValueChange={setSetUpFee}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "setUpFee")}
                        error={formErrorState.setUpFee.isError}
                        helperText={formErrorState.setUpFee.helperText}
                    />
                </Grid>

                <Grid xs={12}></Grid>
                
                <Grid item xs={6}>
                    <FXButton
                        label="Clear"
                        buttonVariant="normal"
                        fullWidth
                        onClick={handleClearState}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        label="Submit to Checker"
                        buttonVariant="submit"
                        disabled={
                            alertSnackbarContext.open || 
                            !isFormComplete(classMasterFormState) ||
                            !isFormValid(formErrorState) ||
                            isFormUpdated(isUpdate, flowType)
                        }
                        endIcon={<ArrowForwardIosIcon/>}
                        fullWidth
                        onClick={() => {
                            handleFormSubmit();
                        } 
                        }
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();

                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default MakerClasssMasterForm;
