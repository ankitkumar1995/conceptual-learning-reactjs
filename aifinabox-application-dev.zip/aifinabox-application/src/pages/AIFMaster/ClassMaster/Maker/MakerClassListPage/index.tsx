import {
    Box,
    Grid,
    IconButton,
    Paper,
    Stack,
    Typography
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchClassDetails, { ClassData } from "../../../../../hooks/api/useFetchClassDetails";
import useFetchFundCodeDetails, { 
    FundDetails 
} from "../../../../../hooks/api/useFetchFundCodeDetails";
import useFetchFundPlanDetails, {
    FundPlanData
} from "../../../../../hooks/api/useFetchFundPlanDetails";

import AddIcon from "../../../../../icons/AddIcon";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import EditIcon from "../../../../../icons/EditIcon";
import FXButton from "../../../../../components/FXButton";
import FXSelectInput from "../../../../../components/FXSelectInput";
import FilterByIcon from "../../../../../icons/FilterByIcon";
import { RootState } from "../../../../../redux/store";
import UpdateIcon from "../../../../../icons/UpdateIcon";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Maker/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const MakerClassListPage = () => {
    const [fundDetails, setFundDetails] = useState<FundDetails[]>([]);
    const [planDetails, setPlanDetails] = useState<FundPlanData[]>([]);
    const [classDetails, setClassDetails] = useState<ClassData[]>([]);

    const navigate = useNavigate();

    const classMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .makerForm
    );

    const {
        companyName,
        fundPlanCode,
        fundCode,
        fundName,
        fundPlanName,
        clientCode,
    } = classMasterFormState;

    const {
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setInitialClassMakerEntry
    } = classMasterDetailsFormDispatchActionsProvider();

    const {
        setFlowType,
        setMakerNavigation,
    } = classMasterPageContextDispatchActionProvider();

    const fetchPlanDetails = useFetchFundPlanDetails();
    const fetchFundCodeDetails = useFetchFundCodeDetails();
    const fetchClassMaster = useFetchClassDetails();

    const fetchClassMasterDetails = (fundCode: string, fundPlanCode: string) => {
        fetchClassMaster(clientCode, fundCode, fundPlanCode)
            .then((result) => {
                setClassDetails(result); 
                console.log("Resulttt", result);
            });
    };

    const handleFetchFundCodeDetails = () => {
        fetchFundCodeDetails(clientCode, "M")
            .then((result) => setFundDetails(result));
    };

    useEffect (() => {
        handleFetchFundCodeDetails();
        fetchClassMasterDetails(fundCode, fundPlanCode);
    },[]);

    const onFundCodeChange = (value: string) => {
        setFundCode(value);
        fetchClassMasterDetails(value, fundPlanCode);
        const matchingFund = fundDetails.find((code) => code.fundCode.label === value);
        matchingFund && setFundName(matchingFund.fundName.value);
        fetchPlanDetails(clientCode, value)
            .then((result) => setPlanDetails(result.fundData));
    };  

    const onFundNameChange = (value: string) => {
        setFundName(value);
        const matchingFund = fundDetails.find((details) => details.fundName.value === value);
        matchingFund && setFundCode(matchingFund.fundCode.value);
        fetchClassMasterDetails( matchingFund ? matchingFund.fundCode.value : "", fundPlanCode);
        fetchPlanDetails(clientCode,  matchingFund ? matchingFund.fundCode.value : "")
            .then((result) => setPlanDetails(result.fundData));
    }; 

    const onFundPlanChange = (value: string) => {
        setFundPlanCode(value);
        fetchClassMasterDetails(fundCode, value);
        const matchingPlan = planDetails.find((code) => code.planCode.value === value);
        matchingPlan && setFundPlanName(matchingPlan.planDescription.value);
    };

    const onFundPlanNameChange = (value: string) => {
        setFundPlanName(value);
        const matchingPlan = planDetails.find((deatils) => deatils.planDescription.value === value);
        matchingPlan && setFundPlanCode(matchingPlan.planCode.value);
        fetchClassMasterDetails(fundCode, matchingPlan ? matchingPlan.planCode.value : "");
    };

    const customSelectInputStyle = {
        "& .MuiFilledInput-root": {
            "borderRadius": "6px",
        },
        "& .MuiFormHelperText-root, & .MuiFormLabel-root ": {
            "display": "block",
            "left": "8px",
            "position": "absolute",
            "top": "5px",
            "zIndex": "1",
        },
        "& .MuiSelect-filled.MuiSelect-select": {
            "& :hover": {
                "background": "#DAE9FF",
                "borderRadius": "6px",
            },
            "&:focus": {
                "background": "#DAE9FF",
                "borderRadius": "6px",
            },
            "background": "#DAE9FF",
            "borderRadius": "6px",
            "minHeight": "unset",
            "py": "6px",
        },
        
        "& .MuiSvgIcon-root": {
            "color": "#474556",
        },
        "& .css-rug5jf-MuiTypography-root": {
            "color": "#9497A3"
        },
    };

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton   
                                onClick={() => {
                                    setMakerNavigation("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>
                            
                            <Typography variant="formHeading">
                                Class
                            </Typography>
                        </Box>
                        
                        <Stack direction="row" spacing={2}>
                            <FXButton
                                label="Add New Class" 
                                buttonVariant="flowaction"
                                startIcon={<AddIcon/>}
                                onClick={() => {
                                    setInitialClassMakerEntry(classMasterFormState);
                                    setMakerNavigation("form");
                                    setFlowType("add");
                                }}
                                sx={{
                                    "fontSize": "12px",
                                    "fontWeight": 500,
                                }}
                            />

                            <FXButton 
                                label="Update Existing" 
                                buttonVariant="flowaction"
                                startIcon={<EditIcon/>}
                                onClick={() => {
                                    setInitialClassMakerEntry(classMasterFormState);
                                    setMakerNavigation("form");
                                    setFlowType("update");
                                }}
                                sx={{
                                    "fontSize": "12px",
                                    "fontWeight": 500,
                                }}
                            />
                            
                            {/* <IconButton sx={{"padding": "0px"}}>
                                <UpdateIcon/>
                            </IconButton> */}
                            
                        </Stack>
                    </Grid>
                </Grid>
            </Grid>

            <Paper elevation={0} sx={{ "borderRadius": "10px", "marginTop": "20px", "width": "100%" }}>
                <Stack alignItems="center" direction="row" spacing={2} padding="10px">
                    <Box>
                        <FilterByIcon/>
                    </Box>

                    <Typography variant="companyCode" width="130px">
                        Filter By
                    </Typography>

                    <Box width="30%">
                        <FXSelectInput
                            value={fundCode}
                            onValueChange={onFundCodeChange}
                            menuItems={fundDetails.map((fund) => fund.fundCode)} 
                            formLabelSx={customSelectInputStyle}
                            {...{...(fundCode?.length ? {"label": "", "required": false} : {"label": "Fund Code", "required": false})}}
                        />
                    </Box>

                    <Box width="60%">
                        <FXSelectInput
                            value={fundName}
                            onValueChange={onFundNameChange}
                            menuItems={fundDetails.map((fund) => fund.fundName)} 
                            formLabelSx={customSelectInputStyle}
                            {...{...(fundName?.length ? {"label": "", "required": false} : {"label": "Fund Name", "required": false})}}
                        />
                    </Box>

                    <Box width="30%">
                        <FXSelectInput 
                            value={fundPlanCode}
                            onValueChange={onFundPlanChange}
                            menuItems={planDetails.map((plan) => ({
                                "label": plan.planCode.value,
                                "value": plan.planCode.value,
                            }))} 
                            formLabelSx={customSelectInputStyle}
                            {...{...(fundPlanCode?.length ? {"label": "", "required": false} : {"label": "Fund Plan Code", "required": false})}}
                        />
                    </Box>

                    <Box width="50%">
                        <FXSelectInput 
                            value={fundPlanName}
                            onValueChange={onFundPlanNameChange}
                            menuItems={planDetails.map((plan) => ({
                                "label": plan.planDescription.value,
                                "value": plan.planDescription.value,
                            }))} 
                            formLabelSx={customSelectInputStyle}
                            {...{...(fundPlanName?.length ? {"label": "", "required": false} : {"label": "Fund Plan Name", "required": false})}}
                        />
                    </Box>
                </Stack>
            </Paper>
                
            <Grid item xs={12}>
                <Grid
                    alignContent="center"
                    display="flex"
                    justifyContent="space-between"
                    marginTop="30px"
                >
                    <Typography variant="clearButtonDescription" display="flex">
                        {companyName}
                    </Typography>

                    <FXButton
                        label="Rejected By Checker"
                        onClick={()=>setMakerNavigation("rejected")}
                    />

                    {/* <Typography variant="rejectedByCheckerLabel">
                        Rejected By Checker
                    </Typography> */}
                </Grid>
            </Grid>
            
            
            {classDetails.map((data) => (
                <>
                    <Paper sx={{ "borderRadius": "15px", "marginTop": "10px" , "padding": "20px" }}>
                        <Stack spacing={1}>
                            <Typography variant="companyCount" display="flex">
                                {data.fundCode} 
                            </Typography>
        
                            <Typography variant="classCompanyName" display="flex">
                                {data.fundName}
                            </Typography>
                        </Stack>
                        
                        <Grid container columnSpacing={5} rowSpacing={5} marginTop="10px">
                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Code
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.classCode.value} 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Description
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassDescription.value} 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Category
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassCategory.value} 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.6}>
                                <Typography variant="classItems" display="flex">
                                    Min Amount
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassMinAmount.value} 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Max Amount
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassMaxAmount.value} 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Management Fee
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassManagementFee.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Performance Fee
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassPerformanceFee.value} % 
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Hurdle Rate
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassHurdleRate.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Per Fee Percentage
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassPerFeePercentage.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Share Ratio
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassShareRatio.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Additional Fee
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassAdditionalFee.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.6}>
                                <Typography variant="classItems" display="flex">
                                    ORG Fee
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassOrgFee.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    GST Rate
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassGstRate.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Preferred Return
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassPreferredReturn.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Max Return
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassMaxReturn.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Carry %
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassCarryPercentage.value} %
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Currency
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassCurrency.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Fund Sponsor Class
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundSponsorClass.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.5}>
                                <Typography variant="classItems" display="flex">
                                    Face Value
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.fundClassFaceValue.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.6}>
                                <Typography variant="classItems" display="flex">
                                    Income Dist Frequency
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.incomeDistFrequency.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    ISIN Code
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.isinCode.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    High Water Mark
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.highWaterMark.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Is Active
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.isActive.value}
                                </Typography>
                            </Grid>

                            <Grid item xs={1.475}>
                                <Typography variant="classItems" display="flex">
                                    Setup Fee %
                                </Typography>

                                <Typography variant="classItemsData" display="flex">
                                    {data.setupFee.value} %
                                </Typography>
                            </Grid>
                        </Grid>
                    </Paper>
                    <Box minHeight={10}></Box>
                </>
            ))}
            
        </>
    );
};

export default MakerClassListPage;
