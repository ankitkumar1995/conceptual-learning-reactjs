import {
    Box,
    FormControl,
    Grid,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchRejectQueue, { 
    PendingRejectedItem 
} from "../../../../../hooks/api/useFetchRejectQueue";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import FXButton from "../../../../../components/FXButton";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import {
    StyledPagination
} from "../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";

import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Auditor/dispatchActionsProvider";
import classMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Nigo/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { nanoid } from "@reduxjs/toolkit";
import useFetchClassMaster from "../../../../../hooks/api/useFetchClassMaster";
import { useSelector } from "react-redux";

const PendingAuditorEntryItems = () => {
    const [pendingAuditorEntryItems, setPendingAuditorEntryItems] = useState<PendingCheckerItem[]>([]);
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage, setItemCountPerPage] = useState(5);
    const [tabActive, setTabActive] = useState({
        "activeToDo": true,
        // "rejectedByAuditor": false,
        "rejectedByMe": false,
    });

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const { 
        setClientCode,
        setClassMasterAuditorStateFromCheckerEntry,
    } = classMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerNavigation,
    } = classMasterPageContextDispatchActionProvider();

    const fetchAuditorQueue = useFetchToDoQueue();
    const fetchClassMaster = useFetchClassMaster();
    const fetchRejectedQueue = useFetchRejectQueue();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleCardOnClick = (
        clientCode: string, 
        classCode: string, 
        fundCode: string,
        planCode: string, 
    ) => {
        fetchClassMaster(classCode, clientCode, fundCode, planCode, "A", userId)
            .then((classMaster) => {
                const {
                    "classMasterState": classMasterCheckerState,    
                } = classMaster;
                setClientCode(clientCode);
                setClassMasterAuditorStateFromCheckerEntry(classMasterCheckerState);
            });
    };

    const handleTabChange = (tab: string) => {
        setTabActive({
            "activeToDo": false,
            // "rejectedByAuditor": false,
            "rejectedByMe": false,
            [tab]: true,
        });
        setItemCountPerPage(5);
    };

    useEffect(() => {
        if (tabActive["activeToDo"]) {
            fetchAuditorQueue(itemCountPerPage, page-1, "class_master", "A", userId)
                .then((result) => {
                    const {
                        checkerQueue,
                        pendingCheckerItemCount,
                    } = result;

                    setPendingAuditorEntryItems(checkerQueue);
                    setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
                });
        }  else {
            fetchRejectedQueue(itemCountPerPage,"",page-1, "class_master", "A", "A", userId)
                .then((result) => {
                    const {
                        rejectQueue,
                        pendingRejectItemCount,
                    } = result;
                    
                    setPendingRejectEntryItems(rejectQueue);
                    setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
                });
        }
    }, [page, tabActive, pageCount, itemCountPerPage,tabActive]);

    const mapData = tabActive["activeToDo"] ? pendingAuditorEntryItems : pendingRejectEntryItems;

    return (  
        <>
            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                <Grid item xs={12} mb={3}>
                    <Grid
                        display="flex"
                    >
                        <FXButton
                            label="To Do"
                            onClick={() => handleTabChange("activeToDo")}
                            disabled={tabActive.activeToDo}
                        />

                        <FXButton
                            label="Rejected By Me"
                            onClick={() => handleTabChange("rejectedByMe")}
                            disabled={tabActive.rejectedByMe}
                        />
                    </Grid>
                </Grid>

                {
                    mapData.map((pendingAuditorEntryItems) => {
                        const {
                            classCode,
                            className,
                            clientCode,
                            clientName,
                            createdBy,
                            createdOn,
                            fundCode,
                            fundName,
                            planCode,
                            planName,
                            rejectRemarks
                        } = pendingAuditorEntryItems;

                        const toDoData = [
                            {
                                "dataPartOne": clientCode,
                                "dataPartTwo": clientName
                            },
                            {
                                "dataPartOne": fundCode,
                                "dataPartTwo": fundName
                            },
                            {
                                "dataPartOne": planCode,
                                "dataPartTwo": planName
                            },
                            {
                                "dataPartOne": classCode,
                                "dataPartTwo": className,
                            },
                        ];

                        const rejectedData = !tabActive["activeToDo"] 
                            ? [
                                {
                                    "dataPartOne": `Remarks: ${rejectRemarks}`
                                }
                            ] : [];

                        return (
                            <Box key={nanoid()}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={toDoData}
                                    remarksData={rejectedData}
                                    onClick={() => handleCardOnClick(clientCode, classCode, fundCode, planCode)} 
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            {(tabActive["activeToDo"] && pendingAuditorEntryItems.length>0 || !tabActive["activeToDo"] && pendingRejectEntryItems.length>0) &&<Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}>
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
            }
        </>
    );
};

export default PendingAuditorEntryItems;
