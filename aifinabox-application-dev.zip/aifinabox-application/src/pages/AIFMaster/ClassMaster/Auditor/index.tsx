import AuditorClassMasterForm from "./AuditorClassMasterForm";
import PendingAuditorEntryItems from "./PendingAuditorEntryItems";
import { RootState } from "../../../../redux/store";
import initialClassMasterDetailsFormDispatchActionProvider from "../../../../redux/AifMaster/ClassMaster/Auditor/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const AuditorClassMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .auditForm
                .clientCode
    );

    const { 
        setClientCode,
    } = initialClassMasterDetailsFormDispatchActionProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingAuditorEntryItems/>
                    : <AuditorClassMasterForm/>
            }
        </>
    );
};

export default AuditorClassMasterPage;
