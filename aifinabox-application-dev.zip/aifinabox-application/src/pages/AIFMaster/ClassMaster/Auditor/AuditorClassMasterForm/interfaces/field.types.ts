import { RadioButtonValue } from "../../../../../../components/FXRadioGroup/FXInputProps.types";

export type Field = 
    "additionalFee" |
    "carryPercentage" |
    "catchupPercentage" |
    "clientCode" |
    "classCode" |
    "companyName" |
    "currency" |
    "description" |
    "faceValue" |
    "fundClassCategory" |
    "fundCode" |
    "fundName" |
    "fundPlanCode" |
    "fundPlanName" |
    "fundSponsorClass" |
    "gstRate" |
    "highWaterMark" |
    "hurdleRate" |
    "incomeDistFrequency" |
    "isActive" |
    "isinCode" |
    "managementFee" |
    "maxAmount" |
    "maxReturn" |
    "minAmount" |
    "orgFee" |
    "perFeePercentage" |
    "performanceFee" |
    "preferredReturn" |
    "setUpFee" |
    "shareRatio";
