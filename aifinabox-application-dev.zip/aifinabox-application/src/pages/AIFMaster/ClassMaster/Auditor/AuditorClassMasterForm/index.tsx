import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Grid,
    IconButton,
    Paper,
    Stack,
    Typography
} from "@mui/material";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useEffect, useState } from "react";

import AddIcon from "../../../../../icons/AddIcon";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXSelectInput from "../../../../../components/FXSelectInput";
import FilterByIcon from "../../../../../icons/FilterByIcon";
import RemarksPopup from "../../../../../components/FXRemarksPopup";
import { RootState } from "../../../../../redux/store";
import UpdateIcon from "../../../../../icons/UpdateIcon";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Auditor/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import usePostClassMaster from "../../../../../hooks/api/usePostClassMaster";
import usePostRejectDetails from "../../../../../hooks/api/usePostRejectDetails";
import { useSelector } from "react-redux";

const AuditorClassMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);
    const [openRemarksPopup, setOpenRemarksPopup] = useState(false);
    const [openSubmitPopup, setOpenSubmitPopup] = useState(false);
    const [rejectRemarkText, setRejectRemarkText] = useState("Please - Check All Details");
    const classMasterFormState = useSelector(
        (state: RootState) => 
            state
                .aifMasterState
                .classMasterState
                .auditForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const {
        additionalFee,
        carryPercentage,
        catchupPercentage,
        clientCode,
        companyName,
        classCode,
        currency,
        description,
        faceValue,
        fundClassCategory,
        fundCode,
        fundName,
        fundPlanCode,
        fundPlanName,
        fundSponsorClass,
        managementFee,
        maxAmount,
        maxReturn,
        minAmount,
        hurdleRate,
        highWaterMark,
        incomeDistFrequency,
        isActive,
        isinCode,
        orgFee,
        gstRate,
        performanceFee,
        perFeePercentage,
        preferredReturn,
        setUpFee,
        shareRatio,
    } = classMasterFormState;

    const { firstName, lastName } = userContextState;

    const {
        clearState,
        setClientCode,
    } = classMasterDetailsFormDispatchActionsProvider();

    const {
        setFlowType,
        setMakerNavigation,
    } = classMasterPageContextDispatchActionProvider();

    const postClassMaster = usePostClassMaster();
    const postRejectClassMaster = usePostRejectDetails();

    const handleFormSubmit = () => {
        postClassMaster(classMasterFormState, `${firstName} ${lastName}`, "0", userId, "A", isUpdate, classCode)
            .then(() => setAlertSnackbarContext({
                "description": `Auditor Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Auditor Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Auditor Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Auditor Entry Failed",
                });
            });
    };

    const handleRejectSubmit = () => {
        setOpenRemarksPopup(false);
        //setAlertSnackbarContext(initialAlertSnackbarContext());
        postRejectClassMaster("", "", classCode, clientCode, fundCode, "class_master", fundPlanCode, "A", rejectRemarkText, userId, `${firstName} ${lastName}`)
            .then(() => setAlertSnackbarContext({
                "description": `Auditor Entry Rejected against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Auditor Entry Rejected Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Auditor Entry Reject Failure against
                                    Client Code ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Auditor Entry Reject Failed",
                });
            });
    };

    return (
        <>
            <Grid item xs={12}>
                <Grid
                    alignItems="center"
                    display="flex"
                    justifyContent="space-between"
                >
                    <Box 
                        alignItems="center"
                        display="flex"
                    >
                        <IconButton
                            onClick={() => {
                                setClientCode("");
                            }}
                        >
                            <BackArrowIcon/>
                        </IconButton>

                        <Typography variant="formHeading">
                            Class Master
                        </Typography>
                    </Box>
                </Grid>
            </Grid>
            
            <Paper elevation={0}>  
                <Grid container columnSpacing={5} rowSpacing={5} marginTop="10px">
                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Company Code
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {clientCode}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Company Name
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {companyName}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Fund Code
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {fundCode}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Fund Name
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {fundName} 
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Fund Plan Code
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {fundPlanCode}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Code
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {classCode} 
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Description
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {description} 
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Category
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {fundClassCategory}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Min Amount
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {minAmount}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Max Amount
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {maxAmount}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Management Fee
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {managementFee}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Performance Fee
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {performanceFee}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Hurdle Rate
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {hurdleRate}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Per Fee Percentage
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {perFeePercentage}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Share Ratio
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {shareRatio}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Additional Fee
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {additionalFee}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            ORG Fee
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {orgFee}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            GST Rate
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {gstRate}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Preferred Return
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {preferredReturn}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Max Return
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {maxReturn}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Carry Percentage
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {carryPercentage}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Catchup Percentage
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {catchupPercentage}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Fund Sponsor Class
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {fundSponsorClass}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Currency
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {currency}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Face Value
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {faceValue}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Income Dist Frequency
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {incomeDistFrequency}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            ISIN Code
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {isinCode}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            High Water Mark
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {highWaterMark}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Is Active
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {isActive}
                        </Typography>
                    </Grid>

                    <Grid item xs={2.4}>
                        <Typography variant="classItems" display="flex">
                            Setup Fee %
                        </Typography>

                        <Typography variant="classItemsData" display="flex">
                            {setUpFee}
                        </Typography>
                    </Grid>

                    <Grid item xs={12}></Grid>
                </Grid>
            </Paper>

            <Grid container xs={12} spacing={2}>
                <Grid item xs={6}>
                    <FXButton
                        label="Reject"
                        buttonVariant="normal"
                        fullWidth
                        disableRipple
                        disabled={alertSnackbarContext.open}
                        onClick={() => setOpenRemarksPopup(true)}
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }} 
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton 
                        label="Accept"
                        disableRipple
                        buttonVariant="submit"
                        fullWidth
                        disabled={alertSnackbarContext.open}
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        onClick={handleFormSubmit}                      
                    />
                </Grid>
            </Grid>

            <RemarksPopup 
                open={openRemarksPopup}
                isDisabled={rejectRemarkText.length===0 || !rejectRemarkText}
                onCancelClick={() => {
                    setOpenRemarksPopup(false);
                    setRejectRemarkText("");
                }}
                onSubmitClick={() => handleRejectSubmit()}
                rejectRemarkText={rejectRemarkText}
                setRejectRemarkText={setRejectRemarkText}            
            />

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        clearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default AuditorClassMasterForm;
