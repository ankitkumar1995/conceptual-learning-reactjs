import AuditorClassMasterPage from "./Auditor";
import CheckerClassMasterPage from "./Checker";
import MakerClassMasterPage from "./Maker";
import NigoClassMasterForm from "./Nigo/NigoClassMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const ClassMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerClassMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerClassMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoClassMasterForm/>
            }

            {
                (authRole === "Auditor") &&
                <AuditorClassMasterPage/>
            }
        </>
    );
};

export default ClassMasterPage;
