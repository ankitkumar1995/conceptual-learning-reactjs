import NigoClassMasterForm from "./NigoClassMasterForm";
import classMasterPageContextDispatchActionProvider from "../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { useEffect } from "react";

const NigoClassMasterPage = () => {


    const { setFormStage, setCheckerNavigation } = classMasterPageContextDispatchActionProvider();

    const {
        "setNigoRaised": setClassnigoRaised,
        
    } = classMasterPageContextDispatchActionProvider();


    useEffect(()=>{
        setClassnigoRaised(false);
        setCheckerNavigation("");
    },[]);

    return (
        <>
            <NigoClassMasterForm/>
        </>
    );
};

export default NigoClassMasterPage;

