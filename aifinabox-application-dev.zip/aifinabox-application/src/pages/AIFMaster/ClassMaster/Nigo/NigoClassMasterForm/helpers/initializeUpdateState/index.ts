import { Field } from "../../../../Maker/MakerClassMasterForm/interfaces/field.types";

export type UpdateState = { 
    [fieldName in Field]: boolean
};

function initializeUpdateState(): UpdateState {
    return (
        {
            "additionalFee": false,
            "carryPercentage": false,
            "catchupPercentage": false,
            "classCode": false,
            "clientCode": false,
            "companyName": false,
            "currency": false,
            "description": false,
            "faceValue": false,
            "fundClassCategory": false,
            "fundCode": false,
            "fundName": false,
            "fundPlanCode": false,
            "fundPlanName": false,
            "fundSponsorClass": false,
            "gstRate": false,
            "highWaterMark": false,
            "hurdleRate": false,
            "incomeDistFrequency": false,
            "isActive": false,
            "isinCode": false,
            "managementFee": false,
            "maxAmount": false,
            "maxReturn": false,
            "minAmount": false,
            "orgFee": false,
            "perFeePercentage": false,
            "performanceFee": false,
            "preferredReturn": false,
            "setUpFee": false,
            "shareRatio": false,
        }
    );
}

export default initializeUpdateState;
