import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import initializeUpdateState, { UpdateState } from "./helpers/initializeUpdateState";

import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import NigoTable from "../../../components/NigoTable";
import NigoTableAuditorReject from "../../../components/NigoTableAuditorRejected";
import { RootState } from "../../../../../redux/store";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Checker/dispatchActionsProvider";
import classMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Nigo/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import usePostClassMaster from "../../../../../hooks/api/usePostClassMaster";
import { useSelector } from "react-redux";
import { useState } from "react";

const NigoClassMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);

    const navigate = useNavigate();

    const checkerClassMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .checkerForm
    );
    
    const nigoClientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .nigoForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const { clientCode } = checkerClassMasterFormState;

    const { 
        checkerData, 
        makerData, 
        nigoMetaData
    } = nigoClientMasterFormState;

    const { 
        "clearState": clearNigoState,
        setCheckerData, 
        setMakerData, 
        setNigoMetaData 
    } = classMasterNigoDetailsFormDispatchActionsProvider();

    const { "clearState": clearCheckerState }  = classMasterDetailsFormDispatchActionsProvider();

    const checkerNavigation = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .checkerNavigation
    );

    const referenceClassCodePostAuditorRejection = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .referenceClassCodePostAuditorRejection
    );

    const {
        setNigoRaised
    } = classMasterPageContextDispatchActionProvider();

    const postClassMaster = usePostClassMaster();

    const makerClassCode = checkerNavigation !=="auditor" ? makerData.classCode : referenceClassCodePostAuditorRejection;
    const handleFormSubmit = () => {
        let modifiedCheckerData = checkerData;
        let modifiedMakerData = makerData;

        nigoMetaData.forEach((data) => {
            const fieldName = data.field;
            const checkerValue = data.checkerEntry;
            const makerValue = data.makerEntry;

            modifiedCheckerData = {
                ...modifiedCheckerData,
                [fieldName]: checkerValue,
            };
            // modifiedMakerData = {
            //     ...modifiedMakerData,
            //     [fieldName]: makerValue,
            // };
        });

        setCheckerData(modifiedCheckerData);
        setMakerData(modifiedMakerData);

        postClassMaster(modifiedCheckerData, `${firstName} ${lastName}`, "0", userId, "C", isUpdate, makerClassCode)
            .then(() => setAlertSnackbarContext({
                "description": `NIGO Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "NIGO Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `NIGO Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "NIGO Entry Failed",
                });
            });
    };

    return (
        <>
            {checkerNavigation !=="auditor" ?
                <NigoTable 
                    disableSubmit={alertSnackbarContext.open}
                    nigoData={nigoMetaData}
                    onDataChange={(nigoData) => {
                        setNigoMetaData(nigoData);
                    }}
                    onSubmitClicked={handleFormSubmit}
                />:
                <NigoTableAuditorReject
                    disableSubmit={alertSnackbarContext.open}
                    nigoData={nigoMetaData}
                    onDataChange={(nigoData) => {
                        setNigoMetaData(nigoData);
                    }}
                    onSubmitClicked={handleFormSubmit}
                />
            
            }
            
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        clearCheckerState();
                        clearNigoState();
                        setNigoRaised(false);
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default NigoClassMasterForm;
