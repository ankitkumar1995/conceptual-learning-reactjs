import {
    ClassMasterDetails as CheckerClassMasterDetails
} from "../../../../../../redux/AifMaster/ClassMaster/Checker/initialState";
import {
    ClassMasterDetails as MakerClassMasterDetails
} from "../../../../../../redux/AifMaster/ClassMaster/Maker/initialState";

import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerClassMasterDetails, checkerFormState: CheckerClassMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerClassMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }
    
    return nigoData;
}

export function getNigoDataAuditorReject(makerFormState: MakerClassMasterDetails, checkerFormState: CheckerClassMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerClassMasterDetails;
            // if (makerFormState[field] !== checkerFormState[field]) {
            const nigo: NigoData = {
                "checkerEntry": checkerFormState[field] as string,
                "dataStatus": makerFormState[field] === checkerFormState[field],
                "field": key,
                "id": id,
                "makerEntry": makerFormState[field] as string,
            };
            nigoData.push(nigo);
            id++;
            // }
        }
    }
    
    return nigoData;
}
