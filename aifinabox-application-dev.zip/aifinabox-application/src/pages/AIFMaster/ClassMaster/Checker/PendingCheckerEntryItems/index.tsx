import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import {
    StyledPagination
} from "../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Checker/dispatchActionsProvider";
import classMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Nigo/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import updateDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/Update/dispatchActionProvider";
import useFetchClassMaster from "../../../../../hooks/api/useFetchClassMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);

    const { 
        setClientCode,
        setCompanyName,
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setClassMasterCheckerState,
        setClassMasterCheckerStateFromMakerEntry,
    } = classMasterDetailsFormDispatchActionsProvider();

    const { setMakerData } = classMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setCheckerNavigation,
    } = classMasterPageContextDispatchActionProvider();

    const { setIsUpdate } = updateDispatchActionProvider();
    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );
    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchClassMaster = useFetchClassMaster();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleCardOnClick = (
        clientCode: string, 
        clientName: string,
        classCode: string, 
        fundCode: string,
        fundName: string,
        planCode: string, 
        planName: string,
    ) => {
        fetchClassMaster(classCode, clientCode, fundCode, planCode, "C", userId)
            .then((classMaster) => {
                const {
                    "classMasterState": classMasterMakerState,
                    "classMasterUpdateState": classMasterMakerUpdateState,
                } = classMaster;

                console.log("updateState", classMasterMakerUpdateState);
                setClassMasterCheckerStateFromMakerEntry(classMasterMakerState, classMasterMakerUpdateState);
                setIsUpdate(classMasterMakerUpdateState);
                setClientCode(clientCode);
                setCompanyName(clientName);
                setFundCode(fundCode);
                setFundName(fundName);
                setFundPlanCode(planCode);
                setFundPlanName(planName);
                setMakerData(classMasterMakerState);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "class_master", "C", userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page,itemCountPerPage,pageCount]);

    return (  
        <>
            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            fundCode,
                            fundName,
                            planCode,
                            planName,
                            classCode,
                            className,
                            createdBy,
                            createdOn,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        },
                                        {
                                            "dataPartOne": fundCode,
                                            "dataPartTwo": fundName
                                        },
                                        {
                                            "dataPartOne": planCode,
                                            "dataPartTwo": planName
                                        },
                                        {
                                            "dataPartOne": classCode,
                                            "dataPartTwo": className,
                                        },
                                    ]}
                                    onClick={() => handleCardOnClick(clientCode, clientName, classCode, fundCode, fundName, planCode, planName,)} 
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>                    
                    </Stack>
                </FormControl>

                <Box></Box>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
