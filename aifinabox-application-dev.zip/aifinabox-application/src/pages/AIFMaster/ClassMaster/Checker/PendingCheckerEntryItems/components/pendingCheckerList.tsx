import { Box, Stack } from "@mui/material";
import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem 
} from "../../../../../../hooks/api/useFetchRejectQueue";
import useFetchTodoQueue, {
    PendingCheckerItem 
} from "../../../../../../hooks/api/useFetchToDoQueue";

import PendingCheckerEntryItemCard from "../../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../../redux/store";
import {
    StyledPagination 
} from "../../../../ClientMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import { nanoid } from "@reduxjs/toolkit";
import useFetchRejectClassMaster from "../../../../../../hooks/api/useFetchRejectClassMaster";
import { useSelector } from "react-redux";

const itemCountPerPage = 5;

interface ActiveTab {
    activeToDo: boolean;
    rejectedByAuditor: boolean;
    rejectedByMe: boolean;
}

interface PendingCheckerListsProps {
    tabActive: ActiveTab;
    handleCardOnClick: (
        clientCode: string, 
        clientName: string,
        classCode: string, 
        fundCode: string,
        fundName: string,
        planCode: string, 
        planName: string
        ) => void;
}

const PendingCheckerLists = (pendingCheckerListsProps: PendingCheckerListsProps) => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);

    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchRejectClassMaster = useFetchRejectClassMaster();
    const fetchRejectedQueue = useFetchRejectQueue();


    const {
        tabActive,
        // handleCardOnClick,
    } = pendingCheckerListsProps;

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleCardOnClick = (
        classCode: string,
        clientCode: string, 
        fundCode: string, 
        fundName: string,
        planCode: string,
    ) => {
        fetchRejectClassMaster("", "", classCode, clientCode, fundCode,"class_master", planCode, "C")
            .then((classMasterMakerState) => {
                // const { 
                //     bankMasterFormState, 
                //     bankMasterUpdateState 
                // } = bankMasterMakerState;
                // setMakerData(bankMasterFormState as BankMasterDetails);
                // setUpdateState(bankMasterUpdateState);
                // bankMasterUpdateState.updateFlag === "1" && setBankDetails(bankMasterFormState as BankMasterDetails);
            });
        // setCompanyCode(companyCode);
        // setCompanyName(companyName);
        // setFundCode(fundCode),
        // setFundName(fundName),
        // setCorporateBankName(corporateBankName),
        // setBankAccountNumber(bankAccountNumber),
        // setCheckerNavigation("form");
    };
    
    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    useEffect(() => {
        if (tabActive["activeToDo"]) {
            fetchCheckerQueue(itemCountPerPage, page-1, "class_master", "C",userId)
                .then((result) => {
                    const {
                        checkerQueue,
                        pendingCheckerItemCount,
                    } = result;

                    setPendingCheckerEntryItems(checkerQueue);
                    setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
                });
        }
        else {
            const rejectedBy = tabActive["rejectedByAuditor"] ? "A" : tabActive["rejectedByMe"] ? "C" : "C";

            fetchRejectedQueue(itemCountPerPage,"",page-1, "class_master", rejectedBy, "C", userId)
                .then((result) => {
                    const {
                        rejectQueue,
                        pendingRejectItemCount,
                    } = result;

                    setPendingRejectEntryItems(rejectQueue);
                    setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
                });
        }
    }, [page, tabActive, itemCountPerPage, pageCount]);

    const mapData = tabActive["activeToDo"] ? pendingCheckerEntryItems : pendingRejectEntryItems;

    return (
        <>
            {
                mapData.map((pendingCheckerEntryItem : PendingRejectedItem | PendingCheckerItem) => {
                    const {
                        bankAccountNumber,
                        bankName,
                        clientCode,
                        clientName,
                        fundCode,
                        fundName,
                        planCode,
                        planName,
                        classCode,
                        className,
                        createdBy,
                        createdOn,
                        // id,
                        rejectRemarks,
                    } = pendingCheckerEntryItem;

                    const toDoData = [
                        {
                            "dataPartOne": clientCode,
                            "dataPartTwo": clientName
                        },
                        {
                            "dataPartOne": fundCode,
                            "dataPartTwo": fundName
                        },
                        {
                            "dataPartOne": planCode,
                            "dataPartTwo": planName
                        },
                        {
                            "dataPartOne": classCode,
                            "dataPartTwo": className,
                        },
                    ];

                    const rejectedData = !tabActive["activeToDo"] ? [...toDoData, {
                        "dataPartOne": "Remarks",
                        "dataPartTwo": rejectRemarks,
                    }] : [...toDoData];

                    return (
                        <Box key={nanoid()}>
                            <PendingCheckerEntryItemCard
                                createdBy={createdBy}
                                creationDate={createdOn}
                                data={rejectedData}
                                onClick={() => tabActive["activeToDo"] && handleCardOnClick(classCode, clientCode, fundCode, fundName, planCode)} 
                            />
                        </Box>
                    );
                })
            }

            <Stack direction="row" justifyContent="space-between"> 
                
                <Box></Box>
                
                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerLists;
