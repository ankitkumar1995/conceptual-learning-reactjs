import { 
    AlertSnackbarContext, 
    initialAlertSnackbarContext 
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Grid,
    IconButton,
    Stack,
    Typography
} from "@mui/material";
import { DECISION_RADIO_OPTIONS, Field } from "./interfaces/field.types";
import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../interfaces/FieldValidation.types";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useEffect, useState } from "react";

import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import { 
    UpdateState as CheckerUpdateState 
} from "../../../../../redux/AifMaster/ClassMaster/Update/initialState";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXInput from "../../../../../components/FXInput";
import FXRadioGroup from "../../../../../components/FXRadioGroup";
import FXSelectInput from "../../../../../components/FXSelectInput";
import RemarksPopup from "../../../../../components/FXRemarksPopup";
import { RootState } from "../../../../../redux/store";
import { ToWords } from "to-words";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Checker/dispatchActionsProvider";
import classMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Nigo/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { getNigoData } from "../../Nigo/NigoClassMasterForm/helpers/getNigoData";
import { inrCurrencyFormatter } from "../../../../../utils/currencyFormatter";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurAmountValidator from "../../../../../validators/onBlurValidator/onBlurAmountValidator";
import onBlurDecimalValidator from "../../../../../validators/onBlurValidator/onBlurDecimalValidator";
import onBlurHighWaterMarkValidator from "../../../../../validators/onBlurValidator/onBlurHighWaterMarkValidator";
import onChangePercentageValidator from "../../../../../validators/onChangeValidator/onChangePercentageValidator";
import useFormRef from "./hooks/useFormRef";
import { useNavigate } from "react-router-dom";
import usePostClassMaster from "../../../../../hooks/api/usePostClassMaster";
import usePostRejectDetails from "../../../../../hooks/api/usePostRejectDetails";
import { useSelector } from "react-redux";

const CheckerClasssMasterForm = () => {
    const formRef = useFormRef();
    const navigate = useNavigate();
    const toWords = new ToWords();
    const [openRemarksPopup, setOpenRemarksPopup] = useState(false);
    const [openSubmitPopup, setOpenSubmitPopup] = useState(false);
    const [rejectRemarkText, setRejectRemarkText] = useState("Please - Check All Details");
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);
    const [isDataMatched, setIsDataMatched] = useState(false);
    
    const formStage = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .formStage
    );

    const classMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .checkerForm
    );

    const nigoClassMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .nigoForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) =>
            state
                .selectInputMenuItemsState
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .updateState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const applicationContextState = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
    );

    const { makerClassCode } = applicationContextState;

    const checkerNavigation = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .checkerNavigation
    );

    const {
        currencyMenuItems,
        fundClassCategoryMenuItems,
        distributionFrequencyMenuItems,
    } = selectInputMenuItems;

    const { firstName, lastName } = userContextState;

    const {
        setCheckerData,
        setNigoMetaData,
    } = classMasterNigoDetailsFormDispatchActionsProvider();

    const {
        additionalFee,
        carryPercentage,
        catchupPercentage,
        clientCode,
        classCode,
        companyName,
        currency,
        description,
        faceValue,
        fundClassCategory,
        fundCode,
        fundName,
        fundPlanCode,
        fundPlanName,
        fundSponsorClass,
        gstRate,
        highWaterMark,
        hurdleRate,
        incomeDistFrequency,
        isActive,
        isinCode,
        managementFee,
        maxAmount,
        maxReturn,
        minAmount,
        orgFee,
        perFeePercentage,
        performanceFee,
        preferredReturn,
        setUpFee,
        shareRatio,
    } = classMasterFormState;

    const {
        clearCriticalFieldsCheckerEntry,
        clearState,
        setAdditionalFee,
        setCarryPercentage,
        setCatchupPercentage,
        setClientCode,
        setClassCode,
        setCompanyName,
        setCurrency,
        setDescription,
        setFaceValue,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setFundSponsorClass,
        setGstRate,
        setHighWaterMark,
        setHurdleRate,
        setIncomeDistFrequency,
        setIsActive,
        setIsinCode,
        setManagementFee,
        setMaxAmount,
        setMaxReturn,
        setMinAmount,
        setOrgFee,
        setPerFeePercentage,
        setPerformanceFee,
        setPreferredReturn,
        setSetUpFee,
        setShareRatio,
    } = classMasterDetailsFormDispatchActionsProvider();

    const { setCheckerNavigation } = classMasterPageContextDispatchActionProvider();

    const {
        setNigoRaised,
    } = classMasterPageContextDispatchActionProvider();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey as Field];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
    };

    const handleClearCriticalFields = (updateState: CheckerUpdateState) => {
        
        if (updateState.updateFlag === "0" || (updateState.classCode && updateState.updateFlag === "1")) {
            if (formRef["classCode"].current)
                formRef["classCode"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.description && updateState.updateFlag === "1")) {
            if (formRef["description"].current)
                formRef["description"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.minAmount && updateState.updateFlag === "1")) {
            if (formRef["minAmount"].current)
                formRef["minAmount"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.maxAmount && updateState.updateFlag === "1")) {
            if (formRef["maxAmount"].current)
                formRef["maxAmount"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.managementFee && updateState.updateFlag === "1")) {
            if (formRef["managementFee"].current)
                formRef["managementFee"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.performanceFee && updateState.updateFlag === "1")) {
            if (formRef["performanceFee"].current)
                formRef["performanceFee"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.currency && updateState.updateFlag === "1")) {
            if (formRef["currency"].current)
                formRef["currency"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.faceValue && updateState.updateFlag === "1")) {
            if (formRef["faceValue"].current)
                formRef["faceValue"].current.value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.setUpFee && updateState.updateFlag === "1")) {
            if (formRef["setUpFee"].current)
                formRef["setUpFee"].current.value = "";
        }

        clearCriticalFieldsCheckerEntry(updateState);
    };

    const postClassMaster = usePostClassMaster();
    const postRejectClassMaster = usePostRejectDetails();
    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    useEffect(()=>{
        if (JSON.stringify(nigoClassMasterFormState.makerData) === JSON.stringify(classMasterFormState)){
            setIsDataMatched(true);
        }
    },[classMasterFormState]);

    const handleFormSubmit = () => {
        postClassMaster(classMasterFormState, `${firstName} ${lastName}`, "0", userId, "C", isUpdate, (formStage === 8) ? makerClassCode : nigoClassMasterFormState.makerData.classCode)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${clientCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    const handleRejectSubmit = () => {
        setOpenRemarksPopup(false);
        //setAlertSnackbarContext(initialAlertSnackbarContext());
        postRejectClassMaster("", "", nigoClassMasterFormState.makerData.classCode, clientCode, fundCode, "class_master", fundPlanCode, "C", rejectRemarkText, userId, `${firstName} ${lastName}`)
            .then(() => {
                setAlertSnackbarContext({
                    "description": `Checker Entry Rejected against Client Code ${clientCode}`,
                    "open": true,
                    "severity": "success",
                    "title": "Checker Entry Rejected Success",
                });
            })
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Reject Failure against
                                    Client Code ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Reject Failed",
                });
            });
    };

    useEffect(() => {
        if ((Number(minAmount) >= Number(maxAmount)) && minAmount.length && maxAmount.length) {
            setFormErrorState({
                ...formErrorState,
                "minAmount": {
                    "helperText": "Minimum Amount Should Be Less Than Maximum Amount",
                    "isError": true,
                    "isVerified": false,
                    "isWarning": false,
                },
            });
        } else {
            setFormErrorState({
                ...formErrorState,
                "minAmount": initializeFieldValidation(),
            });
        }
    }, [minAmount, maxAmount]);

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid
                        alignContent="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    handleClearState();
                                    setCheckerNavigation("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                {checkerNavigation === "todo"? "Update Class Master": "Rejected By Auditor - Class Master"}
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>

                <Grid item xs={4}>
                    <FXInput
                        label="Client Code"
                        defaultValue={clientCode}
                        disabled
                        readOnly
                        inputRef={formRef.clientCode}
                        onBlur={() => handleInputFieldChange("clientCode", setClientCode)}
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Company Name"
                        defaultValue={companyName}
                        disabled
                        readOnly
                        inputRef={formRef.companyName}
                        onBlur={() => handleInputFieldChange("companyName", setCompanyName)}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInput
                        label="Fund Code"
                        defaultValue={fundCode}
                        disabled
                        readOnly
                        required 
                        inputRef={formRef.fundCode}
                        onValueChange={setFundCode}
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Fund Name"
                        defaultValue={fundName}
                        disabled
                        readOnly
                        inputRef={formRef.fundName}
                        onBlur={() => handleInputFieldChange("fundName", setFundName)}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXInput 
                        label="Fund Plan Code"
                        defaultValue={fundPlanCode}
                        disabled
                        readOnly
                        required 
                        inputRef={formRef.fundPlanCode}
                        onValueChange={setFundPlanCode}
                    />
                </Grid>

                <Grid item xs={8}>
                    <FXInput
                        label="Fund Plan Name"
                        defaultValue={fundPlanName}
                        disabled
                        readOnly
                        required
                        inputRef={formRef.fundPlanName}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "fundPlanName")}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Class Code"
                        maxLength={5}
                        forbidTo="alphanumeric"
                        required 
                        disabled={updateState.updateFlag === "1" && !(updateState.classCode)}
                        defaultValue={classCode}
                        onBlur={() => handleInputFieldChange("classCode", setClassCode)}
                        inputRef={formRef.classCode}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "classCode")}
                        error={formErrorState.classCode.isError}
                        helperText={formErrorState.classCode.helperText}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Description" 
                        maxLength={256}
                        disabled={updateState.updateFlag === "1" && !(updateState.description)}
                        required
                        defaultValue={description}
                        inputRef={formRef.description}
                        onBlur={() => handleInputFieldChange("description", setDescription)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "description")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "description")}
                        error={formErrorState.description.isError}
                        helperText={formErrorState.description.helperText}      
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Fund Class Category"
                        value={fundClassCategory}
                        disabled={updateState.updateFlag === "1" && !(updateState.fundClassCategory)}
                        required
                        onValueChange={setFundClassCategory}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "fundClassCategory")}
                        error={formErrorState.fundClassCategory.isError}
                        helperText={formErrorState.fundClassCategory.helperText} 
                        menuItems={fundClassCategoryMenuItems}                    
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Min Amount"
                        maxLength={21}
                        forbidTo="amount"
                        endAdornment= {<Typography color="#9497A3">INR</Typography>}
                        value={minAmount}
                        inputRef={formRef.minAmount}
                        disabled={updateState.updateFlag === "1" && !(updateState.minAmount)}
                        defaultValue={minAmount}
                        required
                        onValueChange={(value) => {
                            setMinAmount(value);
                        }}
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        onFieldErrorChange={(fieldError) =>handleFieldErrorChange(fieldError, "minAmount") }
                        error={formErrorState.minAmount.isError}
                        helperText={
                            formErrorState.minAmount.isError
                                ? formErrorState.minAmount.helperText
                                : (
                                    (Number(minAmount) > 0) &&
                                `${toWords.convert(Number(minAmount), {"currency": true})}`
                                )
                        }                    
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Max Amount" 
                        maxLength={21}
                        forbidTo="amount"
                        endAdornment= {<Typography color="#9497A3">INR</Typography>}
                        value={maxAmount}
                        onValueChange={(value) => {
                            setMaxAmount(value);
                        }}
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        inputRef={formRef.maxAmount}
                        disabled={updateState.updateFlag === "1" && !(updateState.maxAmount)}
                        defaultValue={maxAmount}
                        required
                        onFieldErrorChange={(fieldError) =>handleFieldErrorChange(fieldError, "maxAmount") }
                        error={formErrorState.maxAmount.isError}
                        helperText={
                            formErrorState.maxAmount.isError
                                ? formErrorState.maxAmount.helperText
                                : (
                                    (Number(maxAmount) > 0) &&
                                `${toWords.convert(Number(maxAmount), {"currency": true})}`
                                )
                        }            
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Management Fee"
                        forbidTo="decimal-number"
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        // defaultValue={managementFee}
                        value={managementFee}
                        disabled={updateState.updateFlag === "1" && !(updateState.managementFee)}
                        inputRef={formRef.managementFee}
                        onBlur={() => handleInputFieldChange("managementFee", setManagementFee)}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setManagementFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setManagementFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setManagementFee(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "managementFee");
                                setManagementFee(value);
                            }
                        }}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "managementFee")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "managementFee")}
                        error={formErrorState.managementFee.isError}
                        helperText={formErrorState.managementFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Performance Fee"
                        forbidTo="decimal-number"
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        // defaultValue={performanceFee}
                        value={performanceFee}
                        inputRef={formRef.performanceFee}
                        disabled={updateState.updateFlag === "1" && !(updateState.performanceFee)}
                        onBlur={() => handleInputFieldChange("performanceFee", setPerformanceFee)}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPerformanceFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPerformanceFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPerformanceFee(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "performanceFee");
                                setPerformanceFee(value);
                            }
                        }}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "performanceFee")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "performanceFee")}
                        error={formErrorState.performanceFee.isError}
                        helperText={formErrorState.performanceFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Hurdle Rate"
                        forbidTo="decimal-number"
                        // defaultValue={hurdleRate}
                        value={hurdleRate}
                        inputRef={formRef.hurdleRate}
                        disabled={updateState.updateFlag === "1" && !(updateState.hurdleRate)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("hurdleRate", setHurdleRate)}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setHurdleRate("0");
                            } else if (/^\.\d+/.test(value)) {
                                setHurdleRate("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setHurdleRate(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "hurdleRate");
                                setHurdleRate(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "hurdleRate")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "hurdleRate")}
                        error={formErrorState.hurdleRate.isError}
                        helperText={formErrorState.hurdleRate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Per Fee Percentage"
                        forbidTo="decimal-number"
                        // defaultValue={perFeePercentage}
                        value={perFeePercentage}
                        inputRef={formRef.perFeePercentage}
                        disabled={updateState.updateFlag === "1" && !(updateState.perFeePercentage)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>} 
                        onBlur={() => handleInputFieldChange("perFeePercentage", setPerFeePercentage)}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPerFeePercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPerFeePercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPerFeePercentage(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "perFeePercentage");
                                setPerFeePercentage(value);
                            }
                        }}
                        //// onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "perFeePercentage")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "perFeePercentage")}
                        error={formErrorState.perFeePercentage.isError}
                        helperText={formErrorState.perFeePercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Share Ratio"
                        forbidTo="decimal-number"
                        // defaultValue={shareRatio}
                        value={shareRatio}
                        inputRef={formRef.shareRatio}
                        disabled={updateState.updateFlag === "1" && !(updateState.shareRatio)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("shareRatio", setShareRatio)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setShareRatio("0");
                            } else if (/^\.\d+/.test(value)) {
                                setShareRatio("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setShareRatio(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "shareRatio");
                                setShareRatio(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "shareRatio")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "shareRatio")}
                        error={formErrorState.shareRatio.isError}
                        helperText={formErrorState.shareRatio.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Additional Fee"
                        forbidTo="decimal-number"
                        // defaultValue={additionalFee}
                        value={additionalFee}
                        inputRef={formRef.additionalFee}
                        disabled={updateState.updateFlag === "1" && !(updateState.additionalFee)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("additionalFee", setAdditionalFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setAdditionalFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setAdditionalFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setAdditionalFee(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "additionalFee");
                                setAdditionalFee(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "additionalFee")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "additionalFee")}
                        error={formErrorState.additionalFee.isError}
                        helperText={formErrorState.additionalFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="ORG Fee"
                        forbidTo="decimal-number"
                        // defaultValue={orgFee}
                        value={orgFee}
                        inputRef={formRef.orgFee} 
                        disabled={updateState.updateFlag === "1" && !(updateState.orgFee)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("orgFee", setOrgFee)}
                        // onBlurValidator={onBlurDecimalValidator}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setOrgFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setOrgFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setOrgFee(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "orgFee");
                                setOrgFee(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "orgFee")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "orgFee")}
                        error={formErrorState.orgFee.isError}
                        helperText={formErrorState.orgFee.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="GST Rate"
                        forbidTo="decimal-number"
                        // defaultValue={gstRate}
                        value={gstRate}
                        inputRef={formRef.gstRate}
                        disabled={updateState.updateFlag === "1" && !(updateState.gstRate)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>} 
                        onBlur={() => handleInputFieldChange("gstRate", setGstRate)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setGstRate("0");
                            } else if (/^\.\d+/.test(value)) {
                                setGstRate("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setGstRate(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "gstRate");
                                setGstRate(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "gstRate")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "gstRate")}
                        error={formErrorState.gstRate.isError}
                        helperText={formErrorState.gstRate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Preferred Return"
                        forbidTo="decimal-number"
                        // defaultValue={preferredReturn}
                        value={preferredReturn}
                        inputRef={formRef.preferredReturn}
                        disabled={updateState.updateFlag === "1" && !(updateState.preferredReturn)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>} 
                        onBlur={() => handleInputFieldChange("preferredReturn", setPreferredReturn)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setPreferredReturn("0");
                            } else if (/^\.\d+/.test(value)) {
                                setPreferredReturn("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setPreferredReturn(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "preferredReturn");
                                setPreferredReturn(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "preferredReturn")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "preferredReturn")}
                        error={formErrorState.preferredReturn.isError}
                        helperText={formErrorState.preferredReturn.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Max Return"
                        forbidTo="decimal-number"
                        // defaultValue={maxReturn}
                        value={maxReturn}
                        inputRef={formRef.maxReturn}
                        disabled={updateState.updateFlag === "1" && !(updateState.maxReturn)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("maxReturn", setMaxReturn)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setMaxReturn("0");
                            } else if (/^\.\d+/.test(value)) {
                                setMaxReturn("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setMaxReturn(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "maxReturn");
                                setMaxReturn(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "maxReturn")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "maxReturn")}
                        error={formErrorState.maxReturn.isError}
                        helperText={formErrorState.maxReturn.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Carry Percentage"
                        forbidTo="decimal-number"
                        // defaultValue={carryPercentage}
                        value={carryPercentage}
                        inputRef={formRef.carryPercentage}
                        disabled={updateState.updateFlag === "1" && !(updateState.carryPercentage)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("carryPercentage", setCarryPercentage)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setCarryPercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setCarryPercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setCarryPercentage(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "carryPercentage");
                                setCarryPercentage(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "carryPercentage")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "carryPercentage")}
                        error={formErrorState.carryPercentage.isError}
                        helperText={formErrorState.carryPercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Catchup Percentage"
                        forbidTo="decimal-number"
                        // defaultValue={catchupPercentage}
                        value={catchupPercentage}
                        inputRef={formRef.catchupPercentage}
                        disabled={updateState.updateFlag === "1" && !(updateState.catchupPercentage)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("catchupPercentage", setCatchupPercentage)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setCatchupPercentage("0");
                            } else if (/^\.\d+/.test(value)) {
                                setCatchupPercentage("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setCatchupPercentage(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "catchupPercentage");
                                setCatchupPercentage(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "catchupPercentage")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "catchupPercentage")}
                        error={formErrorState.catchupPercentage.isError}
                        helperText={formErrorState.catchupPercentage.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Fund Sponsor Class" 
                        radioButtonValues={DECISION_RADIO_OPTIONS} 
                        disabled={updateState.updateFlag === "1" && !(updateState.fundSponsorClass)}
                        required   
                        row
                        onValueChange={setFundSponsorClass}
                        value={fundSponsorClass}
                        error={formErrorState.fundSponsorClass.isError}
                        helperText={formErrorState.fundSponsorClass.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Currency" 
                        disabled={updateState.updateFlag === "1" && !(updateState.currency)}
                        required  
                        menuItems={currencyMenuItems}  
                        value={currency}
                        onValueChange={setCurrency}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "currency")}
                        error={formErrorState.currency.isError}
                        helperText={formErrorState.currency.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Face Value"
                        maxLength={8}
                        forbidTo="numbers"
                        required
                        defaultValue={faceValue}
                        inputRef={formRef.faceValue}
                        disabled={updateState.updateFlag === "1" && !(updateState.faceValue)}
                        onBlur={() => handleInputFieldChange("faceValue", setFaceValue)}
                        onBlurValidator={onBlurAmountValidator}
                        validatorOptions={{}}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "faceValue")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "faceValue")}
                        error={formErrorState.faceValue.isError}
                        helperText={formErrorState.faceValue.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Income Dist Frequency" 
                        disabled={updateState.updateFlag === "1" && !(updateState.incomeDistFrequency)}
                        menuItems={distributionFrequencyMenuItems}   
                        required 
                        value={incomeDistFrequency}
                        onValueChange={setIncomeDistFrequency}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "incomeDistFrequency")}
                        error={formErrorState.incomeDistFrequency.isError}
                        helperText={formErrorState.incomeDistFrequency.helperText}                      
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="ISIN Code"
                        maxLength={12}
                        forbidTo="alphanumeric"
                        defaultValue={isinCode}
                        inputRef={formRef.isinCode}
                        disabled={updateState.updateFlag === "1" && !(updateState.isinCode)}
                        onBlur={() => handleInputFieldChange("isinCode", setIsinCode)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "isinCode")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "isinCode")}
                        error={formErrorState.isinCode.isError}
                        helperText={formErrorState.isinCode.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="High Water Mark"
                        maxLength={10}
                        forbidTo="decimal-number"
                        defaultValue={highWaterMark}
                        inputRef={formRef.highWaterMark}
                        disabled={updateState.updateFlag === "1" && !(updateState.highWaterMark)}
                        onBlur={() => handleInputFieldChange("highWaterMark", setHighWaterMark)}
                        validatorOptions={{}}
                        onBlurValidator={onBlurHighWaterMarkValidator}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "highWaterMark")}
                        error={formErrorState.highWaterMark.isError}
                        helperText={formErrorState.highWaterMark.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXRadioGroup
                        label="Is Active" 
                        radioButtonValues={DECISION_RADIO_OPTIONS} 
                        disabled={updateState.updateFlag === "1" && !(updateState.isActive)}
                        required               
                        row
                        value={isActive}
                        onValueChange={setIsActive}
                        error={formErrorState.isActive.isError}
                        helperText={formErrorState.isActive.helperText}
                    />  
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        rightIndent
                        label="Setup Fee %"
                        forbidTo="decimal-number"
                        inputRef={formRef.setUpFee}
                        // defaultValue={setUpFee}
                        value={setUpFee}
                        disabled={updateState.updateFlag === "1" && !(updateState.setUpFee)}
                        endAdornment= {<Typography color="#9497A3">%</Typography>}
                        onBlur={() => handleInputFieldChange("setUpFee", setSetUpFee)}
                        onChangeValidator={onChangePercentageValidator}
                        validatorOptions={{}}
                        onValueChange={(value) => {
                            if (value === "0.00") {
                                setSetUpFee("0");
                            } else if (/^\.\d+/.test(value)) {
                                setSetUpFee("0" + value);
                            }  else if (/^0\d/.test(value)) {
                                setSetUpFee(value.substring(1));
                            } else {
                                handleFieldErrorChange(initializeFieldValidation(), "setUpFee");
                                setSetUpFee(value);
                            }
                        }}
                        // onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "setUpFee")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "setUpFee")}
                        error={formErrorState.setUpFee.isError}
                        helperText={formErrorState.setUpFee.helperText}
                    />
                </Grid>

                <Grid xs={12}></Grid>

                <Grid item xs={4}>
                    <FXButton 
                        disableRipple
                        label="Reject" 
                        buttonVariant="submit" 
                        fullWidth
                        disabled={alertSnackbarContext.open}
                        onClick={() => setOpenRemarksPopup(true)}
                    />
                </Grid>
                <Grid item xs={4}>
                    <FXButton
                        label="Clear"
                        buttonVariant="normal"
                        fullWidth
                        onClick={() => handleClearCriticalFields(updateState)}
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }} 
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXButton 
                        label="Submit"
                        buttonVariant="submit"
                        fullWidth
                        disabled={
                            alertSnackbarContext.open || 
                            !isFormComplete(classMasterFormState) ||
                            !isFormValid(formErrorState)
                        }
                        sx={{
                            "fontSize": "16px",
                            "fontWeight": 500,
                        }}
                        onClick={() => {
                            const nigoData = 
                                (formStage === 8)
                                    ? []
                                    : getNigoData(nigoClassMasterFormState.makerData, classMasterFormState);
        
                            if (nigoData.length !== 0) {
                                setNigoMetaData(nigoData);
                                setCheckerData(classMasterFormState);
                                setNigoRaised(true);
                            }
                            else {
                                handleFormSubmit();
                            }
                        }}                      
                    />
                </Grid>
            </Grid>

            <RemarksPopup 
                open={openRemarksPopup}
                isDisabled={rejectRemarkText.length===0 || !rejectRemarkText}
                onCancelClick={() => {
                    setOpenRemarksPopup(false);
                    setRejectRemarkText("");
                }}
                onSubmitClick={() => handleRejectSubmit()}
                rejectRemarkText={rejectRemarkText}
                setRejectRemarkText={setRejectRemarkText}              
            />

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();

                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default CheckerClasssMasterForm;
