import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

type FormRef = {
    [fieldName in Field]: RefObject<HTMLInputElement>;
};

function useFormRef(): FormRef {
    const formRef: FormRef = {
        "additionalFee": useRef<HTMLInputElement>(null),
        "carryPercentage": useRef<HTMLInputElement>(null),
        "catchupPercentage": useRef<HTMLInputElement>(null),
        "classCode": useRef<HTMLInputElement>(null),
        "clientCode": useRef<HTMLInputElement>(null),
        "companyName": useRef<HTMLInputElement>(null),
        "currency": useRef<HTMLInputElement>(null),
        "description": useRef<HTMLInputElement>(null),
        "faceValue": useRef<HTMLInputElement>(null),
        "fundClassCategory": useRef<HTMLInputElement>(null),
        "fundCode": useRef<HTMLInputElement>(null),
        "fundName": useRef<HTMLInputElement>(null),
        "fundPlanCode": useRef<HTMLInputElement>(null),
        "fundPlanName": useRef<HTMLInputElement>(null),
        "fundSponsorClass": useRef<HTMLInputElement>(null),
        "gstRate": useRef<HTMLInputElement>(null),
        "highWaterMark": useRef<HTMLInputElement>(null),
        "hurdleRate": useRef<HTMLInputElement>(null),
        "incomeDistFrequency": useRef<HTMLInputElement>(null),
        "isActive": useRef<HTMLInputElement>(null),
        "isinCode": useRef<HTMLInputElement>(null),
        "managementFee": useRef<HTMLInputElement>(null),
        "maxAmount": useRef<HTMLInputElement>(null),
        "maxReturn": useRef<HTMLInputElement>(null),
        "minAmount": useRef<HTMLInputElement>(null),
        "orgFee": useRef<HTMLInputElement>(null),
        "perFeePercentage": useRef<HTMLInputElement>(null),
        "performanceFee": useRef<HTMLInputElement>(null),
        "preferredReturn": useRef<HTMLInputElement>(null),
        "setUpFee": useRef<HTMLInputElement>(null),
        "shareRatio": useRef<HTMLInputElement>(null),
    };

    return formRef;
}

export default useFormRef;
