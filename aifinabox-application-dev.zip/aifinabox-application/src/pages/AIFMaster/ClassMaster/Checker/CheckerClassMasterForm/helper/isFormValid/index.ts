import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.additionalFee.isError ||
        formErrorState.carryPercentage.isError ||
        formErrorState.catchupPercentage.isError ||
        formErrorState.clientCode.isError ||
        formErrorState.classCode.isError ||
        formErrorState.companyName.isError ||
        formErrorState.currency.isError ||
        formErrorState.description.isError ||
        formErrorState.faceValue.isError ||
        formErrorState.fundClassCategory.isError ||
        formErrorState.fundCode.isError ||
        formErrorState.fundName.isError ||
        formErrorState.fundPlanCode.isError ||
        formErrorState.fundPlanCode.isError ||
        formErrorState.fundPlanName.isError ||
        formErrorState.fundSponsorClass.isError ||
        formErrorState.gstRate.isError ||
        formErrorState.highWaterMark.isError ||
        formErrorState.hurdleRate.isError ||
        formErrorState.incomeDistFrequency.isError ||
        formErrorState.isActive.isError ||
        formErrorState.isinCode.isError ||
        formErrorState.managementFee.isError ||
        formErrorState.maxAmount.isError ||
        formErrorState.maxReturn.isError ||
        formErrorState.minAmount.isError ||
        formErrorState.orgFee.isError ||
        formErrorState.perFeePercentage.isError ||
        formErrorState.performanceFee.isError ||
        formErrorState.preferredReturn.isError ||
        formErrorState.setUpFee.isError ||
        formErrorState.shareRatio.isError
    );
}

export default isFormValid;
