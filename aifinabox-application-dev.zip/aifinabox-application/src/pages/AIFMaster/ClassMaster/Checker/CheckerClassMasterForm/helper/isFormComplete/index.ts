import { 
    ClassMasterDetails 
} from "../../../../../../../redux/AifMaster/ClassMaster/Checker/initialState";

function isFormComplete(classMasterDetails: ClassMasterDetails): boolean {
    const {
        classCode,
        currency,
        description,
        faceValue,
        fundClassCategory,
        fundCode,
        fundPlanCode,
        fundPlanName,
        fundSponsorClass,
        incomeDistFrequency,
        isActive,
        maxAmount,
        minAmount,
    } = classMasterDetails;

    const isFundClassCodeFilled = ( classCode.length !== 0 );
    const isFundCodeFilled = ( fundCode.length !== 0 );
    const isFundPlanCodeFilled = ( fundPlanCode.length !== 0 );
    const isFundPlanNameFilled = ( fundPlanName.length !== 0 );
    const isDescriptionFilled = ( description.length !== 0 );
    const isFundClassCategoryFilled = ( fundClassCategory.length !== 0 );
    const isMinAmountFilled = ( minAmount.length !== 0 );
    const isMaxAmountFilled = ( maxAmount.length !== 0 );
    const isFundSponsorClassFilled = ( fundSponsorClass.length !== 0 );
    const isCurrencyFilled = ( currency.length !== 0 );
    const isFaceValueFilled = ( faceValue.length !== 0 );
    const isIncomeDistFrequencyFilled = ( incomeDistFrequency.length !== 0 );
    const isIsActiveFilled = ( isActive.length !== 0 );

    return (
        isFundClassCodeFilled &&
        isFundCodeFilled &&
        isFundPlanCodeFilled &&
        isFundPlanNameFilled &&
        isDescriptionFilled &&
        isFundClassCategoryFilled &&
        isMinAmountFilled &&
        isMaxAmountFilled &&
        isFundSponsorClassFilled &&
        isCurrencyFilled &&
        isFaceValueFilled &&
        isIncomeDistFrequencyFilled &&
        isIsActiveFilled
    );
}

export default isFormComplete;
