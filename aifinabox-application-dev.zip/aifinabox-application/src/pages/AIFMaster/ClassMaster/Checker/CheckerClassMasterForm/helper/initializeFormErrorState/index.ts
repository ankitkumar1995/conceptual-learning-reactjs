import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../../../interfaces/FieldValidation.types";

import { Field } from "../../interfaces/field.types";

export type FormErrorState = { 
    [fieldName in Field]:  FieldValidation
};

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "additionalFee": initializeFieldValidation(),
            "carryPercentage": initializeFieldValidation(),
            "catchupPercentage": initializeFieldValidation(),
            "classCode": initializeFieldValidation(),
            "clientCode": initializeFieldValidation(),
            "companyName": initializeFieldValidation(),
            "currency": initializeFieldValidation(),
            "description": initializeFieldValidation(),
            "faceValue": initializeFieldValidation(),
            "fundClassCategory": initializeFieldValidation(),
            "fundCode": initializeFieldValidation(),
            "fundName": initializeFieldValidation(),
            "fundPlanCode": initializeFieldValidation(),
            "fundPlanName": initializeFieldValidation(),
            "fundSponsorClass": initializeFieldValidation(),
            "gstRate": initializeFieldValidation(),
            "highWaterMark": initializeFieldValidation(),
            "hurdleRate": initializeFieldValidation(),
            "incomeDistFrequency": initializeFieldValidation(),
            "isActive": initializeFieldValidation(),
            "isinCode": initializeFieldValidation(),
            "managementFee": initializeFieldValidation(),
            "maxAmount": initializeFieldValidation(),
            "maxReturn": initializeFieldValidation(),
            "minAmount": initializeFieldValidation(),
            "orgFee": initializeFieldValidation(),
            "perFeePercentage": initializeFieldValidation(),
            "performanceFee": initializeFieldValidation(),
            "preferredReturn": initializeFieldValidation(),
            "setUpFee": initializeFieldValidation(),
            "shareRatio": initializeFieldValidation(),
        }
    );
}

export default initializeFormErrorState;
