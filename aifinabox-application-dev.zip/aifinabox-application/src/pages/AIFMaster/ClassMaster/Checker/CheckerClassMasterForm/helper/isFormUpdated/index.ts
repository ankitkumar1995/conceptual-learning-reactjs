import { UpdateState } from "../initializeUpdateState";

function isFormUpdated(
    updateState: UpdateState, 
    updateExistingFlag: "0" | "1"
) {
    if (updateExistingFlag === "0")
        return false;

    return !(
        updateState.additionalFee ||
        updateState.carryPercentage ||
        updateState.catchupPercentage ||
        updateState.classCode ||
        updateState.currency ||
        updateState.description ||
        updateState.faceValue ||
        updateState.fundClassCategory ||
        updateState.fundSponsorClass ||
        updateState.gstRate ||
        updateState.highWaterMark ||
        updateState.hurdleRate ||
        updateState.incomeDistFrequency ||
        updateState.isActive ||
        updateState.isinCode ||
        updateState.managementFee ||
        updateState.maxAmount ||
        updateState.maxReturn ||
        updateState.minAmount ||
        updateState.orgFee ||
        updateState.perFeePercentage ||
        updateState.performanceFee ||
        updateState.preferredReturn ||
        updateState.setUpFee ||
        updateState.shareRatio
    );
} 

export default isFormUpdated;
