import { 
    Box,
    FormControl,
    Grid,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchRejectQueue, {
    PendingRejectedItem
} from "../../../../../hooks/api/useFetchRejectQueue";
import useFetchTodoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import FXButton from "../../../../../components/FXButton";
import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { 
    StyledPagination 
} from "../../../PlanMaster/Checker/PendingCheckerEntryItems/PaginationStyles";
import applicationContextDispatchActionsProvider from "../../../../../redux/ApplicationContext/dispatchActionsProvider";
import classMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Checker/dispatchActionsProvider";
import classMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClassMaster/Nigo/dispatchActionsProvider";
import classMasterPageContextDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/ClassMasterPageContext/dispatchActionsProvider";
import { getNigoDataAuditorReject } from "../../Nigo/NigoClassMasterForm/helpers/getNigoData";
import initialUpdateDispatchActionProvider from "../../../../../redux/AifMaster/ClassMaster/Update/dispatchActionProvider";
import { nanoid } from "@reduxjs/toolkit";
import useFetchClassMaster from "../../../../../hooks/api/useFetchClassMaster";
import useFetchRejectClassMaster from "../../../../../hooks/api/useFetchRejectClassMaster";
import { useSelector } from "react-redux";

const CheckerClassMasterList = () => {
    const checkerNavigateTo = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .fundMasterState
                .pageContext
                .checkerNavigateTo
    );
    const nigoClassMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .nigoForm
    );

    const {
        setCheckerData,
        setNigoMetaData,
    } = classMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised,
        setReferenceClassCodePostAuditorRejection
    } = classMasterPageContextDispatchActionProvider();

    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [pendingRejectEntryItems, setPendingRejectEntryItems] = useState<PendingRejectedItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);
    const [tabActive, setTabActive] = useState({
        "activeToDo": true,
        "rejectedByAuditor": false,
        "rejectedByMe": false,
    });

    const {
        setAdditionalFee,
        setCarryPercentage,
        setCatchupPercentage,
        setClassMasterCheckerState,
        setClassMasterCheckerStateFromMakerEntry,
        setClientCode,
        setClassCode,
        setCompanyName,
        setCurrency,
        setDescription,
        setFaceValue,
        setFundClassCategory,
        setFundCode,
        setFundName,
        setFundPlanCode,
        setFundPlanName,
        setFundSponsorClass,
        setGstRate,
        setHighWaterMark,
        setHurdleRate,
        setIncomeDistFrequency,
        setIsActive,
        setIsinCode,
        setManagementFee,
        setMaxAmount,
        setMaxReturn,
        setMinAmount,
        setOrgFee,
        setPerFeePercentage,
        setPerformanceFee,
        setPreferredReturn,
        setSetUpFee,
        setShareRatio,
    } = classMasterDetailsFormDispatchActionsProvider();

    const { setMakerClassCode } = applicationContextDispatchActionsProvider();
    const { setFormStage, setCheckerNavigation } = classMasterPageContextDispatchActionProvider();

    const { setMakerData } = classMasterNigoDetailsFormDispatchActionsProvider();
    const { setIsUpdate } = initialUpdateDispatchActionProvider();
    const fetchCheckerQueue = useFetchTodoQueue();
    const fetchRejectClassMaster = useFetchRejectClassMaster();
    const fetchRejectedQueue = useFetchRejectQueue();
    const fetchClassMaster = useFetchClassMaster();

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );
    
    const checkerNavigation = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .pageContext
                .checkerNavigation
    );

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const handleTabChange = (tab: string) => {
        setTabActive({
            "activeToDo": false,
            "rejectedByAuditor": false,
            "rejectedByMe": false,
            [tab]: true,
        });
        setItemCountPerPage(5);
    };

    useEffect(()=>{
        if (checkerNavigation ==="auditor"){
            setTabActive({
                "activeToDo": false,
                "rejectedByAuditor": true,
                "rejectedByMe": false
            });
        }
    },[checkerNavigateTo]);

    const handleCardOnClick = (
        clientCode: string, 
        clientName: string,
        classCode: string, 
        fundCode: string,
        fundName: string,
        planCode: string, 
        planName: string,
    ) => {

        if (tabActive.activeToDo) {
            setCheckerNavigation("todo");
            fetchClassMaster(classCode, clientCode, fundCode, planCode, "C", userId)
                .then((classMaster) => {
                    const {
                        "classMasterState": classMasterMakerState,
                        "classMasterUpdateState": classMasterMakerUpdateState,
                    } = classMaster;

                    setClassMasterCheckerStateFromMakerEntry(classMasterMakerState, classMasterMakerUpdateState);
                    setIsUpdate(classMasterMakerUpdateState);
                    setClientCode(clientCode);
                    setCompanyName(clientName);
                    setFundCode(fundCode);
                    setFundName(fundName);
                    setFundPlanCode(planCode);
                    setFundPlanName(planName);
                    setMakerData(classMasterMakerState);
                });
        }
        else
        {
            setCheckerNavigation("auditor");
            fetchRejectClassMaster("","",classCode,clientCode, fundCode,"class_master",planCode,"C")
                .then((classMaster) => {
                    const {
                        "classMasterMakerState": classMasterMakerData,
                        "classMasterState": classMasterData,
                        "classMasterUpdateState": classMasterMakerUpdateState,
                    } = classMaster;

                    const nigoData = getNigoDataAuditorReject(classMasterMakerData, classMasterData);

                    if (nigoData.length !== 0) {
                        setNigoMetaData(nigoData);
                        setCheckerData(classMasterData);
                        setNigoRaised(true);
                    }
                    setClassMasterCheckerStateFromMakerEntry(classMasterData, classMasterMakerUpdateState);
                    setIsUpdate(classMasterMakerUpdateState);
                    setAdditionalFee(classMasterData.additionalFee);
                    setCarryPercentage(classMasterData.carryPercentage);
                    setCatchupPercentage(classMasterData.catchupPercentage);
                    setClassCode(classMasterData.classCode);
                    setClientCode(classMasterData.clientCode);
                    setCompanyName(classMasterData.companyName);
                    setCurrency(classMasterData.currency);
                    setDescription(classMasterData.description);
                    setFaceValue(classMasterData.faceValue);
                    setFundClassCategory(classMasterData.fundClassCategory);
                    setFundCode(classMasterData.fundCode);
                    setFundName(classMasterData.fundName);
                    setFundPlanCode(classMasterData.fundPlanCode);
                    setFundPlanName(classMasterData.fundPlanName);
                    setFundSponsorClass(classMasterData.fundSponsorClass);
                    setGstRate(classMasterData.gstRate);
                    setHighWaterMark(classMasterData.highWaterMark);
                    setHurdleRate(classMasterData.hurdleRate);
                    setIncomeDistFrequency(classMasterData.incomeDistFrequency);
                    setIsActive(classMasterData.isActive);
                    setIsinCode(classMasterData.isinCode);
                    setMakerClassCode(classMasterData.classCode);
                    setManagementFee(classMasterData.managementFee);
                    setMaxAmount(classMasterData.maxAmount);
                    setMaxReturn(classMasterData.maxReturn);
                    setMinAmount(classMasterData.minAmount);
                    setOrgFee(classMasterData.orgFee);
                    setPerFeePercentage(classMasterData.perFeePercentage);
                    setPerformanceFee(classMasterData.performanceFee);
                    setPreferredReturn(classMasterData.preferredReturn);
                    setSetUpFee(classMasterData.setUpFee);
                    setShareRatio(classMasterData.shareRatio);
                    
                    // setFormStage(8);
                    setReferenceClassCodePostAuditorRejection(classMasterData.classCode);
                });
        }
    }; 

    useEffect(() => {
        if (tabActive["activeToDo"]) {
            fetchCheckerQueue(itemCountPerPage, page-1, "class_master", "C", userId)
                .then((result) => {
                    const {
                        checkerQueue,
                        pendingCheckerItemCount,
                    } = result;
    
                    setPendingCheckerEntryItems(checkerQueue);
                    setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
                });
        }
        else {
            const rejectedBy = tabActive["rejectedByAuditor"] ? "A" : tabActive["rejectedByMe"] ? "C" : "C";
    
            fetchRejectedQueue(itemCountPerPage,"",page-1, "class_master", rejectedBy, "C", userId)
                .then((result) => {
                    const {
                        rejectQueue,
                        pendingRejectItemCount,
                    } = result;
    
                    setPendingRejectEntryItems(rejectQueue);
                    setPageCount(Math.ceil(pendingRejectItemCount / itemCountPerPage));
                });
        }
    }, [page, tabActive, itemCountPerPage, pageCount, tabActive]);

    return (
        <Grid container rowSpacing={2} columnSpacing={2}>
            <Grid item xs={12}>
                {/* <Tabs 
                        value={currentTab} 
                        onChange={handleTabChange}
                        sx={{
                            "& .MuiTab-root": {
                                "&.Mui-selected": {
                                    "color": "#2057A6",
                                    "fontWeight": 600,
                                },
                                "color": "rgba(32, 87, 166, 0.5)",
                                "fontFamily": fontFamily,
                                "fontSize": "14px",
                                "fontWeight": 500,
                                "marginRight": "24px",
                                "minWidth": "unset",
                                "padding": "0",
                                "textTransform": "none",
                            },
                            "& .MuiTabs-indicator": {
                                "display": "none"
                            },
                        }}
                    >
                        <Tab disableRipple label="To Do"  />
                        <Tab disableRipple label="Rejected By Me" />
                        <Tab disableRipple label="Rejected By Auditor"/>
                    </Tabs> */}
                <Grid item xs={12} mb={3}>
                    <Grid
                        display="flex"
                    >
                        <FXButton
                            label="To Do"
                            onClick={() => handleTabChange("activeToDo")}
                            disabled={tabActive.activeToDo}
                        />
    
                        <FXButton
                            label="Rejected By Me"
                            onClick={() => handleTabChange("rejectedByMe")}
                            disabled={tabActive.rejectedByMe}
                        />
    
                        <FXButton
                            label="Rejected By Auditor"
                            onClick={() => handleTabChange("rejectedByAuditor")}
                            disabled={tabActive.rejectedByAuditor}
                        />
    
                    </Grid>
                </Grid>
            </Grid>
    
            <Grid item xs={12}>
                <>
                    <Stack 
                        direction="column" 
                        width="100%" 
                        marginBottom="20px"
                        minHeight="430px"
                    >
                        {
                            (tabActive.activeToDo? pendingCheckerEntryItems:pendingRejectEntryItems).map((pendingCheckerEntryItem) => {
                                const {
                                    clientCode,
                                    clientName,
                                    // clientType,
                                    classCode,
                                    className,
                                    createdBy,
                                    createdOn,
                                    fundCode,
                                    fundName,
                                    planCode,
                                    planName,
                                    // id,
                                    rejectRemarks
                                } = pendingCheckerEntryItem;
    
                                const toDoData = [
                                    {
                                        "dataPartOne": clientCode,
                                        "dataPartTwo": clientName
                                    },
                                    {
                                        "dataPartOne": fundCode,
                                        "dataPartTwo": fundName
                                    },
                                    {
                                        "dataPartOne": planCode,
                                        "dataPartTwo": planName
                                    },
                                    {
                                        "dataPartOne": classCode,
                                        "dataPartTwo": className,
                                    },
                                ];
                                const rejectedData = !tabActive["activeToDo"] 
                                    ? [
                                        {
                                            "dataPartOne": `Remarks: ${rejectRemarks}`
                                        }
                                    ] : [];
                            
                                return (
                                    <Box key={nanoid()}>
                                        <PendingCheckerEntryItemCard
                                            createdBy={createdBy}
                                            creationDate={createdOn}
                                            data={toDoData}
                                            remarksData={rejectedData}
                                            onClick={() =>tabActive["rejectedByMe"]? "": handleCardOnClick(clientCode, clientName, classCode, fundCode,  fundName, planCode, planName)}
                                        />
                                    </Box>
                                );
                            })
                        }
                    </Stack>
    
                    {(tabActive["activeToDo"] && pendingCheckerEntryItems.length>0 || !tabActive["activeToDo"] && pendingRejectEntryItems.length>0) && <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                        <FormControl sx={{ "minWidth": "50px"}}>
                            <Stack direction="row" spacing={1} alignItems="center">
                                <Select
                                    value={itemCountPerPage.toString()}
                                    style={{ "height": "30px" }}                        
                                    onChange={(event: SelectChangeEvent) => {
                                        setItemCountPerPage(parseInt(event.target.value));
                                    }}
                                    displayEmpty
                                    inputProps={{ "aria-label": "Without label" }}
                                >
                                    <MenuItem value={5}>5</MenuItem>
                                    <MenuItem value={10}>10</MenuItem>
                                    <MenuItem value={15}>15</MenuItem>
                                </Select>
                            
                                <Typography variant="paginationRow">Rows per page</Typography>                    
                            </Stack>
                        </FormControl>
    
                        <Box></Box>
                    
                        <StyledPagination 
                            count={pageCount} 
                            variant="outlined" 
                            shape="rounded" 
                            page={page} 
                            onChange={handleChange}
                        />
                    </Stack>}
                </>
            </Grid>
        </Grid>
    );
};
    
export default CheckerClassMasterList;
