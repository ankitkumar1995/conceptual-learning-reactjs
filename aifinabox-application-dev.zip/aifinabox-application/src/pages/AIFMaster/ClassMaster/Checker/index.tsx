import CheckerClassMasterList from "./CheckerClassMasterList";
import CheckerClasssMasterForm from "./CheckerClassMasterForm";
import PendingCheckerEntryItems from "./PendingCheckerEntryItems";
import { RootState } from "../../../../redux/store";
import initialClassMasterDetailsFormDispatchActionProvider from "../../../../redux/AifMaster/ClassMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerClassMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .classMasterState
                .checkerForm
                .clientCode
    );

    const { 
        setClientCode,
    } = initialClassMasterDetailsFormDispatchActionProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);
    
    return (
        <>
            {
                (clientCode.length === 0) 
                    ? <CheckerClassMasterList/>
                    : <CheckerClasssMasterForm/>
            }
        </>
    );
};

export default CheckerClassMasterPage;
