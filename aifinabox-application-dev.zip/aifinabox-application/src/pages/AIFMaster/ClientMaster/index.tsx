import CheckerClientMasterPage from "./Checker";
import MakerClientMasterPage from "./Maker";
import NigoClientMasterForm from "./Nigo/NigoClientMasterForm";
import { RootState } from "../../../redux/store";
import { useSelector } from "react-redux";

const ClientMasterPage = () => {
    const nigoRaised = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .pageContext
                .nigoRaised
    );

    const authRole = useSelector(
        (state: RootState) =>
            state
                .authorizationState
                .authRole
    );

    return (
        <>
            {
                (authRole === "Maker") &&
                <MakerClientMasterPage/>
            }

            {
                (authRole === "Checker" && !nigoRaised) &&
                <CheckerClientMasterPage/>
            }

            {
                (authRole === "Checker" && nigoRaised) &&
                <NigoClientMasterForm/>
            }
        </>
    );
};

export default ClientMasterPage;

