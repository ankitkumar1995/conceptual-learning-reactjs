import CheckerClientMasterForm from "./CheckerClientMasterForm";
import PendingCheckerEntryItems from "./PendingCheckerEntryItems";
import { RootState } from "../../../../redux/store";
import clientMasterDetailsFormDispatchActionsProvider from "../../../../redux/AifMaster/ClientMaster/Checker/dispatchActionsProvider";
import { useEffect } from "react";
import { useSelector } from "react-redux";

const CheckerClientMasterPage = () => {
    const clientCode = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .checkerForm
                .clientCode
    );

    const { 
        setClientCode
    } = clientMasterDetailsFormDispatchActionsProvider();

    useEffect(()=>{
        setClientCode("");
    },[]);

    return (
        <>
            {
                (clientCode.length === 0)
                    ? <PendingCheckerEntryItems/>
                    : <CheckerClientMasterForm/>
            }
        </>
    );
};

export default CheckerClientMasterPage;

