import {
    Box,
    FormControl,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import useFetchToDoQueue, { PendingCheckerItem } from "../../../../../hooks/api/useFetchToDoQueue";

import PendingCheckerEntryItemCard from "../../../components/PendingCheckerEntryItemCard";
import { RootState } from "../../../../../redux/store";
import { StyledPagination } from "./PaginationStyles";
import clientMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Checker/dispatchActionsProvider";
import clientMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Nigo/dispatchActionsProvider";
import updateDispatchActionProvider from "../../../../../redux/AifMaster/ClientMaster/Update/dispatchActionProvider";
import useFetchClientMaster from "../../../../../hooks/api/useFetchClientMaster";
import { useSelector } from "react-redux";

const PendingCheckerEntryItems = () => {
    const [pendingCheckerEntryItems, setPendingCheckerEntryItems] = useState<PendingCheckerItem[]>([]);
    const [page, setPage] = useState(1);
    const [pageCount, setPageCount] = useState(1);
    const [itemCountPerPage,setItemCountPerPage] = useState(5);

    const { 
        setClientCode,
        setClientMasterCheckerStateFromMakerEntry,
    } = clientMasterDetailsFormDispatchActionsProvider();

    const { setMakerData } = clientMasterNigoDetailsFormDispatchActionsProvider();

    const { setIsUpdate } = updateDispatchActionProvider();

    const fetchCheckerQueue = useFetchToDoQueue();
    const fetchClientMaster = useFetchClientMaster();

    const handleChange = (
        event: React.ChangeEvent<unknown>,
        pageCurrent: number
    ) => {
        setPage(pageCurrent);
    };

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const handleCardOnClick = (clientCode: string, clientName: string) => {
        fetchClientMaster(clientCode, "0", userId)
            .then((clientMaster) => {
                const {
                    "clientMasterState": clientMasterMakerState,
                    "clientMasterUpdateState": clientMasterMakerUpdateState,
                } = clientMaster;
                setClientMasterCheckerStateFromMakerEntry(clientMasterMakerState, clientMasterMakerUpdateState);
                setIsUpdate(clientMasterMakerUpdateState);
                setClientCode(clientCode);
                setMakerData(clientMasterMakerState);
            });
    };

    useEffect(() => {
        fetchCheckerQueue(itemCountPerPage, page-1, "client_master", "C",userId)
            .then((result) => {
                const {
                    checkerQueue,
                    pendingCheckerItemCount,
                } = result;

                setPendingCheckerEntryItems(checkerQueue);
                setPageCount(Math.ceil(pendingCheckerItemCount / itemCountPerPage));
            });
    }, [page,itemCountPerPage,pageCount]);

    return (
        <>
            <Stack
                paddingBottom="20px"
            >
                <Typography variant="toDoLabel">
                    To Do
                </Typography>
            </Stack>

            <Stack 
                direction="column" 
                width="100%" 
                marginBottom="20px"
                minHeight="430px"
            >
                {
                    pendingCheckerEntryItems.map((pendingCheckerEntryItem) => {
                        const {
                            clientCode,
                            clientName,
                            // clientType,
                            createdBy,
                            createdOn,
                            id,
                        } = pendingCheckerEntryItem;

                        return (
                            <Box key={id}>
                                <PendingCheckerEntryItemCard
                                    createdBy={createdBy}
                                    creationDate={createdOn}
                                    data={[
                                        {
                                            "dataPartOne": clientCode,
                                            "dataPartTwo": clientName
                                        }
                                    ]}
                                    onClick={() => handleCardOnClick(clientCode, clientName)}
                                />
                            </Box>
                        );
                    })
                }
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center" mt={5}> 
                <FormControl sx={{ "minWidth": "50px"}}>
                    <Stack direction="row" spacing={1} alignItems="center">
                        <Select
                            value={itemCountPerPage.toString()}
                            style={{ "height": "30px" }}                        
                            onChange={(event: SelectChangeEvent) => {
                                setItemCountPerPage(parseInt(event.target.value));
                                setPage(1);
                            }}
                            displayEmpty
                            inputProps={{ "aria-label": "Without label" }}
                        >
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={15}>15</MenuItem>
                        </Select>
                        
                        <Typography variant="paginationRow">Rows per page</Typography>
                    </Stack>
                </FormControl>

                <StyledPagination 
                    count={pageCount} 
                    variant="outlined" 
                    shape="rounded" 
                    page={page} 
                    onChange={handleChange}
                />
            </Stack>
        </>
    );
};

export default PendingCheckerEntryItems;
