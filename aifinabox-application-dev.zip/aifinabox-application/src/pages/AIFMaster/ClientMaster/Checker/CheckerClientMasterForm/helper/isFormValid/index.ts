import { FormErrorState } from "../initializeFormErrorState";

function isFormValid(formErrorState: FormErrorState) {
    return !(
        formErrorState.address1.isError ||
        formErrorState.address2.isError ||
        formErrorState.address3.isError ||
        formErrorState.agreementDate.isError ||
        formErrorState.city.isError ||
        formErrorState.ckycInstitutionCode.isError ||
        formErrorState.ckycUserId.isError ||
        formErrorState.ckycUserName.isError ||
        formErrorState.ckycPassword.isError ||
        formErrorState.clientCode.isError ||
        formErrorState.country.isError ||
        formErrorState.domicile.isError ||
        formErrorState.kraName.isError ||
        formErrorState.kraPassword.isError ||
        formErrorState.kraPosCode.isError ||
        formErrorState.kraUserId.isError ||
        formErrorState.kraUserName.isError ||
        formErrorState.landlineNumber.isError ||
        formErrorState.legalEntityIdentificationCode.isError ||
        formErrorState.legalEntityIdentificationCodeValidity.isError ||
        formErrorState.logo.isError ||
        formErrorState.name.isError ||
        formErrorState.permanentAccountNumber.isError ||
        formErrorState.pin.isError ||
        formErrorState.state.isError ||
        formErrorState.taxIdentificationNumber.isError ||
        formErrorState.clientType.isError
    );
}

export default isFormValid;
