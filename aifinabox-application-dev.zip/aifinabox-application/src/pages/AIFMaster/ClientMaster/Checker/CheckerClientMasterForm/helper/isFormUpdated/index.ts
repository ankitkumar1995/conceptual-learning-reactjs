import { UpdateState } from "../initializeUpdateState";

function isFormUpdated(
    updateState: UpdateState, 
    updateExistingFlag: "0" | "1"
) {
    if (updateExistingFlag === "0")
        return false;

    return !(
        updateState.address1 ||
        updateState.address2 ||
        updateState.address3 ||
        updateState.agreementDate ||
        updateState.city ||
        updateState.ckycInstitutionCode ||
        updateState.ckycPassword ||
        updateState.ckycUserId ||
        updateState.ckycUserName ||
        updateState.name ||
        updateState.country ||
        updateState.domicile ||
        updateState.landlineNumber ||
        updateState.legalEntityIdentificationCodeValidity ||
        updateState.kraName ||
        updateState.kraPassword ||
        updateState.kraPosCode ||
        updateState.kraUserId ||
        updateState.kraUserName ||
        updateState.permanentAccountNumber ||
        updateState.pin ||
        updateState.state ||
        updateState.taxIdentificationNumber ||
        updateState.clientType
    );
} 

export default isFormUpdated;
