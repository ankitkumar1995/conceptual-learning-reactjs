import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Box,
    Button,
    Grid,
    IconButton,
    Stack,
    Typography
} from "@mui/material";
import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../interfaces/FieldValidation.types";

import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useDispatch, useSelector } from "react-redux";

import { useEffect, useState } from "react";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import BackArrowIcon from "../../../../../icons/BackArrowIcon";
import { 
    UpdateState as CheckerUpdateState 
} from "../../../../../redux/AifMaster/ClientMaster/Update/initialState";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXFileInput from "../../../../../components/FXFileInput";
import FXInput from "../../../../../components/FXInput";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { Field } from "./interfaces/field.types";
import { RootState } from "../../../../../redux/store";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import clientMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Checker/dispatchActionsProvider";
import clientMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Nigo/dispatchActionsProvider";
import clientMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/PageContext/dispatchActionsProvider";
import dayjs from "dayjs";
import { getNigoData } from "../../Nigo/NigoClientMasterForm/helpers/getNigoData";
import isFormComplete from "./helper/isFormComplete";
import isFormValid from "./helper/isFormValid";
import onBlurContactNumberValidator from "../../../../../validators/onBlurValidator/onBlurContactNumberValidator";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import onBlurPanValidator from "../../../../../validators/onBlurValidator/onBlurPanValidator";
import onBlurPasswordValidator from "../../../../../validators/onBlurValidator/onBlurPasswordValidator";
import onBlurPincodeValidator from "../../../../../validators/onBlurValidator/onBlurPincodeValidator";
import { setOpenBackdrop } from "../../../../../redux/ApplicationContext/reducer";
import useFormRef from "./hooks/useFormRef";
import { useNavigate } from "react-router-dom";
import usePostClientMaster from "../../../../../hooks/api/usePostClientMaster";

const CheckerClientMasterForm = () => {
    const formRef = useFormRef();
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [showCkycPassword, setShowCkycPassword] = useState(false);
    const [showKraPassword, setShowKraPassword] = useState(false);
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState());
    const [isDataMatched, setIsDataMatched] = useState(false);
    const clientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .checkerForm
    );

    const nigoClientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .nigoForm
    );

    const updateState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .updateState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        clientTypeMenuItems,
        countryNameMenuItems,
        kraNameMenuItems
    } = selectInputMenuItems;

    const {
        address1,
        address2,
        address3,
        agreementDate,
        city,
        ckycPassword,
        ckycUserName,
        clientCode,
        country,
        domicile,
        kraName,
        kraPassword,
        kraUserName,
        landlineNumber,
        legalEntityIdentificationCode,
        legalEntityIdentificationCodeValidity,
        logoFile,
        logoFileS3SignedURL,
        pin,
        permanentAccountNumber,
        state,
        clientType,
        taxIdentificationNumber,
        kraUserId,
        kraPosCode,
        ckycUserId,
        ckycInstitutionCode,
        name,
    } = clientMasterFormState;

    const {
        clearCriticalFieldsCheckerEntry,
        clearState,
        setAddress1,
        setAddress2,
        setAddress3,
        setAgreementDate,
        setCity,
        setCkycInstitutionCode,
        setCkycPassword,
        setCkycUserId,
        setCkycUserName,
        setCountry,
        setDomicile,
        setKraName,
        setKraPassword,
        setKraPosCode,
        setKraUserId,
        setKraUserName,
        setLandlineNumber,
        setLegalEntityIdentificationCode,
        setLegalEntityIdentificationCodeValidity,
        setLogoFile,
        setLogoFileS3Key,
        setLogoFileS3SignedURL,
        setName,
        setPermanentAccountNumber,
        setPin,
        setState,
        setTaxIdentificationNumber,
        setClientCode,
        setClientType
    } = clientMasterDetailsFormDispatchActionsProvider();

    const {
        setCheckerData,
        setNigoMetaData,
    } = clientMasterNigoDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised,
    } = clientMasterPageContextDispatchActionsProvider();

    const postClientMaster = usePostClientMaster();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        clearState();
    };

    const handleClearCriticalFields = (updateState: CheckerUpdateState) => { 
        if (updateState.updateFlag === "0" || (updateState.name && updateState.updateFlag === "1")) {       
            if (formRef["name"].current)
                (formRef["name"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.permanentAccountNumber && updateState.updateFlag === "1")) {
            if (formRef["permanentAccountNumber"].current)
                (formRef["permanentAccountNumber"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.taxIdentificationNumber && updateState.updateFlag === "1")) {
            if (formRef["taxIdentificationNumber"].current)
                (formRef["taxIdentificationNumber"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.agreementDate && updateState.updateFlag === "1")) {
            if (formRef["agreementDate"].current)
                (formRef["agreementDate"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.legalEntityIdentificationCodeValidity && updateState.updateFlag === "1")) {
            if (formRef["legalEntityIdentificationCodeValidity"].current)
                (formRef["legalEntityIdentificationCodeValidity"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.kraUserId && updateState.updateFlag === "1")) {
            if (formRef["kraUserId"].current)
                (formRef["kraUserId"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.kraPosCode && updateState.updateFlag === "1")) {
            if (formRef["kraPosCode"].current)
                (formRef["kraPosCode"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.ckycUserId && updateState.updateFlag === "1")) {
            if (formRef["ckycUserId"].current)
                (formRef["ckycUserId"].current as HTMLInputElement).value = "";
        }

        if (updateState.updateFlag === "0" || (updateState.ckycInstitutionCode && updateState.updateFlag === "1")) {
            if (formRef["ckycInstitutionCode"].current)
                (formRef["ckycInstitutionCode"].current as HTMLInputElement).value = "";
        }

        clearCriticalFieldsCheckerEntry(updateState);
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    useEffect(()=>{
        if (JSON.stringify(nigoClientMasterFormState.makerData) === JSON.stringify(clientMasterFormState)){
            setIsDataMatched(true);
        }
    },[clientMasterFormState]);

    const handleFormSubmit = () => {
        postClientMaster(clientMasterFormState, `${firstName} ${lastName}`, "0", userId, "C", isUpdate)
            .then(() => setAlertSnackbarContext({
                "description": `${isDataMatched?"Data Saved Successfully":`Checker Entry Done against Client Code ${clientCode}`}`,
                "open": true,
                "severity": "success",
                "title": "Checker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Checker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Checker Entry Failed",
                });
            });
    };

    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        <Box 
                            alignItems="center"
                            display="flex"
                        >
                            <IconButton 
                                onClick={() => {
                                    handleClearState();
                                    setClientCode("");
                                }}
                            >
                                <BackArrowIcon/>
                            </IconButton>

                            <Typography variant="formHeading">
                                Client Master
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Client Code"
                        required
                        readOnly
                        disabled
                        value={clientCode}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Name"
                        required
                        capitalizeFirstLetter
                        forbidTo="singleSpace"
                        maxLength={256}
                        disabled={updateState.updateFlag === "1" && !(updateState.name)}
                        defaultValue={name}
                        inputRef={formRef.name}
                        onBlur={() => handleInputFieldChange("name", setName)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "name")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "name")}
                        error={formErrorState.name.isError}
                        helperText={formErrorState.name.helperText}
                    />   
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Domicile"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.domicile)}
                        value={domicile}
                        onValueChange={(value) => { 
                            setDomicile(value);
                            setFormErrorState({
                                ...formErrorState,
                                "ckycInstitutionCode": initializeFieldValidation(),
                                "ckycPassword": initializeFieldValidation(),
                                "ckycUserId": initializeFieldValidation(),
                                "ckycUserName": initializeFieldValidation(),
                                "kraPassword": initializeFieldValidation(),
                                "kraPosCode": initializeFieldValidation(),
                                "kraUserId": initializeFieldValidation(),
                                "kraUserName": initializeFieldValidation(),
                                "permanentAccountNumber": initializeFieldValidation(),
                                "pin": initializeFieldValidation(),
                                "taxIdentificationNumber": initializeFieldValidation(),
                            });
                        }}
                        menuItems={countryNameMenuItems}
                    />
                </Grid>
                
                <Grid item xs={3}>
                    <FXInput
                        label="Permanent Account Number"
                        required = { domicile === "India" }
                        disabled={
                            (domicile !== "India") ||
                            (
                                (updateState.updateFlag === "1") &&
                                !(updateState.permanentAccountNumber)
                            )
                        }
                        maxLength={10}
                        autoCapitalize
                        defaultValue={permanentAccountNumber}
                        inputRef={formRef.permanentAccountNumber}
                        onBlur={() => handleInputFieldChange("permanentAccountNumber", setPermanentAccountNumber)}
                        onBlurValidator={onBlurPanValidator}
                        validatorOptions={{}}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "permanentAccountNumber")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "permanentAccountNumber")}
                        error={formErrorState.permanentAccountNumber.isError}
                        helperText={formErrorState.permanentAccountNumber.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Tax Identification Number"
                        required = { domicile != "India" }
                        disabled={
                            (domicile === "India") ||
                            (
                                (updateState.updateFlag === "1") &&
                                !(updateState.taxIdentificationNumber)
                            )
                        }
                        forbidTo="alphanumeric"
                        autoCapitalize
                        maxLength={25}
                        defaultValue={taxIdentificationNumber}
                        inputRef={formRef.taxIdentificationNumber}
                        onBlur={() => handleInputFieldChange("taxIdentificationNumber", setTaxIdentificationNumber)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "taxIdentificationNumber")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "taxIdentificationNumber")}
                        error={formErrorState.taxIdentificationNumber.isError}
                        helperText={formErrorState.taxIdentificationNumber.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Type"
                        disabled={updateState.updateFlag === "1" && !(updateState.clientType)}
                        value={clientType}
                        onValueChange={setClientType}
                        menuItems={clientTypeMenuItems}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 1"
                        required
                        disabled={updateState.updateFlag === "1" && !(updateState.address1)}
                        defaultValue={address1}
                        maxLength={256}
                        inputRef={formRef.address1}
                        onBlur={() => handleInputFieldChange("address1", setAddress1)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "address1")}
                        error={formErrorState.address1.isError}
                        helperText={formErrorState.address1.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 2"
                        disabled={updateState.updateFlag === "1" && !(updateState.address2)}
                        defaultValue={address2}
                        maxLength={256}
                        inputRef={formRef.address2}
                        onBlur={() => handleInputFieldChange("address2", setAddress2)}
                        error={formErrorState.address2.isError}
                        helperText={formErrorState.address2.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 3"
                        disabled={updateState.updateFlag === "1" && !(updateState.address3)}
                        defaultValue={address3}
                        maxLength={256}
                        inputRef={formRef.address3}
                        onBlur={() => handleInputFieldChange("address3", setAddress3)}
                        error={formErrorState.address3.isError}
                        helperText={formErrorState.address3.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="PIN"
                        disabled={updateState.updateFlag === "1" && !(updateState.pin)}
                        required = { domicile === "India" }
                        defaultValue={pin}
                        forbidTo="alphanumeric"
                        autoCapitalize
                        inputRef={formRef.pin}
                        onBlur={() => handleInputFieldChange("pin", setPin)}
                        onBlurValidator={onBlurPincodeValidator}
                        validatorOptions={{ "domicile": domicile }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "pin")}
                        error={formErrorState.pin.isError}
                        helperText={formErrorState.pin.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="City"
                        disabled={updateState.updateFlag === "1" && !(updateState.city)}
                        required
                        defaultValue={city}
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.city}
                        onBlur={() => handleInputFieldChange("city", setCity)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "city")}
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="State"
                        disabled={updateState.updateFlag === "1" && !(updateState.state)}
                        required
                        defaultValue={state}
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.state}
                        onBlur={() => handleInputFieldChange("state", setState)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "state")}
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Country"
                        disabled={updateState.updateFlag === "1" && !(updateState.country)}
                        required
                        defaultValue={country}
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.country}
                        onBlur={() => handleInputFieldChange("country", setCountry)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "country")}
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Landline Number"
                        disabled={updateState.updateFlag === "1" && !(updateState.landlineNumber)}
                        forbidTo="numbers"
                        maxLength={20}
                        defaultValue={landlineNumber}
                        inputRef={formRef.landlineNumber}
                        onBlur={() => handleInputFieldChange("landlineNumber", setLandlineNumber)}
                        onBlurValidator={onBlurContactNumberValidator}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "landlineNumber") }
                        error={formErrorState.landlineNumber.isError}
                        helperText={formErrorState.landlineNumber.helperText}
                        validatorOptions={{}}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Agreement Date"
                        disabled={updateState.updateFlag === "1" && !(updateState.agreementDate)}
                        required
                        value={agreementDate}
                        disableFuture
                        onValueChange={(value) => {
                            handleFieldErrorChange(initializeFieldValidation(), "agreementDate");
                            setAgreementDate(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": true, 
                            "disablePast": false, 
                            "disablePresent": false 
                        }}                        
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "agreementDate")}
                        error={formErrorState.agreementDate.isError}
                        helperText={formErrorState.agreementDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Legal Entity Identification Code"
                        required
                        forbidTo="alphanumeric"
                        autoCapitalize
                        maxLength={20}
                        disabled={updateState.updateFlag === "1"}
                        defaultValue={legalEntityIdentificationCode}
                        inputRef={formRef.legalEntityIdentificationCode}
                        onBlur={() => handleInputFieldChange("legalEntityIdentificationCode", setLegalEntityIdentificationCode)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "legalEntityIdentificationCode")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "legalEntityIdentificationCode")}
                        error={formErrorState.legalEntityIdentificationCode.isError}
                        helperText={formErrorState.legalEntityIdentificationCode.helperText}
                    />
                </Grid>

                <Grid item xs={5}>
                    <FXDateInput
                        label="Legal Entity Identification Code Validity"
                        disabled={updateState.updateFlag === "1" && !(updateState.legalEntityIdentificationCodeValidity)}
                        required
                        disablePast
                        shouldDisableDate={(date) => 
                            date.isSame(dayjs(), "day")
                        }
                        value={legalEntityIdentificationCodeValidity}
                        onValueChange={(value) => {
                            handleFieldErrorChange(initializeFieldValidation(), "legalEntityIdentificationCodeValidity");
                            setLegalEntityIdentificationCodeValidity(value);
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": false, 
                            "disablePast": true, 
                            "disablePresent": true, 
                        }}                        
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "legalEntityIdentificationCodeValidity")}
                        error={formErrorState.legalEntityIdentificationCodeValidity.isError}
                        helperText={formErrorState.legalEntityIdentificationCodeValidity.helperText}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXFileInput
                        disabled
                        label="Logo"
                        onFileUpload={() => {}}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "logo")}                        error={formErrorState.logo.isError}
                        helperText={formErrorState.logo.helperText}
                    />
                </Grid>

                {
                    domicile === "India" &&
                <>
                    <Grid item xs={12}>
                        <Typography variant="formSubHeading" display="flex">
                            KRA & CERSAI Details
                        </Typography>
                    </Grid>

                    <Grid item xs={3}>
                        <FXSelectInput
                            label="KRA Name"
                            disabled={updateState.updateFlag === "1" && !(updateState.kraName)}
                            value={kraName}
                            onValueChange={setKraName}
                            menuItems={kraNameMenuItems}
                        />
                    </Grid>

                    <Grid item xs={9}>
                        <></>
                    </Grid>
                
                    <Grid item xs={3}>
                        <FXInput
                            label="KRA User ID"
                            disabled={updateState.updateFlag === "1" && !(updateState.kraUserId)}
                            forbidTo="user-id"
                            maxLength={20}
                            defaultValue={kraUserId}
                            inputRef={formRef.kraUserId}
                            onBlur={() => handleInputFieldChange("kraUserId", setKraUserId)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraUserId")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraUserId")}
                            error={formErrorState.kraUserId.isError}
                            helperText={formErrorState.kraUserId.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA User Name"
                            disabled={updateState.updateFlag === "1" && !(updateState.kraUserName)}
                            defaultValue={kraUserName}
                            forbidTo="namespaceapostrophe"
                            maxLength={20}
                            inputRef={formRef.kraUserName}
                            onBlur={() => handleInputFieldChange("kraUserName", setKraUserName)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraUserName")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraUserName")}
                            error={formErrorState.kraUserName.isError}
                            helperText={formErrorState.kraUserName.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA Password"
                            disabled={updateState.updateFlag === "1" && !(updateState.kraPassword)}
                            defaultValue={kraPassword}
                            maxLength={20}
                            inputRef={formRef.kraPassword}
                            onBlur={() => handleInputFieldChange("kraPassword", setKraPassword)}
                            onBlurValidator={onBlurPasswordValidator}
                            validatorOptions={{}}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraPassword")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraPassword")}
                            error={formErrorState.kraPassword.isError}
                            helperText={formErrorState.kraPassword.helperText}
                            type={showKraPassword ? "string" : "password"}
                            endAdornment={
                                <IconButton
                                    disableRipple
                                    onMouseDown={() => setShowKraPassword(true)}
                                    onMouseUp={() => setShowKraPassword(false)}
                                >
                                    {
                                        (showKraPassword)
                                            ? <VisibilityIcon/>
                                            : <VisibilityOffIcon/>
                                    }
                                </IconButton>
                            }
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA POS Code"
                            disabled={updateState.updateFlag === "1" && !(updateState.kraPosCode)}
                            forbidTo="numbers"
                            maxLength={15}
                            defaultValue={kraPosCode}
                            inputRef={formRef.kraPosCode}
                            onBlur={() => handleInputFieldChange("kraPosCode", setKraPosCode)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraPosCode")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraPosCode")}
                            error={formErrorState.kraPosCode.isError}
                            helperText={formErrorState.kraPosCode.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC User ID"
                            disabled={updateState.updateFlag === "1" && !(updateState.ckycUserId)}
                            forbidTo="user-id"
                            maxLength={20}
                            defaultValue={ckycUserId}
                            inputRef={formRef.ckycUserId}
                            onBlur={() => handleInputFieldChange("ckycUserId", setCkycUserId)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycUserId")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycUserId")}
                            error={formErrorState.ckycUserId.isError}
                            helperText={formErrorState.ckycUserId.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC User Name"
                            disabled={updateState.updateFlag === "1" && !(updateState.ckycUserName)}
                            defaultValue={ckycUserName}
                            forbidTo="namespaceapostrophe"
                            maxLength={20}
                            inputRef={formRef.ckycUserName}
                            onBlur={() => handleInputFieldChange("ckycUserName", setCkycUserName)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycUserName")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycUserName")}
                            error={formErrorState.ckycUserName.isError}
                            helperText={formErrorState.ckycUserName.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC Password"
                            disabled={updateState.updateFlag === "1" && !(updateState.ckycPassword)}
                            defaultValue={ckycPassword}
                            maxLength={20}
                            inputRef={formRef.ckycPassword}
                            onBlur={() => handleInputFieldChange("ckycPassword", setCkycPassword)}
                            onBlurValidator={onBlurPasswordValidator}
                            validatorOptions={{}}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycPassword")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycPassword")}
                            error={formErrorState.ckycPassword.isError}
                            helperText={formErrorState.ckycPassword.helperText}
                            type={showCkycPassword ? "string" : "password"}
                            endAdornment={
                                <IconButton
                                    disableRipple
                                    onMouseDown={() => setShowCkycPassword(true)}
                                    onMouseUp={() => setShowCkycPassword(false)}
                                >
                                    {
                                        (showCkycPassword)
                                            ? <VisibilityIcon/>
                                            : <VisibilityOffIcon/>
                                    }
                                </IconButton>
                            }
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC Institution Code"
                            disabled={updateState.updateFlag === "1" && !(updateState.ckycInstitutionCode)}
                            maxLength={10}
                            forbidTo="alphanumeric"
                            autoCapitalize
                            defaultValue={ckycInstitutionCode}
                            inputRef={formRef.ckycInstitutionCode}
                            onBlur={() => handleInputFieldChange("ckycInstitutionCode", setCkycInstitutionCode)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycInstitutionCode")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycInstitutionCode")}
                            error={formErrorState.ckycInstitutionCode.isError}
                            helperText={formErrorState.ckycInstitutionCode.helperText}
                        />
                    </Grid>
                </>
                }

                <Grid item xs={6}>
                    <FXButton 
                        disableRipple
                        label="Clear" 
                        buttonVariant="normal" 
                        fullWidth
                        onClick={() => handleClearCriticalFields(updateState)}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton
                        buttonVariant="submit"
                        disableRipple
                        disabled={
                            alertSnackbarContext.open ||
                            !(isFormComplete(clientMasterFormState)) ||
                            !(isFormValid(formErrorState))
                        }
                        endIcon={<ArrowForwardIosIcon/>}
                        fullWidth
                        label="Submit"
                        onClick={() => {
                            const nigoData = getNigoData(nigoClientMasterFormState.makerData, clientMasterFormState);
        
                            if (nigoData.length !== 0) {
                                setNigoMetaData(nigoData);
                                setCheckerData(clientMasterFormState);
                                setNigoRaised(true);
                            }
                            else {
                                handleFormSubmit();
                            }
                        }}   
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success")
                        handleClearState();
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default CheckerClientMasterForm;
