import { 
    FieldValidation, 
    initializeFieldValidation 
} from "../../../../../../../interfaces/FieldValidation.types";

import { Field } from "../../interfaces/field.types";

export type FormErrorState = { 
    [fieldName in Field]:  FieldValidation
};

function initializeFormErrorState(): FormErrorState {
    return (
        {
            "address1": initializeFieldValidation(),
            "address2": initializeFieldValidation(),
            "address3": initializeFieldValidation(),
            "agreementDate": initializeFieldValidation(),
            "city": initializeFieldValidation(),
            "ckycInstitutionCode": initializeFieldValidation(),
            "ckycPassword": initializeFieldValidation(),
            "ckycUserId": initializeFieldValidation(),
            "ckycUserName": initializeFieldValidation(),
            "clientCode": initializeFieldValidation(),
            "clientType": initializeFieldValidation(),
            "country": initializeFieldValidation(),
            "domicile": initializeFieldValidation(),
            "kraName": initializeFieldValidation(),
            "kraPassword": initializeFieldValidation(),
            "kraPosCode": initializeFieldValidation(),
            "kraUserId": initializeFieldValidation(),
            "kraUserName": initializeFieldValidation(),
            "landlineNumber": initializeFieldValidation(),
            "legalEntityIdentificationCode": initializeFieldValidation(),
            "legalEntityIdentificationCodeValidity": initializeFieldValidation(),
            "logo": initializeFieldValidation(),
            "name": initializeFieldValidation(),
            "permanentAccountNumber": initializeFieldValidation(),
            "pin": initializeFieldValidation(),
            "state": initializeFieldValidation(),
            "taxIdentificationNumber": initializeFieldValidation(),
        }
    );
}

export default initializeFormErrorState;
