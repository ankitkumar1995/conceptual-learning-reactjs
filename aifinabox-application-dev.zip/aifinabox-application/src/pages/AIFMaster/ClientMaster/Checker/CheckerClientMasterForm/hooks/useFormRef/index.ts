import { RefObject, useRef } from "react";
import { Field } from "../../interfaces/field.types";

interface FormRef {
    [key: string]: RefObject<HTMLInputElement>;
};

function useFormRef(): FormRef {
    const formRef: { 
        [fieldName in Field]:  RefObject<HTMLInputElement>
    } = {
        "address1": useRef<HTMLInputElement>(null),
        "address2": useRef<HTMLInputElement>(null),
        "address3": useRef<HTMLInputElement>(null),
        "agreementDate": useRef<HTMLInputElement>(null),
        "city": useRef<HTMLInputElement>(null),
        "ckycInstitutionCode": useRef<HTMLInputElement>(null),
        "ckycPassword": useRef<HTMLInputElement>(null),
        "ckycUserId": useRef<HTMLInputElement>(null),
        "ckycUserName": useRef<HTMLInputElement>(null),
        "clientCode": useRef<HTMLInputElement>(null),
        "clientType": useRef<HTMLInputElement>(null),
        "country": useRef<HTMLInputElement>(null),
        "domicile": useRef<HTMLInputElement>(null),
        "kraName": useRef<HTMLInputElement>(null),
        "kraPassword": useRef<HTMLInputElement>(null),
        "kraPosCode": useRef<HTMLInputElement>(null),
        "kraUserId": useRef<HTMLInputElement>(null),
        "kraUserName": useRef<HTMLInputElement>(null),
        "landlineNumber": useRef<HTMLInputElement>(null),
        "legalEntityIdentificationCode": useRef<HTMLInputElement>(null),
        "legalEntityIdentificationCodeValidity": useRef<HTMLInputElement>(null),
        "logo": useRef<HTMLInputElement>(null),
        "name": useRef<HTMLInputElement>(null),
        "permanentAccountNumber": useRef<HTMLInputElement>(null),
        "pin": useRef<HTMLInputElement>(null),
        "state": useRef<HTMLInputElement>(null),
        "taxIdentificationNumber": useRef<HTMLInputElement>(null),
    };

    return formRef;
}

export default useFormRef;
