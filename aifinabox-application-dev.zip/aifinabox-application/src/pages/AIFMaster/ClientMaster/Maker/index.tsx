import MakerClientMasterForm from "./MakerClientMasterForm";

const MakerClientMasterPage = () => {
    return (
        <>
            <MakerClientMasterForm/>
        </>
    );
};

export default MakerClientMasterPage;

