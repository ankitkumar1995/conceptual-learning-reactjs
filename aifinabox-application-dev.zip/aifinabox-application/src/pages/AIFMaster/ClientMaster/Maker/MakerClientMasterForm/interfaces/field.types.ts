export type Field = 
    "address1" |
    "address2" |
    "address3" |
    "agreementDate" |
    "city" |
    "ckycInstitutionCode" |
    "ckycUserId" |
    "ckycUserName" |
    "ckycPassword" |
    "clientCode" |
    "country" |
    "domicile" |
    "landlineNumber" |
    "legalEntityIdentificationCode" |
    "legalEntityIdentificationCodeValidity" |
    "logo" |
    "kraName" |
    "kraPassword" |
    "kraPosCode" |
    "kraUserId" |
    "kraUserName" |
    "name" |
    "permanentAccountNumber" |
    "pin" |
    "state" |
    "taxIdentificationNumber" |
    "clientType";

export type UpdateField =
    "address1" |
    "address2" |
    "address3" |
    "agreementDate" |
    "city" |
    "ckycInstitutionCode" |
    "ckycUserId" |
    "ckycUserName" |
    "ckycPassword" |
    "name" |
    "country" |
    "domicile" |
    "kraName" |
    "kraPassword" |
    "kraPosCode" |
    "kraUserId" |
    "kraUserName" |
    "landlineNumber" |
    "legalEntityIdentificationCodeValidity" |
    "permanentAccountNumber" |
    "pin" |
    "state" |
    "taxIdentificationNumber" |
    "clientType";
