import { 
    ClientMasterDetails 
} from "../../../../../../../redux/AifMaster/ClientMaster/Maker/initialState";

function isFormComplete(clientMasterDetails: ClientMasterDetails): boolean {
    const {
        address1,
        address2,
        address3,
        agreementDate,
        city,
        ckycInstitutionCode,
        ckycPassword,
        ckycUserId,
        ckycUserName,
        clientCode,
        country,
        domicile,
        kraName,
        kraPassword,
        kraPosCode,
        kraUserId,
        kraUserName,
        landlineNumber,
        legalEntityIdentificationCode,
        legalEntityIdentificationCodeValidity,
        logoFile,
        name,
        permanentAccountNumber,
        pin,
        state,
        taxIdentificationNumber,
        clientType
    } = clientMasterDetails;

    const isaddress1Filled = ( address1.length !== 0 );
    const isAgreementDateFilled = ( 
        agreementDate !== null && 
        agreementDate.length !== 0 
    );
    const isClientCodeFilled = ( clientCode.length !== 0 );
    const isCityFilled = ( city.length !== 0 );
    const isCountryFilled = ( country.length !== 0 );
    const isDomicileFilled = ( domicile.length !== 0 );
    const isLegalEntityIdentificationCodeFilled = ( legalEntityIdentificationCode.length !== 0 );
    const isLegalEntityIdentificationCodeValidityFilled = ( 
        legalEntityIdentificationCodeValidity !== null && 
        legalEntityIdentificationCodeValidity?.length !== 0 
    );
    const isNameFilled = ( name.length !== 0 );
    const isPermanentAccountNumberFilled = (
        ( domicile === "India" )
            ? permanentAccountNumber.length !== 0
            : true
    );
    const isPinFilled = (
        ( domicile === "India" )
            ? pin.length !== 0
            : true
    );
    const isStateFilled = ( state.length !== 0 );
    const isTaxIdentificationNumberFileld = ( 
        ( domicile !== "India" )
            ? taxIdentificationNumber.length !== 0 
            : true        
    );

    return (
        isaddress1Filled &&
        isAgreementDateFilled &&
        isClientCodeFilled &&
        isCityFilled &&
        isCountryFilled &&
        isDomicileFilled &&
        isLegalEntityIdentificationCodeFilled &&
        isLegalEntityIdentificationCodeValidityFilled &&
        isNameFilled &&
        isPermanentAccountNumberFilled &&
        isPinFilled &&
        isStateFilled &&
        isTaxIdentificationNumberFileld 
    );
}

export default isFormComplete;
