import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import {
    Button,
    Grid,
    IconButton,
    Stack,
    Typography
} from "@mui/material";
import { 
    ClientMasterDetails, 
    initialClientMasterDetailsFormState 
} from "../../../../../redux/AifMaster/ClientMaster/Maker/initialState";
import { Field, UpdateField } from "./interfaces/field.types";
import {
    FieldValidation,
    initializeFieldValidation
} from "../../../../../interfaces/FieldValidation.types";
import {
    addNewButtonStyles,
    masterSetupClearButtonStyles,
    masterSetupSubmitButtonStyles,
    updateExistingButtonStyles
} from "../../../styles/ButtonStyles";
import initializeFormErrorState, { FormErrorState } from "./helper/initializeFormErrorState";
import initializeUpdateState, { UpdateState } from "./helper/initializeUpdateState";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";

import AddIcon from "../../../../../icons/AddIcon";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import EditIcon from "../../../../../icons/EditIcon";
import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import FXButton from "../../../../../components/FXButton";
import FXDateInput from "../../../../../components/FXDateInput";
import FXFileInput from "../../../../../components/FXFileInput";
import FXInput from "../../../../../components/FXInput";
import FXSelectInput from "../../../../../components/FXSelectInput";
import { RootState } from "../../../../../redux/store";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import axios from "axios";
import clientMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Maker/dispatchActionsProvider";
import dayjs from "dayjs";
import { initializeMenuItem } from "../../../../../interfaces/MenuItem.types";
import isFormComplete from "./helper/isFormComplete";
import isFormUpdated from "./helper/isFormUpdated";
import isFormValid from "./helper/isFormValid";
import onBlurContactNumberValidator from "../../../../../validators/onBlurValidator/onBlurContactNumberValidator";
import onBlurDateValidator from "../../../../../validators/onBlurValidator/onBlurDateValidator";
import onBlurPanValidator from "../../../../../validators/onBlurValidator/onBlurPanValidator";
import onBlurPasswordValidator from "../../../../../validators/onBlurValidator/onBlurPasswordValidator";
import onBlurPincodeValidator from "../../../../../validators/onBlurValidator/onBlurPincodeValidator";
import { setOpenBackdrop } from "../../../../../redux/ApplicationContext/reducer";
import useFetchClientCodes from "../../../../../hooks/api/useFetchClientCodes";
import useFetchClientMaster from "../../../../../hooks/api/useFetchClientMaster";
import useFormRef from "./hooks/useFormRef";
import useGenerateClientCode from "../../../../../hooks/api/useGenerateClientCode";
import usePostClientMaster from "../../../../../hooks/api/usePostClientMaster";

const MakerClientMasterForm = () => {
    const formRef = useFormRef();
    const dispatch = useDispatch();

    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [clientCodes, setClientCodes] = useState([initializeMenuItem()]);
    const [formErrorState, setFormErrorState] = useState<FormErrorState>(initializeFormErrorState);
    const [updateExistingFlag, setUpdateExistingFlag] = useState<"0" | "1">("0");
    const [showCkycPassword, setShowCkycPassword] = useState(false);
    const [showKraPassword, setShowKraPassword] = useState(false);
    const [clientMasterState, setClientMasterState] = useState<ClientMasterDetails>(initialClientMasterDetailsFormState);
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState());

    const clientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .makerForm
    );

    const selectInputMenuItems = useSelector(
        (state: RootState) => 
            state
                .selectInputMenuItemsState
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const {
        clientTypeMenuItems,
        countryNameMenuItems,
        kraNameMenuItems
    } = selectInputMenuItems;

    const {
        agreementDate,
        city,
        clientCode,
        domicile,
        kraName,
        legalEntityIdentificationCodeValidity,
        legalEntityIdentificationCode,
        logoFile,
        logoFileS3SignedURL,
        clientType,
    } = clientMasterFormState;

    const {
        clearState,
        setAddress1,
        setAddress2,
        setAddress3,
        setAgreementDate,
        setCity,
        setCkycInstitutionCode,
        setCkycPassword,
        setCkycUserId,
        setCkycUserName,
        setClientCode,
        setClientMasterMakerState,
        setCountry,
        setDomicile,
        setKraName,
        setKraPassword,
        setKraPosCode,
        setKraUserId,
        setKraUserName,
        setLandlineNumber,
        setLegalEntityIdentificationCode,
        setLegalEntityIdentificationCodeValidity,
        setLogoFile,
        setLogoFileFormat,
        setLogoFileS3Key,
        setLogoFileS3SignedURL,
        setLogoFileSize,
        setName,
        setPermanentAccountNumber,
        setPin,
        setState,
        setTaxIdentificationNumber,
        setClientType
    } = clientMasterDetailsFormDispatchActionsProvider();

    const fetchClientCodes = useFetchClientCodes();
    const fetchClientMaster = useFetchClientMaster();
    const postClientMaster = usePostClientMaster();
    const generateClientCode = useGenerateClientCode();

    const handleClearState = () => {
        const formRefKeys = Object.keys(formRef);

        formRefKeys.map((formRefKey) => {
            const fieldRef = formRef[formRefKey as Field];

            if (fieldRef && fieldRef.current)
                fieldRef.current.value = "";
        });

        setFormErrorState(initializeFormErrorState());
        clearState();
    };

    const handleInputFieldChange = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];
        
        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);
        }
    };

    const handleFieldErrorChange = (
        fieldValue: FieldValidation,
        field: Field
    ) => {
        setFormErrorState({
            ...formErrorState,
            [field]: fieldValue,
        });
    };

    const handleFormSubmit = () => {
        postClientMaster(clientMasterFormState, `${firstName} ${lastName}`, (updateExistingFlag), userId, "M", isUpdate)
            .then(() => setAlertSnackbarContext({
                "description": `Maker Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "Maker Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `Maker Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    const handleonChange = (
        field: Field,
        value: string,
        dispatchFunction: any,
    ) => {
        dispatchFunction(value);

        if (updateExistingFlag === "1") {
            if (clientMasterState[field as UpdateField] === value) {
                setIsUpdate({
                    ...isUpdate,
                    [field]: false
                });
            }
            else {
                setIsUpdate({
                    ...isUpdate,
                    [field]: true
                });
            }
        }
    };

    const handleInputFieldOnsubmit = (
        field: Field,
        dispatchFunction: any,
    ) => {
        const fieldRef = formRef[field];

        if (fieldRef && fieldRef.current) {
            const fieldValue = fieldRef.current.value;
            dispatchFunction(fieldValue);

            if (updateExistingFlag === "1") {
                if (clientMasterState[field as UpdateField] === fieldValue) {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: false
                    });
                }
                else {
                    setIsUpdate({
                        ...isUpdate,
                        [field]: true
                    });
                }
            }
        };
    };

    const handleFetchClientCodes = () => {
        fetchClientCodes("client_master", "1")
            .then((result) => setClientCodes(result));
    };

    const handleFetchClientMaster = (_clientCode: string) => {
        fetchClientMaster(_clientCode, "1", userId)
            .then((clientMaster) => {
                const {
                    "clientMasterState": clientMasterData,
                } = clientMaster;
                setClientMasterState(clientMasterData);
                setClientMasterMakerState(clientMasterData);
                setFormErrorState(initializeFormErrorState);
                
                (formRef["address1"].current as HTMLInputElement).value = clientMasterData.address1;
                (formRef["address2"].current as HTMLInputElement).value = clientMasterData.address2;
                (formRef["address3"].current as HTMLInputElement).value = clientMasterData.address3;
                (formRef["city"].current as HTMLInputElement).value = clientMasterData.city;
                (formRef["country"].current as HTMLInputElement).value = clientMasterData.country;
                (formRef["landlineNumber"].current as HTMLInputElement).value = clientMasterData.landlineNumber;
                (formRef["name"].current as HTMLInputElement).value = clientMasterData.name;
                (formRef["pin"].current as HTMLInputElement).value = clientMasterData.pin;
                (formRef["state"].current as HTMLInputElement).value = clientMasterData.state;
                (formRef["permanentAccountNumber"].current as HTMLInputElement).value = clientMasterData.permanentAccountNumber;
                (formRef["taxIdentificationNumber"].current as HTMLInputElement).value = clientMasterData.taxIdentificationNumber;

                if (domicile === "India")
                {                
                    (formRef["ckycInstitutionCode"].current as HTMLInputElement).value = clientMasterData.ckycInstitutionCode;
                    (formRef["ckycUserId"].current as HTMLInputElement).value = clientMasterData.ckycUserId;
                    (formRef["ckycUserName"].current as HTMLInputElement).value = clientMasterData.ckycUserName;
                    (formRef["ckycPassword"].current as HTMLInputElement).value = clientMasterData.ckycPassword;    
                    (formRef["kraPassword"].current as HTMLInputElement).value = clientMasterData.kraPassword;
                    (formRef["kraPosCode"].current as HTMLInputElement).value = clientMasterData.kraPosCode;
                    (formRef["kraUserId"].current as HTMLInputElement).value = clientMasterData.kraUserId;
                    (formRef["kraUserName"].current as HTMLInputElement).value = clientMasterData.kraUserName;
                }
            });
    };

    const handleUploadFileAndSubmitForm = async () => {
        dispatch(setOpenBackdrop(true));
        const putS3ObjectAxiosConfig = {
            "data": logoFile,
            "headers": { 
                "Content-Type": "application/octet-stream",
            },
            "method": "put",
            "url": logoFileS3SignedURL,
        };

        await axios(putS3ObjectAxiosConfig)
            .then(() => {
                handleFormSubmit();
            })
            .catch((error) => {
                dispatch(setOpenBackdrop(false));
                setAlertSnackbarContext({
                    "description": `Maker Entry Failer Client Code ${clientCode}`,
                    "open": true,
                    "severity": "error",
                    "title": "Maker Entry Failed",
                });
            });
    };

    useEffect(() => {
        setClientMasterMakerState(initialClientMasterDetailsFormState);
        if (updateExistingFlag === "0")
            generateClientCode()
                .then((result) => {
                    setClientCode(result);
                });
    }, []);

    const handleAddNew = () => {
        clearState();
        setUpdateExistingFlag("0");
        generateClientCode()
            .then((result) => {
                setClientCode(result);
            });
    };
    
    return (
        <>
            <Grid container rowSpacing={2} columnSpacing={2}>
                <Grid item xs={12}>
                    <Grid 
                        alignItems="center"
                        display="flex"
                        justifyContent="space-between"
                    >
                        
                        <Typography variant="formHeading" display="flex">
                            {
                                (updateExistingFlag === "0")
                                    ? "Add Client Master"
                                    : "Update Client Master"
                            }
                        </Typography>
                        
                        <Stack direction="row" spacing={2}>
                            <FXButton
                                buttonVariant="flowaction"
                                label="Add New"
                                disabled={(updateExistingFlag === "0")}
                                startIcon={<AddIcon/>}
                                onClick={() => {
                                    handleClearState();
                                    setUpdateExistingFlag("0");
                                    handleAddNew();
                                }}
                            />

                            <FXButton
                                buttonVariant="flowaction"
                                label="Update Existing"
                                disabled={(updateExistingFlag === "1")}                                
                                startIcon={<EditIcon/>}
                                onClick={() => {
                                    handleFetchClientCodes();
                                    setUpdateExistingFlag("1");
                                    handleClearState();
                                }}
                            />
                        </Stack>
                    </Grid>
                </Grid>

                <Grid item xs={3}>
                    {
                        (updateExistingFlag === "0")
                            ? <FXInput
                                label="Client Code"
                                required
                                readOnly
                                disabled
                                value={clientCode}
                            />
                            : <FXSelectInput
                                label="Client Code"
                                required
                                value={clientCode}
                                menuItems={clientCodes}
                                onValueChange={handleFetchClientMaster}
                            />
                    }
                </Grid>

                <Grid item xs={6}>
                    <FXInput
                        label="Name"
                        autoFocus
                        required
                        capitalizeFirstLetter
                        forbidTo="singleSpace"
                        maxLength={256}
                        inputRef={formRef.name}
                        onBlur={() => handleInputFieldOnsubmit("name", setName)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "name")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "name")}
                        error={formErrorState.name.isError}
                        helperText={formErrorState.name.helperText}
                    />   
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Domicile"
                        required
                        value={domicile}
                        onValueChange={(value) => { 
                            handleonChange("domicile", value, setDomicile);
                            if (value === "India") {
                                (formRef["taxIdentificationNumber"].current as HTMLInputElement).value = "";
                                handleInputFieldOnsubmit("taxIdentificationNumber", setTaxIdentificationNumber);
                            }
                            else
                            {
                                (formRef["permanentAccountNumber"].current as HTMLInputElement).value = "";
                                handleInputFieldOnsubmit("permanentAccountNumber", setPermanentAccountNumber);
                            }
                            setFormErrorState({
                                ...formErrorState,
                                "ckycInstitutionCode": initializeFieldValidation(),
                                "ckycPassword": initializeFieldValidation(),
                                "ckycUserId": initializeFieldValidation(),
                                "ckycUserName": initializeFieldValidation(),
                                "kraPassword": initializeFieldValidation(),
                                "kraPosCode": initializeFieldValidation(),
                                "kraUserId": initializeFieldValidation(),
                                "kraUserName": initializeFieldValidation(),
                                "permanentAccountNumber": initializeFieldValidation(),
                                "pin": initializeFieldValidation(),
                                "taxIdentificationNumber": initializeFieldValidation(),
                            });
                        }}
                        menuItems={countryNameMenuItems}
                    />
                </Grid>
            
                <Grid item xs={3}>
                    <FXInput
                        label="Permanent Account Number"
                        required = { domicile === "India" }
                        disabled = { domicile !== "India" }
                        maxLength={10}
                        autoCapitalize
                        inputRef={formRef.permanentAccountNumber}
                        onBlur={() => handleInputFieldOnsubmit("permanentAccountNumber", setPermanentAccountNumber)}
                        onBlurValidator={onBlurPanValidator}
                        validatorOptions={{}}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "permanentAccountNumber")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "permanentAccountNumber")}
                        error={formErrorState.permanentAccountNumber.isError}
                        helperText={formErrorState.permanentAccountNumber.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Tax Identification Number"
                        required = { domicile != "India" }
                        disabled = { domicile === "India" }
                        forbidTo="alphanumeric"
                        autoCapitalize
                        maxLength={25}
                        inputRef={formRef.taxIdentificationNumber}
                        onBlur={() => handleInputFieldOnsubmit("taxIdentificationNumber", setTaxIdentificationNumber)}
                        onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "taxIdentificationNumber")}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "taxIdentificationNumber")}
                        error={formErrorState.taxIdentificationNumber.isError}
                        helperText={formErrorState.taxIdentificationNumber.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXSelectInput
                        label="Type"
                        value={clientType}
                        onValueChange={(value) => {
                            handleonChange("clientType", value, setClientType);
                        }}
                        menuItems={clientTypeMenuItems}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 1"
                        required
                        maxLength={256}
                        inputRef={formRef.address1}
                        onBlur={() => handleInputFieldOnsubmit("address1", setAddress1)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "address1")}
                        error={formErrorState.address1.isError}
                        helperText={formErrorState.address1.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 2"
                        maxLength={256}
                        inputRef={formRef.address2}
                        onBlur={() => handleInputFieldOnsubmit("address2", setAddress2)}
                        error={formErrorState.address2.isError}
                        helperText={formErrorState.address2.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Address 3"
                        maxLength={256}
                        inputRef={formRef.address3}
                        onBlur={() => handleInputFieldOnsubmit("address3", setAddress3)}
                        error={formErrorState.address3.isError}
                        helperText={formErrorState.address3.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="PIN"
                        required = { domicile === "India" }
                        forbidTo="alphanumeric"
                        autoCapitalize
                        inputRef={formRef.pin}
                        onBlur={() => handleInputFieldOnsubmit("pin", setPin)}
                        onBlurValidator={onBlurPincodeValidator}
                        validatorOptions={{ "domicile": domicile }}
                        error={formErrorState.pin.isError}
                        helperText={formErrorState.pin.helperText}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "pin")}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="City"
                        required
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.city}
                        onBlur={() => handleInputFieldOnsubmit("city", setCity)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "city")}
                        error={formErrorState.city.isError}
                        helperText={formErrorState.city.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="State"
                        required
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.state}
                        onBlur={() => handleInputFieldOnsubmit("state", setState)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "state")}
                        error={formErrorState.state.isError}
                        helperText={formErrorState.state.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Country"
                        required
                        forbidTo="letters"
                        maxLength={256}
                        inputRef={formRef.country}
                        onBlur={() => handleInputFieldOnsubmit("country", setCountry)}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "country")}
                        error={formErrorState.country.isError}
                        helperText={formErrorState.country.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXInput
                        label="Landline Number"
                        forbidTo="numbers"
                        maxLength={20}
                        inputRef={formRef.landlineNumber}
                        onBlur={() => handleInputFieldOnsubmit("landlineNumber", setLandlineNumber)}
                        onBlurValidator={onBlurContactNumberValidator}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "landlineNumber") }
                        error={formErrorState.landlineNumber.isError}
                        helperText={formErrorState.landlineNumber.helperText}
                        validatorOptions={{}}
                    />
                </Grid>

                <Grid item xs={3}>
                    <FXDateInput
                        label="Agreement Date"
                        required
                        value={agreementDate}
                        disableFuture
                        onValueChange={(value) => {
                            handleonChange("agreementDate", value, setAgreementDate);
                            handleFieldErrorChange(initializeFieldValidation(), "agreementDate");
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            "disableFuture": true, 
                            "disablePast": false, 
                            "disablePresent": false 
                        }}                        
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "agreementDate")}
                        error={formErrorState.agreementDate.isError}
                        helperText={formErrorState.agreementDate.helperText}
                    />
                </Grid>

                <Grid item xs={3}>
                    { 
                        (updateExistingFlag === "0")
                            ? <FXInput
                                label="Legal Entity Identification Code"
                                required
                                maxLength={20}
                                forbidTo="alphanumeric"
                                autoCapitalize
                                inputRef={formRef.legalEntityIdentificationCode}
                                onBlur={() => handleInputFieldChange("legalEntityIdentificationCode", setLegalEntityIdentificationCode)}
                                onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "legalEntityIdentificationCode")}
                                onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "legalEntityIdentificationCode")}
                                error={formErrorState.legalEntityIdentificationCode.isError}
                                helperText={formErrorState.legalEntityIdentificationCode.helperText}
                            />
                            : <FXInput
                                label="Legal Entity Identification Code"
                                required
                                readOnly
                                disabled
                                value={legalEntityIdentificationCode}
                            />
                    }
                </Grid>

                <Grid item xs={5}>
                    <FXDateInput
                        label="Legal Entity Identification Code Validity"
                        required
                        disablePast
                        shouldDisableDate={(date) => 
                            date.isSame(dayjs(), "day")
                        }
                        value={legalEntityIdentificationCodeValidity}
                        onValueChange={(value) => {
                            handleonChange("legalEntityIdentificationCodeValidity", value, setLegalEntityIdentificationCodeValidity);
                            handleFieldErrorChange(initializeFieldValidation(), "legalEntityIdentificationCodeValidity");
                        }}
                        onBlurValidator={onBlurDateValidator}
                        validatorOptions={{
                            
                            "disableFuture": false, 
                            "disablePast": true, 
                            "disablePresent": true 
                        }}
                        onFieldValidationChange={(fieldError) => handleFieldErrorChange(fieldError, "legalEntityIdentificationCodeValidity")}
                        error={formErrorState.legalEntityIdentificationCodeValidity.isError}
                        helperText={formErrorState.legalEntityIdentificationCodeValidity.helperText}
                    />
                </Grid>

                <Grid item xs={4}>
                    <FXFileInput
                        label="Logo"
                        value={(logoFile === null) ? "" : undefined}
                        accept={[".jpeg", ".jpg", ".png", ".svg"]}
                        documentType="CMPNYLOGO"
                        assetType="Client Assets"
                        identifier={
                            (clientCode !== "") 
                                ? `CLIENT_CODE_${clientCode}`
                                : ""
                        }
                        onFileUpload={(fileDetails) => {
                            setLogoFile(fileDetails.file);
                            setLogoFileSize(fileDetails.dimensions);
                        }}
                        onS3PresignedUrlFetch={(format, s3Key, s3Url) => {
                            setLogoFileS3Key(s3Key);
                            setLogoFileS3SignedURL(s3Url);
                            setLogoFileFormat(format);
                        }}
                        onRemoveFile={() => {
                            setFormErrorState({
                                ...formErrorState,
                                "logo": initializeFieldValidation(),
                            });
                            setLogoFile(null);
                            setLogoFileS3Key("");
                            setLogoFileS3SignedURL("");
                            setLogoFileFormat("");
                            setLogoFileSize("");
                        }}
                        onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "logo")}
                        error={formErrorState.logo.isError}
                        helperText={formErrorState.logo.helperText}
                    />
                </Grid>

                {
                    domicile === "India" &&
                <>
                    <Grid item xs={12}>
                        <Typography variant="formSubHeading" display="flex">
                            KRA & CERSAI Details
                        </Typography>
                    </Grid>

                    <Grid item xs={3}>
                        <FXSelectInput
                            label="KRA Name"
                            value={kraName}
                            onValueChange={(value) =>
                                handleonChange("kraName", value, setKraName) 
                            }
                            menuItems={kraNameMenuItems}
                        />
                    </Grid>

                    <Grid item xs={9}>
                        <></>
                    </Grid>
                
                    <Grid item xs={3}>
                        <FXInput
                            label="KRA User ID"
                            forbidTo="user-id"
                            maxLength={20}
                            inputRef={formRef.kraUserId}
                            onBlur={() => handleInputFieldOnsubmit("kraUserId", setKraUserId)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraUserId")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraUserId")}
                            error={formErrorState.kraUserId.isError}
                            helperText={formErrorState.kraUserId.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA User Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={20}
                            inputRef={formRef.kraUserName}
                            onBlur={() => handleInputFieldOnsubmit("kraUserName", setKraUserName)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraUserName")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraUserName")}
                            error={formErrorState.kraUserName.isError}
                            helperText={formErrorState.kraUserName.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA Password"
                            maxLength={20}
                            inputRef={formRef.kraPassword}
                            onBlur={() => handleInputFieldOnsubmit("kraPassword", setKraPassword)}
                            onBlurValidator={onBlurPasswordValidator}
                            validatorOptions={{}}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraPassword")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraPassword")}
                            error={formErrorState.kraPassword.isError}
                            helperText={formErrorState.kraPassword.helperText}
                            type={showKraPassword ? "string" : "password"}
                            endAdornment={
                                <IconButton
                                    disableRipple
                                    onMouseDown={() => setShowKraPassword(true)}
                                    onMouseUp={() => setShowKraPassword(false)}
                                >
                                    {
                                        (showKraPassword)
                                            ? <VisibilityIcon/>
                                            : <VisibilityOffIcon/>
                                    }
                                </IconButton>
                            }
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="KRA POS Code"
                            forbidTo="numbers"
                            maxLength={15}
                            inputRef={formRef.kraPosCode}
                            onBlur={() => handleInputFieldOnsubmit("kraPosCode", setKraPosCode)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "kraPosCode")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "kraPosCode")}
                            error={formErrorState.kraPosCode.isError}
                            helperText={formErrorState.kraPosCode.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC User ID"
                            forbidTo="user-id"
                            maxLength={20}
                            inputRef={formRef.ckycUserId}
                            onBlur={() => handleInputFieldOnsubmit("ckycUserId", setCkycUserId)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycUserId")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycUserId")}
                            error={formErrorState.ckycUserId.isError}
                            helperText={formErrorState.ckycUserId.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC User Name"
                            forbidTo="namespaceapostrophe"
                            maxLength={20}
                            inputRef={formRef.ckycUserName}
                            onBlur={() => handleInputFieldOnsubmit("ckycUserName", setCkycUserName)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycUserName")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycUserName")}
                            error={formErrorState.ckycUserName.isError}
                            helperText={formErrorState.ckycUserName.helperText}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC Password"
                            maxLength={20}
                            inputRef={formRef.ckycPassword}
                            onBlur={() => handleInputFieldOnsubmit("ckycPassword", setCkycPassword)}
                            onBlurValidator={onBlurPasswordValidator}
                            validatorOptions={{}}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycPassword")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycPassword")}
                            error={formErrorState.ckycPassword.isError}
                            helperText={formErrorState.ckycPassword.helperText}
                            type={showCkycPassword ? "string" : "password"}
                            endAdornment={
                                <IconButton
                                    disableRipple
                                    onMouseDown={() => setShowCkycPassword(true)}
                                    onMouseUp={() => setShowCkycPassword(false)}
                                >
                                    {
                                        (showCkycPassword)
                                            ? <VisibilityIcon/>
                                            : <VisibilityOffIcon/>
                                    }
                                </IconButton>
                            }
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <FXInput
                            label="CKYC Institution Code"
                            forbidTo="alphanumeric"
                            autoCapitalize
                            maxLength={10}
                            inputRef={formRef.ckycInstitutionCode}
                            onBlur={() => handleInputFieldOnsubmit("ckycInstitutionCode", setCkycInstitutionCode)}
                            onValueChange={() => handleFieldErrorChange(initializeFieldValidation(), "ckycInstitutionCode")}
                            onFieldErrorChange={(fieldError) => handleFieldErrorChange(fieldError, "ckycInstitutionCode")}
                            error={formErrorState.ckycInstitutionCode.isError}
                            helperText={formErrorState.ckycInstitutionCode.helperText}
                        />
                    </Grid>
                </>
                }

                <Grid item xs={6}>
                    <FXButton 
                        disableRipple
                        label="Clear" 
                        buttonVariant="normal" 
                        fullWidth
                        onClick={handleClearState}
                    />
                </Grid>

                <Grid item xs={6}>
                    <FXButton
                        buttonVariant="submit"
                        disableRipple
                        disabled={
                            alertSnackbarContext.open ||
                            !(isFormComplete(clientMasterFormState)) ||
                            !(isFormValid(formErrorState)) ||
                            isFormUpdated(isUpdate, updateExistingFlag)
                        }
                        endIcon={<ArrowForwardIosIcon/>}
                        fullWidth
                        label="Submit to Checker"                       
                        onClick={() => {
                            logoFileS3SignedURL === ""
                                ? handleFormSubmit()
                                : handleUploadFileAndSubmitForm();
                        }}
                    />
                </Grid>
            </Grid>

            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success"){
                        handleClearState();
                        setClientCode("");
                        setUpdateExistingFlag("1");
                        handleFetchClientCodes();
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default MakerClientMasterForm;
