import {
    ClientMasterDetails as CheckerClientMasterDetails
} from "../../../../../../redux/AifMaster/ClientMaster/Checker/initialState";
import {
    ClientMasterDetails as MakerClientMasterDetails
} from "../../../../../../redux/AifMaster/ClientMaster/Maker/initialState";
import { NigoData } from "../../../../../../interfaces/NigoData.types";

export function getNigoData(makerFormState: MakerClientMasterDetails, checkerFormState: CheckerClientMasterDetails): NigoData[] {
    const nigoData: NigoData[] = [];
    let id = 1;

    for (const key in makerFormState) {
        if (key === "logoFile" || key === "logoFileS3Key" || key === "logoFileS3SignedURL" || key === "logoFileFormat" || key === "logoFileSize") 
            continue;

        if (makerFormState.hasOwnProperty(key) && checkerFormState.hasOwnProperty(key)) {
            const field = key as keyof MakerClientMasterDetails;
            if (makerFormState[field] !== checkerFormState[field]) {
                const nigo: NigoData = {
                    "checkerEntry": checkerFormState[field] as string,
                    "dataStatus": false,
                    "field": key,
                    "id": id,
                    "makerEntry": makerFormState[field] as string,
                };
                nigoData.push(nigo);
                id++;
            }
        }
    }

    return nigoData;
}
