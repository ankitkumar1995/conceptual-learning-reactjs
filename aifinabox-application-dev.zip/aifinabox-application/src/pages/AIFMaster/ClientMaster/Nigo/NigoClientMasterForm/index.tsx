import {
    AlertSnackbarContext,
    initialAlertSnackbarContext
} from "../../../../../interfaces/AlertSnackbarContext.types";
import initializeUpdateState, { UpdateState } from "./helpers/initializeUpdateState";

import FXAlertSnackbar from "../../../../../components/FXAlertSnackbar";
import NigoTable from "../../../components/NigoTable";
import { RootState } from "../../../../../redux/store";
import clientMasterDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Checker/dispatchActionsProvider";
import clientMasterNigoDetailsFormDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/Nigo/dispatchActionsProvider";
import clientMasterPageContextDispatchActionsProvider from "../../../../../redux/AifMaster/ClientMaster/PageContext/dispatchActionsProvider";
import { useNavigate } from "react-router-dom";
import usePostClientMaster from "../../../../../hooks/api/usePostClientMaster";
import { useSelector } from "react-redux";
import { useState } from "react";

const NigoClientMasterForm = () => {
    const [alertSnackbarContext, setAlertSnackbarContext] = useState<AlertSnackbarContext>(initialAlertSnackbarContext());
    const [isUpdate, setIsUpdate] = useState<UpdateState>(initializeUpdateState);
    const navigate = useNavigate();

    const checkerClientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .checkerForm
    );
    
    const nigoClientMasterFormState = useSelector(
        (state: RootState) =>
            state
                .aifMasterState
                .clientMasterState
                .nigoForm
    );

    const userId = useSelector(
        (state: RootState) =>
            state
                .authenticationState
                .userId
    );

    const userContextState = useSelector(
        (state: RootState) =>
            state
                .userContextState
    );

    const { firstName, lastName } = userContextState;

    const { clientCode } = checkerClientMasterFormState;

    const { 
        checkerData, 
        makerData, 
        nigoMetaData
    } = nigoClientMasterFormState;

    const { 
        "clearState": clearNigoState,
        setCheckerData, 
        setMakerData, 
        setNigoMetaData 
    } = clientMasterNigoDetailsFormDispatchActionsProvider();

    const { "clearState": clearCheckerState }  = clientMasterDetailsFormDispatchActionsProvider();

    const {
        setNigoRaised,
    } = clientMasterPageContextDispatchActionsProvider();

    const postClientMaster = usePostClientMaster();

    const handleFormSubmit = () => {
        let modifiedCheckerData = checkerData;
        let modifiedMakerData = makerData;

        nigoMetaData.forEach((data) => {
            const fieldName = data.field;
            const checkerValue = data.checkerEntry;
            const makerValue = data.makerEntry;

            modifiedCheckerData = {
                ...modifiedCheckerData,
                [fieldName]: checkerValue,
                "logoFileFormat": makerData.logoFileFormat,
                "logoFileS3Key": makerData.logoFileS3Key,
                "logoFileSize": makerData.logoFileSize,
            };
            modifiedMakerData = {
                ...modifiedMakerData,
                [fieldName]: makerValue,
            };
        });

        setCheckerData(modifiedCheckerData);
        setMakerData(modifiedMakerData);

        postClientMaster(modifiedCheckerData, `${firstName} ${lastName}`, "0", userId, "C", isUpdate)
            .then(() => setAlertSnackbarContext({
                "description": `NIGO Entry Done against Client Code ${clientCode}`,
                "open": true,
                "severity": "success",
                "title": "NIGO Entry Success",
            }))
            .catch((error) => {
                console.error(error);
                setAlertSnackbarContext({
                    "description": `NIGO Entry Failure against
                                    Client Code: ${clientCode}
                                    Error Message: ${(JSON.parse(error.response.data.message).map((msg: { error: string; })=>"•"+" "+msg.error) )}`,
                    "open": true,
                    "severity": "error",
                    "title": "NIGO Entry Failed",
                });
            });
    };

    return (
        <>
            <NigoTable
                disableSubmit={alertSnackbarContext.open}
                nigoData={nigoMetaData}
                onDataChange={(nigoData) => {
                    setNigoMetaData(nigoData);
                }}
                onSubmitClicked={handleFormSubmit}
            />
            
            <FXAlertSnackbar
                open={alertSnackbarContext.open}
                alertTitle={alertSnackbarContext.title}
                alertDescription={alertSnackbarContext.description}
                severity={alertSnackbarContext.severity}
                onClose={() => {
                    if (alertSnackbarContext.severity === "success") {
                        clearCheckerState();
                        clearNigoState();
                        setNigoRaised(false);
                    }
                    
                    setAlertSnackbarContext(initialAlertSnackbarContext());
                }}
            />
        </>
    );
};

export default NigoClientMasterForm;
