import { UpdateField } from "../../../../Maker/MakerClientMasterForm/interfaces/field.types";

export type UpdateState = { 
    [fieldName in UpdateField]: boolean
};

function initializeUpdateState(): UpdateState {
    return (
        {
            "address1": false,
            "address2": false,
            "address3": false,
            "agreementDate": false,
            "city": false,
            "ckycInstitutionCode": false,
            "ckycPassword": false,
            "ckycUserId": false,
            "ckycUserName": false,
            "clientType": false,
            "country": false,
            "domicile": false,
            "kraName": false,
            "kraPassword": false,
            "kraPosCode": false,
            "kraUserId": false,
            "kraUserName": false,
            "landlineNumber": false,
            "legalEntityIdentificationCodeValidity": false,
            "name": false,
            "permanentAccountNumber": false,
            "pin": false,
            "state": false,
            "taxIdentificationNumber": false,
        }
    );
}

export default initializeUpdateState;
