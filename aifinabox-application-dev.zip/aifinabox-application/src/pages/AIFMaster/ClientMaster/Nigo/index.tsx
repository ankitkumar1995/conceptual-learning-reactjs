import NigoClientMasterForm from "./NigoClientMasterForm";

const NigoClientMasterPage = () => {
    return (
        <>
            <NigoClientMasterForm/>
        </>
    );
};

export default NigoClientMasterPage;

