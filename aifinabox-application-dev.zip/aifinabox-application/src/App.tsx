import "./fonts";
import "./init";
import FXBackdrop from "./components/FXBackdrop";
import MultipleFileInputPopup from "./pages/InitiateTransaction/components/MultipleFileInputPopup";
import { RootState } from "./redux/store";
import Routes from "./routes";
import useFetchCountries from "./hooks/api/useFetchCountries";
import useFetchStandardDictionary from "./hooks/api/useFetchStandardDictionary";
import { useSelector } from "react-redux";
// eslint-disable-next-line sort-imports
import {
    RefObject,
    createRef,
    useState
} from "react";
import FXButton from "./components/FXButton";

function App() {
    useFetchCountries();
    useFetchStandardDictionary();
    
    const applicationContextState = useSelector(
        (state: RootState) =>
            state
                .applicationContextState
    );

    const inputRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>();
    const [files, setFiles] = useState<File[]>([]);

    const handleOnFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            const file = event.target.files[0];
            setFiles([ file ]);
        }
    };

    const { openBackdrop } = applicationContextState;

    return (
        <>
            <Routes/> 
            {/* <FileUploadAccept open onFileUpload={function (fileDetails: FileDetails): void {
                throw new Error("Function not implemented.");
            } } /> */}
            <FXBackdrop open={openBackdrop}/> 
            {/* <FXBackdrop open={openBackdrop}/>

            <MultipleFileInputPopup
                files={files}
                onFilesChange={(updatedFiles) => setFiles(updatedFiles)}
                onProceedButtonClick={() => {}}
                open={(files.length > 0)}
            />

            <FXButton
                label="Add Source File"
                buttonVariant="submit"
                onClick={() => inputRef.current?.click()}
            />

            <input
                type="file"
                data-testid="input-testid"
                ref={inputRef}
                onClick={() => {
                    if (inputRef.current !== null) 
                        inputRef.current.value = '';
                }}
                onChange={(event) => {
                    handleOnFileChange(event);
                }}
                hidden
            /> */}
        </>
    );
}

export default App;
