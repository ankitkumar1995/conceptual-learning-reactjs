function Product() {
  return <div> This is product Component</div>;
}

export default Product;
