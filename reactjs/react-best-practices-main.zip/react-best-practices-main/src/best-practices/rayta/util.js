export const fetchData = () => {};
