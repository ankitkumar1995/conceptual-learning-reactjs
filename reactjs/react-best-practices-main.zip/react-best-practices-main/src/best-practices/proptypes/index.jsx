function PropTypes({ name, age, hobbies, socialAccounts, address }) {
  return (
    <div className="card green">
      <h1>🎊 Prop types</h1>
    </div>
  );
}

export default PropTypes;
